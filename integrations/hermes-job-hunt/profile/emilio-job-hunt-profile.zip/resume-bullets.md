# Emilio Nunez-Garcia — Resume Bullet Bank

## Purpose

Reusable accomplishment bullets future agents can adapt for resumes and applications. Preserve Emilio's unusual combination: media/adtech operator plus hands-on AI builder.

## Usage rules

- Do not invent numbers.
- Preserve specificity: Audacy Denver, SEM, paid social, programmatic, CTV/OTT, Amazon DSP, streaming audio, GCP, LLM systems, agent workflows, and AI search/GEO.
- Tailor by role type rather than pasting the full stack into every resume.
- Keep bullets achievement-oriented and start every bullet with a strong verb.
- Use quantified bullets only where metrics are known.
- Mark uncertain metrics as `[metric needed]` or `needs Emilio confirmation`.
- Do not make Emilio sound like a pure software engineer unless the role requires technical-adjacent framing.
- Avoid secrets, API keys, private account details, phone/email, and sensitive personal data.

## Executive summary bullets

- Bridge 10+ years of performance marketing, digital media sales leadership, and hands-on AI product building across paid acquisition, client strategy, and workflow automation.
- Led Audacy Denver digital strategy across SEM, paid social, programmatic display, CTV/OTT, Amazon DSP, streaming audio, attribution, and KPI design for local and regional advertisers.
- Owned a $10M+ annual digital media P&L and helped drive Denver to a consistent top-3 national Digital Marketing Solutions revenue ranking across Audacy's footprint.
- Translate business goals into channel strategy, KPI architecture, media execution, and client-ready reporting across CAC, ROAS, LTV, payback, and booked-revenue outcomes.
- Built AI/adtech systems including Elio Intelligence Suite, JobBored, Hormiga Dormida, Hermes workflows, GCP Cloud Run deployments, multi-model LLM routing, RAG pipelines, and prompt-engineered automation.
- Advise clients and internal teams on AI-search disruption, GEO/AIO readiness, attribution, bidding strategy, and future-facing marketing strategy.
- Combine client-facing revenue leadership with enough technical depth to prototype, deploy, and explain AI workflows in practical business terms.
- Communicate fluently across executive stakeholders, sellers, campaign managers, technical partners, and clients; bilingual English/Spanish with additional French and Italian proficiency.

## Audacy / media sales leadership bullets

- Owned a $10M+ annual digital media P&L for Audacy Denver, reallocating spend across Google Ads, Meta, OTT/CTV, programmatic, and streaming audio toward marginal ROAS.
- Drove Denver to a consistent top-3 ranking in Digital Marketing Solutions revenue across Audacy's national footprint while operating in a #19 U.S. market.
- Led the market's transformation from broadcast-dominant to approximately 60% digital revenue mix by building the playbook, pitch system, and seller training motion.
- Coached 10 AE desks and ran 20+ tracked pitches per month through Advisr, improving digital strategy quality and seller confidence.
- Managed a rotating team of up to three Digital Campaign Managers plus internal media specialists, creative and agency partners, and platform vendors.
- Built cross-platform proposals integrating broadcast audio, streaming audio, OTT/CTV, programmatic display, SEM, paid social, and local-market client strategy.
- Retained and grew strategic Denver accounts as the digital SME for SEM, paid social, OTT/CTV, streaming audio, and programmatic strategy.
- Led QBRs, mid-year reviews, attribution disputes, retention conversations, and high-stakes client pitches across home services, financial services, healthcare, dental, hospitality, retail, and automotive.
- Created and led enablement series including Digital Cafe and Happy Half-Hour on bidding strategy, attribution modeling, creative testing, and platform-algorithm shifts.
- Promoted from Digital Campaign Manager to Key Account Manager / Senior Key Account Manager and then Digital Sales Manager on the strength of account retention and digital revenue growth.

## Performance marketing bullets

- Architected advanced bidding and attribution frameworks across Google Ads Search, YouTube, PMax, Meta Ads, Amazon DSP, and programmatic display.
- Delivered 130% YoY paid-search conversion growth and 13% YoY new-user lift on a flagship financial-services account through bidding overhaul, audience-signal layering, and landing-page CRO.
- Optimized paid media portfolios across CAC, ROAS, LTV, payback period, contribution margin, lead volume, and booked-revenue KPIs.
- Built reporting dashboards and pacing systems used across the Denver market for client performance reviews.
- Translated advertiser goals into media mix, budget allocation, attribution approach, and optimization plan across SEM, paid social, programmatic, OTT/CTV, and streaming audio.
- Applied advanced bidding strategies including tCPA, tROAS, Max Conversions, manual CPC, audience-signal layering, geo-modifier strategy, dayparting, and portfolio bid strategies.
- Advised clients on measurement strategy across GA4, GTM, Looker Studio, CallRail, ServiceTitan, CRM-back attribution, conversion API, and incrementality concepts.
- Developed AI-search and GEO/AIO readiness guidance covering AI Overviews, hub-and-spoke content architecture, entity SEO, structured data, and LLM-citation strategy.
- Built and optimized SEM and WordPress content programs across 8 states for mortgage and real-estate partners at Primary Residential Mortgage Inc.
- Cofounded Bucketz, automating focus-group recruitment for market-research firms via paid social and paid search.

## AI product / agent workflow bullets

- Designed, built, and deployed Elio Intelligence Suite, a production multi-model AI platform on GCP Cloud Run for campaign forecasting, client briefings, and reporting workflows.
- Routed AI workflows across Claude, GPT, Gemini, Grok, and Llama based on task fit, latency, and cost.
- Built Vertex AI Search RAG pipelines and Google Chirp 3 HD text-to-speech into client-facing and workflow automation systems.
- Shipped an SEM Revenue Forecast tool using Gemini with live Google Search grounding; ran 21+ forecasts against $2.4M of real pipeline data for pitch cycles.
- Stood up agentic scheduled workflows for client-pulse briefings, daily job-board scans, Telegram delivery, resume tailoring, and reporting automation.
- Built JobBored as an AI-assisted job-search product with a React dashboard, Hermes agent, scheduled job-board scans, resume tailoring, and Telegram notifications.
- Built Hormiga Dormida as an automated AI agency concept delivering marketing and operations workflows to SMB clients on the Elio Intelligence Suite stack.
- Authored an 18-idea automation playbook spanning client intelligence, sales ops, content production, lead generation, and reporting.
- Built or maintained MCP/agent workflows and a Google Ads MCP server context for natural-language analysis of Google Ads data; public framing needs Emilio confirmation.
- Prototyped LaHormigaDormida as a Mac desktop ads-operator app for paid campaign management across Meta, Google, TikTok, and X with approvals, audit trails, monitoring, and messaging-based review; scope and market status need Emilio confirmation.

## Strategy / leadership bullets

- Translated executive client goals into channel strategy, KPI architecture, media execution, and reporting narratives that sellers and clients could act on.
- Led attribution and AI-search disruption conversations with clients, positioning Denver ahead of peer markets on AI Overviews, GEO/AIO readiness, and hub-and-spoke strategy.
- Built seller enablement systems that turned platform complexity into practical pitch language and repeatable market motion.
- Guided advertisers through complex performance questions including attribution disputes, budget reallocation, creative testing, and retention-risk conversations.
- Connected sales, campaign management, creative, agency, and vendor partners around shared client KPIs.
- Balanced strategic advisory with hands-on operating fluency across campaign setup, trafficking, optimization, reporting, forecasting, and client review cycles.

## Role-specific bullet variants

### AI Product Marketing roles

- Translate AI product capabilities into buyer-ready narratives grounded in real marketing workflows, client pain, and measurable revenue outcomes.
- Built and deployed AI systems for SEM forecasting, client briefings, reporting automation, and agentic workflow delivery, giving product marketing work a hands-on operator foundation.
- Connect technical AI concepts such as RAG, multi-model routing, prompt engineering, and agent workflows to GTM messaging that business buyers can understand.
- Led client-facing education on AI-search disruption, GEO/AIO readiness, attribution, and marketing strategy shifts.
- Combine founder-style product building with 10+ years of paid media and client advisory experience.

### Sales Engineering / Solutions Consulting roles

- Bridge executive business goals, marketing KPIs, platform capabilities, and technical implementation details in client-facing sales cycles.
- Led high-stakes pitches, QBRs, attribution reviews, and retention conversations across multiple advertiser verticals.
- Built AI and workflow prototypes on GCP, LLM APIs, RAG pipelines, and agent automation to demonstrate practical business value.
- Translate complex systems into clear client narratives, seller enablement, implementation plans, and success criteria.
- Advise buyers on how AI, adtech, attribution, and media execution connect to CAC, ROAS, LTV, payback, and booked revenue.

### Performance Marketing / Growth roles

- Owned paid media strategy across SEM, paid social, programmatic, OTT/CTV, Amazon DSP, streaming audio, retargeting, and native placements.
- Improved paid-search performance for a flagship financial-services account, delivering 130% YoY conversion growth and 13% YoY new-user lift.
- Built KPI frameworks and reporting systems for CAC, ROAS, LTV, payback, contribution margin, lead quality, and booked revenue.
- Reallocated budget across channels based on marginal ROAS, audience-signal quality, attribution, and funnel performance.
- Built forecasting and scenario-modeling workflows to support pitch cycles and budget allocation decisions.

### AdTech / MarTech roles

- Bring operator credibility across Google Ads, Meta, Amazon DSP, DV360, The Trade Desk, GA4, GTM, Looker Studio, CallRail, ServiceTitan, Advisr, Salesforce basics, and HubSpot basics.
- Advise advertisers on media mix, measurement, attribution, bidding strategy, AI search readiness, and platform adoption.
- Connect adtech capabilities to sales enablement, client retention, campaign performance, and revenue growth.
- Built AI/adtech workflows that automate forecasting, reporting, briefings, job discovery, and client intelligence.
- Understand the commercial realities of selling technology into marketers, media teams, agencies, and local/regional businesses.

### Digital Sales Director / Media Strategy roles

- Led Audacy Denver's digital sales strategy across a $10M+ annual digital media book and helped move the market toward approximately 60% digital revenue mix.
- Built seller training, pitch systems, and client strategy playbooks that supported digital revenue growth and account retention.
- Managed digital campaign, internal media, creative/agency, and vendor partners against client KPIs.
- Served as client-facing digital SME for strategic accounts across SEM, paid social, programmatic, OTT/CTV, and streaming audio.
- Positioned AI search, attribution, and performance marketing strategy as client advisory opportunities rather than back-office tactics.

## Metrics known

- 10+ years across paid acquisition, sales leadership, and AI product building. Source: resume.html.
- Eight years at Audacy / Entercom, Sep 2017-2026. Source: resume.html; exact end month needs confirmation.
- $10M+ annual digital media P&L. Source: resume.html.
- Consistent top-3 Digital Marketing Solutions revenue ranking across Audacy national footprint. Source: resume.html.
- Denver described as #19 U.S. market. Source: resume.html.
- Approximately 60% digital revenue mix after market transformation. Source: resume.html.
- 130% YoY paid-search conversion growth and 13% YoY new-user lift on flagship financial-services account. Source: resume.html.
- 20+ tracked pitches per month. Source: resume.html.
- Coached 10 AE desks. Source: resume.html.
- Managed up to three Digital Campaign Managers. Source: resume.html.
- Hundreds of advertisers across home services, financial services, healthcare, hospitality, retail, dental, and automotive. Source: resume.html.
- 21+ SEM forecasts against $2.4M of real pipeline data. Source: resume.html.
- Authored an 18-idea automation playbook. Source: resume.html.
- SEM and WordPress programs across 8 states at Primary Residential Mortgage Inc. Source: resume.html.

## Metrics needing confirmation

- Exact Audacy end month and whether the resume should say 2026, May 2026, or another date.
- Team size beyond "up to three Digital Campaign Managers" and whether indirect seller/vendor leadership should be quantified differently.
- Revenue growth percentages beyond the listed $10M+ book and top-3 ranking.
- Retention rate, renewal rate, net revenue retention, or account growth metrics.
- Number of advertisers/accounts directly owned vs. supported.
- Number of sellers trained, training attendance, or adoption outcomes beyond 10 AE desks.
- Elio Intelligence Suite users, customers, revenue, usage volume, uptime, or active workflows.
- JobBored usage metrics, number of discovered roles, applications managed, or automation runs.
- Hormiga Dormida / LaHormigaDormida client count, revenue, launch status, and external availability.
- Certification issue dates and current validity.

## Claims to avoid unless verified

- Do not claim Emilio is a full-time software engineer, ML engineer, or data scientist.
- Do not claim production users, paying customers, ARR, funding, client logos, or adoption numbers for Elio, JobBored, Hormiga Dormida, or LaHormigaDormida unless Emilio confirms them.
- Do not claim direct ownership of all Audacy Denver digital revenue unless phrased as the resume source supports: owned a $10M+ annual digital media P&L / digital book.
- Do not claim national leadership titles beyond top-3 ranking unless verified.
- Do not claim current certification validity unless Emilio confirms.
- Do not invent compensation targets, relocation willingness, or remote/hybrid preferences.
- Do not mention private account details, API keys, tokens, service-account identifiers, phone/email, or private URLs.
- Do not overstate AI search/GEO work as a formal product unless Emilio confirms the scope.
- Do not use sensitive personal identity details in job materials unless Emilio explicitly asks.
