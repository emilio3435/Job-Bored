# Emilio Nunez-Garcia — Job Preferences

## Purpose

Future job-search agents should use this file to decide which jobs to find, score, write to the Pipeline, ignore, or escalate for review. Separate known facts from assumptions, preserve Emilio's media/adtech plus AI-builder positioning, and never submit applications without approval.

## Primary target roles

- AI Product Marketing.
- GTM / Growth roles at AI companies.
- Sales Engineering / Solutions Consulting.
- Digital Strategy / Digital Sales Director.
- Performance Marketing / SEM leadership.
- AdTech / MarTech strategy.
- AI search / GEO strategy.
- Revenue / client strategy roles.

## Best-fit titles

- Senior Product Marketing Manager, AI.
- Staff Product Marketing Manager, AI.
- Principal Product Marketing Manager, AI.
- Director of Product Marketing, AI.
- AI GTM Lead.
- GTM Strategy Lead, AI.
- Growth Marketing Lead, AI.
- Head of Growth Marketing.
- Director of Performance Marketing.
- Director of Growth Marketing.
- Senior Performance Marketing Manager.
- SEM Strategy Lead.
- Digital Strategy Director.
- Digital Sales Director.
- Director, Digital Media Strategy.
- Principal Solutions Consultant, AI.
- Senior Solutions Consultant, AI.
- Sales Engineer, AI / Marketing Technology.
- Solutions Architect, AI Agents.
- Technical Account Manager, AI / AdTech / MarTech.
- AdTech Strategy Lead.
- MarTech Strategy Lead.
- AI Search / GEO Strategist.

## Acceptable adjacent titles

- Revenue Strategy Lead.
- GTM Engineer, AI.
- Founder-in-Residence, GTM / AI.
- Partner Marketing Manager, AI Ecosystem.
- Enterprise Account Strategist, AdTech / MarTech.
- Strategic Customer Success Manager, AI / AdTech / MarTech.
- Client Strategy Director.
- Marketing Solutions Consultant.
- Demand Generation Lead.
- Growth Operations Lead.
- Marketing Automation Strategist.
- Technical Product Marketing Manager.

## Lower-priority titles

- Brand Marketing Manager.
- Content Marketing Manager.
- Social Media Manager.
- Media Buyer.
- Account Executive.
- Customer Success Manager without strategic or technical scope.
- RevOps Analyst.
- Marketing Generalist.
- SEO Specialist, unless AI search/GEO strategy is central.
- Product Manager, unless the role values GTM/customer workflow expertise over deep engineering ownership.

## Avoid / reject titles

- Pure Software Engineer.
- ML Researcher.
- Data Scientist with no GTM/client/product implementation component.
- Recruiter / Talent Acquisition.
- HR Business Partner.
- Junior Media Buyer.
- Entry-level Marketing Coordinator.
- Commission-only sales roles unless Emilio explicitly approves.
- Roles with no AI, adtech, martech, performance marketing, client strategy, or revenue strategy overlap.

## Ideal company types

- AI-first companies selling products with clear GTM, marketing, sales, agent workflow, or enterprise adoption challenges.
- Adtech/martech platforms involving programmatic, CTV/OTT, retail media, attribution, identity, measurement, campaign optimization, or marketing automation.
- Media, streaming, audio, CTV, and advertising businesses where Emilio's Audacy and digital transformation experience translates directly.
- Performance marketing, growth, and analytics platforms.
- Agentic workflow tools, RAG/LLM platforms, AI productivity tools, and applied AI companies with business-user adoption needs.
- Marketing automation, CDP/CDLE, lifecycle, CRM, RevOps, and customer intelligence platforms.
- AI search, GEO/AIO, and content intelligence companies.
- B2B SaaS companies where the role bridges buyers, technical teams, and measurable revenue outcomes.

## Target companies / watchlist

High confidence:

- The Trade Desk.
- LiveRamp.
- Klaviyo.
- HubSpot.
- Braze.
- Amplitude.
- Intercom.
- Netflix Ads.
- Pinterest.
- PubMatic.
- TripleLift.
- Simon Data.
- Salesforce Marketing Cloud.

Medium confidence:

- Scale AI.
- Cohere.
- Writer.
- Anthropic.
- Moveworks.
- Fireworks AI.
- Abnormal AI.
- Glean.
- Gong.
- Jasper.
- Runway.
- Fireflies.ai.
- Cursor.
- Clay.
- Harvey.
- Zapier.
- Notion.
- Figma.
- Snowflake.
- mParticle.
- Beehiiv.

Needs confirmation:

- MediaMath.
- TransUnion.
- Capsule.
- Loop AI.
- Perch.
- Wolters Kluwer.
- Samsara.
- CrowdStrike.
- Databricks.
- Procore.
- Generated Health.
- DistantJob.
- ServiceNow.
- AeroVect.
- Houzz.
- MariaDB.

## No-go or caution companies

Needs Emilio input. Do not infer no-go companies from past searches, skipped roles, politics, industry stereotypes, or model assumptions.

## Location preferences

- Denver context is verified.
- Hermes memory says Emilio is Denver-based but operates on Central Time for scheduling; job agents should not confuse scheduling timezone with relocation preference.
- Remote/hybrid/on-site preference: needs Emilio confirmation.
- Timezone constraints: Central Time is verified for scheduling; work-hour constraints need Emilio confirmation.
- Travel willingness: needs Emilio confirmation.
- Relocation willingness: needs Emilio confirmation.
- Search default until confirmed: prioritize Remote (US), Remote or Hybrid, Denver, Boulder, Colorado, and roles that can plausibly work from Mountain/Central time.

## Compensation preferences

Known:

- Salary transparency matters in scoring; missing salary should be penalized but not an automatic rejection for exceptional roles.
- Prior job-search prompts used high-fit roles with listed salaries as stronger matches, but no personal compensation floor is verified.

Needs Emilio confirmation:

- Salary floor.
- OTE expectations for sales/solutions/revenue roles.
- Equity importance.
- Contract vs. full-time preference.
- Benefits requirements.
- Minimum acceptable base salary vs. total compensation.
- Whether commission-heavy roles are acceptable.

## Scoring rubric

Use a 1-10 fit score. Write to Pipeline only when fit score is 8+ unless Emilio changes the gate.

- 10: Exceptional overlap across AI/LLM relevance, GTM/marketing/sales relevance, adtech/martech/media relevance, seniority, location/remote fit, compensation transparency, credible company, and reasonable application path.
- 9: Strong overlap across at least five dimensions, with no major red flags.
- 8: Strong overlap across at least four dimensions, or an unusually strong company/role match with one manageable gap.
- 7: Interesting but incomplete fit; hold for review or include in extras, not Pipeline.
- 6: Plausible adjacent role but weak on AI, adtech/martech, seniority, or compensation.
- 5 or below: Ignore unless Emilio explicitly asks for broader exploration.

Dimension weights:

- AI/LLM relevance: high weight. Look for AI products, LLMs, agents, RAG, prompt engineering, AI search/GEO, applied AI, or AI GTM.
- GTM/marketing/sales relevance: high weight. Look for product marketing, growth, demand generation, sales engineering, solutions consulting, client strategy, revenue strategy, or performance marketing.
- Adtech/martech/media relevance: high weight. Look for programmatic, CTV/OTT, streaming/audio, retail media, attribution, CDP, marketing automation, SEO/SEM, paid social, or measurement.
- Seniority: high weight. Favor senior manager, principal IC, staff, director, head-of, or strategic lead roles. Penalize junior execution-only roles.
- Compensation transparency: medium weight. Listed salary boosts priority; missing salary penalizes but does not auto-reject a role that is otherwise exceptional.
- Remote/location fit: medium-high weight until Emilio confirms. Favor Remote US, Remote/Hybrid, Denver/Colorado, and roles compatible with Mountain/Central time.
- Credibility of company: medium weight. Favor credible AI/adtech/martech/media companies with real products, clear customers, and serious GTM motion.
- Application complexity: medium weight. Prefer direct ATS links, Greenhouse, Lever, Ashby, company pages, or Google Jobs links. Penalize Workday complexity.

## Salary policy

Missing salary should be penalized but not an automatic rejection if the role is otherwise exceptionally strong. If written to Pipeline without salary, set Salary to "Not listed" and explain the exception in Fit Assessment.

## Workday / application complexity policy

Workday should be discovery-link only through Google Jobs / SerpApi-style sources. Do not directly automate Workday applications. Workday links can be saved for Emilio review when the role is strong, but agents should not attempt direct Workday browser automation.

## Application approval policy

No application submission without Pipeline status `Approved` plus final chat confirmation. Discovery, scoring, resume tailoring, cover-letter drafting, and talking-point preparation are allowed; submission, account creation, recruiter outreach, or message sending requires explicit approval.

## Pipeline write policy

- Pipeline sheet is the job-search source of truth.
- Dedupe by job URL / Column E.
- New roles should use Pipeline status `New` unless Emilio changes the workflow.
- Preserve unknown columns and do not overwrite manual notes/status.
- If a role is below fit score 8, keep it out of Pipeline unless Emilio asks for broader capture.
- If automation fails, save pending rows locally and report the failure rather than silently dropping results.

## Open questions for Emilio

- What is the minimum base salary and total compensation/OTE range?
- Are contract, fractional, consulting, or founding-operator roles acceptable, or should agents prefer full-time W2 roles?
- Is remote required, strongly preferred, or simply nice to have?
- Which cities or timezones are acceptable for hybrid roles?
- Is relocation off the table?
- How much travel is acceptable?
- Which target companies are dream companies, which are maybes, and which are no-go?
- Should agents prioritize AI Product Marketing, Sales Engineering/Solutions, or Performance/Growth when all are available?
- What is the minimum seniority floor?
- Are commission-heavy sales roles acceptable?
- Should startup risk be embraced, capped, or avoided?
- Which industries should be excluded?
- Should bilingual English/Spanish be actively used in job targeting or only mentioned when relevant?
- What approval phrase or Pipeline workflow should count as final application authorization?

## Source notes

- Resume facts and metrics come from `/Users/emiliong/.hermes/job-hunt/resume-template/resume.html`.
- Automation rules come from Hermes memory, JobBored `AGENT_CONTRACT.md`, `pipeline-row.v1.json`, and local job-search handoff prompts.
- Target company list comes from local job-search handoff prompts and recent job scan outputs; confidence should be confirmed with Emilio before treating it as a hard allowlist.
