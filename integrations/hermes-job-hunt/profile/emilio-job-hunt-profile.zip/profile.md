# Emilio Nunez-Garcia — Canonical Job-Hunt Profile

## One-line positioning

Former Audacy Denver digital sales leader and hands-on AI product builder who bridges performance media, revenue strategy, and AI/agent systems for companies selling into the future of marketing.

## Short professional summary

Emilio Nunez-Garcia is a Denver-based performance marketing and digital media leader with 10+ years across paid acquisition, client strategy, sales leadership, and AI product building. At Audacy Denver, he progressed through digital campaign, key account, and digital sales leadership roles while helping grow a $10M+ annual digital media book and moving the market toward a digital-first revenue mix. His media fluency spans SEM, SEO, paid social, programmatic display, CTV/OTT, Amazon DSP, streaming audio, attribution, KPI strategy, and unit economics. He is also a hands-on builder of AI/adtech systems, including Elio Intelligence Suite, JobBored, Hormiga Dormida, Hermes workflows, GCP/Cloud Run deployments, multi-model LLM routing, RAG, MCP/agent workflows, and prompt-engineered automation. His strongest fit is for roles where GTM, performance marketing, client advisory, and technical AI implementation need to meet in one person.

## Core differentiators

- Combines senior media/adtech operator experience with hands-on AI product building instead of sitting only on the strategy side.
- Has carried client-facing revenue responsibility while also understanding platform mechanics: bidding, attribution, CRO, channel allocation, and reporting.
- Can translate executive business goals into channel strategy, KPI architecture, and technical workflow design.
- Understands both legacy media transformation and newer AI search/GEO disruption, which makes him useful to companies navigating marketing change rather than simply buying more media.
- Brings practical GCP, LLM, RAG, agent workflow, and prompt-engineering experience without needing to be positioned as a pure software engineer.
- Has a rare mix of local-market sales leadership, national-platform fluency, and founder-style building.
- Bilingual English/Spanish, with additional French and Italian proficiency from the resume source.

## Verified experience themes

### Advertising and media leadership

- Former Audacy Denver Digital Sales Manager with eight years at Audacy/Entercom across four progressive roles.
- Owned a $10M+ annual digital media P&L and helped Denver reach a consistent top-3 Digital Marketing Solutions revenue ranking across Audacy's national footprint, despite Denver being a #19 U.S. market.
- Led market transformation from broadcast-dominant to approximately 60% digital revenue mix by building playbooks, pitch systems, and seller training.
- Coached 10 AE desks and managed a rotating team of up to three Digital Campaign Managers plus internal media specialists, creative/agency partners, and vendors.
- Built cross-platform proposals integrating broadcast audio, streaming audio, OTT, and digital.

### Performance marketing / SEM / paid media

- Hands-on and leadership experience across Google Ads, Meta Ads, Amazon DSP, programmatic display, OTT/CTV, streaming audio, SEM, paid social, native, retargeting, and SEO/AI-search readiness.
- Architected advanced bidding and attribution strategy across Search, YouTube, PMax, Meta, Amazon DSP, and programmatic display.
- Delivered 130% YoY paid-search conversion growth and 13% YoY new-user lift for a flagship financial-services account through bidding, audience-signal, and CRO work.
- Built reporting dashboards and pacing systems for client performance reviews.
- Fluent in CAC, LTV, ROAS, contribution margin, payback, attribution, channel forecasting, and portfolio allocation.

### AI product and agent systems

- Founder of Elio Intelligence Suite / elioai.app, described in the resume as a production multi-model AI platform.
- Built systems routing across Claude, GPT, Gemini, Grok, and Llama based on task fit, latency, and cost.
- Shipped an SEM Revenue Forecast tool using Gemini with live Google Search grounding; resume reports 21+ forecasts against $2.4M of real pipeline data for pitch cycles.
- Built agentic scheduled workflows for client-pulse briefings, job-board scans, resume tailoring, Telegram notifications, and reporting workflows.
- Built JobBored as an AI-assisted job-search product with a React dashboard and Hermes agent.
- Built or is building LaHormigaDormida / Hormiga Dormida concepts around AI-assisted marketing and ops workflows; exact external positioning needs Emilio confirmation.

### Cloud / technical implementation

- Built and deployed AI systems on GCP Cloud Run, Vertex AI Search, Firebase auth, and RAG pipelines.
- Uses Python, JavaScript, React, SQL, HTML/CSS, Node, bash, git worktrees, tmux, Claude Code, Codex, Cursor, VS Code, and Swift basics according to resume and local memory.
- Has worked with Claude API, OpenAI API, Gemini/Vertex AI, Grok API, self-hosted Llama, Google Chirp 3 HD TTS, Firebase, service accounts, and IAM.
- Has local project context around a Google Ads MCP server and agent workflows; exact production usage and public framing need Emilio confirmation.

### Client strategy and revenue

- Owned client strategy across home services, financial services, healthcare, dental, hospitality, retail, and automotive.
- Led high-stakes pitches, QBRs, mid-year reviews, attribution disputes, KPI strategy, and retention conversations.
- Became a market go-to strategist/presenter for attribution and AI-search disruption topics, including AI Overviews, GEO/AIO readiness, shadow sites, and hub-and-spoke architecture.
- Brings sales enablement experience through Digital Cafe and Happy Half-Hour training series.

### Bilingual / cross-cultural strengths

- Bilingual English/Spanish with native fluency listed in the resume.
- Proficient French and proficient Italian are listed in the resume.
- Cross-cultural positioning should be used only where relevant to the role or client base, not as filler.

## Target role fit

Emilio is strongest for senior roles that need a business-facing operator who can make AI, adtech, martech, and performance media useful in revenue conversations. Best-fit lanes include AI Product Marketing, GTM/Growth at AI companies, Sales Engineering or Solutions Consulting for AI/adtech/martech platforms, Digital Strategy or Digital Sales Director roles, Performance Marketing/SEM leadership, AdTech/MarTech strategy, AI search/GEO strategy, and revenue/client strategy roles where technical fluency is a differentiator.

## Adjacent but plausible roles

- Strategic Account Director or Enterprise Account Strategy roles in adtech, martech, or AI platforms.
- Technical Account Manager for AI, marketing automation, measurement, or advertising platforms.
- Revenue Operations or GTM Systems roles when they emphasize customer strategy and AI workflow design.
- Partner Marketing or Channel Strategy roles for AI/adtech ecosystems.
- Founder-in-residence, GTM engineer, or AI workflow consultant roles where hands-on building plus sales judgment matters.
- Growth marketing roles when they include paid acquisition, lifecycle, measurement, and AI experimentation rather than narrow content-only execution.

## Poor-fit roles

- Pure software engineering roles with no GTM, marketing, client, or solutions component.
- Pure research data science or ML research roles without business/application ownership.
- Junior media buying roles that underuse revenue leadership and client advisory experience.
- Generic brand/content marketing roles with no performance, AI, adtech, or revenue strategy component.
- HR/recruiting roles.
- Roles requiring heavy relocation or strict on-site expectations should be treated as needs Emilio confirmation.

## Evidence / remembered facts

- Emilio Nunez-Garcia is based in Denver, CO. Source: User-provided / Verified from memory/session.
- Emilio is a former Audacy Denver Digital Sales Manager. Source: User-provided / File-derived.
- Audacy/Entercom tenure is listed as Sep 2017-2026, eight years, four progressive roles. Source: File-derived.
- Audacy roles listed: Digital Campaign Manager, Key Account Manager / Senior Key Account Manager, Digital Sales Manager. Source: File-derived.
- $10M+ annual digital media P&L and top-3 national Audacy Digital Marketing Solutions revenue ranking for Denver are listed in the resume. Source: File-derived.
- Denver is described as a #19 U.S. market in the resume. Source: File-derived.
- Market transformation to approximately 60% digital revenue mix is listed in the resume. Source: File-derived.
- 130% YoY paid-search conversion growth and 13% YoY new-user lift on a flagship financial-services account are listed in the resume. Source: File-derived.
- 20+ tracked pitches per month and coaching 10 AE desks are listed in the resume. Source: File-derived.
- Managed up to three Digital Campaign Managers plus internal specialists, partners, and vendors. Source: File-derived.
- Platform fluency includes Google Ads, Meta Ads, Amazon DSP, programmatic display, OTT/CTV, DV360, The Trade Desk, streaming audio, GA4, Looker Studio, GTM, CallRail, ServiceTitan, Advisr, Salesforce basics, and HubSpot basics. Source: File-derived.
- Founder of Elio Intelligence Suite / elioai.app, Founder & AI Engineer, Denver, 2024-present. Source: File-derived.
- Elio Intelligence Suite is described as a production multi-model AI platform on GCP Cloud Run using Claude, GPT, Gemini, Grok, Llama, Vertex AI Search RAG, and Google Chirp 3 HD TTS. Source: File-derived.
- SEM Revenue Forecast tool ran 21+ forecasts against $2.4M of real pipeline data. Source: File-derived.
- JobBored is an AI-assisted job-search product with React dashboard and Hermes agent. Source: File-derived / Verified from memory/session.
- Hormiga Dormida is listed as an automated AI agency delivering marketing and ops workflows to SMB clients. Source: File-derived.
- LaHormigaDormida is remembered as a Mac desktop ads-operator app for managing paid campaigns with approvals, audit trail, monitoring, and messaging-based approvals. Source: Verified from memory/session; needs Emilio confirmation for job-search phrasing.
- B.A. Mathematical Economics, Colorado College, 2017. Source: File-derived.
- Bilingual English/Spanish; proficient French and Italian. Source: File-derived / Verified from memory/session.
- Google Ads Fundamentals, Google Ads Search, Google Ads Mobile Advertising, and Google Analytics Certified are listed. Source: File-derived; current validity needs Emilio confirmation.
- Emilio prefers scannable, low-filler, direct, precise writing that is methodical but conversational. Source: Verified from memory/session.
- Job Hunt OS policy: Workday discovery-link only via Google Jobs/SerpApi-style sources; no direct Workday automation; applications require Pipeline status Approved plus final chat confirmation. Source: Verified from memory/session / File-derived.

## Uncertainties to confirm with Emilio

- Exact Audacy end date, final title status, and preferred explanation for departure.
- Whether to publicly use "AI Engineer" or softer "AI product builder" framing by default.
- Current status and public positioning of Elio Intelligence Suite, Elio AI LLC, Hormiga Dormida, and LaHormigaDormida.
- Which AI projects have live users, clients, revenue, or production traffic that can be safely stated.
- Whether Google Ads / Google Analytics certifications are current or historical.
- Preferred target seniority floor and whether director-level, principal IC, staff PMM, or solutions leadership is the main lane.
- Remote, hybrid, on-site, travel, and relocation constraints.
- Compensation floor, OTE expectations, equity importance, contract vs. full-time preference, and benefits requirements.
- Target company watchlist, no-go companies, and industries to avoid.
- Whether to emphasize multilingual strengths in every resume or only when relevant.
