# Emilio Nunez-Garcia — Voice Guide

## Purpose

Future agents should use this guide to write resumes, cover letters, LinkedIn notes, recruiter replies, and application answers in Emilio's voice without flattening him into a generic marketing leader or overhyping the AI-builder angle.

## Voice summary

Emilio's professional voice is crisp, strategic, practical, and high-touch. It should sound like someone who has sat across from serious clients, owned revenue outcomes, and understands the messy mechanics behind paid media, attribution, and executive decision-making. The AI angle should feel earned and concrete: not "AI visionary," but a builder who ships useful systems that make marketing, forecasting, and workflow execution sharper. The tone should be confident without puffery, polished without corporate fog, and specific enough that a hiring manager can see the actual operating surface.

## What the voice should sound like

- Direct and scannable, with low filler and clear business stakes.
- Strategic, but anchored in concrete platforms, metrics, workflows, and client situations.
- Calmly confident; let evidence carry the weight rather than adding hype.
- Sophisticated media-sales language: client strategy, KPI architecture, attribution, marginal ROAS, channel allocation, QBRs, retention, and sales enablement.
- Practical AI-builder language: built, shipped, deployed, routed, automated, forecasted, instrumented, tested.
- Executive-ready but human; polished enough for a VP, specific enough for a practitioner.
- High-touch and advisory, especially when discussing clients, sellers, cross-functional partners, or recruiters.
- Future-facing without sounding breathless: AI search, GEO/AIO, agent workflows, and multi-model systems should be framed as practical market shifts.

## What the voice should not sound like

- Generic SaaS marketer language with no media, adtech, client, or revenue texture.
- Hype-heavy AI language such as "revolutionary," "game-changing," "disruptive visionary," or "unlocking the future."
- Overly humble filler such as "I had the opportunity to" or "I was responsible for helping with."
- Resume mush like "results-driven professional," "dynamic leader," "proven track record," or "passionate about innovation."
- Pure-engineer positioning unless the role requires technical-adjacent framing.
- Buzzword strings that do not explain the business outcome.
- Overly casual, cute, or magical language in job materials.
- Unsupported claims about revenue, headcount, users, clients, funding, or production scale.

## Core narrative

Emilio's recurring story is that he came up through media and adtech the hard way: campaign execution, account strategy, sales enablement, client retention, and digital revenue leadership in a complex local market. He learned how SEM, paid social, programmatic, CTV/OTT, Amazon DSP, streaming audio, attribution, and KPI strategy actually behave when advertisers are spending real money and asking hard questions. Instead of treating AI as a talking point, he began building AI products and agent workflows himself: Elio Intelligence Suite, JobBored, Hormiga Dormida, Hermes workflows, multi-model LLM routing, GCP deployments, and prompt-engineered automation. The bridge is the value: he can connect business strategy to technical implementation, and he can explain both sides in language that clients, sellers, product teams, and executives can trust.

## Resume voice rules

- Lead with the unusual combination: media/adtech operator plus AI product builder.
- Start bullets with strong verbs: owned, led, built, architected, shipped, coached, retained, translated, deployed, automated, forecasted, optimized.
- Use metrics only when verified; otherwise use `[metric needed]`.
- Tie platform work to business outcomes: ROAS, CAC, LTV, payback, lead volume, booked revenue, retention, seller enablement, client confidence.
- Keep technical bullets business-readable; mention GCP, RAG, LLM routing, MCP, and agent workflows only where they support a real use case.
- Avoid stuffing every channel into every bullet; tailor the channel list to the role.
- Preserve Audacy specificity: Denver market, $10M+ digital book, top-3 national ranking, #19 U.S. market, digital revenue mix, Digital Cafe / Happy Half-Hour, and client verticals when relevant.

## Cover letter voice rules

- Open with the specific overlap between the role and Emilio's operator-builder profile.
- Use one compact Audacy proof point and one compact AI-builder proof point.
- Explain why the company or role is interesting in strategic terms, not flattery.
- Keep it to 3-4 tight paragraphs unless the application asks for more.
- Avoid generic enthusiasm; say what Emilio would help the company do.
- Do not apologize for a non-traditional path; frame it as the advantage.

## LinkedIn / recruiter message voice rules

- Keep messages short, direct, and role-specific.
- Mention the sharpest fit angle in one sentence: AI GTM, adtech, performance marketing, sales engineering, or media strategy.
- Use one proof point max; do not paste a mini-cover-letter.
- Ask for a concrete next step: quick fit check, intro, recruiter screen, or permission to send a tailored resume.
- Sound warm and senior, not needy.

## Interview answer voice rules

- Use a clean structure: context, action, result, lesson.
- Lead with business stakes before tactics.
- Name tradeoffs and how Emilio made decisions under ambiguity.
- When discussing AI, explain what the system did, who used it, why it mattered, and what constraints shaped the build.
- When discussing sales leadership, show how client needs, seller enablement, platform strategy, and revenue outcomes connected.
- Mark uncertain details as "I would want to verify the exact number, but the shape was..." rather than guessing.

## Preferred phrasing patterns

- "I sit at the intersection of..."
- "The useful part is not the tool itself; it is what it changes in the workflow."
- "Translate business goals into channel strategy, KPI architecture, and execution."
- "Move spend toward marginal ROAS."
- "Make the strategy legible to the client and actionable for the team."
- "Built the playbook, the pitch system, and the operating rhythm."
- "Hands-on enough to know where the system breaks; senior enough to know what the business needs."
- "AI product builder with a media operator's sense for revenue, adoption, and client trust."
- "Needs more samples" for exact personal cadence outside resume/profile materials.

## Phrases to avoid

- Results-driven professional.
- Proven track record.
- Passionate about leveraging technology.
- Unlock the power of AI.
- Game-changing / revolutionary / cutting-edge solution.
- Dynamic leader.
- Wearing many hats.
- Data-driven storyteller, unless backed by a specific example.
- Ninja, guru, wizard, rockstar.
- I am uniquely qualified, unless immediately followed by concrete evidence.
- Synergy, empower, optimize outcomes, leverage innovation, in today's fast-paced landscape.

## Example rewrites

### Example 1

Generic version:

"I am a results-driven marketing leader with a proven track record of using data to drive growth."

Better Emilio version:

"I have spent 10+ years turning advertiser goals into channel strategy, KPI architecture, and paid-media execution across SEM, paid social, programmatic, CTV/OTT, Amazon DSP, and streaming audio."

Why the Emilio version is better:

It replaces generic claims with the actual operating surface: advertiser goals, KPI strategy, paid media channels, and execution depth.

### Example 2

Generic version:

"I am passionate about AI and excited to help companies innovate."

Better Emilio version:

"I have been building AI systems hands-on: multi-model LLM workflows, GCP deployments, SEM forecasting, client briefings, reporting automation, and agentic job-search workflows."

Why the Emilio version is better:

It makes the AI angle concrete and practical without pretending Emilio is a pure ML researcher.

### Example 3

Generic version:

"At Audacy, I managed digital advertising campaigns and worked with clients to improve performance."

Better Emilio version:

"At Audacy Denver, I helped move a broadcast-heavy market toward a digital-first revenue mix while advising clients on SEM, paid social, CTV/OTT, programmatic, streaming audio, attribution, and KPI strategy."

Why the Emilio version is better:

It preserves the transformation story, client strategy, and media-sales sophistication that make the experience more senior than campaign management.

## Evidence and gaps

- Resume source provides strong evidence for polished, strategic, performance-marketing language.
- Hermes memory confirms Emilio prefers scannable, low-filler, direct, precise output that is methodical but conversational.
- Additional real writing samples are not present in the local source folder. Needs more samples for exact email cadence, humor level, and personal phrasing.
