/* ============================================
   COMMAND CENTER v2 — App Logic
   CSV read + Google Sheets API v4 write-back
   Google Identity Services (GIS) OAuth 2.0
   ============================================ */

(function ensureDiscoveryWizardLocalApiLoaded() {
  if (typeof window === "undefined" || typeof document === "undefined") {
    return;
  }
  try {
    const root =
      window.JobBoredDiscoveryWizard || (window.JobBoredDiscoveryWizard = {});
    if (root.local && typeof root.local.runLocalWizardAction === "function") {
      return;
    }
    const cur = document.currentScript;
    const fallbackSrc =
      cur && cur.src
        ? new URL("./discovery-wizard-local.js", cur.src).href
        : "discovery-wizard-local.js";
    const s = document.createElement("script");
    s.src = fallbackSrc;
    s.async = false;
    (document.head || document.documentElement).appendChild(s);
  } catch (err) {
    if (typeof console !== "undefined" && console.warn) {
      console.warn("[JobBored] could not load discovery-wizard-local.js:", err);
    }
  }
})();

const COMMAND_CENTER_CONFIG_OVERRIDE_KEY = "command_center_config_overrides";
const DISCOVERY_TRANSPORT_SETUP_KEY =
  "command_center_discovery_transport_setup";
const DISCOVERY_LOCAL_BOOTSTRAP_STATE_PATH = "discovery-local-bootstrap.json";
const DISCOVERY_RUN_TRACKER_KEY = "command_center_discovery_run_state";
// Set by performSettingsClearOverrides before reload so the next interactive
// sign-in forces Google's consent screen instead of silently re-issuing a
// token from the prior consent grant. One-shot: cleared after the next signIn.
const FORCE_CONSENT_PROMPT_KEY = "command_center_force_consent_prompt";

// ============================================
// RUN STATUS TRACKER
// ============================================

/**
 * Browser-side state machine for async discovery run lifecycle.
 * Persists run handle so refresh/reopen can recover tracking.
 *
 * Valid states and transitions:
 *   idle -> pending   (triggerDiscoveryRun succeeds with accepted_async)
 *   idle -> failed    (triggerDiscoveryRun fails at network level)
 *   pending -> running (first poll returns non-terminal status)
 *   pending -> failed  (polling fails with non-retryable error)
 *   running -> completed (poll returns terminal:completed/empty)
 *   running -> partial   (poll returns terminal:partial)
 *   running -> failed    (poll returns terminal:failed)
 *   running -> polling_error (retryable network error)
 *   polling_error -> running (retry succeeds)
 *   polling_error -> failed   (retries exhausted)
 *
 * A runId that has reached terminal state (completed/empty/partial/failed)
 * is preserved in storage so refresh/reopen can still show the outcome.
 */
class DiscoveryRunTracker {
  constructor(storageKey = DISCOVERY_RUN_TRACKER_KEY) {
    this._key = storageKey;
    this._state = this._load();
  }

  _load() {
    try {
      const raw = localStorage.getItem(this._key);
      if (!raw) return this._idle();
      const parsed = JSON.parse(raw);
      if (!parsed || typeof parsed !== "object") return this._idle();
      // Re-hydrate with defaults for missing fields
      return {
        status: parsed.status || "idle",
        runId: parsed.runId || "",
        statusPath: parsed.statusPath || "",
        pollAfterMs: parsed.pollAfterMs || 2000,
        webhookUrl: parsed.webhookUrl || "",
        initiatedAt: parsed.initiatedAt || "",
        terminalAt: parsed.terminalAt || "",
        terminalKind: parsed.terminalKind || "", // completed|empty|partial|failed
        errorMessage: parsed.errorMessage || "",
        pollErrorCount: parsed.pollErrorCount || 0,
        lastPollAt: parsed.lastPollAt || "",
        trigger: parsed.trigger || "manual",
        variationKey: parsed.variationKey || "",
        requestedAt: parsed.requestedAt || "",
        message: parsed.message || "",
        startedAt: parsed.startedAt || "",
        completedAt: parsed.completedAt || "",
        companiesSeen: Number.isFinite(parsed.companiesSeen)
          ? parsed.companiesSeen
          : 0,
        leadsWritten: Number.isFinite(parsed.leadsWritten)
          ? parsed.leadsWritten
          : 0,
      };
    } catch (_) {
      return this._idle();
    }
  }

  _persist(state) {
    try {
      localStorage.setItem(this._key, JSON.stringify(state));
    } catch (_) {
      /* storage full or unavailable — run state is best-effort */
    }
    dispatchDiscoveryRunTrackerEvent(state);
  }

  _idle() {
    return {
      status: "idle",
      runId: "",
      statusPath: "",
      pollAfterMs: 2000,
      webhookUrl: "",
      initiatedAt: "",
      terminalAt: "",
      terminalKind: "",
      errorMessage: "",
      pollErrorCount: 0,
      lastPollAt: "",
      trigger: "manual",
      variationKey: "",
      requestedAt: "",
      message: "",
      startedAt: "",
      completedAt: "",
      companiesSeen: 0,
      leadsWritten: 0,
    };
  }

  /** Current immutable snapshot for UI reads */
  getState() {
    return { ...this._state };
  }

  /**
   * Begin tracking an async run that was accepted by the discovery worker.
   * @param {object} options
   * @param {string} options.runId
   * @param {string} [options.statusPath]  e.g. "/runs/run_abc123"
   * @param {number} [options.pollAfterMs] polling interval in ms (default 2000)
   * @param {string} [options.webhookUrl]  the webhook URL for status polling
   */
  beginTracking({
    runId,
    statusPath = "",
    pollAfterMs = 2000,
    webhookUrl = "",
    trigger = "manual",
    variationKey = "",
    requestedAt = "",
  }) {
    this._state = {
      status: "pending",
      runId: String(runId || "").trim(),
      statusPath: String(statusPath || "").trim(),
      pollAfterMs: Number.isFinite(pollAfterMs) ? pollAfterMs : 2000,
      webhookUrl: String(webhookUrl || "").trim(),
      initiatedAt: new Date().toISOString(),
      terminalAt: "",
      terminalKind: "",
      errorMessage: "",
      pollErrorCount: 0,
      lastPollAt: "",
      trigger: String(trigger || "manual"),
      variationKey: String(variationKey || "").trim(),
      requestedAt: String(requestedAt || "").trim(),
      message: "",
      startedAt: "",
      completedAt: "",
      companiesSeen: 0,
      leadsWritten: 0,
    };
    this._persist(this._state);
    return this;
  }

  /** Transition from pending → running on first poll confirmation */
  markRunning() {
    if (this._state.status !== "pending") return this;
    this._state.status = "running";
    this._persist(this._state);
    return this;
  }

  /**
   * Called on each poll response.
   * @param {object} statusData  parsed /runs/{runId} JSON body
   */
  updateFromStatusResponse(statusData) {
    if (!statusData || typeof statusData !== "object") return this;
    this._state.lastPollAt = new Date().toISOString();
    const isTerminal = !!statusData.terminal;
    const runStatus = String(statusData.status || "").toLowerCase();
    const request = statusData.request && typeof statusData.request === "object"
      ? statusData.request
      : {};
    const lifecycle =
      statusData.lifecycle && typeof statusData.lifecycle === "object"
        ? statusData.lifecycle
        : {};
    const writeResult =
      statusData.writeResult && typeof statusData.writeResult === "object"
        ? statusData.writeResult
        : {};
    this._state.trigger = String(statusData.trigger || this._state.trigger || "manual");
    this._state.variationKey = String(
      request.variationKey || this._state.variationKey || "",
    );
    this._state.requestedAt = String(
      request.requestedAt || this._state.requestedAt || "",
    );
    this._state.message = String(statusData.message || this._state.message || "");
    this._state.startedAt = String(statusData.startedAt || this._state.startedAt || "");
    this._state.completedAt = String(statusData.completedAt || "");
    if (Number.isFinite(lifecycle.companyCount)) {
      this._state.companiesSeen = lifecycle.companyCount;
    }
    if (Number.isFinite(writeResult.appended)) {
      this._state.leadsWritten = writeResult.appended;
    }
    if (isTerminal) {
      this._state.status = runStatus; // completed | empty | partial | failed
      this._state.terminalAt = new Date().toISOString();
      this._state.terminalKind = runStatus;
      this._state.errorMessage = String(statusData.error || statusData.message || "");
      this._persist(this._state);
      return this;
    }
    // Non-terminal: ensure we're in running, not stuck in pending
    if (this._state.status === "pending") {
      this._state.status = "running";
    }
    this._state.pollErrorCount = 0; // reset on successful poll
    this._persist(this._state);
    return this;
  }

  /** Called when polling itself fails (network error, timeout, non-2xx). */
  markPollError(errorMessage = "") {
    this._state.pollErrorCount = (this._state.pollErrorCount || 0) + 1;
    this._state.lastPollAt = new Date().toISOString();
    this._state.errorMessage = String(errorMessage || "Polling failed");
    // Transition to polling_error state if we've been in running/pending
    if (this._state.status === "running" || this._state.status === "pending") {
      this._state.status = "polling_error";
    }
    this._persist(this._state);
    return this;
  }

  /** Retry after polling error — back to running if we have a runId */
  resumeFromPollError() {
    if (this._state.status !== "polling_error") return this;
    this._state.status = this._state.runId ? "running" : "idle";
    this._state.pollErrorCount = 0;
    this._persist(this._state);
    return this;
  }

  /** Mark the run as failed with an explicit error message (non-poll-error path). */
  markFailed(errorMessage = "") {
    this._state.status = "failed";
    this._state.terminalAt = new Date().toISOString();
    this._state.terminalKind = "failed";
    this._state.errorMessage = String(errorMessage || "Run failed");
    this._persist(this._state);
    return this;
  }

  /** Clear any active run — used after user explicitly dismisses or run is stale. */
  clear() {
    this._state = this._idle();
    try {
      localStorage.removeItem(this._key);
    } catch (_) {}
    dispatchDiscoveryRunTrackerEvent(this._state);
    return this;
  }

  /** True when there is an in-progress run that should show UI feedback. */
  isActive() {
    return ["pending", "running", "polling_error"].includes(this._state.status);
  }

  /** True when the run has reached a terminal state (completed/empty/partial/failed). */
  isTerminal() {
    return ["completed", "empty", "partial", "failed"].includes(this._state.status);
  }

  /** True when status polling is in an error state that might recover. */
  isPollingError() {
    return this._state.status === "polling_error";
  }
}

/** Shared singleton — initialized once at module load */
const discoveryRunTracker = new DiscoveryRunTracker();

function dispatchDiscoveryRunTrackerEvent(state) {
  try {
    if (typeof document === "undefined") return;
    if (typeof CustomEvent !== "function") return;
    document.dispatchEvent(
      new CustomEvent("jobbored:job-discovery-run-updated", {
        detail: { state: { ...(state || {}) } },
      }),
    );
  } catch (_) {
    // Best-effort UI bridge for runs-tab.js.
  }
}

const COMMAND_CENTER_OVERRIDE_KEYS = [
  "sheetId",
  "oauthClientId",
  "title",
  "discoveryWebhookUrl",
  "discoveryWebhookSecret",
  "resumeProvider",
  "resumeGeminiApiKey",
  "resumeGeminiModel",
  "resumeOpenAIApiKey",
  "resumeOpenAIModel",
  "resumeAnthropicApiKey",
  "resumeAnthropicModel",
  "resumeGenerationWebhookUrl",
  "jobPostingScrapeUrl",
  "atsScoringMode",
  "atsScoringServerUrl",
  "atsScoringWebhookUrl",
];

function readStoredConfigOverrides() {
  try {
    const raw = localStorage.getItem(COMMAND_CENTER_CONFIG_OVERRIDE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch (e) {
    console.warn("[JobBored] Stored config overrides:", e);
    return {};
  }
}

function applyConfigOverridesToWindowConfig(overrides) {
  if (
    !window.COMMAND_CENTER_CONFIG ||
    typeof window.COMMAND_CENTER_CONFIG !== "object"
  ) {
    window.COMMAND_CENTER_CONFIG = {};
  }
  const base = window.COMMAND_CENTER_CONFIG;
  const src = overrides && typeof overrides === "object" ? overrides : {};
  for (const k of COMMAND_CENTER_OVERRIDE_KEYS) {
    if (Object.prototype.hasOwnProperty.call(src, k) && src[k] != null) {
      base[k] = src[k];
    }
  }
}

function writeStoredConfigOverrides(overrides) {
  const next = overrides && typeof overrides === "object" ? overrides : {};
  localStorage.setItem(
    COMMAND_CENTER_CONFIG_OVERRIDE_KEY,
    JSON.stringify(next),
  );
  applyConfigOverridesToWindowConfig(next);
  return next;
}

function mergeStoredConfigOverridePatch(patch) {
  const next = {
    ...readStoredConfigOverrides(),
  };
  const src = patch && typeof patch === "object" ? patch : {};
  for (const k of COMMAND_CENTER_OVERRIDE_KEYS) {
    if (Object.prototype.hasOwnProperty.call(src, k) && src[k] != null) {
      next[k] = src[k];
    }
  }
  return writeStoredConfigOverrides(next);
}

/** Merge values saved in this browser (localStorage) onto config from config.js. */
function applyStoredConfigOverrides() {
  applyConfigOverridesToWindowConfig(readStoredConfigOverrides());
}

applyStoredConfigOverrides();

function readDiscoveryTransportSetupState() {
  try {
    const raw = localStorage.getItem(DISCOVERY_TRANSPORT_SETUP_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch (e) {
    console.warn("[JobBored] Discovery transport setup:", e);
    return {};
  }
}

function normalizeDiscoveryLocalWebhookUrl(raw) {
  const s = raw != null ? String(raw).trim() : "";
  if (!s) return "";
  try {
    const url = new URL(s);
    if (url.protocol !== "http:" && url.protocol !== "https:") return "";
    url.hash = "";
    url.search = "";
    return url.toString();
  } catch (_) {
    return "";
  }
}

function normalizeDiscoveryTunnelPublicUrl(raw) {
  const s = raw != null ? String(raw).trim() : "";
  if (!s) return "";
  try {
    const url = new URL(s);
    if (url.protocol !== "https:") return "";
    url.hash = "";
    url.search = "";
    return url.toString();
  } catch (_) {
    return "";
  }
}

function getDiscoveryTransportSetupState() {
  const raw = readDiscoveryTransportSetupState();
  return {
    localWebhookUrl: normalizeDiscoveryLocalWebhookUrl(raw.localWebhookUrl),
    tunnelPublicUrl: normalizeDiscoveryTunnelPublicUrl(raw.tunnelPublicUrl),
  };
}

function writeDiscoveryTransportSetupState(patch) {
  const current = readDiscoveryTransportSetupState();
  const src = patch && typeof patch === "object" ? patch : {};
  const next = {
    ...current,
  };

  if (Object.prototype.hasOwnProperty.call(src, "localWebhookUrl")) {
    next.localWebhookUrl = normalizeDiscoveryLocalWebhookUrl(
      src.localWebhookUrl,
    );
  }
  if (Object.prototype.hasOwnProperty.call(src, "tunnelPublicUrl")) {
    next.tunnelPublicUrl = normalizeDiscoveryTunnelPublicUrl(
      src.tunnelPublicUrl,
    );
  }

  localStorage.setItem(DISCOVERY_TRANSPORT_SETUP_KEY, JSON.stringify(next));
  return getDiscoveryTransportSetupState();
}

function isLocalDashboardOrigin() {
  if (typeof window === "undefined" || !window.location) return false;
  const host = String(window.location.hostname || "").toLowerCase();
  if (
    host === "localhost" ||
    host === "127.0.0.1" ||
    host === "[::1]" ||
    host === "::1"
  ) {
    return true;
  }
  const port = String(window.location.port || "");
  if (port === "8080") return true;
  return false;
}

/**
 * If discovery-local-bootstrap.json exposes a webhookSecret AND the user has
 * not already saved one in Settings, merge it into the stored config overrides
 * so verifyDiscoveryEndpoint will send `x-discovery-secret` automatically.
 *
 * This is the load-bearing piece of "super easy onboarding": after running
 * `npm run discovery:bootstrap-local`, the user reloads the dashboard and
 * Run discovery just works — no copy/paste of a hex string anywhere.
 */
function autofillDiscoveryWebhookSecretFromBootstrap(data) {
  if (!data || typeof data !== "object") return false;
  const secret =
    typeof data.webhookSecret === "string" ? data.webhookSecret.trim() : "";
  if (!secret) return false;
  const existing = getDiscoveryWebhookSecret();
  if (existing) return false; // never overwrite a manually-saved value
  try {
    mergeStoredConfigOverridePatch({ discoveryWebhookSecret: secret });
    return true;
  } catch (err) {
    console.warn(
      "[JobBored] could not autofill discoveryWebhookSecret from bootstrap:",
      err,
    );
    return false;
  }
}

// ====== [discovery-autodetect lane: relay URL auto-fill] ======
// After scripts/deploy-cloudflare-relay.mjs deploys the Cloudflare Worker
// it writes a `relay` block into discovery-local-bootstrap.json with the
// deployed Worker URL. This sibling of the secret autofill copies that URL
// into the discoveryWebhookUrl config setting so the dashboard's wizard
// shows it pre-filled. Greenfield user goal: zero copy/paste of the
// Worker URL anywhere, ever.
//
// Same conservative semantics as autofillDiscoveryWebhookSecretFromBootstrap:
//   - never overwrite a manually-saved value
//   - silently no-op if the field is missing or empty
//   - never throws; logs and returns false on failure
function autofillDiscoveryWebhookUrlFromBootstrap(data) {
  if (!data || typeof data !== "object") return false;
  const relay = data.relay;
  const candidate =
    relay && typeof relay === "object" && typeof relay.workerUrl === "string"
      ? relay.workerUrl.trim()
      : "";
  if (!candidate) return false;
  if (!/^https?:\/\//i.test(candidate)) return false;
  const existing = getDiscoveryWebhookUrl();
  if (existing) return false; // never overwrite a manually-saved value
  try {
    mergeStoredConfigOverridePatch({ discoveryWebhookUrl: candidate });
    return true;
  } catch (err) {
    console.warn(
      "[JobBored] could not autofill discoveryWebhookUrl from bootstrap:",
      err,
    );
    return false;
  }
}
// ====== [/discovery-autodetect lane] ======

async function hydrateDiscoveryTransportSetupFromLocalBootstrap() {
  if (!isLocalDashboardOrigin()) return getDiscoveryTransportSetupState();
  try {
    const res = await fetch(DISCOVERY_LOCAL_BOOTSTRAP_STATE_PATH, {
      cache: "no-store",
    });
    if (!res.ok) return getDiscoveryTransportSetupState();
    const data = await res.json().catch(() => null);
    if (!data || typeof data !== "object") {
      return getDiscoveryTransportSetupState();
    }
    autofillDiscoveryWebhookSecretFromBootstrap(data);
    autofillDiscoveryWebhookUrlFromBootstrap(data);
    return writeDiscoveryTransportSetupState({
      localWebhookUrl: data.localWebhookUrl,
      tunnelPublicUrl: data.tunnelPublicUrl || data.ngrokPublicUrl,
    });
  } catch (_) {
    return getDiscoveryTransportSetupState();
  }
}

// ============================================
// CONFIG VALIDATION
// ============================================

/**
 * Extract a Google Sheet ID from a full spreadsheet URL or a raw ID paste.
 * Accepts e.g. https://docs.google.com/spreadsheets/d/SHEET_ID/edit?gid=0…
 */
const MIN_PLAUSIBLE_GOOGLE_SHEET_ID_LENGTH = 20;

function isPlausibleGoogleSheetId(value) {
  return (
    typeof value === "string" &&
    /^[a-zA-Z0-9_-]+$/.test(value) &&
    value.length >= MIN_PLAUSIBLE_GOOGLE_SHEET_ID_LENGTH &&
    value !== "YOUR_SHEET_ID_HERE"
  );
}

function parseGoogleSheetId(raw) {
  if (raw == null || typeof raw !== "string") return null;
  const s = raw.trim();
  if (!s) return null;
  const fromPath = s.match(/\/spreadsheets\/d\/([a-zA-Z0-9_-]+)(?:\/|$|\?|#)/);
  if (fromPath && isPlausibleGoogleSheetId(fromPath[1])) return fromPath[1];
  const compact = s.replace(/\s/g, "");
  if (isPlausibleGoogleSheetId(compact)) {
    return compact;
  }
  return null;
}

/** Default dashboard label; legacy templates used "Command Center". */
function normalizeDashboardTitle(raw) {
  const t = raw != null ? String(raw).trim() : "";
  if (!t) return "JobBored";
  if (t.toLowerCase() === "command center") return "JobBored";
  return t;
}

function getConfig() {
  const cfg = window.COMMAND_CENTER_CONFIG;
  if (!cfg) return null;
  const sheetId = parseGoogleSheetId(String(cfg.sheetId || ""));
  if (!sheetId || sheetId === "YOUR_SHEET_ID_HERE") return null;
  return {
    ...cfg,
    sheetId,
    title: normalizeDashboardTitle(cfg.title),
  };
}

function getSheetId() {
  const params = new URLSearchParams(window.location.search);
  const urlSheet = params.get("sheet");
  if (urlSheet) {
    const id = parseGoogleSheetId(urlSheet);
    if (id) return id;
  }

  const cfg = getConfig();
  return cfg ? cfg.sheetId : null;
}

function getOAuthClientId() {
  const cfg = window.COMMAND_CENTER_CONFIG || {};
  const id = String(cfg.oauthClientId || "").trim();
  if (!id || id === "YOUR_CLIENT_ID_HERE.apps.googleusercontent.com") {
    return null;
  }
  return id;
}

/** Optional POST target for &ldquo;Run discovery&rdquo; (browser-use worker / Hermes / n8n / Apps Script). */
function getDiscoveryWebhookUrl() {
  const cfg = getConfig();
  const u = cfg && cfg.discoveryWebhookUrl;
  if (!u || typeof u !== "string") return "";
  const t = u.trim();
  return t.length > 0 ? t : "";
}

/**
 * Optional shared secret for the discovery webhook. When set, the dashboard
 * forwards it as the `x-discovery-secret` header so receivers that fail-closed
 * on empty secrets (e.g. the browser-use worker) accept the request.
 */
function getDiscoveryWebhookSecret() {
  const cfg = getConfig();
  const s = cfg && cfg.discoveryWebhookSecret;
  if (!s || typeof s !== "string") return "";
  const t = s.trim();
  return t.length > 0 ? t : "";
}

const APPS_SCRIPT_API_BASE = "https://script.googleapis.com/v1";
const GOOGLE_SHEETS_SCOPE = "https://www.googleapis.com/auth/spreadsheets";
const GOOGLE_USERINFO_EMAIL_SCOPE =
  "https://www.googleapis.com/auth/userinfo.email";
const GOOGLE_USERINFO_PROFILE_SCOPE =
  "https://www.googleapis.com/auth/userinfo.profile";
const GOOGLE_SIGNIN_SCOPES = [
  GOOGLE_SHEETS_SCOPE,
  GOOGLE_USERINFO_EMAIL_SCOPE,
  GOOGLE_USERINFO_PROFILE_SCOPE,
].join(" ");
const APPS_SCRIPT_DEPLOY_SCOPES = [
  "https://www.googleapis.com/auth/script.projects",
  "https://www.googleapis.com/auth/script.deployments",
];
const APPS_SCRIPT_MANAGED_BY = "command-center";
const APPS_SCRIPT_PROJECT_TITLE = "Command Center discovery webhook";
const APPS_SCRIPT_WEBAPP_ACCESS = "ANYONE_ANONYMOUS";
const APPS_SCRIPT_WEBAPP_EXECUTE_AS = "USER_DEPLOYING";
const APPS_SCRIPT_PUBLIC_ACCESS_READY = "ready";
const APPS_SCRIPT_PUBLIC_ACCESS_NEEDS_REMEDIATION = "needs_remediation";
const DISCOVERY_ENGINE_STATE_NONE = "none";
const DISCOVERY_ENGINE_STATE_STUB_ONLY = "stub_only";
const DISCOVERY_ENGINE_STATE_UNVERIFIED = "unverified";
const DISCOVERY_ENGINE_STATE_CONNECTED = "connected";
const GIS_INIT_STUCK_MS = 8000;
const STARTER_PIPELINE_HEADERS = [
  "Date Found",
  "Title",
  "Company",
  "Location",
  "Link",
  "Source",
  "Salary",
  "Fit Score",
  "Priority",
  "Tags",
  "Fit Assessment",
  "Contact",
  "Status",
  "Applied Date",
  "Notes",
  "Follow-up Date",
  "Talking Points",
  "Last contact",
  "Did they reply?",
  "Logo URL",
];
const STARTER_PIPELINE_HEADER_RANGE = `Pipeline!A1:${String.fromCharCode("A".charCodeAt(0) + STARTER_PIPELINE_HEADERS.length - 1)}1`;

let appsScriptDeployStateCache = null;
let appsScriptDeployBusy = false;
let appsScriptDeployStatus = null;
let discoveryEngineStateCache = null;
let discoveryReadinessSnapshotCache = null;
let discoveryReadinessSnapshotPromise = null;
let discoveryWizardRuntime = null;

function getSettingsFieldValue(id) {
  const el = document.getElementById(id);
  return el ? String(el.value || "") : "";
}

function getSettingsSheetIdValue() {
  const el = document.getElementById("settingsSheetId");
  const raw = el
    ? String(el.value || "")
    : String((window.COMMAND_CENTER_CONFIG || {}).sheetId || "");
  return parseGoogleSheetId(raw.trim());
}

function getSettingsOAuthClientIdValue() {
  const el = document.getElementById("settingsOAuthClientId");
  const raw = el
    ? String(el.value || "")
    : String((window.COMMAND_CENTER_CONFIG || {}).oauthClientId || "");
  const id = raw.trim();
  if (!id || id === "YOUR_CLIENT_ID_HERE.apps.googleusercontent.com") {
    return "";
  }
  return id;
}

function hasUnsavedOAuthClientIdChange(candidateId) {
  const nextId =
    candidateId != null
      ? String(candidateId || "").trim()
      : getSettingsOAuthClientIdValue();
  const activeId = String(getOAuthClientId() || "").trim();
  return !!nextId && nextId !== activeId;
}

function getDiscoveryEngineStateStore() {
  const UC = window.CommandCenterUserContent;
  return UC &&
    typeof UC.getDiscoveryEngineState === "function" &&
    typeof UC.saveDiscoveryEngineState === "function"
    ? UC
    : null;
}

function normalizeDiscoveryWebhookIdentity(raw) {
  const s = raw != null ? String(raw).trim() : "";
  if (!s) return "";
  try {
    const url = new URL(s);
    url.hash = "";
    if (url.pathname !== "/") {
      url.pathname = url.pathname.replace(/\/+$/, "") || "/";
    }
    return url.toString();
  } catch (_) {
    return s.replace(/\/+$/, "");
  }
}

function getDiscoveryWebhookUrlForSettingsPreview() {
  const field = document.getElementById("settingsDiscoveryWebhookUrl");
  if (field) {
    return String(field.value || "").trim();
  }
  return getDiscoveryWebhookUrl();
}

function getManagedAppsScriptWebhookIdentity() {
  if (
    !appsScriptDeployStateCache ||
    typeof appsScriptDeployStateCache.webAppUrl !== "string"
  ) {
    return "";
  }
  return normalizeDiscoveryWebhookIdentity(
    appsScriptDeployStateCache.webAppUrl,
  );
}

function getSavedDiscoveryEngineStateForUrl(rawUrl) {
  const target = normalizeDiscoveryWebhookIdentity(rawUrl);
  if (!target) return null;
  const saved =
    discoveryEngineStateCache &&
    typeof discoveryEngineStateCache === "object" &&
    typeof discoveryEngineStateCache.state === "string"
      ? discoveryEngineStateCache
      : null;
  if (!saved) return null;
  const savedUrl = normalizeDiscoveryWebhookIdentity(saved.webhookUrl);
  if (!savedUrl || savedUrl !== target) return null;
  return saved;
}

function getEffectiveDiscoveryEngineStatus(rawUrl) {
  const hook = normalizeDiscoveryWebhookIdentity(rawUrl);
  if (!hook) {
    return {
      state: DISCOVERY_ENGINE_STATE_NONE,
      tone: "info",
      label: "No discovery webhook configured",
      detail:
        "Pipeline still works without a webhook. Add a real discovery endpoint only if you want the Run discovery button.",
    };
  }

  const saved = getSavedDiscoveryEngineStateForUrl(hook);
  if (saved && saved.state === DISCOVERY_ENGINE_STATE_CONNECTED) {
    return {
      state: DISCOVERY_ENGINE_STATE_CONNECTED,
      tone: "success",
      label: "Discovery endpoint connected",
      detail:
        "Run discovery will POST to your endpoint so your automation can add or update Pipeline rows.",
    };
  }

  if (saved && saved.state === DISCOVERY_ENGINE_STATE_STUB_ONLY) {
    return {
      state: DISCOVERY_ENGINE_STATE_STUB_ONLY,
      tone: "warning",
      label: "Webhook stub connected",
      detail:
        "This endpoint only verifies wiring or appends a [CC test] row. It does not add real job leads.",
    };
  }

  const managedAppsScriptUrl = getManagedAppsScriptWebhookIdentity();
  if (managedAppsScriptUrl && managedAppsScriptUrl === hook) {
    return {
      state: DISCOVERY_ENGINE_STATE_STUB_ONLY,
      tone: "warning",
      label: "Managed Apps Script stub connected",
      detail:
        "The dashboard-deployed Apps Script endpoint is a stub for webhook verification only. Connect a real discovery engine before using Run discovery.",
    };
  }

  return {
    state: DISCOVERY_ENGINE_STATE_UNVERIFIED,
    tone: "info",
    label: "Custom discovery endpoint configured",
    detail:
      "This app can POST to the URL, but it cannot prove the endpoint writes Pipeline rows yet. Make sure it is a real discovery engine, not the default stub.",
  };
}

function buildDiscoveryStatusActions(status) {
  switch (status.state) {
    case DISCOVERY_ENGINE_STATE_STUB_ONLY:
      return [
        {
          label: "Open real discovery paths",
          href: "docs/DISCOVERY-PATHS.md",
          primary: true,
        },
        {
          label: "Open agent discovery guide",
          href: "integrations/openclaw-command-center/README.md",
        },
        {
          label: "Apps Script stub walkthrough",
          href: "integrations/apps-script/WALKTHROUGH.md",
        },
      ];
    case DISCOVERY_ENGINE_STATE_UNVERIFIED:
      return [
        {
          label: "Open AGENT_CONTRACT",
          href: "AGENT_CONTRACT.md",
          primary: true,
        },
        {
          label: "Open discovery paths",
          href: "docs/DISCOVERY-PATHS.md",
        },
      ];
    case DISCOVERY_ENGINE_STATE_CONNECTED:
      return [
        {
          label: "Open AGENT_CONTRACT",
          href: "AGENT_CONTRACT.md",
          primary: true,
        },
        {
          label: "Open discovery paths",
          href: "docs/DISCOVERY-PATHS.md",
        },
      ];
    default:
      return [
        {
          label: "Open discovery paths",
          href: "docs/DISCOVERY-PATHS.md",
          primary: true,
        },
        {
          label: "Open agent discovery guide",
          href: "integrations/openclaw-command-center/README.md",
        },
      ];
  }
}

function refreshDiscoveryUiState() {
  syncDiscoveryButtonState();
  renderDiscoveryEngineStatusUi();
  if (discoveryWizardRuntime) {
    updateDiscoveryWizardRuntime({
      snapshot: getDiscoveryReadinessSnapshot(),
    });
    void renderDiscoverySetupWizard();
  }
  if (!dashboardDataHydrated) return;
  if (document.getElementById("briefInsights")) {
    renderPipelineDailyBrief();
  }
  if (document.getElementById("jobCards")) {
    renderPipeline();
  }
}

async function saveDiscoveryEngineStatePatch(patch) {
  const store = getDiscoveryEngineStateStore();
  const next =
    patch && typeof patch === "object"
      ? patch
      : { state: DISCOVERY_ENGINE_STATE_NONE };
  if (!store) {
    discoveryEngineStateCache = next;
    refreshDiscoveryUiState();
    void refreshDiscoveryReadinessSnapshot({ force: true });
    return next;
  }
  try {
    discoveryEngineStateCache = await store.saveDiscoveryEngineState(next);
  } catch (err) {
    console.warn("[JobBored] discovery engine state:", err);
    discoveryEngineStateCache = next;
  }
  refreshDiscoveryUiState();
  void refreshDiscoveryReadinessSnapshot({ force: true });
  return discoveryEngineStateCache;
}

async function recordDiscoveryEngineState(rawUrl, state, source) {
  const normalizedUrl = normalizeDiscoveryWebhookIdentity(rawUrl);
  if (!normalizedUrl) {
    return saveDiscoveryEngineStatePatch({
      state: DISCOVERY_ENGINE_STATE_NONE,
      webhookUrl: "",
      source: source || "",
      lastCheckedAt: new Date().toISOString(),
    });
  }
  return saveDiscoveryEngineStatePatch({
    state,
    webhookUrl: normalizedUrl,
    source: source || "",
    lastCheckedAt: new Date().toISOString(),
  });
}

async function preloadDiscoveryUiState() {
  const stores = {
    appsScript: getAppsScriptDeployStateStore(),
    discovery: getDiscoveryEngineStateStore(),
  };
  if (stores.appsScript) {
    try {
      appsScriptDeployStateCache =
        await stores.appsScript.getAppsScriptDeployState();
    } catch (err) {
      console.warn("[JobBored] Apps Script deploy state preload:", err);
    }
  }
  if (stores.discovery) {
    try {
      discoveryEngineStateCache =
        await stores.discovery.getDiscoveryEngineState();
    } catch (err) {
      console.warn("[JobBored] discovery engine state preload:", err);
    }
  }
  await refreshDiscoveryReadinessSnapshot({ force: true, rerender: false });
  refreshDiscoveryUiState();
}

function getWindowOriginLabel() {
  try {
    return window.location.origin || "";
  } catch (_) {
    return "";
  }
}

function buildAppsScriptGisNotReadyStatus(clientId) {
  const currentOrigin = getWindowOriginLabel();
  const needsReload = hasUnsavedOAuthClientIdChange(clientId);
  if (needsReload) {
    return {
      tone: "warning",
      message:
        "Save settings to load Google sign-in for this new OAuth client.",
      detail:
        "This page is still running with the previous OAuth config. Save Settings once so the app reloads with the new client ID, then open Settings again and deploy.",
      steps: [
        "Click Save in Settings. The page will reload.",
        "Open Settings again after reload and confirm Google sign-in is ready.",
        `In Google Cloud, make sure this OAuth client is a Web application and includes ${currentOrigin || "this site origin"} under Authorized JavaScript origins.`,
        "After sign-in is ready, Apps Script deploy also needs Google Apps Script API enabled in the same Google Cloud project.",
      ],
      actions: [
        {
          label: "Open OAuth clients in Cloud Console",
          href: "https://console.cloud.google.com/auth/clients",
        },
        {
          label: "Open Apps Script API in Cloud Console",
          href: "https://console.cloud.google.com/apis/library/script.googleapis.com",
        },
      ],
    };
  }

  return {
    tone:
      gisInitStartedAt && Date.now() - gisInitStartedAt >= GIS_INIT_STUCK_MS
        ? "warning"
        : "info",
    message:
      gisInitStartedAt && Date.now() - gisInitStartedAt >= GIS_INIT_STUCK_MS
        ? "Google sign-in did not finish loading."
        : "Google sign-in is still loading.",
    detail:
      gisInitStartedAt && Date.now() - gisInitStartedAt >= GIS_INIT_STUCK_MS
        ? "Google Identity Services did not finish initializing for this page. This is usually an OAuth client origin mismatch, a blocked Google script, or a browser popup/cookie/privacy setting."
        : "Try Deploy again in a moment.",
    steps:
      gisInitStartedAt && Date.now() - gisInitStartedAt >= GIS_INIT_STUCK_MS
        ? [
            "Hard refresh the page once.",
            `In Google Cloud, make sure this OAuth client is a Web application and includes ${currentOrigin || "this site origin"} under Authorized JavaScript origins.`,
            "Allow popups for this site and avoid embedded browser previews that block Google sign-in.",
            "If Sheets sign-in works but Apps Script deploy later fails, then enable Google Apps Script API in the same Google Cloud project.",
          ]
        : [],
    actions: [
      {
        label: "Open OAuth clients in Cloud Console",
        href: "https://console.cloud.google.com/auth/clients",
      },
      {
        label: "Open Apps Script API in Cloud Console",
        href: "https://console.cloud.google.com/apis/library/script.googleapis.com",
      },
    ],
  };
}

function isManagedAppsScriptDeployState(state) {
  return !!(
    state &&
    typeof state === "object" &&
    String(state.managedBy || "") === APPS_SCRIPT_MANAGED_BY &&
    String(state.scriptId || "").trim()
  );
}

function isAppsScriptPublicAccessReady(state) {
  if (!isManagedAppsScriptDeployState(state)) return false;
  const status = String(state.publicAccessState || "").trim();
  if (!status) {
    return !!String(state.webAppUrl || "").trim();
  }
  return status === APPS_SCRIPT_PUBLIC_ACCESS_READY;
}

function getAppsScriptEditorUrl(scriptId) {
  const id = String(scriptId || "").trim();
  if (!id) return "";
  return `https://script.google.com/home/projects/${encodeURIComponent(id)}/edit`;
}

function formatAppsScriptWebAppAccessLabel(raw) {
  switch (String(raw || "").trim()) {
    case "ANYONE_ANONYMOUS":
      return "Anyone";
    case "ANYONE":
      return "Anyone with Google account";
    case "DOMAIN":
      return "Anyone in your Google Workspace domain";
    case "MYSELF":
      return "Only me";
    default:
      return raw ? String(raw).trim() : "unknown";
  }
}

function formatAppsScriptExecuteAsLabel(raw) {
  switch (String(raw || "").trim()) {
    case "USER_DEPLOYING":
      return "Me";
    case "USER_ACCESSING":
      return "User accessing the web app";
    default:
      return raw ? String(raw).trim() : "unknown";
  }
}

function buildAppsScriptPublicAccessRemediationStatus(options) {
  const o = options && typeof options === "object" ? options : {};
  const scriptId = String(o.scriptId || "").trim();
  const webAppUrl = String(o.webAppUrl || "").trim();
  const deploymentAccess = String(o.deploymentAccess || "").trim();
  const deploymentExecuteAs = String(o.deploymentExecuteAs || "").trim();
  const failureKind = String(o.failureKind || "").trim();

  const accessLabel = formatAppsScriptWebAppAccessLabel(deploymentAccess);
  const executeAsLabel = formatAppsScriptExecuteAsLabel(deploymentExecuteAs);

  let detail =
    "JobBored needs anonymous access to this web app before it can use the URL or Cloudflare relay.";

  if (deploymentAccess && deploymentAccess !== APPS_SCRIPT_WEBAPP_ACCESS) {
    detail = `Google has “Who has access” set to ${accessLabel}, not “Anyone.” Change it in Deploy → Manage deployments.`;
  } else if (
    deploymentExecuteAs &&
    deploymentExecuteAs !== APPS_SCRIPT_WEBAPP_EXECUTE_AS
  ) {
    detail = `Google has “Execute as” set to ${executeAsLabel}, not “Me.” Change it in Deploy → Manage deployments.`;
  } else if (failureKind === "probe") {
    detail =
      "Google says the deployment is public, but an anonymous check still failed. Re-save the deployment or run the script once in the editor and approve access.";
  }

  const steps = [
    "Apps Script → Deploy → Manage deployments → edit the web app: Execute as “Me”, Who has access “Anyone”, then Save.",
    "Click Re-check public access below.",
  ];

  const actions = [];
  const editorUrl = getAppsScriptEditorUrl(scriptId);
  if (editorUrl) {
    actions.push({ label: "Open Apps Script project", href: editorUrl });
  }
  if (webAppUrl) {
    actions.push({
      label: "Open web app URL",
      href: webAppUrl,
      primary: true,
    });
  }

  return {
    tone: "error",
    message: "Web app isn’t publicly reachable yet",
    detail,
    steps,
    actions,
  };
}

function openAppsScriptRemediationFlowInSettings() {
  const details = document.getElementById("settingsAppsScriptDetails");
  if (details) details.open = true;
  const statusCard = document.getElementById("settingsAppsScriptStatus");
  if (statusCard && typeof statusCard.scrollIntoView === "function") {
    statusCard.scrollIntoView({ block: "nearest", behavior: "smooth" });
  }
}

function showAppsScriptPublicAccessRemediationFromState() {
  const state = appsScriptDeployStateCache;
  if (!isManagedAppsScriptDeployState(state)) return false;
  if (isAppsScriptPublicAccessReady(state)) return false;

  const status = buildAppsScriptPublicAccessRemediationStatus({
    scriptId: state.scriptId,
    webAppUrl: state.webAppUrl,
    deploymentAccess: state.deploymentAccess || state.access,
    deploymentExecuteAs: state.deploymentExecuteAs || state.executeAs,
    failureKind: state.publicAccessIssue,
  });
  setAppsScriptDeployStatus(status.tone, status.message, status.detail, {
    actions: status.actions,
    steps: status.steps,
  });
  openAppsScriptRemediationFlowInSettings();
  return true;
}

function isLikelyAppsScriptWebAppUrl(raw) {
  const s = raw != null ? String(raw).trim() : "";
  if (!s) return false;
  try {
    const url = new URL(s);
    return (
      url.protocol === "https:" &&
      /(^|\.)script\.google\.com$/i.test(url.hostname) &&
      /\/macros\/s\/[^/]+\/(?:exec|dev)\/?$/i.test(url.pathname)
    );
  } catch (_) {
    return /https:\/\/script\.google\.com\/macros\/s\/[^/]+\/(?:exec|dev)\/?/i.test(
      s,
    );
  }
}

function isLikelyCloudflareWorkerUrl(raw) {
  const s = raw != null ? String(raw).trim() : "";
  if (!s) return false;
  try {
    const url = new URL(s);
    return (
      url.protocol === "https:" &&
      (/\.workers\.dev$/i.test(url.hostname) ||
        /(^|\.)cloudflareworkers\.com$/i.test(url.hostname))
    );
  } catch (_) {
    return /workers\.dev/i.test(s);
  }
}

function inferLocalWebhookPort(raw) {
  const normalized = normalizeDiscoveryLocalWebhookUrl(raw);
  if (!normalized) return "8644";
  try {
    const url = new URL(normalized);
    if (url.port) return url.port;
    return url.protocol === "https:" ? "443" : "80";
  } catch (_) {
    return "8644";
  }
}

function buildDiscoveryTunnelTargetUrl(localWebhookUrl, tunnelPublicUrl) {
  const local = normalizeDiscoveryLocalWebhookUrl(localWebhookUrl);
  const tunnel = normalizeDiscoveryTunnelPublicUrl(tunnelPublicUrl);
  if (!local || !tunnel) return "";
  try {
    const localUrl = new URL(local);
    const tunnelUrl = new URL(tunnel);
    if (/\/webhooks\/[^/]+/i.test(tunnelUrl.pathname)) {
      tunnelUrl.search = "";
      tunnelUrl.hash = "";
      return tunnelUrl.toString();
    }
    tunnelUrl.pathname = localUrl.pathname || "/";
    tunnelUrl.search = "";
    tunnelUrl.hash = "";
    return tunnelUrl.toString();
  } catch (_) {
    return "";
  }
}

function getDiscoveryLocalWebhookHealthUrl(localWebhookUrl) {
  const local = normalizeDiscoveryLocalWebhookUrl(localWebhookUrl);
  if (!local) return "";
  try {
    const url = new URL(local);
    url.pathname = "/health";
    url.search = "";
    url.hash = "";
    return url.toString();
  } catch (_) {
    return "";
  }
}

function getCloudflareRelayTargetInfo() {
  const currentWebhookUrl =
    getSettingsFieldValue("settingsDiscoveryWebhookUrl").trim() ||
    getDiscoveryWebhookUrl();
  const transportSetup = getDiscoveryTransportSetupState();
  const localTunnelTargetUrl = buildDiscoveryTunnelTargetUrl(
    transportSetup.localWebhookUrl,
    transportSetup.tunnelPublicUrl,
  );
  const managedWebAppUrl =
    isAppsScriptPublicAccessReady(appsScriptDeployStateCache) &&
    appsScriptDeployStateCache &&
    typeof appsScriptDeployStateCache.webAppUrl === "string"
      ? appsScriptDeployStateCache.webAppUrl.trim()
      : "";

  if (isLikelyAppsScriptWebAppUrl(currentWebhookUrl)) {
    return { url: currentWebhookUrl, source: "settings" };
  }
  if (isLikelyCloudflareWorkerUrl(currentWebhookUrl) && localTunnelTargetUrl) {
    return {
      url: localTunnelTargetUrl,
      source: "local_tunnel",
      localWebhookUrl: transportSetup.localWebhookUrl,
      tunnelPublicUrl: transportSetup.tunnelPublicUrl,
    };
  }
  if (currentWebhookUrl && !isLikelyCloudflareWorkerUrl(currentWebhookUrl)) {
    return { url: currentWebhookUrl, source: "settings" };
  }
  if (localTunnelTargetUrl) {
    return {
      url: localTunnelTargetUrl,
      source: "local_tunnel",
      localWebhookUrl: transportSetup.localWebhookUrl,
      tunnelPublicUrl: transportSetup.tunnelPublicUrl,
    };
  }
  if (isLikelyAppsScriptWebAppUrl(managedWebAppUrl)) {
    return { url: managedWebAppUrl, source: "managed" };
  }
  if (currentWebhookUrl) return { url: currentWebhookUrl, source: "settings" };
  if (managedWebAppUrl) return { url: managedWebAppUrl, source: "managed" };
  return { url: "", source: "" };
}

function buildCloudflareRelayCorsSnippet(origin) {
  const value =
    origin && origin !== "*" ? origin : "https://your-static-site.example";
  return `[vars]\nCORS_ORIGIN = "${value.replace(/"/g, '\\"')}"`;
}

function sanitizeCloudflareWorkerName(raw) {
  const s = String(raw || "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9-]+/g, "-")
    .replace(/-{2,}/g, "-")
    .replace(/^-+|-+$/g, "");
  return s.slice(0, 63).replace(/^-+|-+$/g, "");
}

function inferCloudflareRelaySuffixFromTarget(targetUrl) {
  const url = String(targetUrl || "").trim();
  if (!url) return "";
  try {
    const parsed = new URL(url);
    const scriptIdMatch = parsed.pathname.match(/\/macros\/s\/([^/]+)/i);
    if (scriptIdMatch && scriptIdMatch[1]) {
      return scriptIdMatch[1].slice(-6).toLowerCase();
    }
    return parsed.hostname.replace(/[^a-z0-9]+/gi, "-").slice(0, 10);
  } catch (_) {
    return "";
  }
}

function getSuggestedCloudflareRelayWorkerName(targetUrl) {
  const suffix =
    inferCloudflareRelaySuffixFromTarget(targetUrl) ||
    String(getSettingsSheetIdValue() || "")
      .slice(-6)
      .toLowerCase() ||
    "main";
  return (
    sanitizeCloudflareWorkerName(`jobbored-discovery-relay-${suffix}`) ||
    "jobbored-discovery-relay"
  );
}

/** First label of *.workers.dev hostname, e.g. jobbored-discovery-relay-abc123. */
function inferCloudflareWorkerNameFromOpenWorkerUrl(raw) {
  const s = String(raw || "").trim();
  if (!s) return "";
  try {
    const u = new URL(s);
    if (!/\.workers\.dev$/i.test(u.hostname)) return "";
    const first = u.hostname.split(".")[0];
    return sanitizeCloudflareWorkerName(first);
  } catch (_) {
    return "";
  }
}

function quoteShellArg(raw) {
  return `'${String(raw || "").replace(/'/g, `'\"'\"'`)}'`;
}

function buildCloudflareRelayDeployCommand(
  targetUrl,
  origin,
  workerName,
  sheetId,
) {
  const parts = ["npm run cloudflare-relay:deploy --"];
  if (targetUrl) {
    parts.push(`--target-url ${quoteShellArg(targetUrl)}`);
  }
  if (origin && origin !== "*") {
    parts.push(`--cors-origin ${quoteShellArg(origin)}`);
  }
  if (workerName) {
    parts.push(`--worker-name ${quoteShellArg(workerName)}`);
  }
  if (sheetId) {
    parts.push(`--sheet-id ${quoteShellArg(sheetId)}`);
  }
  return parts.join(" ");
}

function getDiscoveryRelaySuggestedOrigin() {
  return typeof window !== "undefined" &&
    window.location &&
    typeof window.location.origin === "string" &&
    /^https?:\/\//i.test(window.location.origin)
    ? window.location.origin.trim()
    : "";
}

function getDiscoveryRelayWorkerName(targetUrl, preferredWorkerUrl = "") {
  const currentWorkerUrl =
    normalizeDiscoveryWebhookIdentity(preferredWorkerUrl) ||
    normalizeDiscoveryWebhookIdentity(
      getSettingsFieldValue("settingsDiscoveryWebhookUrl").trim(),
    ) ||
    normalizeDiscoveryWebhookIdentity(getDiscoveryWebhookUrl());
  const explicitWorker =
    inferCloudflareWorkerNameFromOpenWorkerUrl(currentWorkerUrl);
  return explicitWorker || getSuggestedCloudflareRelayWorkerName(targetUrl);
}

function buildDiscoveryRelayDeployCommandForTarget(targetUrl, options = {}) {
  const normalizedTargetUrl = normalizeDiscoveryWebhookIdentity(targetUrl);
  if (!normalizedTargetUrl) return "";
  const explicitWorkerName = sanitizeCloudflareWorkerName(options.workerName);
  const workerName =
    explicitWorkerName ||
    getDiscoveryRelayWorkerName(
      normalizedTargetUrl,
      String(options.workerUrl || ""),
    );
  return buildCloudflareRelayDeployCommand(
    normalizedTargetUrl,
    String(options.origin || "").trim() || getDiscoveryRelaySuggestedOrigin(),
    workerName,
    String(options.sheetId || "").trim() || getSettingsSheetIdValue() || "",
  );
}

function createDiscoveryRelayCopyCommandToastAction(command) {
  const text = String(command || "").trim();
  if (!text) return null;
  return {
    label: "Copy command",
    onClick() {
      copyTextToClipboard(text);
    },
  };
}

function buildCloudflareRelayAgentPrompt(
  targetUrl,
  origin,
  workerName,
  sheetId,
) {
  if (!targetUrl) {
    return `We’re in the Job-Bored repo.\n\nStop: no Apps Script /exec URL is configured yet, so there is no downstream TARGET_URL for the Cloudflare relay.\n\nAsk the user to finish Apps Script deploy first, then rerun relay setup.`;
  }
  const deployCommand = buildCloudflareRelayDeployCommand(
    targetUrl,
    origin,
    workerName,
    sheetId,
  );
  const verifyLine = sheetId
    ? "5. Because the command includes `--sheet-id`, the helper should also run the webhook verification step automatically after deploy."
    : "5. After it succeeds, tell me to paste the Worker URL into Settings -> Discovery webhook URL and run Test webhook.";
  return `We’re in the Job-Bored repo. Set up the Cloudflare Worker relay for Command Center discovery.\n\nCurrent values:\n- TARGET_URL: ${targetUrl}\n- CORS_ORIGIN: ${origin || "*"}\n- Suggested worker name: ${workerName}\n\nDo this:\n1. Run this command from the repo root:\n   ${deployCommand}\n2. If Cloudflare auth is missing, let the helper script open \`wrangler login\` automatically. If that still cannot work, then tell me exactly whether you need \`npx wrangler login\` manually or \`CLOUDFLARE_API_TOKEN\` + \`CLOUDFLARE_ACCOUNT_ID\`.\n3. Return the deployed \`workers.dev\` URL only.\n4. Do not use \`/forward\` or \`FORWARD_SECRET\` for this dashboard path, and keep Cloudflare Access disabled on the open \`workers.dev\` URL.\n${verifyLine}\n\nIf the script stops at a one-time \`workers.dev\` subdomain prompt, tell me which path applies:\n- browser-login path: I should answer the prompt once in the terminal\n- API-token path: rerun with \`CLOUDFLARE_API_TOKEN\`; the helper can then reuse or create the account subdomain automatically.`;
}

function describeCloudflareAccessProtectedWebhook(status, text, responseUrl) {
  const body = String(text || "");
  const url = String(responseUrl || "");
  const combined = `${url}\n${body}`;
  if (
    !/cloudflare access|cloudflareaccess\.com|cdn-cgi\/access\/login|access\.cloudflare/i.test(
      combined,
    )
  ) {
    return "";
  }
  if (
    Number(status) !== 200 &&
    Number(status) !== 302 &&
    Number(status) !== 401 &&
    Number(status) !== 403
  ) {
    return "";
  }
  return "This Worker URL is protected by Cloudflare Access. Disable Cloudflare Access for the open workers.dev URL, then test again.";
}

function describeAppsScriptHtmlAccessIssue(status, text) {
  const body = String(text || "");
  if (Number(status) !== 403) return "";
  if (
    !/you need access/i.test(body) &&
    !/open the document directly/i.test(body) &&
    !/script\.google\.com\/macros\/edit\?lib=/i.test(body)
  ) {
    return "";
  }
  return 'Google is rejecting anonymous access to the Apps Script web app. Open the Apps Script deployment and confirm Execute as is "Me" and Who has access is "Anyone", then re-check public access.';
}

function isAppsScriptWebhookStubResponse(data) {
  return !!(
    data &&
    typeof data === "object" &&
    data.ok === true &&
    (data.service === "command-center-apps-script-stub" ||
      data.mode === "stub" ||
      (data.received === true &&
        data.realDiscoveryConfigured === false &&
        Object.prototype.hasOwnProperty.call(data, "appendedTestRow")))
  );
}

function isAsyncDiscoveryAcceptedResponse(data, status) {
  const httpStatus = Number(status);
  if (!data || typeof data !== "object") return false;
  if (data.ok === true) return false;
  if (httpStatus !== 202 && httpStatus !== 200) return false;
  return !!(
    String(data.status || "").toLowerCase() === "accepted" ||
    data.accepted === true ||
    String(data.event || "").toLowerCase() === "command-center.discovery" ||
    Object.prototype.hasOwnProperty.call(data, "delivery_id")
  );
}

function buildDiscoverySuccessToast(data, options) {
  const o = options && typeof options === "object" ? options : {};
  const isTest = !!o.isTest;
  const acceptedAsync = isAsyncDiscoveryAcceptedResponse(data, o.status);
  if (isAppsScriptWebhookStubResponse(data)) {
    if (data.appendedTestRow === true) {
      return {
        type: "info",
        persistent: true,
        message: isTest
          ? "Stub OK — appended a [CC test] row. This confirms webhook wiring only; it does not find real jobs."
          : "Stub received the request and appended a [CC test] row. This confirms webhook wiring only; no real job discovery is configured yet.",
      };
    }
    return {
      type: "info",
      persistent: true,
      message: isTest
        ? "Stub OK — endpoint is wired, but it will not add jobs. Set ENABLE_TEST_ROW=true for a smoke test, or replace the stub with real discovery logic."
        : "The current endpoint is the Apps Script stub. It accepted the request, but it does not add real job leads. Set ENABLE_TEST_ROW=true for a smoke test, or replace the stub with real discovery logic.",
    };
  }
  if (acceptedAsync) {
    return {
      type: "success",
      persistent: false,
      message: isTest
        ? "Webhook accepted — your automation queued the run"
        : "Discovery accepted — your automation queued the run",
    };
  }
  return {
    type: "success",
    persistent: false,
    message: isTest
      ? "Webhook OK — endpoint returned ok: true"
      : "Discovery started — new roles will appear in your sheet when your agent finishes",
  };
}

function getDiscoveryWizardRoot() {
  return window.JobBoredDiscoveryWizard || null;
}

function getDiscoveryWizardShellApi() {
  const root = getDiscoveryWizardRoot();
  return root && root.shell ? root.shell : null;
}

function getDiscoveryWizardProbesApi() {
  const root = getDiscoveryWizardRoot();
  return root && root.probes ? root.probes : null;
}

function getDiscoveryWizardLocalApi() {
  const root = getDiscoveryWizardRoot();
  const backup =
    typeof window !== "undefined" ? window.__JobBoredDiscoveryLocalApi : null;
  if (backup && typeof backup.runLocalWizardAction === "function") {
    if (root) {
      root.local = backup;
    }
    return backup;
  }
  if (
    root &&
    root.local &&
    typeof root.local.runLocalWizardAction === "function"
  ) {
    return root.local;
  }
  return null;
}

function getDiscoveryWizardRelayApi() {
  const root = getDiscoveryWizardRoot();
  return root && root.relay ? root.relay : null;
}

function getDiscoveryWizardVerifyApi() {
  const root = getDiscoveryWizardRoot();
  return root && root.verify ? root.verify : null;
}

function mapDiscoveryWizardFlow(rawFlow) {
  const flow = String(rawFlow || "").trim();
  if (flow === "existing_endpoint" || flow === "external_endpoint") {
    return "external_endpoint";
  }
  if (flow === "no_webhook") return "no_webhook";
  if (flow === "stub_only") return "stub_only";
  return "local_agent";
}

function getFallbackAppsScriptState() {
  if (!appsScriptDeployStateCache) return "none";
  if (
    isManagedAppsScriptDeployState(appsScriptDeployStateCache) &&
    isAppsScriptPublicAccessReady(appsScriptDeployStateCache)
  ) {
    return "stub_only";
  }
  return isManagedAppsScriptDeployState(appsScriptDeployStateCache)
    ? "unverified"
    : "none";
}

function classifySavedWebhookKindForFallback(rawUrl) {
  const probes = getDiscoveryWizardProbesApi();
  if (probes && typeof probes.classifySavedWebhookKind === "function") {
    return probes.classifySavedWebhookKind(rawUrl);
  }
  const url = normalizeDiscoveryWebhookIdentity(rawUrl);
  if (!url) return "none";
  if (
    normalizeDiscoveryLocalWebhookUrl(url) &&
    /^https?:\/\//i.test(normalizeDiscoveryLocalWebhookUrl(url))
  ) {
    return "local_http";
  }
  if (isLikelyAppsScriptWebAppUrl(url)) return "apps_script_stub";
  if (isLikelyCloudflareWorkerUrl(url)) return "worker";
  return /^https?:\/\//i.test(url) ? "generic_https" : "none";
}

function getDiscoveryLocalEngineKind(snapshot) {
  const state = snapshot && typeof snapshot === "object" ? snapshot : {};
  const explicit = String(state.localEngineKind || "")
    .trim()
    .toLowerCase();
  if (explicit === "browser_use_worker") return "browser_use_worker";
  if (explicit === "hermes") return "hermes";
  if (explicit === "other") return "other";

  const localWebhookUrl = normalizeDiscoveryLocalWebhookUrl(
    state.localWebhookUrl || "",
  );
  if (/\/webhook\/?$/i.test(localWebhookUrl)) return "browser_use_worker";
  if (/\/webhooks\/[^/]+/i.test(localWebhookUrl)) return "hermes";
  return localWebhookUrl ? "other" : "none";
}

function getDiscoveryLocalEngineLabel(snapshot) {
  const kind = getDiscoveryLocalEngineKind(snapshot);
  if (kind === "browser_use_worker") return "Browser-use worker";
  if (kind === "hermes") return "Hermes route";
  if (kind === "other") return "Local discovery service";
  return "";
}

function getDiscoveryLocalEngineSummary(snapshot) {
  const state = snapshot && typeof snapshot === "object" ? snapshot : {};
  const label = getDiscoveryLocalEngineLabel(state);
  if (!label) return "not confirmed";
  if (state.localWebhookUrl) return `${label} (${state.localWebhookUrl})`;
  return label;
}

function getDiscoveryRecoveryCopy(snapshot) {
  const probesApi =
    window.JobBoredDiscoveryWizard && window.JobBoredDiscoveryWizard.probes;
  if (probesApi && typeof probesApi.buildRecoveryCopy === "function") {
    return probesApi.buildRecoveryCopy(snapshot);
  }
  const recovery = String((snapshot && snapshot.localRecoveryState) || "ok");
  const detailMap = {
    needs_full_restart:
      "Your computer restarted, so the local worker and tunnel need to be brought back up.",
    worker_down:
      "The local discovery worker is not responding. It may need to be restarted.",
    tunnel_down:
      "The public ngrok tunnel is not running, so the saved Worker URL cannot reach your local worker right now.",
    tunnel_rotated:
      "ngrok gave your local setup a new public URL, so the relay behind your saved Worker URL needs to be redeployed.",
  };
  const detail =
    detailMap[recovery] ||
    "Part of the local discovery chain is down after a restart.";
  return {
    title:
      recovery === "tunnel_rotated"
        ? "Public tunnel changed"
        : "Local setup needs recovery",
    detail,
    compactDetail: detail,
    actionHint:
      "Click Fix setup to restart what is down and redeploy the relay if needed.",
    detectBody: [detail],
  };
}

function buildFallbackSettingsDiscoveryView(snapshot) {
  const status = getEffectiveDiscoveryEngineStatus(snapshot.savedWebhookUrl);
  const kind = String(snapshot.savedWebhookKind || "none");
  const appsScriptState = String(snapshot.appsScriptState || "none");
  const recovery = snapshot.localRecoveryState || "ok";
  const recoveryCopy = getDiscoveryRecoveryCopy(snapshot);
  const hasSavedExternalEndpoint =
    kind === "worker" || kind === "generic_https";
  const stubCurrent =
    status.state === DISCOVERY_ENGINE_STATE_STUB_ONLY ||
    kind === "apps_script_stub";

  if (
    recovery !== "ok" &&
    (status.state === DISCOVERY_ENGINE_STATE_CONNECTED ||
      hasSavedExternalEndpoint)
  ) {
    return {
      tone: "warning",
      title: recoveryCopy.title,
      detail: recoveryCopy.compactDetail,
      chipLabel: "Needs recovery",
      chipTone: "warning",
      runDiscoveryEnabled: false,
      primaryActionLabel: "Fix setup",
      primaryActionHint: recoveryCopy.actionHint,
    };
  }

  if (
    status.state === DISCOVERY_ENGINE_STATE_CONNECTED ||
    status.state === DISCOVERY_ENGINE_STATE_UNVERIFIED ||
    hasSavedExternalEndpoint
  ) {
    const verified = status.state === DISCOVERY_ENGINE_STATE_CONNECTED;
    return {
      tone: verified ? "success" : "warning",
      title: verified ? "Discovery is connected" : "Discovery endpoint saved",
      detail: verified
        ? "Run discovery will POST to the public endpoint already saved in JobBored."
        : "A public webhook is already saved. Test it if you changed the service.",
      chipLabel: verified ? "Connected" : "Ready to test",
      chipTone: verified ? "success" : "warning",
      runDiscoveryEnabled: true,
      primaryActionLabel: "Open discovery setup",
      primaryActionHint:
        "Use the wizard to review or change your discovery path.",
    };
  }

  if (kind === "local_http") {
    const engineLabel = getDiscoveryLocalEngineLabel(snapshot);
    return {
      tone: "info",
      title: engineLabel
        ? `${engineLabel} detected`
        : "Local receiver detected",
      detail: engineLabel
        ? `Complete the local server, tunnel, and relay steps to finish setup for ${engineLabel}.`
        : "Complete the server, tunnel, and relay steps to finish setup.",
      chipLabel: "Local path",
      chipTone: "info",
      runDiscoveryEnabled: false,
      primaryActionLabel: "Open discovery setup",
      primaryActionHint: "Continue the local setup path.",
    };
  }

  if (stubCurrent || appsScriptState === "stub_only") {
    return {
      tone: "warning",
      title: "Apps Script stub wired",
      detail:
        "This path can smoke-test webhook wiring, but it is not your real discovery engine.",
      chipLabel: "Stub only",
      chipTone: "warning",
      runDiscoveryEnabled: false,
      primaryActionLabel: "Open discovery setup",
      primaryActionHint: "Switch to a real webhook if you want Run discovery.",
    };
  }

  return {
    tone: "info",
    title: "No discovery webhook configured",
    detail:
      "Pipeline works without discovery. Use the wizard only if you want automated runs.",
    chipLabel: "No webhook",
    chipTone: "info",
    runDiscoveryEnabled: false,
    primaryActionLabel: "Open discovery setup",
    primaryActionHint:
      "Use the wizard to review or change your discovery path.",
  };
}

function buildFallbackEmptyStateDiscoveryView(snapshot) {
  const status = getEffectiveDiscoveryEngineStatus(snapshot.savedWebhookUrl);
  const kind = String(snapshot.savedWebhookKind || "none");
  const appsScriptState = String(snapshot.appsScriptState || "none");
  const recovery = snapshot.localRecoveryState || "ok";
  const recoveryCopy = getDiscoveryRecoveryCopy(snapshot);
  const hasSavedExternalEndpoint =
    kind === "worker" || kind === "generic_https";
  const stubCurrent =
    status.state === DISCOVERY_ENGINE_STATE_STUB_ONLY ||
    kind === "apps_script_stub";

  if (
    recovery !== "ok" &&
    (status.state === DISCOVERY_ENGINE_STATE_CONNECTED ||
      hasSavedExternalEndpoint)
  ) {
    return {
      title: recoveryCopy.title,
      body: `${recoveryCopy.compactDetail} Use Fix setup to recover it.`,
      ctaLabel: "Fix setup",
      ctaAction: "open_setup",
    };
  }

  if (status.state === DISCOVERY_ENGINE_STATE_CONNECTED) {
    return {
      title: "Pipeline is ready",
      body: "No roles yet. When your automation runs, new rows will appear here. You can also run discovery on demand.",
      ctaLabel: "Run discovery now",
      ctaAction: "run_discovery",
    };
  }
  if (
    status.state === DISCOVERY_ENGINE_STATE_UNVERIFIED ||
    hasSavedExternalEndpoint
  ) {
    return {
      title: "Endpoint saved, verification pending",
      body: "A public webhook is already saved, but JobBored has not confirmed the full end-to-end path yet.",
      ctaLabel: "Open discovery setup",
      ctaAction: "open_setup",
    };
  }
  if (kind === "local_http") {
    const engineLabel = getDiscoveryLocalEngineLabel(snapshot);
    return {
      title: engineLabel
        ? `${engineLabel} not finished`
        : "Local discovery path not finished",
      body: engineLabel
        ? `${engineLabel} is known, but the public tunnel or Worker URL still needs to be finished.`
        : "Your local receiver is known, but the public tunnel or Worker URL still needs to be finished.",
      ctaLabel: "Continue setup",
      ctaAction: "open_setup",
    };
  }
  if (stubCurrent || appsScriptState === "stub_only") {
    return {
      title: "Stub-only wiring detected",
      body: "The current webhook confirms wiring only. Connect a real discovery engine before expecting new job leads.",
      ctaLabel: "Connect real discovery",
      ctaAction: "open_setup",
    };
  }
  return {
    title: "Pipeline is empty",
    body: "Pipeline works without discovery, but you can use the wizard if you want Run discovery or guided setup.",
    ctaLabel: "Open discovery setup",
    ctaAction: "open_setup",
  };
}

function buildFallbackReadinessSnapshot() {
  const transport = getDiscoveryTransportSetupState();
  const savedWebhookUrl = normalizeDiscoveryWebhookIdentity(
    getDiscoveryWebhookUrl(),
  );
  const savedWebhookKind = classifySavedWebhookKindForFallback(savedWebhookUrl);
  const relayTargetUrl = buildDiscoveryTunnelTargetUrl(
    transport.localWebhookUrl,
    transport.tunnelPublicUrl,
  );
  const engineStatus = getEffectiveDiscoveryEngineStatus(savedWebhookUrl);
  const appsScriptState = getFallbackAppsScriptState();
  const hasSavedExternalEndpoint =
    savedWebhookKind === "worker" || savedWebhookKind === "generic_https";
  const hasSavedStubEndpoint = savedWebhookKind === "apps_script_stub";
  const hasLocalPathSignals =
    savedWebhookKind === "local_http" ||
    !!transport.localWebhookUrl ||
    !!transport.tunnelPublicUrl;
  let recommendedFlow = "local_agent";
  let recommendedReason =
    "No public webhook is saved yet, so start with the path you want to use.";
  if (
    hasSavedExternalEndpoint ||
    engineStatus.state === DISCOVERY_ENGINE_STATE_CONNECTED
  ) {
    recommendedFlow = "existing_endpoint";
    recommendedReason =
      savedWebhookKind === "worker"
        ? "A Cloudflare Worker URL is already saved."
        : "A public HTTPS webhook is already saved.";
  } else if (hasLocalPathSignals) {
    recommendedFlow = "local_agent";
    recommendedReason =
      getDiscoveryLocalEngineKind({
        localWebhookUrl: transport.localWebhookUrl || "",
      }) === "hermes"
        ? "A local Hermes route was detected on this machine. It can work, but the browser-use worker is the recommended default."
        : "A local browser-use worker or local discovery path was detected on this machine.";
  } else if (hasSavedStubEndpoint) {
    recommendedFlow = "stub_only";
    recommendedReason =
      "Only the Apps Script stub is saved — good for testing.";
  } else if (appsScriptState === "stub_only") {
    recommendedFlow = "local_agent";
    recommendedReason =
      "An Apps Script stub exists, but it's not your main discovery path.";
  }
  const snapshot = {
    sheetConfigured: !!SHEET_ID,
    savedWebhookUrl,
    savedWebhookKind,
    localBootstrapAvailable: false,
    localWebhookUrl: transport.localWebhookUrl || "",
    localWebhookReady: false,
    tunnelPublicUrl: transport.tunnelPublicUrl || "",
    tunnelLive: false,
    tunnelReady: false,
    tunnelStale: false,
    relayTargetUrl,
    relayReady: savedWebhookKind === "worker",
    engineState: engineStatus.state,
    appsScriptState,
    recommendedFlow,
    recommendedReason,
    blockingIssue: !SHEET_ID
      ? "missing_sheet"
      : hasSavedStubEndpoint
        ? "stub_only"
        : "",
    localRecoveryState:
      hasLocalPathSignals || savedWebhookKind === "worker"
        ? "needs_full_restart"
        : "ok",
  };
  return {
    ...snapshot,
    views: {
      settings: buildFallbackSettingsDiscoveryView(snapshot),
      emptyState: buildFallbackEmptyStateDiscoveryView(snapshot),
    },
    wizardState: null,
  };
}

function getDiscoveryReadinessSnapshot() {
  return discoveryReadinessSnapshotCache || buildFallbackReadinessSnapshot();
}

function getDiscoverySettingsView(snapshot) {
  const state =
    snapshot && typeof snapshot === "object"
      ? snapshot
      : getDiscoveryReadinessSnapshot();
  if (
    state.views &&
    state.views.settings &&
    typeof state.views.settings === "object"
  ) {
    return state.views.settings;
  }
  const probes = getDiscoveryWizardProbesApi();
  if (probes && typeof probes.buildSettingsDiscoveryView === "function") {
    return probes.buildSettingsDiscoveryView(state);
  }
  return buildFallbackSettingsDiscoveryView(state);
}

function getDiscoveryEmptyStateView(snapshot) {
  const state =
    snapshot && typeof snapshot === "object"
      ? snapshot
      : getDiscoveryReadinessSnapshot();
  if (
    state.views &&
    state.views.emptyState &&
    typeof state.views.emptyState === "object"
  ) {
    return state.views.emptyState;
  }
  const probes = getDiscoveryWizardProbesApi();
  if (probes && typeof probes.buildEmptyStateDiscoveryView === "function") {
    return probes.buildEmptyStateDiscoveryView(state);
  }
  return buildFallbackEmptyStateDiscoveryView(state);
}

async function refreshDiscoveryReadinessSnapshot(options = {}) {
  if (discoveryReadinessSnapshotPromise && !options.force) {
    return discoveryReadinessSnapshotPromise;
  }
  const buildFallback = () => buildFallbackReadinessSnapshot();
  const probes = getDiscoveryWizardProbesApi();
  discoveryReadinessSnapshotPromise = Promise.resolve()
    .then(async () => {
      if (probes && typeof probes.buildReadinessSnapshot === "function") {
        return probes.buildReadinessSnapshot();
      }
      return buildFallback();
    })
    .then((snapshot) => {
      discoveryReadinessSnapshotCache =
        snapshot && typeof snapshot === "object" ? snapshot : buildFallback();
      return discoveryReadinessSnapshotCache;
    })
    .catch((err) => {
      console.warn("[JobBored] discovery readiness snapshot:", err);
      discoveryReadinessSnapshotCache = buildFallback();
      return discoveryReadinessSnapshotCache;
    })
    .finally(() => {
      discoveryReadinessSnapshotPromise = null;
    });
  const next = await discoveryReadinessSnapshotPromise;
  if (options.rerender !== false) {
    refreshDiscoveryUiState();
  }
  return next;
}

async function buildDiscoveryWebhookPayload(sheetIdOverride) {
  const resolvedSheetId =
    parseGoogleSheetId(String(sheetIdOverride || "")) || SHEET_ID || "";
  let discoveryProfile = {};
  try {
    const UC = window.CommandCenterUserContent;
    if (UC && typeof UC.getDiscoveryProfile === "function") {
      discoveryProfile = await UC.getDiscoveryProfile();
    }
  } catch (e) {
    console.warn("[JobBored] discovery profile:", e);
  }
  // Hand the user's existing GIS access token to the worker so it can write
  // to Google Sheets without holding any persistent credential of its own.
  // This is the "no hoops" path: if the user is signed in to the dashboard,
  // discovery just works — no service account, no .env wiring, no Hermes
  // archaeology. The worker treats this token as the highest-precedence
  // credential and falls back to its env config if it's absent or stale.
  // We declare the key unconditionally so JSON.stringify drops it when
  // empty (keeps the contract scanner happy and the wire format unchanged).
  const dashboardGoogleAccessToken = getDiscoveryRequestGoogleAccessToken();
  // ====== [discovery-autodetect lane: contract sanitization] ======
  // Per .factory/library/source-preset-contract.md: "Omitted sourcePreset →
  // passes validation; fallback resolved by config resolver." But sending
  // `sourcePreset: ""` (empty string) is rejected by the worker because the
  // field is *present* but not in the enum. A fresh greenfield user has an
  // empty discovery profile object, so getDiscoveryProfile() returns {} and
  // any code path that defaulted sourcePreset to "" would trip the
  // validator. Strip empty/whitespace sourcePreset before sending.
  //
  // Symptom this fixes: Step 7 wizard "Run test" returning
  //   "discoveryProfile.sourcePreset must be one of: browser_only, ats_only,
  //    browser_plus_ats. Received: ''."
  if (
    discoveryProfile &&
    typeof discoveryProfile === "object" &&
    Object.prototype.hasOwnProperty.call(discoveryProfile, "sourcePreset")
  ) {
    const sp = discoveryProfile.sourcePreset;
    const trimmed = typeof sp === "string" ? sp.trim() : sp;
    if (
      trimmed === "" ||
      trimmed == null ||
      typeof trimmed !== "string"
    ) {
      // Clone so we never mutate the stored profile in IndexedDB.
      const sanitized = { ...discoveryProfile };
      delete sanitized.sourcePreset;
      discoveryProfile = sanitized;
    } else if (trimmed !== sp) {
      discoveryProfile = { ...discoveryProfile, sourcePreset: trimmed };
    }
  }
  // ====== [/discovery-autodetect lane] ======
  return {
    event: "command-center.discovery",
    schemaVersion: 1,
    sheetId: resolvedSheetId,
    variationKey: generateDiscoveryVariationKey(),
    requestedAt: new Date().toISOString(),
    discoveryProfile,
    googleAccessToken: dashboardGoogleAccessToken || undefined,
  };
}

/**
 * Returns the dashboard's current Google access token IFF the user is signed
 * in AND the token has at least 60 seconds of lifetime left. Anything less
 * isn't worth sending — discovery runs typically take 20–60s and a token that
 * expires mid-run will fail at the Sheets write step.
 */
function getDiscoveryRequestGoogleAccessToken() {
  if (!accessToken || typeof accessToken !== "string") return "";
  const trimmed = accessToken.trim();
  if (!trimmed) return "";
  if (Number.isFinite(tokenExpiresAt)) {
    const remainingMs = Number(tokenExpiresAt) - Date.now();
    if (remainingMs < 60_000) return "";
  }
  return trimmed;
}

function getDiscoveryEngineStateFromVerificationResult(result) {
  if (!result || result.ok !== true) return "";
  if (result.kind === "stub_only") return DISCOVERY_ENGINE_STATE_STUB_ONLY;
  if (result.kind === "accepted_async")
    return DISCOVERY_ENGINE_STATE_UNVERIFIED;
  if (result.kind === "connected_ok") return DISCOVERY_ENGINE_STATE_CONNECTED;
  return result.engineState || DISCOVERY_ENGINE_STATE_UNVERIFIED;
}

function showDiscoveryVerificationToast(result, options = {}) {
  if (!result || typeof result !== "object") return;
  const context = String(options.context || "test_webhook").trim();
  const isRun = context === "run_discovery";
  let type = "info";
  let persistent = false;
  if (result.ok) {
    if (result.kind === "stub_only") {
      type = "info";
      persistent = true;
    } else {
      type = "success";
    }
  } else {
    type = "error";
    persistent = true;
  }
  const detail =
    !result.ok && result.detail && result.detail !== result.message
      ? ` ${result.detail}`
      : "";
  const fallback = isRun
    ? "Discovery verification finished."
    : "Webhook verification finished.";

  let action;
  if (!result.ok && result.kind === "auth_required") {
    // The browser-use worker fail-closed because the secret is missing or
    // wrong. The fix is "run bootstrap and reload" — give the user a copy
    // button for the command so they don't have to retype it.
    action = {
      label: "Copy bootstrap command",
      onClick: () => {
        copyTextToClipboard(
          result.suggestedCommand || "npm run discovery:bootstrap-local",
        );
      },
    };
  } else if (!result.ok && isLocalDashboardOrigin()) {
    const hasLocalTunnel = !!getDiscoveryTransportSetupState().tunnelPublicUrl;
    const endpointUrl = options.endpointUrl || "";
    const isTunnelFailure =
      result.layer === "downstream" ||
      (result.kind === "network_error" &&
        isLikelyCloudflareWorkerUrl(endpointUrl)) ||
      (result.kind === "network_error" && hasLocalTunnel) ||
      (/ngrok|tunnel|offline/i.test(result.detail || "") && hasLocalTunnel);
    if (isTunnelFailure) {
      action = {
        label: "Fix tunnel",
        onClick: () => {
          void requestDiscoverySetup({
            entryPoint: "settings",
            flow: "local_agent",
            startStep: "tunnel",
            allowWhileOnboarding: true,
          });
        },
      };
    }
  }

  showToast(
    `${result.message || fallback}${detail}`.trim(),
    type,
    persistent,
    action,
  );
}

async function verifyDiscoveryWebhookWithSharedModel(
  url,
  payload,
  options = {},
) {
  const verifyApi = getDiscoveryWizardVerifyApi();
  const secret =
    typeof options.secret === "string" && options.secret.trim()
      ? options.secret.trim()
      : getDiscoveryWebhookSecret();
  if (verifyApi && typeof verifyApi.verifyDiscoveryEndpoint === "function") {
    return verifyApi.verifyDiscoveryEndpoint(url, {
      payload,
      context: options.context || "test_webhook",
      sheetId: options.sheetId || "",
      timeoutMs: options.timeoutMs || 15000,
      secret,
    });
  }
  return {
    ok: false,
    kind: "invalid_endpoint",
    engineState: "none",
    httpStatus: 0,
    message: "Discovery verifier is not available.",
    detail: "Reload the page and try again.",
    layer: "browser",
  };
}

function getDiscoveryWizardDefaultDrafts(snapshot) {
  const state =
    snapshot && typeof snapshot === "object"
      ? snapshot
      : getDiscoveryReadinessSnapshot();
  return {
    endpointUrl: state.savedWebhookUrl || getDiscoveryWebhookUrl() || "",
    workerUrl: isLikelyCloudflareWorkerUrl(state.savedWebhookUrl)
      ? state.savedWebhookUrl
      : "",
  };
}

function createDiscoveryWizardRuntime(patch = {}) {
  const next = {
    entryPoint: "manual",
    snapshot: getDiscoveryReadinessSnapshot(),
    state: {
      version: 1,
      flow: "local_agent",
      currentStep: "detect",
      completedSteps: [],
      transportMode: "",
      lastProbeAt: "",
      lastVerifiedAt: "",
      result: "none",
      dismissedStubWarning: false,
    },
    activeStepId: "detect",
    drafts: getDiscoveryWizardDefaultDrafts(getDiscoveryReadinessSnapshot()),
    lastLocalResult: null,
    lastRelayResult: null,
    lastRelayModel: null,
    lastVerificationResult: null,
    lastDownstreamDiagnosis: null,
    lastWizardMessage: "",
    lastWizardMessageTone: "info",
    localBootstrapState: null,
    flowProgressCache: {},
    ...patch,
  };
  next.state = {
    ...(next.state || {}),
    flow: mapDiscoveryWizardFlow(next.state && next.state.flow),
  };
  next.activeStepId = next.activeStepId || next.state.currentStep || "detect";
  next.drafts = {
    ...getDiscoveryWizardDefaultDrafts(next.snapshot),
    ...(patch.drafts && typeof patch.drafts === "object" ? patch.drafts : {}),
  };
  return next;
}

function getDiscoveryWizardRuntime() {
  if (!discoveryWizardRuntime) {
    discoveryWizardRuntime = createDiscoveryWizardRuntime();
  }
  return discoveryWizardRuntime;
}

function updateDiscoveryWizardRuntime(patch = {}) {
  const current = getDiscoveryWizardRuntime();
  discoveryWizardRuntime = createDiscoveryWizardRuntime({
    ...current,
    ...patch,
    state: {
      ...(current.state || {}),
      ...(patch.state && typeof patch.state === "object" ? patch.state : {}),
    },
    drafts: {
      ...(current.drafts || {}),
      ...(patch.drafts && typeof patch.drafts === "object" ? patch.drafts : {}),
    },
    flowProgressCache: {
      ...(current.flowProgressCache || {}),
      ...(patch.flowProgressCache && typeof patch.flowProgressCache === "object"
        ? patch.flowProgressCache
        : {}),
    },
  });
  return discoveryWizardRuntime;
}

function createWizardNode(tag, className, text) {
  const el = document.createElement(tag);
  if (className) el.className = className;
  if (text != null) el.textContent = text;
  return el;
}

function appendWizardParagraph(
  parent,
  text,
  className = "discovery-setup-wizard__copy",
) {
  if (!text) return null;
  const p = createWizardNode("p", className, text);
  parent.appendChild(p);
  return p;
}

function appendWizardList(parent, items) {
  const list = createWizardNode("ul", "discovery-setup-wizard__list");
  items.filter(Boolean).forEach((item) => {
    const li = document.createElement("li");
    li.textContent = item;
    list.appendChild(li);
  });
  parent.appendChild(list);
  return list;
}

function appendWizardCodeBlock(parent, text, copyLabel = "Copy") {
  if (!text) return null;
  const row = createWizardNode("div", "scraper-setup-copyrow");
  const code = createWizardNode("pre", "scraper-setup-code", text);
  const button = createWizardNode("button", "btn-copy-scraper", copyLabel);
  button.type = "button";
  button.addEventListener("click", () => {
    copyTextToClipboard(text);
  });
  row.append(code, button);
  parent.appendChild(row);
  return row;
}

/**
 * Resolve the user's local repo root from bootstrap state. Returns "" if
 * unknown — callers should fall back gracefully (e.g. omit the cd prefix).
 */
function getDiscoveryRepoRoot(runtime) {
  const data =
    runtime &&
    runtime.localBootstrapState &&
    runtime.localBootstrapState.data;
  return (data && typeof data.repoRoot === "string" && data.repoRoot) || "";
}

/**
 * Build a "cd <repo> && <cmd>" combined command so the user can paste it into
 * any Terminal window — no need to navigate to the repo first. Quotes the
 * path to handle spaces. Returns the bare command if repoRoot is unknown.
 */
function buildRunInRepoCommand(repoRoot, cmd) {
  const c = String(cmd || "").trim();
  if (!c) return "";
  const root = String(repoRoot || "").trim();
  if (!root) return c;
  // Quote the path; escape any embedded double-quote (rare).
  const safe = root.replace(/"/g, '\\"');
  return `cd "${safe}" && ${c}`;
}

/**
 * Trigger a download of a macOS .command script that opens Terminal in the
 * repo and runs the given command. macOS-only delight: double-click and go.
 * On other OSes the file just won't open (Terminal-specific extension).
 */
function downloadDiscoveryRunCommandFile(repoRoot, cmd, suggestedName) {
  const c = String(cmd || "").trim();
  if (!c) return;
  const root = String(repoRoot || "").trim();
  const lines = [
    "#!/bin/bash",
    "# Generated by JobBored discovery setup wizard.",
    "# Double-click to run: opens Terminal here and executes the command.",
    "set -e",
  ];
  if (root) {
    const safe = root.replace(/"/g, '\\"');
    lines.push(`cd "${safe}"`);
  }
  lines.push(c);
  // Keep terminal open after the command exits so the user can read output.
  lines.push("echo");
  lines.push('echo "[JobBored] Done. You can close this window."');
  const body = lines.join("\n") + "\n";
  const blob = new Blob([body], { type: "text/x-shellscript" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = suggestedName || "jobbored-run.command";
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1500);
  showToast(
    "Downloaded. On macOS: right-click → Open the first time (Gatekeeper). After that, double-click to run.",
    "info",
    true,
  );
}

/**
 * Append a "run-in-terminal" block: combined cd+command with a Copy button
 * AND (on capable browsers) a "Download .command" delight button that opens
 * Terminal in the repo and runs the command on double-click. Includes an
 * inline instruction so users know what to do — addresses the "copy buttons
 * with no context" feedback.
 */
function appendWizardRunInTerminalBlock(parent, runtime, options) {
  const opts = options && typeof options === "object" ? options : {};
  const cmd = String(opts.command || "").trim();
  if (!cmd) return null;
  const repoRoot = getDiscoveryRepoRoot(runtime);
  const combined = buildRunInRepoCommand(repoRoot, cmd);
  const wrap = createWizardNode(
    "div",
    "discovery-wizard-runblock",
  );
  // Plain-English instruction line. No more "where do I run this?"
  appendWizardParagraph(
    wrap,
    repoRoot
      ? "Open Terminal anywhere on your computer, paste this one line, press Enter. It changes into your repo folder and runs the command."
      : "Open Terminal in your JobBored repo folder, paste this, press Enter.",
    "discovery-setup-wizard__copy discovery-setup-wizard__copy--bold",
  );
  // Combined "cd repo && cmd" block.
  appendWizardCodeBlock(wrap, combined, "Copy command");
  // Optional macOS .command shortcut. Hidden if we don't know the repo path
  // (the script would just be the bare command, which isn't worth a download).
  if (repoRoot) {
    const dlRow = createWizardNode(
      "div",
      "discovery-wizard-runblock__dlrow",
    );
    const dlHint = createWizardNode(
      "span",
      "settings-field-hint settings-field-hint--compact",
      "macOS shortcut:",
    );
    const dlBtn = createWizardNode(
      "button",
      "btn-modal-secondary discovery-wizard-runblock__dlbtn",
      "↓ Download run-in-terminal file",
    );
    dlBtn.type = "button";
    dlBtn.title =
      "Downloads a .command file. Double-click it to open Terminal in your repo and run the command (macOS only).";
    dlBtn.addEventListener("click", () => {
      downloadDiscoveryRunCommandFile(
        repoRoot,
        cmd,
        opts.fileName || "jobbored-run.command",
      );
    });
    dlRow.append(dlHint, dlBtn);
    wrap.appendChild(dlRow);
  }
  parent.appendChild(wrap);
  return wrap;
}

function appendWizardCallout(parent, text) {
  if (!text) return null;
  const card = createWizardNode("div", "discovery-setup-wizard__callout");
  appendWizardParagraph(card, text, "discovery-setup-wizard__callout-text");
  parent.appendChild(card);
  return card;
}

function appendWizardInput(parent, options) {
  const o = options && typeof options === "object" ? options : {};
  const wrap = createWizardNode("div", "discovery-wizard-field");
  const label = createWizardNode("label", "field-label", o.label || "");
  label.htmlFor = o.id;
  const input =
    o.multiline === true
      ? createWizardNode("textarea", "modal-input modal-textarea")
      : createWizardNode("input", "modal-input");
  input.id = o.id;
  if (o.multiline !== true) {
    input.type = o.type || "text";
  } else if (Number.isFinite(o.rows)) {
    input.rows = o.rows;
  } else {
    input.rows = 3;
  }
  input.placeholder = o.placeholder || "";
  input.value = o.value || "";
  input.addEventListener("input", (event) => {
    if (typeof o.onInput === "function") {
      o.onInput(String(event.target.value || ""));
    }
  });
  wrap.append(label, input);
  if (o.hint) {
    appendWizardParagraph(
      wrap,
      o.hint,
      "settings-field-hint settings-field-hint--compact",
    );
  }
  parent.appendChild(wrap);
  return input;
}

function appendWizardResultCard(parent, result, titleOverride) {
  if (!result || typeof result !== "object") return null;
  const tone =
    result.ok === true
      ? result.kind === "stub_only"
        ? "warning"
        : "success"
      : "warning";
  const card = createWizardNode(
    "div",
    `discovery-setup-wizard__summary-card discovery-setup-wizard__summary-card--${tone}`,
  );
  appendWizardParagraph(
    card,
    titleOverride || result.message || "Latest result",
    "discovery-setup-wizard__card-title",
  );
  if (result.detail) {
    appendWizardParagraph(card, result.detail, "discovery-setup-wizard__copy");
  }
  if (result.remediation) {
    const lines = result.remediation.split("\n").filter((l) => l.trim());
    if (lines.length > 1) {
      const intro = lines[0];
      const steps = lines.slice(1);
      appendWizardParagraph(
        card,
        intro,
        "discovery-setup-wizard__copy discovery-setup-wizard__copy--bold",
      );
      const ol = createWizardNode(
        "ol",
        "discovery-setup-wizard__list discovery-setup-wizard__list--ordered",
      );
      steps.forEach((step) => {
        const li = document.createElement("li");
        li.textContent = step.replace(/^\d+\.\s*/, "");
        ol.appendChild(li);
      });
      card.appendChild(ol);
    } else {
      appendWizardParagraph(
        card,
        `Next step: ${result.remediation}`,
        "discovery-setup-wizard__copy",
      );
    }
  }
  if (result.suggestedUrl) {
    appendWizardSuggestedUrlBlock(card, result);
  }
  if (result.suggestedCommand) {
    appendWizardSuggestedCommandBlock(card, result);
  }
  parent.appendChild(card);
  return card;
}

/**
 * Heuristic: classify a suggested URL so we can render a context-rich action
 * instead of a bare "Copy URL". We look at the result.kind first (set by the
 * worker code paths that create these results), then fall back to URL shape.
 */
function classifyDiscoverySuggestedUrl(result) {
  const kind = String(result && result.kind ? result.kind : "").toLowerCase();
  const url = String(result && result.suggestedUrl ? result.suggestedUrl : "");
  if (
    kind.includes("worker") ||
    /workers\.dev/i.test(url) ||
    /\bworker[-.]/i.test(url)
  ) {
    return {
      kind: "worker",
      label: "Use this Worker URL",
      caption:
        "This is the public Cloudflare Worker URL the dashboard should POST to.",
      applyHint:
        "Saved to Settings → Discovery webhook URL when you click Use it.",
      settingsField: "settingsDiscoveryWebhookUrl",
    };
  }
  if (kind.includes("tunnel") || /ngrok/i.test(url) || /\.ngrok-free/.test(url)) {
    return {
      kind: "tunnel",
      label: "Use this tunnel URL",
      caption:
        "This is the public ngrok URL forwarding to your local server.",
      applyHint:
        "Saved to your discovery transport config when you click Use it.",
      settingsField: null, // no direct settings field — kept in transport state
    };
  }
  if (kind.includes("webhook") || /\/webhook\b/i.test(url)) {
    return {
      kind: "webhook",
      label: "Use this webhook URL",
      caption: "This is your discovery webhook endpoint.",
      applyHint:
        "Saved to Settings → Discovery webhook URL when you click Use it.",
      settingsField: "settingsDiscoveryWebhookUrl",
    };
  }
  return {
    kind: "generic",
    label: "Copy URL",
    caption: "",
    applyHint: "",
    settingsField: null,
  };
}

function appendWizardSuggestedUrlBlock(card, result) {
  const url = String(result.suggestedUrl || "").trim();
  if (!url) return;
  const meta = classifyDiscoverySuggestedUrl(result);
  if (meta.caption) {
    appendWizardParagraph(
      card,
      meta.caption,
      "discovery-setup-wizard__copy discovery-setup-wizard__copy--bold",
    );
  }
  const row = createWizardNode("div", "scraper-setup-copyrow");
  const code = createWizardNode("pre", "scraper-setup-code", url);
  // Primary "Use this URL" action — applies it where it belongs (settings
  // field today; transport state callers handle their own apply-on-detect
  // path elsewhere). Falls back to clipboard so users always have an out.
  const primary = createWizardNode(
    "button",
    "btn-copy-scraper btn-copy-scraper--primary",
    meta.label,
  );
  primary.type = "button";
  primary.addEventListener("click", () => {
    let applied = false;
    if (meta.settingsField) {
      const el = document.getElementById(meta.settingsField);
      if (el) {
        el.value = url;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
        applied = true;
      }
    }
    copyTextToClipboard(url);
    showToast(
      applied
        ? `Saved to ${meta.kind === "worker" ? "Discovery webhook URL" : "settings"} and copied to clipboard.`
        : "Copied to clipboard.",
      applied ? "success" : "info",
    );
  });
  // Secondary "just copy" so users who don't want auto-apply still have it.
  const copy = createWizardNode("button", "btn-copy-scraper", "Copy only");
  copy.type = "button";
  copy.addEventListener("click", () => {
    copyTextToClipboard(url);
    showToast("Copied to clipboard.", "info");
  });
  row.append(code, primary);
  if (meta.kind !== "generic") row.append(copy);
  card.appendChild(row);
  if (meta.applyHint) {
    appendWizardParagraph(
      card,
      meta.applyHint,
      "settings-field-hint settings-field-hint--compact",
    );
  }
}

function appendWizardSuggestedCommandBlock(card, result) {
  const cmd = String(result.suggestedCommand || "").trim();
  if (!cmd) return;
  // Use the run-in-terminal helper so users see the same combined cd+command
  // and macOS .command download as the per-step renderers. Repo-aware via
  // the active wizard runtime.
  const runtime = getDiscoveryWizardRuntime();
  appendWizardParagraph(
    card,
    "Run this command:",
    "discovery-setup-wizard__copy discovery-setup-wizard__copy--bold",
  );
  appendWizardRunInTerminalBlock(card, runtime, {
    command: cmd,
    fileName: "jobbored-suggested.command",
  });
}

/**
 * Render a recovery cluster after a failed step action: Try again + Copy AI
 * prompt + Skip. Only appended when the latest result for this step failed.
 * Skip writes the wizard state to "skipped" for the step and advances.
 */
function appendWizardFailureRecoveryCluster(parent, options) {
  const opts = options && typeof options === "object" ? options : {};
  const result = opts.result;
  if (!result || result.ok) return null;
  const wrap = createWizardNode("div", "discovery-wizard-recovery");
  appendWizardParagraph(
    wrap,
    "Stuck? Try one of these:",
    "discovery-setup-wizard__copy discovery-setup-wizard__copy--bold",
  );
  const row = createWizardNode("div", "discovery-wizard-recovery__row");

  // 1) Try again — re-runs the same step action.
  const retryBtn = createWizardNode(
    "button",
    "btn-modal-primary discovery-wizard-recovery__btn",
    "↻ Try again",
  );
  retryBtn.type = "button";
  retryBtn.addEventListener("click", () => {
    void handleDiscoveryWizardAction(opts.retryActionId);
  });
  row.appendChild(retryBtn);

  // 2) Copy AI prompt — copies the diagnose prompt to clipboard.
  if (opts.aiPrompt) {
    const aiBtn = createWizardNode(
      "button",
      "btn-modal-secondary discovery-wizard-recovery__btn",
      "📋 Copy AI assistant prompt",
    );
    aiBtn.type = "button";
    aiBtn.title =
      "Copies a diagnose-and-fix prompt to your clipboard. Paste it into your AI coding assistant (Claude, ChatGPT, Cursor, Factory) and it will walk you through the fix.";
    aiBtn.addEventListener("click", () => {
      copyTextToClipboard(opts.aiPrompt);
      showToast(
        "AI prompt copied. Paste it into your coding assistant for a guided fix.",
        "success",
      );
    });
    row.appendChild(aiBtn);
  }

  // 3) Skip for now — advances the wizard so advanced users with custom
  // routes aren't blocked by a probe that can't see their setup.
  if (opts.skipToStepId) {
    const skipBtn = createWizardNode(
      "button",
      "btn-modal-secondary discovery-wizard-recovery__btn discovery-wizard-recovery__btn--ghost",
      "Skip for now →",
    );
    skipBtn.type = "button";
    skipBtn.title =
      "Advances past this check. Use this if you have a custom setup the wizard can't auto-detect.";
    skipBtn.addEventListener("click", () => {
      const runtime = getDiscoveryWizardRuntime();
      const snapshot = getDiscoveryReadinessSnapshot();
      void moveDiscoveryWizardToStep(opts.skipToStepId, {
        snapshot,
        state: { ...(runtime.state || {}), [`${opts.skipKey || "skipped"}`]: true },
      });
      showToast(
        "Skipped. You can come back to this step from the rail any time.",
        "info",
      );
    });
    row.appendChild(skipBtn);
  }

  wrap.appendChild(row);
  parent.appendChild(wrap);
  return wrap;
}

function buildDiscoveryWizardMessageCard(runtime) {
  if (!runtime.lastWizardMessage) return null;
  return {
    type: "card",
    title: runtime.lastWizardMessage,
    body:
      runtime.lastWizardMessageTone === "warning"
        ? "Fix the issue above, then continue."
        : "Settings updated.",
  };
}

function normalizeDiscoveryWizardAssistMode(raw, fallback = "") {
  const value = raw == null ? "" : String(raw).trim().toLowerCase();
  if (value === "agent" || value === "manual") return value;
  return fallback;
}

function getDiscoveryWizardAssistMode(stepId, fallback = "manual") {
  const runtime = getDiscoveryWizardRuntime();
  const assistModes =
    runtime &&
    runtime.drafts &&
    runtime.drafts.assistModes &&
    typeof runtime.drafts.assistModes === "object"
      ? runtime.drafts.assistModes
      : {};
  return normalizeDiscoveryWizardAssistMode(assistModes[stepId], fallback);
}

function setDiscoveryWizardAssistMode(stepId, mode) {
  const runtime = getDiscoveryWizardRuntime();
  const currentAssistModes =
    runtime &&
    runtime.drafts &&
    runtime.drafts.assistModes &&
    typeof runtime.drafts.assistModes === "object"
      ? runtime.drafts.assistModes
      : {};
  updateDiscoveryWizardRuntime({
    drafts: {
      assistModes: {
        ...currentAssistModes,
        [stepId]: normalizeDiscoveryWizardAssistMode(mode, "manual"),
      },
    },
  });
}

function appendWizardAssistChooser(parent, options) {
  const o = options && typeof options === "object" ? options : {};
  const stepId = o.stepId || "";
  const choices = Array.isArray(o.choices) ? o.choices.filter(Boolean) : [];
  if (!stepId || !choices.length) return null;
  const activeMode = getDiscoveryWizardAssistMode(stepId, o.defaultMode || "");
  const activeChoice =
    choices.find((choice) => choice.id === activeMode) ||
    choices.find((choice) => choice.id === o.defaultMode) ||
    choices[0];
  const card = createWizardNode(
    "div",
    "discovery-setup-wizard__summary-card discovery-setup-wizard__assist-card",
  );
  appendWizardParagraph(
    card,
    o.title || "Choose how you want to do this.",
    "discovery-setup-wizard__card-title",
  );
  if (o.intro) {
    appendWizardParagraph(card, o.intro, "discovery-setup-wizard__copy");
  }
  const actions = createWizardNode(
    "div",
    "discovery-setup-wizard__assist-actions",
  );
  choices.forEach((choice) => {
    const isActive = choice.id === activeChoice.id;
    const button = createWizardNode(
      "button",
      `discovery-setup-wizard__btn discovery-setup-wizard__btn--${
        isActive ? "secondary" : "ghost"
      }`,
      choice.label || choice.id,
    );
    button.type = "button";
    button.setAttribute("aria-pressed", isActive ? "true" : "false");
    button.addEventListener("click", () => {
      setDiscoveryWizardAssistMode(stepId, choice.id);
      void renderDiscoverySetupWizard();
    });
    actions.appendChild(button);
  });
  card.appendChild(actions);
  if (activeChoice.summary) {
    appendWizardParagraph(
      card,
      activeChoice.summary,
      "discovery-setup-wizard__assist-note",
    );
  }
  if (typeof activeChoice.render === "function") {
    const content = createWizardNode(
      "div",
      "discovery-setup-wizard__assist-content",
    );
    activeChoice.render(content);
    card.appendChild(content);
  }
  parent.appendChild(card);
  return card;
}

function buildDiscoveryBootstrapAgentPrompt(snapshot) {
  const port = inferLocalWebhookPort(snapshot.localWebhookUrl || "");
  return [
    "We are in the Job-Bored repo. Prepare the local discovery bootstrap for the wizard.",
    "",
    `Expected local port: ${port}`,
    "",
    "Do this:",
    "1. Run `npm run discovery:bootstrap-local` from the repo root.",
    "2. Prefer the browser-use discovery worker as the local engine. Only use Hermes/OpenClaw if the user intentionally wants the advanced path.",
    "3. If bootstrap needs an ngrok token, local worker start command, or any login step, stop and tell me exactly what is missing.",
    "4. Return the local webhook URL, health URL, ngrok URL, and public target URL you found.",
    "5. Do not edit `app.js` or `index.html`.",
  ].join("\n");
}

function buildDiscoveryLocalHealthAgentPrompt(snapshot) {
  const engineKind = getDiscoveryLocalEngineKind(snapshot);
  return [
    "We are in the Job-Bored repo. Fix the local discovery receiver so the wizard health check can pass.",
    "",
    `Current local webhook: ${snapshot.localWebhookUrl || "not detected yet"}`,
    "",
    "Do this:",
    engineKind === "hermes"
      ? "1. The current local path points at Hermes/OpenClaw. If that is intentional, run `hermes gateway run --replace`. Otherwise switch to the browser-use worker with `npm run discovery:worker:start-local`."
      : "1. Start the recommended local browser-use worker with `npm run discovery:worker:start-local`.",
    "2. Confirm the local `/health` endpoint responds successfully.",
    "3. If the local server still does not become healthy, tell me exactly which service, credential, or dependency is missing.",
    "4. Do not edit `app.js` or `index.html`.",
  ].join("\n");
}

function buildDiscoveryTunnelAgentPrompt(snapshot) {
  const port = inferLocalWebhookPort(snapshot.localWebhookUrl || "");
  return [
    "We are in the Job-Bored repo. Get the ngrok tunnel ready for the local discovery path.",
    "",
    `Expected local port: ${port}`,
    `Current local webhook: ${snapshot.localWebhookUrl || "not detected yet"}`,
    "",
    "Do this:",
    `1. Detect whether ngrok is already exposing port ${port}.`,
    `2. If not, run \`ngrok http ${port}\`.`,
    "3. Return the public HTTPS ngrok URL only, plus any blocker if ngrok auth is missing.",
    "4. Do not save the ngrok URL as the final dashboard webhook. It is only the downstream target behind the Worker.",
  ].join("\n");
}

function getDiscoveryWizardStepIds(flow) {
  const normalizedFlow = mapDiscoveryWizardFlow(flow);
  if (normalizedFlow === "external_endpoint") {
    return ["detect", "path_select", "existing_endpoint", "verify", "ready"];
  }
  if (normalizedFlow === "no_webhook") {
    return ["detect", "path_select", "no_webhook", "ready"];
  }
  if (normalizedFlow === "stub_only") {
    return ["detect", "path_select", "stub_only", "ready"];
  }
  const localApi = getDiscoveryWizardLocalApi();
  if (localApi && typeof localApi.getLocalStepIds === "function") {
    return localApi.getLocalStepIds();
  }
  return [
    "detect",
    "path_select",
    "bootstrap",
    "local_health",
    "tunnel",
    "relay_deploy",
    "verify",
    "ready",
  ];
}

function getDiscoveryWizardActionableStep(flow, snapshot) {
  const normalizedFlow = mapDiscoveryWizardFlow(flow);
  const state =
    snapshot && typeof snapshot === "object"
      ? snapshot
      : getDiscoveryReadinessSnapshot();
  if (normalizedFlow === "external_endpoint") return "existing_endpoint";
  if (normalizedFlow === "no_webhook") return "no_webhook";
  if (normalizedFlow === "stub_only") return "stub_only";
  if (state.relayReady && isLikelyCloudflareWorkerUrl(state.savedWebhookUrl)) {
    return "verify";
  }
  if (state.tunnelReady) return "relay_deploy";
  if (state.localWebhookReady) return "tunnel";
  if (state.localWebhookUrl) return "local_health";
  return "bootstrap";
}

function getDiscoveryWizardStepsBefore(flow, targetStep) {
  const ids = getDiscoveryWizardStepIds(flow);
  const idx = ids.indexOf(targetStep);
  return idx > 0 ? ids.slice(0, idx) : [];
}

function getDiscoveryWizardRecommendedFlow(snapshot) {
  const state =
    snapshot && typeof snapshot === "object"
      ? snapshot
      : getDiscoveryReadinessSnapshot();
  return mapDiscoveryWizardFlow(state.recommendedFlow);
}

function getDiscoveryWizardFlowLabel(flow) {
  if (flow === "external_endpoint") return "My own webhook";
  if (flow === "no_webhook") return "Manual / no webhook";
  if (flow === "stub_only") return "Stub only (testing)";
  return "Local worker (this computer)";
}

function getDiscoveryWizardStepTitle(flow) {
  return getDiscoveryWizardFlowLabel(flow);
}

function getDiscoveryWizardSavedEndpointLabel(kind) {
  if (kind === "worker") return "Cloudflare Worker";
  if (kind === "generic_https") return "HTTPS webhook";
  if (kind === "apps_script_stub") return "Apps Script stub";
  if (kind === "local_http") return "localhost (needs relay)";
  return "none";
}

function getDiscoveryWizardBlockingIssueLabel(issue) {
  if (issue === "missing_sheet") return "Pipeline sheet not configured.";
  if (issue === "stub_only") return "Only the Apps Script stub is saved.";
  if (issue === "local_health_unavailable") {
    return "Local server found but not responding.";
  }
  if (issue === "ngrok_missing") {
    return "Server is up but no tunnel running.";
  }
  if (issue === "relay_missing") {
    return "Relay not deployed yet.";
  }
  if (issue === "needs_recovery") {
    return "Local setup needs recovery after restart.";
  }
  return "";
}

function getDiscoveryWizardRecommendationReason(snapshot) {
  const state =
    snapshot && typeof snapshot === "object"
      ? snapshot
      : getDiscoveryReadinessSnapshot();
  if (state.recommendedReason) return state.recommendedReason;
  if (state.savedWebhookKind === "worker") {
    return "A Cloudflare Worker URL is already saved.";
  }
  if (state.savedWebhookKind === "generic_https") {
    return "A webhook URL is already saved.";
  }
  if (state.savedWebhookKind === "apps_script_stub") {
    return "Only the Apps Script stub is saved — upgrade to a real endpoint.";
  }
  if (
    state.savedWebhookKind === "local_http" ||
    state.localWebhookUrl ||
    state.tunnelPublicUrl ||
    state.localBootstrapAvailable
  ) {
    return getDiscoveryLocalEngineKind(state) === "hermes"
      ? "A local Hermes route was detected. It can work, but the browser-use worker is the recommended local discovery engine."
      : "A local browser-use worker or local discovery path was detected on this machine.";
  }
  return "No webhook saved yet — pick a path to get started.";
}

function getDiscoveryWizardOptionDetails(flow) {
  const normalizedFlow = mapDiscoveryWizardFlow(flow);
  if (normalizedFlow === "external_endpoint") {
    return {
      title: "My own webhook URL",
      bestWhen: "You already have a public HTTPS endpoint.",
      setupTime: "~2 min",
      effort: "Low",
      pro: "Fastest — just paste and verify.",
      tradeoff:
        "You own that endpoint. Any hosting cost comes from your provider, not from JobBored.",
    };
  }
  if (normalizedFlow === "no_webhook") {
    return {
      title: "No webhook (manual)",
      bestWhen: "You use cron, GitHub Actions, or n8n to run discovery.",
      setupTime: "~1 min",
      effort: "Low",
      pro: "No endpoint to maintain.",
      tradeoff: "No on-demand Run discovery button.",
    };
  }
  if (normalizedFlow === "stub_only") {
    return {
      title: "Stub only (testing)",
      bestWhen: "You just want to confirm webhook delivery works.",
      setupTime: "~2 min",
      effort: "Low",
      pro: "Quick wiring test.",
      tradeoff: "No real job results.",
    };
  }
  return {
    title: "Local discovery worker",
    bestWhen:
      "You want the recommended browser-use discovery worker on this machine.",
    setupTime: "~10 min",
    effort: "Medium",
    pro: "Best local path for real discovery.",
    tradeoff:
      "Needs a local worker + ngrok + relay. Hermes/OpenClaw remains an advanced custom path.",
  };
}

function buildDiscoveryWizardOptionCard(flow, snapshot) {
  const option = getDiscoveryWizardOptionDetails(flow);
  const recommended = getDiscoveryWizardRecommendedFlow(snapshot) === flow;
  const body = [];
  if (recommended) {
    body.push(getDiscoveryWizardRecommendationReason(snapshot));
  }
  body.push({
    type: "list",
    items: [
      `${option.bestWhen}`,
      `${option.setupTime} · ${option.effort} effort`,
      `${option.pro}`,
      `${option.tradeoff}`,
    ],
  });
  return {
    type: "card",
    kicker: recommended ? "Recommended" : "",
    title: option.title,
    body,
    flow,
  };
}

async function persistDiscoveryWizardState(patch = {}) {
  const probes = getDiscoveryWizardProbesApi();
  const current = getDiscoveryWizardRuntime();
  const next = {
    ...(current.state || {}),
    ...(patch && typeof patch === "object" ? patch : {}),
    flow: mapDiscoveryWizardFlow(
      patch && Object.prototype.hasOwnProperty.call(patch, "flow")
        ? patch.flow
        : current.state.flow,
    ),
  };
  if (probes && typeof probes.saveDiscoverySetupWizardState === "function") {
    try {
      const saved = await probes.saveDiscoverySetupWizardState(next);
      updateDiscoveryWizardRuntime({ state: saved });
      return saved;
    } catch (err) {
      console.warn("[JobBored] discovery wizard state:", err);
    }
  }
  updateDiscoveryWizardRuntime({ state: next });
  return next;
}

function buildDiscoveryPathSelectBody(runtime) {
  const snapshot = runtime.snapshot;
  return [
    {
      type: "option-grid",
      items: [
        buildDiscoveryWizardOptionCard("local_agent", snapshot),
        buildDiscoveryWizardOptionCard("external_endpoint", snapshot),
        buildDiscoveryWizardOptionCard("no_webhook", snapshot),
      ].filter(Boolean),
    },
  ].filter(Boolean);
}

function buildDiscoveryDetectBody(runtime) {
  const snapshot = runtime.snapshot;
  const recovery = snapshot.localRecoveryState || "ok";
  const recoveryCopy = getDiscoveryRecoveryCopy(snapshot);
  const foundItems = [];
  const missingItems = [];
  const localEngineLabel = getDiscoveryLocalEngineLabel(snapshot);

  if (snapshot.sheetConfigured) {
    foundItems.push("Pipeline sheet connected");
  } else {
    missingItems.push("Pipeline sheet not set up");
  }

  if (snapshot.savedWebhookUrl) {
    foundItems.push(
      `Webhook URL saved (${getDiscoveryWizardSavedEndpointLabel(snapshot.savedWebhookKind)})`,
    );
  } else {
    missingItems.push("No webhook URL saved");
  }

  if (snapshot.localBootstrapAvailable) {
    foundItems.push("Local config file found");
  }

  if (snapshot.localWebhookUrl) {
    foundItems.push(
      localEngineLabel
        ? `Local engine detected (${localEngineLabel})`
        : "Local server detected",
    );
    if (!snapshot.localWebhookReady) {
      missingItems.push("Local server not responding — needs restart");
    }
  }

  if (snapshot.tunnelReady) {
    foundItems.push("ngrok tunnel active");
  } else if (snapshot.localWebhookReady) {
    missingItems.push("No ngrok tunnel running");
  }

  if (recovery === "tunnel_rotated") {
    missingItems.push(
      "Relay still points to the previous ngrok URL — redeploy needed",
    );
  }

  if (snapshot.relayReady || snapshot.savedWebhookKind === "worker") {
    foundItems.push("Cloudflare relay deployed");
  } else if (
    snapshot.tunnelReady ||
    snapshot.savedWebhookKind === "local_http"
  ) {
    missingItems.push("Relay not deployed yet");
  }

  if (snapshot.savedWebhookKind === "apps_script_stub") {
    missingItems.push("Saved URL is still the Apps Script stub");
  }

  if (!foundItems.length) {
    foundItems.push("Nothing detected yet — this is a fresh start");
  }

  if (!missingItems.length) {
    missingItems.push("Everything looks good");
  }

  const allItems = [
    ...foundItems.map((i) => `✓ ${i}`),
    ...missingItems.map((i) => `✗ ${i}`),
  ];
  const cards = [];
  if (recovery !== "ok") {
    cards.push({
      type: "card",
      title: recoveryCopy.title,
      body: [...recoveryCopy.detectBody, recoveryCopy.actionHint],
    });
  }
  cards.push({
    type: "card",
    title: "Status",
    body: [{ type: "list", items: allItems }],
  });
  cards.push(buildDiscoveryWizardMessageCard(runtime));
  return cards.filter(Boolean);
}

function buildDiscoveryExistingEndpointBody(runtime) {
  const container = createWizardNode("div", "discovery-wizard-step-body");
  appendWizardParagraph(
    container,
    "Paste your public HTTPS webhook URL below.",
  );
  appendWizardInput(container, {
    id: "discoveryWizardExistingEndpointInput",
    label: "Webhook URL",
    type: "url",
    value: runtime.drafts.endpointUrl || "",
    placeholder: "https://your-endpoint.example/webhook",
    hint: "Must be a public HTTPS URL — localhost won't work here.",
    onInput(value) {
      updateDiscoveryWizardRuntime({ drafts: { endpointUrl: value } });
    },
  });
  if (runtime.lastVerificationResult) {
    appendWizardResultCard(container, runtime.lastVerificationResult);
  }
  return container;
}

function buildDiscoveryBootstrapBody(runtime) {
  const snapshot = runtime.snapshot;
  const result = runtime.lastLocalResult;
  const container = createWizardNode("div", "discovery-wizard-step-body");
  appendWizardParagraph(
    container,
    "This reads your local config file to auto-fill ports, URLs, and tunnel info.",
  );
  appendWizardList(container, [
    `Config file: ${snapshot.localBootstrapAvailable ? "found" : "missing"}`,
    `Local server: ${snapshot.localWebhookUrl || "not detected"}`,
    `Tunnel: ${snapshot.tunnelPublicUrl || "not detected"}`,
  ]);
  appendWizardAssistChooser(container, {
    stepId: "bootstrap",
    title: "Generate the config file:",
    intro: "",
    defaultMode: "agent",
    choices: [
      {
        id: "agent",
        label: "AI assistant",
        summary: "Paste this into your AI coding assistant.",
        render(content) {
          appendWizardCodeBlock(
            content,
            buildDiscoveryBootstrapAgentPrompt(snapshot),
            "Copy prompt",
          );
          appendWizardParagraph(
            content,
            "Then press Load config above.",
            "settings-field-hint settings-field-hint--compact",
          );
        },
      },
      {
        id: "manual",
        label: "Terminal",
        summary: "Paste one line into Terminal — no need to find your repo.",
        render(content) {
          appendWizardRunInTerminalBlock(content, runtime, {
            command: "npm run discovery:bootstrap-local",
            fileName: "jobbored-bootstrap.command",
          });
          appendWizardParagraph(
            content,
            "When the command finishes, press Load config above.",
            "settings-field-hint settings-field-hint--compact",
          );
        },
      },
    ],
  });
  appendWizardResultCard(container, result, "Result");
  return container;
}

function buildDiscoveryLocalHealthBody(runtime) {
  const snapshot = runtime.snapshot;
  const localEngineLabel =
    getDiscoveryLocalEngineLabel(snapshot) || "local discovery server";
  const container = createWizardNode("div", "discovery-wizard-step-body");
  appendWizardParagraph(
    container,
    `Checking that ${localEngineLabel} is running on this computer.`,
  );
  appendWizardList(container, [
    `Server: ${snapshot.localWebhookUrl || "not found"}`,
    `Status: ${snapshot.localWebhookReady ? "healthy" : "not responding"}`,
  ]);
  if (!snapshot.localWebhookReady) {
    appendWizardAssistChooser(container, {
      stepId: "local_health",
      title: "Start or restart the server:",
      intro: "",
      defaultMode: "agent",
      choices: [
        {
          id: "agent",
          label: "AI assistant",
          summary:
            "Paste this into your AI coding assistant to diagnose and fix.",
          render(content) {
            appendWizardCodeBlock(
              content,
              buildDiscoveryLocalHealthAgentPrompt(snapshot),
              "Copy prompt",
            );
            appendWizardParagraph(
              content,
              "Then press Check health above.",
              "settings-field-hint settings-field-hint--compact",
            );
          },
        },
        {
          id: "manual",
          label: "Terminal",
          summary:
            getDiscoveryLocalEngineKind(snapshot) === "hermes"
              ? "Paste one line — no need to find your repo first."
              : "Paste one line — no need to find your repo first.",
          render(content) {
            const cmd =
              getDiscoveryLocalEngineKind(snapshot) === "hermes"
                ? "hermes gateway run --replace"
                : "npm run discovery:worker:start-local";
            appendWizardRunInTerminalBlock(content, runtime, {
              command: cmd,
              fileName: "jobbored-start-worker.command",
            });
            if (getDiscoveryLocalEngineKind(snapshot) !== "hermes") {
              appendWizardParagraph(
                content,
                "Advanced only: if you intentionally use Hermes/OpenClaw instead, run `hermes gateway run --replace`.",
                "settings-field-hint settings-field-hint--compact",
              );
            }
            appendWizardParagraph(
              content,
              "Leave this terminal running, then press Check health above.",
              "settings-field-hint settings-field-hint--compact",
            );
          },
        },
      ],
    });
  }
  appendWizardResultCard(container, runtime.lastLocalResult, "Result");
  // Failure recovery: surface Try again + Copy AI prompt + Skip when the
  // last health probe failed. Lets users unstick themselves without hunting
  // through the rail or scrolling.
  appendWizardFailureRecoveryCluster(container, {
    result: runtime.lastLocalResult,
    retryActionId: "local_health_check",
    aiPrompt: buildDiscoveryLocalHealthAgentPrompt(snapshot),
    skipToStepId: "tunnel",
    skipKey: "skippedLocalHealth",
  });
  return container;
}

function buildDiscoveryTunnelBody(runtime) {
  const snapshot = runtime.snapshot;
  const localPort = inferLocalWebhookPort(snapshot.localWebhookUrl || "");
  const container = createWizardNode("div", "discovery-wizard-step-body");

  const stalePlaceholder = createWizardNode(
    "div",
    "tunnel-stale-banner-wizard-slot",
  );
  stalePlaceholder.id = "wizardTunnelStalePlaceholder";
  container.appendChild(stalePlaceholder);
  void probeAndShowWizardTunnelBanner(
    stalePlaceholder,
    snapshot.tunnelPublicUrl || "",
    localPort,
  );

  appendWizardParagraph(
    container,
    "ngrok creates a public URL that forwards to your local server.",
  );
  appendWizardList(container, [
    `Local server: ${snapshot.localWebhookUrl || "not found"}`,
    `Tunnel: ${snapshot.tunnelPublicUrl || "not detected"}`,
  ]);
  appendWizardAssistChooser(container, {
    stepId: "tunnel",
    title: "Start or detect the tunnel:",
    intro: "",
    defaultMode: "agent",
    choices: [
      {
        id: "agent",
        label: "AI assistant",
        summary: "Paste this into your AI coding assistant.",
        render(content) {
          appendWizardCodeBlock(
            content,
            buildDiscoveryTunnelAgentPrompt(snapshot),
            "Copy prompt",
          );
          appendWizardParagraph(
            content,
            "Then press Detect tunnel above.",
            "settings-field-hint settings-field-hint--compact",
          );
        },
      },
      {
        id: "manual",
        label: "Terminal",
        summary: "Run ngrok in a separate Terminal window — keep it open.",
        render(content) {
          // ngrok doesn't need to be in the repo, but we still offer the
          // .command shortcut so Mac users get one-click. The combined cd
          // is harmless even when not strictly needed.
          appendWizardRunInTerminalBlock(content, runtime, {
            command: `ngrok http ${localPort}`,
            fileName: "jobbored-ngrok.command",
          });
          appendWizardParagraph(
            content,
            "Leave the ngrok terminal open. Then press Detect tunnel above.",
            "settings-field-hint settings-field-hint--compact",
          );
        },
      },
    ],
  });
  appendWizardResultCard(container, runtime.lastLocalResult, "Result");
  // Same recovery cluster as local_health. Skip target is the relay step.
  appendWizardFailureRecoveryCluster(container, {
    result: runtime.lastLocalResult,
    retryActionId: "local_tunnel_detect",
    aiPrompt: buildDiscoveryTunnelAgentPrompt(snapshot),
    skipToStepId: "relay_deploy",
    skipKey: "skippedTunnel",
  });
  return container;
}

async function probeAndShowWizardTunnelBanner(slot, storedTunnelUrl, port) {
  if (!slot || !isLocalDashboardOrigin()) return;
  const storedNorm = (storedTunnelUrl || "").replace(/\/+$/, "");
  const liveUrl = await probeNgrokFromLocalApi();

  if (!liveUrl && !storedNorm) return;

  const banner = createWizardNode("div", "tunnel-stale-banner");

  const icon = createWizardNode("span", "tunnel-stale-banner__icon");
  icon.setAttribute("aria-hidden", "true");
  icon.innerHTML =
    '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>';
  banner.appendChild(icon);

  const body = createWizardNode("div", "tunnel-stale-banner__body");
  const title = createWizardNode("p", "tunnel-stale-banner__title");
  const detail = createWizardNode("p", "tunnel-stale-banner__detail");
  body.appendChild(title);
  body.appendChild(detail);
  banner.appendChild(body);

  if (!liveUrl) {
    banner.classList.add("tunnel-stale-banner--down");
    title.textContent = "No ngrok tunnel detected.";
    detail.textContent = `Run ngrok http ${port || "8644"} to bring the public tunnel back up, then click Detect tunnel.`;
  } else if (storedNorm && liveUrl !== storedNorm) {
    title.textContent = "Public tunnel changed.";
    detail.textContent = [
      "ngrok gave your local setup a new public URL.",
      `Previous tunnel: ${storedNorm}`,
      `Current tunnel: ${liveUrl}`,
      "Keep the same Worker URL saved in JobBored. Click Fix setup to redeploy the relay behind it.",
    ].join("\n");
    const action = createWizardNode(
      "button",
      "btn-modal-primary tunnel-stale-banner__action",
      "Fix setup",
    );
    action.type = "button";
    action.addEventListener("click", () => {
      void handleDiscoveryWizardAction("wizard_fix_setup");
    });
    banner.appendChild(action);
  } else {
    return;
  }

  slot.appendChild(banner);
}

function buildDiscoveryRelayBody(runtime) {
  const snapshot = runtime.snapshot;
  const relayApi = getDiscoveryWizardRelayApi();
  const model =
    relayApi && typeof relayApi.buildRelayWizardModel === "function"
      ? relayApi.buildRelayWizardModel(snapshot, {
          origin:
            (window.location && typeof window.location.origin === "string"
              ? window.location.origin
              : "") || "*",
          sheetId: getSettingsSheetIdValue() || "",
          workerUrl: runtime.drafts.workerUrl || "",
        })
      : null;
  updateDiscoveryWizardRuntime({ lastRelayModel: model });
  const container = createWizardNode("div", "discovery-wizard-step-body");
  appendWizardParagraph(
    container,
    "The Cloudflare relay gives you a permanent public URL. It forwards requests to your ngrok tunnel.",
  );
  appendWizardAssistChooser(container, {
    stepId: "relay_deploy",
    title: "Deploy the relay:",
    intro: "",
    defaultMode: "agent",
    choices: [
      {
        id: "agent",
        label: "AI assistant",
        summary:
          "Paste this into your AI coding assistant to deploy automatically.",
        render(content) {
          if (model && model.agentPrompt) {
            appendWizardCodeBlock(content, model.agentPrompt, "Copy prompt");
          } else {
            appendWizardCallout(
              content,
              "Complete the tunnel step first — the relay needs a target URL.",
            );
          }
          appendWizardParagraph(
            content,
            "Then paste the Worker URL below.",
            "settings-field-hint settings-field-hint--compact",
          );
        },
      },
      {
        id: "manual",
        label: "Terminal",
        summary: "Copy the command, paste it into Terminal, then press Enter.",
        render(content) {
          if (model && model.downstreamTargetUrl) {
            appendWizardCodeBlock(
              content,
              model.downstreamTargetUrl,
              "Copy target URL",
            );
          }
          if (model && model.deployCommand) {
            appendWizardCodeBlock(
              content,
              model.deployCommand,
              "Copy terminal command",
            );
          } else {
            appendWizardCallout(
              content,
              "Complete the tunnel step first — the relay needs a target URL.",
            );
          }
          appendWizardParagraph(
            content,
            "Copy the command, paste it into a terminal opened in the Job-Bored repo, press Enter, then paste the Worker URL below.",
            "settings-field-hint settings-field-hint--compact",
          );
        },
      },
    ],
  });
  appendWizardInput(container, {
    id: "discoveryWizardWorkerUrlInput",
    label: "Worker URL",
    type: "url",
    value: runtime.drafts.workerUrl || "",
    placeholder: "https://your-worker.your-subdomain.workers.dev/",
    hint: "The workers.dev URL from the deploy output — not the /forward path.",
    onInput(value) {
      updateDiscoveryWizardRuntime({ drafts: { workerUrl: value } });
    },
  });
  appendWizardResultCard(container, runtime.lastRelayResult, "Result");
  return container;
}

function buildDiagnosisChainItem(label, url, statusIcon, statusText) {
  const row = createWizardNode("div", "diag-chain-row");
  const icon = createWizardNode(
    "span",
    `diag-chain-icon diag-chain-icon--${statusIcon}`,
  );
  icon.textContent =
    statusIcon === "ok" ? "✓" : statusIcon === "warn" ? "!" : "✗";
  icon.setAttribute("aria-hidden", "true");
  const copy = createWizardNode("div", "diag-chain-copy");
  const lbl = createWizardNode("span", "diag-chain-label", label);
  copy.appendChild(lbl);
  if (url) {
    const urlEl = createWizardNode("code", "diag-chain-url", url);
    copy.appendChild(urlEl);
  }
  const status = createWizardNode(
    "span",
    `diag-chain-status diag-chain-status--${statusIcon}`,
    statusText,
  );
  copy.appendChild(status);
  row.append(icon, copy);
  return row;
}

function buildDiscoveryVerifyBody(runtime) {
  const snapshot = runtime.snapshot;
  const container = createWizardNode("div", "discovery-wizard-step-body");
  const result = runtime.lastVerificationResult;
  const diagnosis = runtime.lastDownstreamDiagnosis;
  const recovery = snapshot.localRecoveryState || "ok";
  const isDownstreamFailure =
    result && !result.ok && !!diagnosis && diagnosis.ran;

  const endpointUrl =
    snapshot.savedWebhookUrl ||
    runtime.drafts.workerUrl ||
    runtime.drafts.endpointUrl ||
    "missing";

  if (recovery !== "ok") {
    const recoveryCopy = getDiscoveryRecoveryCopy(snapshot);
    const recoveryCard = createWizardNode(
      "div",
      "discovery-setup-wizard__summary-card discovery-setup-wizard__summary-card--recovery",
    );
    appendWizardParagraph(
      recoveryCard,
      recoveryCopy.title,
      "discovery-setup-wizard__card-title",
    );
    for (const line of recoveryCopy.detectBody) {
      appendWizardParagraph(recoveryCard, line, "discovery-setup-wizard__copy");
    }
    appendWizardParagraph(
      recoveryCard,
      recoveryCopy.actionHint,
      "discovery-setup-wizard__copy",
    );
    container.appendChild(recoveryCard);
    return container;
  }

  appendWizardParagraph(container, `Testing: ${endpointUrl}`);

  if (isDownstreamFailure && diagnosis && diagnosis.ran) {
    const diagCard = createWizardNode(
      "div",
      "discovery-setup-wizard__summary-card discovery-setup-wizard__summary-card--warning diag-card",
    );

    appendWizardParagraph(
      diagCard,
      "What went wrong",
      "discovery-setup-wizard__card-title",
    );
    appendWizardParagraph(
      diagCard,
      diagnosis.summary,
      "discovery-setup-wizard__copy diag-summary",
    );

    // Detect localhost so we can advertise the one-click auto-heal.
    const isLocalhostHost =
      typeof window !== "undefined" &&
      window.location &&
      (window.location.hostname === "localhost" ||
        window.location.hostname === "127.0.0.1" ||
        window.location.hostname === "[::1]" ||
        window.location.hostname === "::1");

    if (diagnosis.redeployCommand) {
      appendWizardParagraph(
        diagCard,
        "How to redeploy",
        "discovery-setup-wizard__card-title diag-redeploy-title",
      );
      appendWizardParagraph(
        diagCard,
        isLocalhostHost
          ? "One-click fix: click \u201cAuto-fix\u201d below to redeploy the relay against the live ngrok URL \u2014 no terminal needed. (Backup: copy the command if Cloudflare auth is missing.)"
          : "Copy this command, paste it into a terminal opened in the Job-Bored repo, press Enter, then come back here and click Test again. It keeps the same Worker name and updates TARGET_URL to the live ngrok URL.",
        "discovery-setup-wizard__copy diag-redeploy-copy",
      );
      appendWizardCodeBlock(
        diagCard,
        diagnosis.redeployCommand,
        "Copy terminal command",
      );
    } else if (
      diagnosis.primaryFix &&
      diagnosis.primaryFix.id === "diag_fix_update_tunnel_and_relay"
    ) {
      appendWizardParagraph(
        diagCard,
        "How to redeploy",
        "discovery-setup-wizard__card-title diag-redeploy-title",
      );
      appendWizardParagraph(
        diagCard,
        "We could not build the deploy command (local webhook path or live tunnel URL missing). Open the Relay deploy step after saving the Live ngrok URL, or from the repo root run: npm run cloudflare-relay:deploy -- --target-url 'https://YOUR-NGROK-HOST/your-webhook-path' --worker-name 'your-existing-worker-name'",
        "discovery-setup-wizard__copy diag-redeploy-copy",
      );
    }

    const chain = createWizardNode("div", "diag-chain");
    chain.appendChild(
      buildDiagnosisChainItem("Relay", endpointUrl, "ok", "OK"),
    );
    const tunnelStatus = diagnosis.tunnel.status;
    chain.appendChild(
      buildDiagnosisChainItem(
        "Tunnel",
        diagnosis.tunnel.url || snapshot.tunnelPublicUrl || "",
        tunnelStatus === "active"
          ? "ok"
          : tunnelStatus === "stale_url"
            ? "warn"
            : "fail",
        tunnelStatus === "active"
          ? "OK"
          : tunnelStatus === "stale_url"
            ? "URL changed — redeploy"
            : "Down",
      ),
    );
    const localStatus = diagnosis.localServer.status;
    chain.appendChild(
      buildDiagnosisChainItem(
        "Server",
        diagnosis.localServer.url || snapshot.localWebhookUrl || "",
        localStatus === "running"
          ? "ok"
          : localStatus === "not_configured"
            ? "warn"
            : "fail",
        localStatus === "running"
          ? "OK"
          : localStatus === "not_configured"
            ? "Not configured"
            : "Down",
      ),
    );
    if (diagnosis.relay.targetMismatch) {
      chain.appendChild(
        buildDiagnosisChainItem(
          "Relay target",
          snapshot.relayTargetUrl || "",
          "warn",
          "Stale — redeploy with current ngrok URL",
        ),
      );
    }
    diagCard.appendChild(chain);

    const fixActions = createWizardNode("div", "diag-fix-actions");

    if (diagnosis.primaryFix) {
      const primaryBtn = createWizardNode(
        "button",
        "btn-modal-primary diag-fix-btn diag-fix-btn--primary",
        diagnosis.primaryFix.label,
      );
      primaryBtn.type = "button";
      primaryBtn.dataset.wizardAction = "action";
      primaryBtn.dataset.actionId = diagnosis.primaryFix.id;
      primaryBtn.dataset.stepId = "verify";
      primaryBtn.dataset.actionKind = "diagnosis_fix";
      if (diagnosis.primaryFix.detail) {
        primaryBtn.title = diagnosis.primaryFix.detail;
      }
      fixActions.appendChild(primaryBtn);
    }

    const secondaryFixes = [];
    if (
      !diagnosis.primaryFix ||
      diagnosis.primaryFix.id !== "diag_fix_local_server"
    ) {
      secondaryFixes.push({
        id: "diag_fix_local_server",
        label: "Check server",
      });
    }
    if (
      !diagnosis.primaryFix ||
      diagnosis.primaryFix.id !== "diag_fix_tunnel"
    ) {
      secondaryFixes.push({
        id: "diag_fix_tunnel",
        label: "Fix tunnel",
      });
    }
    if (
      !diagnosis.primaryFix ||
      (diagnosis.primaryFix.id !== "diag_fix_relay" &&
        diagnosis.primaryFix.id !== "diag_fix_update_tunnel_and_relay")
    ) {
      secondaryFixes.push({
        id: "diag_fix_relay",
        label: "Fix relay",
      });
    }
    secondaryFixes.push({
      id: "diag_rerun_diagnosis",
      label: "Re-check",
    });

    secondaryFixes.forEach((fix) => {
      const btn = createWizardNode(
        "button",
        "btn-modal-secondary diag-fix-btn",
        fix.label,
      );
      btn.type = "button";
      btn.dataset.wizardAction = "action";
      btn.dataset.actionId = fix.id;
      btn.dataset.stepId = "verify";
      btn.dataset.actionKind = "diagnosis_fix";
      fixActions.appendChild(btn);
    });

    diagCard.appendChild(fixActions);
    container.appendChild(diagCard);
  } else if (isDownstreamFailure && !diagnosis) {
    const loadingCard = createWizardNode(
      "div",
      "discovery-setup-wizard__summary-card discovery-setup-wizard__summary-card--warning",
    );
    appendWizardParagraph(
      loadingCard,
      "Diagnosing...",
      "discovery-setup-wizard__card-title",
    );
    appendWizardParagraph(
      loadingCard,
      "Checking your server, tunnel, and relay to find what's broken.",
      "discovery-setup-wizard__copy",
    );
    container.appendChild(loadingCard);
  }

  appendWizardResultCard(container, result);
  return container;
}

function buildDiscoveryNoWebhookBody(runtime) {
  return [
    {
      type: "card",
      title: "No webhook — that's fine.",
      body: [
        "You can still add jobs to Pipeline using GitHub Actions, cron, n8n, or Apps Script triggers. You can come back and add a webhook later.",
      ],
    },
    buildDiscoveryWizardMessageCard(runtime),
  ].filter(Boolean);
}

function buildDiscoveryStubOnlyBody(runtime) {
  return [
    {
      type: "card",
      title: "Stub mode — testing only.",
      body: [
        "The stub confirms webhook delivery works, but won't produce real job results. Switch to the Local or Webhook path when you're ready for real discovery.",
      ],
    },
    buildDiscoveryWizardMessageCard(runtime),
  ].filter(Boolean);
}

function buildDiscoveryReadyBody(runtime) {
  const snapshot = runtime.snapshot;
  const cards = [];
  cards.push({
    type: "card",
    title: "Connection summary",
    body: [
      `Engine: ${
        snapshot.localWebhookUrl
          ? getDiscoveryLocalEngineSummary(snapshot)
          : snapshot.savedWebhookKind === "generic_https" ||
              snapshot.savedWebhookKind === "worker"
            ? snapshot.savedWebhookUrl
            : snapshot.engineState === "stub_only"
              ? "stub only"
              : "not confirmed"
      }`,
      `Tunnel: ${snapshot.tunnelPublicUrl || "not needed"}`,
      `Webhook URL: ${snapshot.savedWebhookUrl || runtime.drafts.workerUrl || "not saved"}`,
    ],
  });
  if (runtime.lastVerificationResult) {
    cards.push({
      type: "card",
      title: runtime.lastVerificationResult.message || "Test result",
      body: [runtime.lastVerificationResult.detail || "Verification complete."],
    });
  }
  return cards;
}

function buildDiscoveryWizardSteps(runtime) {
  const flow = mapDiscoveryWizardFlow(runtime.state.flow);
  const steps = [];
  const detectRecovery =
    runtime.snapshot &&
    runtime.snapshot.localRecoveryState &&
    runtime.snapshot.localRecoveryState !== "ok";
  steps.push({
    id: "detect",
    label: "Status",
    title: detectRecovery
      ? "Local setup needs recovery"
      : "Current setup status",
    description: detectRecovery
      ? "The local worker or tunnel is down. Click Fix setup to restore everything."
      : "What's already connected and what still needs work.",
    body: () => buildDiscoveryDetectBody(getDiscoveryWizardRuntime()),
    actions: detectRecovery
      ? [
          {
            id: "wizard_fix_setup",
            label: "Fix setup",
            variant: "primary",
          },
        ]
      : [
          {
            id: "wizard_review_options",
            label: "Next: choose a path",
            variant: "primary",
          },
        ],
    secondaryActions: [
      ...(detectRecovery
        ? [
            {
              id: "wizard_review_options",
              label: "Choose a different path",
              variant: "secondary",
            },
          ]
        : []),
      {
        id: "wizard_refresh_detect",
        label: "Re-scan",
        variant: "secondary",
      },
      ...(detectRecovery
        ? [
            {
              id: "wizard_show_manual_steps",
              label: "Show manual steps",
              variant: "secondary",
            },
          ]
        : []),
    ],
  });
  steps.push({
    id: "path_select",
    label: "Path",
    title: "How do you want to connect discovery?",
    description: "Click a card to choose your setup path.",
    body: () => buildDiscoveryPathSelectBody(getDiscoveryWizardRuntime()),
    actions: [],
    secondaryActions: [],
  });

  if (flow === "external_endpoint") {
    steps.push({
      id: "existing_endpoint",
      label: "Endpoint",
      title: "Enter your webhook URL.",
      description: "Paste the public HTTPS URL you want JobBored to call.",
      body: () =>
        buildDiscoveryExistingEndpointBody(getDiscoveryWizardRuntime()),
      actions: [
        {
          id: "wizard_verify_existing_endpoint",
          label: "Save and verify",
          variant: "primary",
        },
      ],
    });
  } else if (flow === "no_webhook") {
    steps.push({
      id: "no_webhook",
      label: "Manual",
      title: "Keep discovery manual.",
      description:
        "You can still add jobs to Pipeline manually or via automation — just no on-demand button.",
      body: () => buildDiscoveryNoWebhookBody(getDiscoveryWizardRuntime()),
      actions: [
        {
          id: "wizard_complete_no_webhook",
          label: "Confirm — no webhook",
          variant: "primary",
        },
      ],
    });
  } else if (flow === "stub_only") {
    steps.push({
      id: "stub_only",
      label: "Stub",
      title: "Test-only mode.",
      description:
        "The stub confirms wiring works but won't produce real job results.",
      body: () => buildDiscoveryStubOnlyBody(getDiscoveryWizardRuntime()),
      actions: [
        {
          id: "wizard_complete_stub_only",
          label: "Confirm stub setup",
          variant: "primary",
        },
      ],
    });
  } else {
    steps.push({
      id: "bootstrap",
      label: "Config",
      title: detectRecovery ? "Fix local setup" : "Load local config.",
      description: detectRecovery
        ? "Fix setup restarts what is down and redeploys the relay if ngrok changed."
        : "Reads your saved local setup so the wizard knows your ports, URLs, and tunnel info.",
      body: () => buildDiscoveryBootstrapBody(getDiscoveryWizardRuntime()),
      actions: detectRecovery
        ? [
            {
              id: "wizard_fix_setup",
              label: "Fix setup",
              variant: "primary",
            },
          ]
        : [
            {
              id: "local_bootstrap_refresh",
              label: "Load config",
              variant: "primary",
            },
          ],
      secondaryActions: detectRecovery
        ? [
            {
              id: "local_bootstrap_refresh",
              label: "Load config manually",
              variant: "secondary",
            },
          ]
        : [],
    });
    steps.push({
      id: "local_health",
      label: "Server",
      title: "Check local server.",
      description:
        "Makes sure your local discovery server is running and accepting requests.",
      body: () => buildDiscoveryLocalHealthBody(getDiscoveryWizardRuntime()),
      actions: [
        {
          id: "local_health_check",
          label: "Check health",
          variant: "primary",
        },
      ],
    });
    steps.push({
      id: "tunnel",
      label: "Tunnel",
      title: "Connect ngrok tunnel.",
      description: "ngrok makes your local server reachable from the internet.",
      body: () => buildDiscoveryTunnelBody(getDiscoveryWizardRuntime()),
      actions: [
        {
          id: "local_tunnel_detect",
          label: "Detect tunnel",
          variant: "primary",
        },
      ],
    });
    steps.push({
      id: "relay_deploy",
      label: "Relay",
      title: "Deploy the Cloudflare relay.",
      description:
        "The relay gives you a permanent URL that forwards to your ngrok tunnel.",
      body: () => buildDiscoveryRelayBody(getDiscoveryWizardRuntime()),
      actions: [
        {
          id: "relay_apply_worker_url",
          label: "Save Worker URL",
          variant: "primary",
        },
      ],
    });
  }

  const verifyDesc =
    flow === "external_endpoint"
      ? "Sends a test request to your webhook URL to confirm it responds correctly."
      : flow === "no_webhook"
        ? "Quick sanity check that your manual pipeline configuration is valid."
        : "Sends a test request through the relay → tunnel → server chain to confirm the full loop works.";
  steps.push({
    id: "verify",
    label: "Test",
    title: detectRecovery
      ? "Local setup needs recovery"
      : "Test the connection.",
    description: detectRecovery
      ? "The local worker or tunnel is down. Fix the setup first, then test."
      : verifyDesc,
    body: () => buildDiscoveryVerifyBody(getDiscoveryWizardRuntime()),
    actions: detectRecovery
      ? [
          {
            id: "wizard_fix_setup",
            label: "Fix setup",
            variant: "primary",
          },
        ]
      : [
          {
            id: "wizard_verify_current_endpoint",
            label: "Run test",
            variant: "primary",
          },
        ],
    secondaryActions: detectRecovery
      ? [
          {
            id: "wizard_verify_current_endpoint",
            label: "Run test anyway",
            variant: "secondary",
          },
        ]
      : [],
  });
  const readyDesc =
    flow === "external_endpoint"
      ? "Your webhook URL is verified. Run discovery on demand or close this wizard."
      : flow === "no_webhook"
        ? "Manual mode is active. Add jobs via Pipeline, cron, or automation."
        : "Local discovery worker path is connected. Run discovery on demand or close this wizard.";
  steps.push({
    id: "ready",
    label: "Done",
    title: "You're all set.",
    description: readyDesc,
    body: () => buildDiscoveryReadyBody(getDiscoveryWizardRuntime()),
    actions: [
      {
        id: "wizard_run_discovery_now",
        label: "Run discovery now",
        variant: "primary",
        disabled: !getDiscoverySettingsView(runtime.snapshot)
          .runDiscoveryEnabled,
      },
    ],
    secondaryActions: [
      {
        id: "wizard_finish_setup",
        label: "Close wizard",
        variant: "secondary",
      },
    ],
  });
  return steps.filter((step) =>
    getDiscoveryWizardStepIds(flow).includes(step.id),
  );
}

async function renderDiscoverySetupWizard() {
  const shell = getDiscoveryWizardShellApi();
  if (!shell || typeof shell.renderWizardShell !== "function") {
    await openCommandCenterSettingsModal();
    return null;
  }
  const runtime = getDiscoveryWizardRuntime();
  return shell.renderWizardShell({
    title: "Discovery setup wizard",
    lede: "Connect your job discovery pipeline in a few steps.",
    snapshot: runtime.snapshot,
    state: runtime.state,
    steps: buildDiscoveryWizardSteps(runtime),
    activeStepId: runtime.activeStepId,
    onAction: (actionId) => {
      void handleDiscoveryWizardAction(actionId).catch((err) => {
        console.error("[JobBored] discovery wizard action:", actionId, err);
        showToast(
          "That action failed. Check the browser console for details.",
          "error",
        );
      });
    },
    onNavigate: (stepId, detail) => {
      const current = getDiscoveryWizardRuntime();
      updateDiscoveryWizardRuntime({
        activeStepId: stepId,
        state: {
          ...(current.state || {}),
          ...(detail && detail.state ? detail.state : {}),
          currentStep: stepId,
        },
      });
      void persistDiscoveryWizardState({
        ...(detail && detail.state ? detail.state : {}),
        currentStep: stepId,
      });
    },
    onStateChange: (state) => {
      updateDiscoveryWizardRuntime({ state });
      void persistDiscoveryWizardState(state);
    },
    onClose: () => {
      // Restore onboarding if it was showing when discovery wizard opened
      const runtime = discoveryWizardRuntime;
      const shouldRestoreOnboarding =
        runtime &&
        runtime.state &&
        runtime.state._onboardingWasHiddenByDiscovery;
      discoveryWizardRuntime = null;
      void refreshDiscoveryReadinessSnapshot({ force: true });
      if (shouldRestoreOnboarding) {
        showOnboardingWizard();
      }
    },
  });
}

async function openDiscoverySetupWizard(options = {}) {
  // ====== [discovery-autodetect lane: silent recover] ======
  // Probe the local discovery stack BEFORE rendering the wizard. If
  // everything is healthy, skip the wizard entirely. If the only problem
  // is fixable (worker down, ngrok rotated, etc.), the autodetect module
  // runs /__proxy/full-boot silently and re-probes. Only when human input
  // is genuinely needed do we fall through to the wizard below.
  //
  // Module owns no UI. Endpoint contract locked in dev-server.mjs
  // handleDiscoveryState header. Pass options.skipAutodetect to bypass.
  if (
    !options.skipAutodetect &&
    typeof window !== "undefined" &&
    window.JobBoredDiscoveryAutodetect &&
    typeof window.JobBoredDiscoveryAutodetect.recoverIfPossible === "function"
  ) {
    try {
      const verdict =
        await window.JobBoredDiscoveryAutodetect.recoverIfPossible();
      if (verdict && verdict.ready) {
        // Belt-and-suspenders: greenfield users who land on a healthy
        // discovery stack still need keep-alive installed so the next ngrok
        // rotation doesn't break them. installKeepAliveOnce is idempotent
        // (localStorage-gated), so running it here is safe even if the
        // explicit "Fix tunnel" path also called it earlier.
        if (typeof installKeepAliveOnce === "function") {
          try {
            installKeepAliveOnce();
          } catch (_) {
            /* never block the user on keep-alive bookkeeping */
          }
        }
        if (typeof showToast === "function") {
          showToast("Discovery is already set up.", "info");
        }
        return;
      }
    } catch (err) {
      // Autodetect failure is never fatal — fall through to the wizard.
      console.warn("[JobBored] discovery autodetect skipped:", err);
    }
  }
  // ====== [/discovery-autodetect lane] ======

  // Remember if onboarding was showing so we can restore it after wizard closes
  const onboardingWasVisible = isOnboardingWizardVisible();
  if (onboardingWasVisible) {
    hideOnboardingWizard();
  }
  if (isSettingsModalOpen()) {
    closeCommandCenterSettingsModal();
  }
  const helpModal = document.getElementById("discoveryHelpModal");
  if (helpModal) {
    helpModal.style.display = "none";
  }
  closeDiscoverySetupGuideModal();
  const snapshot = await refreshDiscoveryReadinessSnapshot({
    force: true,
    rerender: false,
  });
  const probes = getDiscoveryWizardProbesApi();
  let savedState = null;
  if (probes && typeof probes.getDiscoverySetupWizardState === "function") {
    try {
      savedState = await probes.getDiscoverySetupWizardState();
    } catch (err) {
      console.warn("[JobBored] load discovery wizard state:", err);
    }
  }
  const needsRecovery =
    snapshot.localRecoveryState && snapshot.localRecoveryState !== "ok";
  const initialFlow = mapDiscoveryWizardFlow(
    needsRecovery
      ? "local_agent"
      : options.flow ||
          (savedState && savedState.flow) ||
          snapshot.recommendedFlow,
  );
  const initialStep = needsRecovery
    ? "bootstrap"
    : options.startStep ||
      (savedState &&
      savedState.currentStep !== "path_select" &&
      getDiscoveryWizardStepIds(initialFlow).includes(savedState.currentStep)
        ? savedState.currentStep
        : "detect");
  const savedCompleted =
    savedState && Array.isArray(savedState.completedSteps)
      ? savedState.completedSteps
      : [];
  const implicitlyCompleted = getDiscoveryWizardStepsBefore(
    initialFlow,
    initialStep,
  );
  const mergedCompleted = [
    ...new Set([...savedCompleted, ...implicitlyCompleted]),
  ];
  discoveryWizardRuntime = createDiscoveryWizardRuntime({
    entryPoint: options.entryPoint || "manual",
    snapshot,
    state: {
      ...(savedState && typeof savedState === "object" ? savedState : {}),
      flow: initialFlow,
      currentStep: initialStep,
      completedSteps: mergedCompleted,
      // Track that we hid onboarding so we can reshow it on close
      _onboardingWasHiddenByDiscovery: onboardingWasVisible,
    },
    activeStepId: initialStep,
    drafts: {
      ...getDiscoveryWizardDefaultDrafts(snapshot),
      ...(options.drafts && typeof options.drafts === "object"
        ? options.drafts
        : {}),
    },
  });
  await persistDiscoveryWizardState({
    ...discoveryWizardRuntime.state,
    flow: initialFlow,
    currentStep: initialStep,
    completedSteps: mergedCompleted,
  });
  return renderDiscoverySetupWizard();
}

function getDiscoveryWizardCurrentStepContext() {
  const shell = getDiscoveryWizardShellApi();
  return shell &&
    shell.lastRender &&
    shell.lastRender.context &&
    typeof shell.lastRender.context === "object"
    ? shell.lastRender.context
    : null;
}

async function moveDiscoveryWizardToStep(stepId, patch = {}) {
  const runtime = updateDiscoveryWizardRuntime({
    activeStepId: stepId,
    state: {
      ...(getDiscoveryWizardRuntime().state || {}),
      ...(patch.state && typeof patch.state === "object" ? patch.state : {}),
      currentStep: stepId,
    },
    ...patch,
  });
  await persistDiscoveryWizardState({
    ...(runtime.state || {}),
    currentStep: stepId,
  });
  return renderDiscoverySetupWizard();
}

function setDiscoveryWizardMessage(message, tone = "info") {
  updateDiscoveryWizardRuntime({
    lastWizardMessage: message || "",
    lastWizardMessageTone: tone,
  });
}

async function handleDiscoveryWizardFlowSelection(flow) {
  const snapshot = await refreshDiscoveryReadinessSnapshot({
    force: true,
    rerender: false,
  });
  const mappedFlow = mapDiscoveryWizardFlow(flow);
  const runtime = getDiscoveryWizardRuntime();
  const currentState = runtime.state || {};

  const flowCache = { ...(runtime.flowProgressCache || {}) };
  if (currentState.flow) {
    flowCache[currentState.flow] = {
      completedSteps: [...(currentState.completedSteps || [])],
      currentStep: runtime.activeStepId || currentState.currentStep || "",
      drafts: { ...(runtime.drafts || {}) },
    };
  }

  const cached = flowCache[mappedFlow];
  const nextStep =
    cached && cached.currentStep
      ? cached.currentStep
      : getDiscoveryWizardActionableStep(mappedFlow, snapshot);
  const restoredSteps =
    cached && cached.completedSteps
      ? cached.completedSteps
      : getDiscoveryWizardStepsBefore(mappedFlow, nextStep);
  const restoredDrafts = cached && cached.drafts ? cached.drafts : undefined;

  setDiscoveryWizardMessage("");
  return moveDiscoveryWizardToStep(nextStep, {
    snapshot,
    flowProgressCache: flowCache,
    drafts: restoredDrafts,
    state: {
      flow: mappedFlow,
      completedSteps: [...restoredSteps],
    },
  });
}

async function diagnoseDownstreamChain(snapshot) {
  const probes = getDiscoveryWizardProbesApi();
  const diagnosis = {
    ran: true,
    timestamp: new Date().toISOString(),
    localServer: { status: "unknown", url: "", healthy: false },
    tunnel: { status: "unknown", url: "", active: false, stale: false },
    relay: { status: "unknown", targetMismatch: false },
    summary: "",
    primaryFix: null,
    redeployCommand: "",
    redeployTargetUrl: "",
  };

  const transport =
    probes && typeof probes.readDiscoveryTransportSetupState === "function"
      ? probes.readDiscoveryTransportSetupState()
      : {};
  const localUrl = snapshot.localWebhookUrl || transport.localWebhookUrl || "";
  diagnosis.localServer.url = localUrl;

  if (localUrl && probes && typeof probes.probeHealthUrl === "function") {
    const healthUrl = probes.buildLocalHealthUrl
      ? probes.buildLocalHealthUrl(localUrl)
      : localUrl.replace(/\/[^/]*$/, "/health");
    diagnosis.localServer.healthy = await probes.probeHealthUrl(healthUrl);
    diagnosis.localServer.status = diagnosis.localServer.healthy
      ? "running"
      : "unreachable";
  } else if (!localUrl) {
    diagnosis.localServer.status = "not_configured";
  }

  if (probes && typeof probes.probeNgrokTunnels === "function") {
    const liveNgrokUrl = await probes.probeNgrokTunnels();
    diagnosis.tunnel.url = liveNgrokUrl;
    diagnosis.tunnel.active = !!liveNgrokUrl;
    if (
      liveNgrokUrl &&
      snapshot.tunnelPublicUrl &&
      liveNgrokUrl !== snapshot.tunnelPublicUrl
    ) {
      diagnosis.tunnel.stale = true;
    }
    diagnosis.tunnel.status = liveNgrokUrl
      ? diagnosis.tunnel.stale
        ? "stale_url"
        : "active"
      : "not_running";
  }

  if (
    snapshot.relayTargetUrl &&
    diagnosis.tunnel.active &&
    diagnosis.tunnel.url
  ) {
    const savedTarget = snapshot.relayTargetUrl.replace(/\/+$/, "");
    const liveBase = diagnosis.tunnel.url.replace(/\/+$/, "");
    if (!savedTarget.startsWith(liveBase)) {
      diagnosis.relay.targetMismatch = true;
    }
    diagnosis.relay.status = diagnosis.relay.targetMismatch
      ? "target_stale"
      : "ok";
  }

  if (diagnosis.localServer.status === "unreachable") {
    diagnosis.summary = "Local server is down.";
    diagnosis.primaryFix = {
      id: "diag_fix_local_server",
      label: "Start server",
      detail:
        "Attempts to start the recommended local browser-use worker automatically.",
    };
  } else if (diagnosis.tunnel.status === "not_running") {
    diagnosis.summary = "ngrok tunnel is not running.";
    diagnosis.primaryFix = {
      id: "diag_fix_tunnel",
      label: "Fix tunnel",
      detail: "Go to the tunnel step to start ngrok.",
    };
  } else if (diagnosis.tunnel.stale || diagnosis.relay.targetMismatch) {
    const liveRaw = diagnosis.tunnel.url || "";
    const liveNorm = liveRaw.replace(/\/+$/, "") || "unknown";
    const tunnelOrigin = (u) => {
      try {
        const s = String(u || "").trim();
        if (!s) return "";
        const parsed = new URL(s);
        return `${parsed.protocol}//${parsed.host}`;
      } catch (_) {
        return String(u || "").replace(/\/+$/, "");
      }
    };
    const liveOrigin = liveRaw ? tunnelOrigin(liveRaw) : "";
    let oldDisplay = "";
    if (diagnosis.relay.targetMismatch && snapshot.relayTargetUrl) {
      const relayOrig = tunnelOrigin(snapshot.relayTargetUrl);
      if (relayOrig && liveOrigin && relayOrig !== liveOrigin) {
        oldDisplay = relayOrig;
      }
    }
    if (
      !oldDisplay &&
      diagnosis.tunnel.stale &&
      snapshot.tunnelPublicUrl &&
      liveOrigin
    ) {
      const pubOrig = tunnelOrigin(snapshot.tunnelPublicUrl);
      if (pubOrig && pubOrig !== liveOrigin) {
        oldDisplay = snapshot.tunnelPublicUrl.replace(/\/+$/, "");
      }
    }
    if (!oldDisplay) {
      oldDisplay =
        snapshot.tunnelPublicUrl ||
        (snapshot.relayTargetUrl
          ? tunnelOrigin(snapshot.relayTargetUrl)
          : "") ||
        "unknown";
    }
    diagnosis.summary = `ngrok URL changed \u2014 relay needs redeployment.\nOld: ${oldDisplay}\nLive: ${liveNorm}`;
    diagnosis.liveNgrokUrl = liveNorm;
    const onLocalhost =
      typeof window !== "undefined" &&
      window.location &&
      (window.location.hostname === "localhost" ||
        window.location.hostname === "127.0.0.1" ||
        window.location.hostname === "[::1]" ||
        window.location.hostname === "::1");
    diagnosis.primaryFix = {
      id: "diag_fix_update_tunnel_and_relay",
      label: onLocalhost
        ? "Auto-fix: redeploy relay & re-test"
        : "Update tunnel & save ngrok, then redeploy",
      detail: onLocalhost
        ? "One click. Calls the local helper to redeploy the relay against the live ngrok URL, then re-runs the test."
        : "Click to save the Live ngrok URL, then run the deploy command shown below from your Job-Bored repo (same Worker name = update in place).",
    };

    if (liveNorm && liveNorm !== "unknown") {
      const relayApi = getDiscoveryWizardRelayApi();
      let redeployTarget = buildDiscoveryTunnelTargetUrl(
        snapshot.localWebhookUrl,
        liveNorm,
      );
      if (
        !redeployTarget &&
        relayApi &&
        typeof relayApi.buildDownstreamTargetUrl === "function"
      ) {
        const patched = {
          ...snapshot,
          tunnelPublicUrl: liveNorm,
          relayTargetUrl: "",
        };
        redeployTarget = relayApi.buildDownstreamTargetUrl(patched, {}) || "";
      }
      diagnosis.redeployTargetUrl = redeployTarget;
      const workerUrl =
        snapshot.savedWebhookUrl || getDiscoveryWebhookUrl() || "";
      const explicitWorker =
        inferCloudflareWorkerNameFromOpenWorkerUrl(workerUrl);
      const workerName =
        explicitWorker || getSuggestedCloudflareRelayWorkerName(redeployTarget);
      const sheetId = getSettingsSheetIdValue() || "";
      if (redeployTarget) {
        diagnosis.redeployCommand = buildDiscoveryRelayDeployCommandForTarget(
          redeployTarget,
          {
            origin: getDiscoveryRelaySuggestedOrigin(),
            workerName,
            workerUrl,
            sheetId,
          },
        );
      }
    }
  } else if (
    diagnosis.localServer.healthy &&
    diagnosis.tunnel.active &&
    !diagnosis.relay.targetMismatch
  ) {
    diagnosis.summary =
      "Everything looks connected — may have been a temporary issue.";
    diagnosis.primaryFix = {
      id: "diag_fix_reverify",
      label: "Try again",
      detail: "Re-run the test to see if it passes now.",
    };
  } else {
    diagnosis.summary =
      "Couldn't pinpoint the issue. Fix the first red item below.";
  }

  return diagnosis;
}

async function handleDiscoveryWizardVerification(url, context) {
  const payload = await buildDiscoveryWebhookPayload(
    context === "run_discovery"
      ? SHEET_ID
      : getSettingsSheetIdValue() || SHEET_ID,
  );
  const result = await verifyDiscoveryWebhookWithSharedModel(url, payload, {
    context,
    sheetId: getSettingsSheetIdValue() || SHEET_ID || "",
  });
  updateDiscoveryWizardRuntime({
    lastVerificationResult: result,
    lastDownstreamDiagnosis: null,
  });
  if (result.ok) {
    const engineState = getDiscoveryEngineStateFromVerificationResult(result);
    if (engineState) {
      await recordDiscoveryEngineState(
        url,
        engineState,
        context === "run_discovery"
          ? "wizard_run_discovery"
          : "wizard_verify_endpoint",
      );
    }
    if (url) {
      mergeStoredConfigOverridePatch({ discoveryWebhookUrl: url });
    }
    await refreshDiscoveryReadinessSnapshot({ force: true, rerender: false });
    const snapshot = getDiscoveryReadinessSnapshot();
    const flow =
      result.kind === "stub_only"
        ? "stub_only"
        : getDiscoveryWizardRuntime().state.flow;
    setDiscoveryWizardMessage(
      result.message,
      result.kind === "stub_only" ? "warning" : "info",
    );
    await persistDiscoveryWizardState({
      flow,
      currentStep: result.kind === "stub_only" ? "stub_only" : "ready",
      completedSteps: [
        ...((getDiscoveryWizardRuntime().state || {}).completedSteps || []),
        "verify",
      ],
      lastVerifiedAt: new Date().toISOString(),
      result:
        result.kind === "stub_only"
          ? "stub_only"
          : result.engineState || "connected",
    });
    updateDiscoveryWizardRuntime({
      snapshot,
      state: {
        ...(getDiscoveryWizardRuntime().state || {}),
        flow: mapDiscoveryWizardFlow(flow),
      },
    });
    showDiscoveryVerificationToast(result, { context });
    return moveDiscoveryWizardToStep(
      result.kind === "stub_only" ? "stub_only" : "ready",
      {
        snapshot,
        state: {
          flow: mapDiscoveryWizardFlow(flow),
        },
      },
    );
  }
  if (
    (result.kind === "network_error" || result.kind === "invalid_endpoint") &&
    (await handleAppsScriptBrowserCorsFailure(url))
  ) {
    // Apps Script stub that is publicly accessible — CORS blocked the browser from
    // reading the response, but the endpoint did receive and accept the request.
    // Classify as stub_only so the wizard shows warning semantics, not a generic
    // network error, and the Run discovery path does not report full-connected success.
    // Also handles the case where the Apps Script stub URL returns 404 because it is
    // not yet deployed — the 404 is classified as invalid_endpoint by the verifier,
    // but for a known managed Apps Script stub URL we treat it as stub_only.
    result.kind = "stub_only";
    result.engineState = "stub_only";
    result.message =
      "Apps Script stub received the request. Wiring works, but the stub does not find real jobs.";
    result.detail =
      "Switch to a real discovery engine or set up a Cloudflare relay to enable real discovery.";
    setDiscoveryWizardMessage(result.message, "warning");
    return renderDiscoverySetupWizard();
  }
  const freshSnapshot = await refreshDiscoveryReadinessSnapshot({
    force: true,
    rerender: false,
  });

  const freshRecovery = freshSnapshot.localRecoveryState || "ok";
  if (freshRecovery !== "ok") {
    updateDiscoveryWizardRuntime({
      snapshot: freshSnapshot,
      lastDownstreamDiagnosis: null,
    });
    setDiscoveryWizardMessage(
      "The local chain is down. Click Fix setup to restore it.",
      "warning",
    );
    showDiscoveryVerificationToast(result, { context, endpointUrl: url });
    return renderDiscoverySetupWizard();
  }

  const hasLocalTunnel =
    isLocalDashboardOrigin() && !!freshSnapshot.tunnelPublicUrl;
  const isDiagnosableDownstreamFailure =
    result.layer === "downstream" &&
    [502, 503, 504].includes(Number(result.httpStatus) || 0);
  const isLikelyTunnelFailure =
    !isDiagnosableDownstreamFailure &&
    hasLocalTunnel &&
    (result.kind === "network_error" ||
      /ngrok|tunnel|offline|err_ngrok_/i.test(
        `${result.message || ""}\n${result.detail || ""}`,
      ));
  if (isDiagnosableDownstreamFailure || isLikelyTunnelFailure) {
    const diagnosis = await diagnoseDownstreamChain(freshSnapshot);
    updateDiscoveryWizardRuntime({
      snapshot: freshSnapshot,
      lastDownstreamDiagnosis: diagnosis,
    });
  } else {
    updateDiscoveryWizardRuntime({
      snapshot: freshSnapshot,
      lastDownstreamDiagnosis: null,
    });
  }
  showDiscoveryVerificationToast(result, { context, endpointUrl: url });
  setDiscoveryWizardMessage(result.message, "warning");
  return renderDiscoverySetupWizard();
}

async function handleDiscoveryWizardAction(actionId) {
  let runtime = getDiscoveryWizardRuntime();
  const shellContext = getDiscoveryWizardCurrentStepContext();
  const shell = getDiscoveryWizardShellApi();
  const snapshot = await refreshDiscoveryReadinessSnapshot({
    force: true,
    rerender: false,
  });
  updateDiscoveryWizardRuntime({ snapshot });
  runtime = getDiscoveryWizardRuntime();

  if (actionId === "wizard_back") {
    const previousStep =
      shellContext && shellContext.previousStep
        ? shellContext.previousStep.id
        : "";
    if (previousStep) {
      return moveDiscoveryWizardToStep(previousStep);
    }
    return null;
  }

  if (actionId === "wizard_next" || actionId === "wizard_finish_setup") {
    const nextStep =
      shellContext && shellContext.nextStep ? shellContext.nextStep.id : "";
    if (actionId === "wizard_finish_setup" || !nextStep) {
      if (shell && typeof shell.closeWizardShell === "function") {
        shell.closeWizardShell("finish");
      }
      return null;
    }
    return moveDiscoveryWizardToStep(nextStep);
  }

  if (actionId === "wizard_run_discovery_now") {
    const shellApi = getDiscoveryWizardShellApi();
    if (shellApi && typeof shellApi.closeWizardShell === "function") {
      shellApi.closeWizardShell("run-discovery");
    }
    return triggerDiscoveryRun();
  }

  if (actionId === "wizard_choose_flow_local") {
    return handleDiscoveryWizardFlowSelection("local_agent");
  }
  if (actionId === "wizard_choose_flow_existing") {
    return handleDiscoveryWizardFlowSelection("external_endpoint");
  }
  if (actionId === "wizard_choose_flow_no_webhook") {
    return handleDiscoveryWizardFlowSelection("no_webhook");
  }

  if (actionId === "wizard_refresh_detect") {
    setDiscoveryWizardMessage(
      "Refreshed discovery signals from the current repo and browser state.",
    );
    return moveDiscoveryWizardToStep("detect", {
      snapshot,
      state: {
        completedSteps: [
          ...((runtime.state || {}).completedSteps || []),
          "detect",
        ],
        lastProbeAt: new Date().toISOString(),
      },
    });
  }
  if (actionId === "wizard_fix_setup") {
    const probes = getDiscoveryWizardProbesApi();
    if (!probes || typeof probes.requestFixSetup !== "function") {
      setDiscoveryWizardMessage(
        "Fix setup is not available outside the local dev server.",
      );
      return renderDiscoverySetupWizard();
    }
    setDiscoveryWizardMessage(
      "Running Fix setup — checking worker, tunnel, and relay...",
    );
    await renderDiscoverySetupWizard();
    const result = await probes.requestFixSetup();
    if (result && result.ok) {
      if (result.needsAuth) {
        const authMsg = (result.phases || []).find(
          (p) => p.phase === "needs_cloudflare_auth",
        );
        setDiscoveryWizardMessage(
          (authMsg && authMsg.message) ||
            "Cloudflare auth needed. Run `npx wrangler login` in a terminal, then try again.",
        );
        return renderDiscoverySetupWizard();
      }
      const freshSnapshot = await refreshDiscoveryReadinessSnapshot({
        force: true,
        rerender: false,
      });
      updateDiscoveryWizardRuntime({ snapshot: freshSnapshot });
      const verifiedMsg = (result.phases || []).find(
        (p) => p.phase === "verified",
      );
      setDiscoveryWizardMessage(
        (verifiedMsg && verifiedMsg.message) || "Setup restored successfully.",
      );
      return moveDiscoveryWizardToStep("verify", {
        snapshot: freshSnapshot,
      });
    }
    const failedPhase = ((result && result.phases) || []).slice(-1)[0];
    setDiscoveryWizardMessage(
      (failedPhase && failedPhase.message) ||
        (result && result.message) ||
        "Fix setup failed. Check the terminal for details.",
    );
    return renderDiscoverySetupWizard();
  }
  if (actionId === "wizard_show_manual_steps") {
    setDiscoveryWizardMessage(
      "Showing manual steps. Follow bootstrap → server → tunnel → relay → verify.",
    );
    return moveDiscoveryWizardToStep("bootstrap", {
      snapshot,
      state: {
        flow: "local_agent",
        completedSteps: [
          ...((runtime.state || {}).completedSteps || []),
          "detect",
          "path_select",
        ],
      },
    });
  }
  if (actionId === "wizard_review_options") {
    setDiscoveryWizardMessage("");
    return moveDiscoveryWizardToStep("path_select", {
      snapshot,
      state: {
        completedSteps: [
          ...((runtime.state || {}).completedSteps || []),
          "detect",
        ],
      },
    });
  }
  if (actionId === "wizard_use_recommended_flow") {
    const recommendedFlow = getDiscoveryWizardRecommendedFlow(snapshot);
    const targetStep = getDiscoveryWizardActionableStep(
      recommendedFlow,
      snapshot,
    );
    const priorSteps = getDiscoveryWizardStepsBefore(
      recommendedFlow,
      targetStep,
    );
    setDiscoveryWizardMessage(
      `Continuing with the recommended path: ${getDiscoveryWizardStepTitle(recommendedFlow)}.`,
    );
    return moveDiscoveryWizardToStep(targetStep, {
      snapshot,
      state: {
        flow: recommendedFlow,
        completedSteps: [
          ...((runtime.state || {}).completedSteps || []),
          ...priorSteps,
        ],
      },
    });
  }
  if (actionId === "wizard_complete_no_webhook") {
    setDiscoveryWizardMessage(
      "Saved the no-webhook path. Run discovery will stay disabled on purpose.",
    );
    return moveDiscoveryWizardToStep("ready", {
      state: {
        flow: "no_webhook",
        completedSteps: [
          ...((runtime.state || {}).completedSteps || []),
          "detect",
          "no_webhook",
        ],
        result: "none",
      },
    });
  }
  if (actionId === "wizard_complete_stub_only") {
    if (runtime.snapshot.savedWebhookUrl) {
      await recordDiscoveryEngineState(
        runtime.snapshot.savedWebhookUrl,
        DISCOVERY_ENGINE_STATE_STUB_ONLY,
        "wizard_stub_only",
      );
    }
    await refreshDiscoveryReadinessSnapshot({ force: true, rerender: false });
    setDiscoveryWizardMessage(
      "Stub-only wiring stays available, but it is not real discovery-ready.",
      "warning",
    );
    return moveDiscoveryWizardToStep("ready", {
      snapshot: getDiscoveryReadinessSnapshot(),
      state: {
        flow: "stub_only",
        completedSteps: [
          ...((runtime.state || {}).completedSteps || []),
          "detect",
          "stub_only",
        ],
        result: "stub_only",
      },
    });
  }
  if (actionId === "wizard_verify_existing_endpoint") {
    const relayApi = getDiscoveryWizardRelayApi();
    const endpointUrl = normalizeDiscoveryWebhookIdentity(
      runtime.drafts.endpointUrl || runtime.snapshot.savedWebhookUrl || "",
    );
    if (
      relayApi &&
      typeof relayApi.buildExternalEndpointValidationResult === "function"
    ) {
      const validation = relayApi.buildExternalEndpointValidationResult(
        endpointUrl,
        runtime.snapshot,
      );
      updateDiscoveryWizardRuntime({ lastVerificationResult: validation });
      if (!validation.ok && validation.kind === "invalid_endpoint") {
        showDiscoveryVerificationToast(validation, { context: "test_webhook" });
        setDiscoveryWizardMessage(validation.message, "warning");
        return renderDiscoverySetupWizard();
      }
    }
    return handleDiscoveryWizardVerification(endpointUrl, "test_webhook");
  }

  if (
    actionId === "local_bootstrap_refresh" ||
    actionId === "local_health_check" ||
    actionId === "local_tunnel_detect" ||
    actionId === "local_relay_apply" ||
    actionId === "local_verify_end_to_end"
  ) {
    const localApi = getDiscoveryWizardLocalApi();
    if (!localApi || typeof localApi.runLocalWizardAction !== "function") {
      console.warn(
        "[JobBored] discovery wizard local API missing; check discovery-wizard-local.js loaded",
      );
      showToast(
        "Discovery local helpers failed to load. Try a hard refresh (cache clear).",
        "error",
      );
      return null;
    }
    const result = await localApi.runLocalWizardAction(actionId, {
      snapshot: runtime.snapshot,
      state: runtime.state,
      wizardState: runtime.state,
      bootstrapState: runtime.localBootstrapState,
    });
    if (
      actionId === "local_tunnel_detect" &&
      result.ok &&
      result.suggestedUrl
    ) {
      writeDiscoveryTransportSetupState({
        tunnelPublicUrl: result.suggestedUrl,
      });
    }
    updateDiscoveryWizardRuntime({
      lastLocalResult: result,
      localBootstrapState: result.bootstrap
        ? { available: true, data: result.bootstrap }
        : runtime.localBootstrapState,
    });
    setDiscoveryWizardMessage(
      result.message || "Updated the local discovery path.",
      result.ok ? "info" : "warning",
    );
    let nextStep = result.nextStepId || runtime.activeStepId;
    let statePatch = result.wizardStatePatch || {};
    // Per UX consultation: auto-advance on success for the gate steps
    // (local_health_check + local_tunnel_detect). The previous design held
    // the user on the step which felt like "stuck" — most users missed the
    // step rail and didn't realize they could continue.
    const detailOneLine =
      result.detail && typeof result.detail === "string"
        ? result.detail.replace(/\s+/g, " ").trim().slice(0, 220)
        : "";
    const toastText = [result.message || "", detailOneLine]
      .filter(Boolean)
      .join(" ")
      .trim();
    showToast(
      toastText || (result.ok ? "Done." : "Something went wrong."),
      result.ok ? "success" : "warning",
    );
    if (result.ok && result.wizardStatePatch) {
      await persistDiscoveryWizardState(statePatch);
    }
    await refreshDiscoveryReadinessSnapshot({ force: true, rerender: false });
    const nextSnapshot = getDiscoveryReadinessSnapshot();
    return moveDiscoveryWizardToStep(nextStep, {
      snapshot: nextSnapshot,
      state: statePatch,
    });
  }

  if (
    actionId === "relay_copy_deploy_command" ||
    actionId === "relay_copy_agent_prompt" ||
    actionId === "relay_apply_worker_url"
  ) {
    const relayApi = getDiscoveryWizardRelayApi();
    if (!relayApi || typeof relayApi.runRelayWizardAction !== "function") {
      return null;
    }
    const relayResult = await relayApi.runRelayWizardAction(actionId, {
      snapshot: runtime.snapshot,
      workerUrl: runtime.drafts.workerUrl || runtime.snapshot.savedWebhookUrl,
      sheetId: getSettingsSheetIdValue() || "",
      origin:
        (window.location && typeof window.location.origin === "string"
          ? window.location.origin
          : "") || "*",
    });
    updateDiscoveryWizardRuntime({ lastRelayResult: relayResult });
    if (relayResult && relayResult.text) {
      copyTextToClipboard(relayResult.text);
      showToast("Copied to clipboard", "success");
      setDiscoveryWizardMessage("Copied relay setup text to the clipboard.");
      return renderDiscoverySetupWizard();
    }
    if (actionId === "relay_apply_worker_url") {
      if (!relayResult.ok) {
        const result = {
          ok: false,
          kind: relayResult.kind || "invalid_endpoint",
          message: relayResult.message || "Worker URL validation failed.",
          detail: relayResult.detail || "",
        };
        updateDiscoveryWizardRuntime({ lastVerificationResult: result });
        showDiscoveryVerificationToast(result, { context: "test_webhook" });
        setDiscoveryWizardMessage(result.message, "warning");
        return renderDiscoverySetupWizard();
      }
      mergeStoredConfigOverridePatch({ discoveryWebhookUrl: relayResult.url });
      await recordDiscoveryEngineState(
        relayResult.url,
        DISCOVERY_ENGINE_STATE_UNVERIFIED,
        "wizard_relay_apply",
      );
      await refreshDiscoveryReadinessSnapshot({ force: true, rerender: false });
      setDiscoveryWizardMessage("Worker URL saved — ready to test.");
      return moveDiscoveryWizardToStep("verify", {
        snapshot: getDiscoveryReadinessSnapshot(),
        state: {
          completedSteps: [
            ...((runtime.state || {}).completedSteps || []),
            "relay_deploy",
          ],
        },
      });
    }
    return null;
  }

  if (actionId === "wizard_verify_current_endpoint") {
    updateDiscoveryWizardRuntime({ lastDownstreamDiagnosis: null });
    const endpointUrl = normalizeDiscoveryWebhookIdentity(
      getDiscoveryWebhookUrl() ||
        runtime.drafts.workerUrl ||
        runtime.drafts.endpointUrl ||
        runtime.snapshot.savedWebhookUrl ||
        "",
    );
    return handleDiscoveryWizardVerification(endpointUrl, "test_webhook");
  }

  if (actionId === "diag_rerun_diagnosis") {
    const freshSnapshot = await refreshDiscoveryReadinessSnapshot({
      force: true,
      rerender: false,
    });
    const diagnosis = await diagnoseDownstreamChain(freshSnapshot);
    updateDiscoveryWizardRuntime({
      snapshot: freshSnapshot,
      lastDownstreamDiagnosis: diagnosis,
    });
    setDiscoveryWizardMessage(
      diagnosis.summary || "Diagnosis complete.",
      diagnosis.primaryFix ? "warning" : "info",
    );
    return renderDiscoverySetupWizard();
  }

  if (actionId === "diag_fix_local_server") {
    const freshSnapshot = await refreshDiscoveryReadinessSnapshot({
      force: true,
      rerender: false,
    });
    const diagnosis = await diagnoseDownstreamChain(freshSnapshot);
    updateDiscoveryWizardRuntime({
      snapshot: freshSnapshot,
      lastDownstreamDiagnosis: diagnosis,
    });
    if (diagnosis.localServer.healthy) {
      showToast("Server is running.", "success");
      setDiscoveryWizardMessage(
        "Server is healthy — try the test again.",
        "info",
      );
    } else {
      showToast("Server still down — go to the Server step for help.", "error");
      setDiscoveryWizardMessage(
        "Server not responding. Use the Server step to start it.",
        "warning",
      );
      return moveDiscoveryWizardToStep("local_health");
    }
    return renderDiscoverySetupWizard();
  }

  if (actionId === "diag_fix_tunnel") {
    return moveDiscoveryWizardToStep("tunnel");
  }

  if (actionId === "diag_fix_relay") {
    return moveDiscoveryWizardToStep("relay_deploy");
  }

  if (actionId === "diag_fix_update_tunnel_and_relay") {
    const diagnosis = runtime.lastDownstreamDiagnosis;
    const liveUrl = diagnosis && diagnosis.liveNgrokUrl;
    if (liveUrl && liveUrl !== "unknown") {
      writeDiscoveryTransportSetupState({ tunnelPublicUrl: liveUrl });
    }

    // Auto-heal path: when running on localhost, the dev-server exposes
    // /__proxy/fix-setup which redeploys the relay against the live ngrok
    // URL in place. No copy-paste, no second terminal.
    const isLocal =
      typeof window !== "undefined" &&
      window.location &&
      (window.location.hostname === "localhost" ||
        window.location.hostname === "127.0.0.1" ||
        window.location.hostname === "[::1]" ||
        window.location.hostname === "::1");

    if (isLocal) {
      setDiscoveryWizardMessage(
        "Auto-healing tunnel & relay… (no terminal needed)",
        "info",
      );
      try {
        const resp = await fetch("/__proxy/fix-setup", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: "{}",
        });
        const body = await resp.json().catch(() => ({}));
        if (resp.ok && body && body.ok) {
          showToast(
            body.relayRedeployed
              ? "Relay redeployed against live ngrok URL — re-testing…"
              : "Local setup restored — re-testing…",
            "success",
          );
          // Re-snapshot, clear stale diagnosis, then re-run verification.
          await refreshDiscoveryReadinessSnapshot({
            force: true,
            rerender: false,
          });
          updateDiscoveryWizardRuntime({ lastDownstreamDiagnosis: null });
          const endpointUrl = normalizeDiscoveryWebhookIdentity(
            getDiscoveryWebhookUrl() ||
              runtime.drafts.workerUrl ||
              runtime.drafts.endpointUrl ||
              runtime.snapshot.savedWebhookUrl ||
              "",
          );
          return handleDiscoveryWizardVerification(
            endpointUrl,
            "test_webhook",
          );
        }
        if (body && body.needsAuth) {
          showToast(
            "Cloudflare auth needed. Run `npx wrangler login` in a terminal, then click Re-check.",
            "warning",
            true,
          );
          return renderDiscoverySetupWizard();
        }
        // fall through to copy-command UX
      } catch (e) {
        console.warn("[JobBored] fix-setup proxy unavailable:", e);
      }
    }

    // Fallback: hosted dashboard or proxy unavailable — show the copy command
    // (preserves the original UX so we never regress non-local users).
    const deployCommand =
      diagnosis && diagnosis.redeployCommand ? diagnosis.redeployCommand : "";
    if (liveUrl && liveUrl !== "unknown") {
      showToast(
        "Live ngrok URL saved. Copy the command, paste it into a terminal in the Job-Bored repo, press Enter, then Test again.",
        "warning",
        true,
        createDiscoveryRelayCopyCommandToastAction(deployCommand),
      );
    }
    return moveDiscoveryWizardToStep("relay_deploy");
  }

  if (actionId === "diag_fix_reverify") {
    updateDiscoveryWizardRuntime({ lastDownstreamDiagnosis: null });
    const endpointUrl = normalizeDiscoveryWebhookIdentity(
      getDiscoveryWebhookUrl() ||
        runtime.drafts.workerUrl ||
        runtime.drafts.endpointUrl ||
        runtime.snapshot.savedWebhookUrl ||
        "",
    );
    return handleDiscoveryWizardVerification(endpointUrl, "test_webhook");
  }

  return null;
}

function setAppsScriptDeployStatus(tone, message, detail) {
  const extra = arguments.length > 3 ? arguments[3] : null;
  const actions = Array.isArray(extra)
    ? extra
    : extra && typeof extra === "object" && Array.isArray(extra.actions)
      ? extra.actions
      : [];
  const steps =
    extra && typeof extra === "object" && Array.isArray(extra.steps)
      ? extra.steps.map((step) => String(step || "").trim()).filter(Boolean)
      : [];
  appsScriptDeployStatus = {
    tone: tone || "info",
    message: String(message || ""),
    detail: detail ? String(detail) : "",
    steps,
    actions: actions
      .map((action) => ({
        label:
          action && action.label != null ? String(action.label).trim() : "",
        href: action && action.href != null ? String(action.href).trim() : "",
        primary: !!(action && action.primary),
      }))
      .filter((action) => action.label && action.href),
  };
  renderAppsScriptDeployUi();
}

function clearAppsScriptDeployStatus() {
  appsScriptDeployStatus = null;
  renderAppsScriptDeployUi();
}

const PENDING_DISCOVERY_SETUP_KEY = "pendingDiscoverySetup";

function hasPendingDiscoverySetup() {
  try {
    return sessionStorage.getItem(PENDING_DISCOVERY_SETUP_KEY) === "1";
  } catch (_) {
    return false;
  }
}

function queuePendingDiscoverySetup() {
  try {
    sessionStorage.setItem(PENDING_DISCOVERY_SETUP_KEY, "1");
    return true;
  } catch (_) {
    return false;
  }
}

async function resumePendingDiscoverySetupIfNeeded() {
  if (!hasPendingDiscoverySetup()) return false;
  try {
    sessionStorage.removeItem(PENDING_DISCOVERY_SETUP_KEY);
  } catch (_) {
    /* ignore */
  }
  await openSettingsForDiscoveryWebhook();
  return true;
}

function stripSetupDiscoveryParam() {
  const params = new URLSearchParams(window.location.search);
  if (params.get("setup") !== "discovery") return;
  params.delete("setup");
  const q = params.toString();
  const path =
    window.location.pathname + (q ? "?" + q : "") + window.location.hash;
  history.replaceState(null, "", path);
}

function focusDiscoveryWebhookFieldInSettings() {
  const Adapters = window.JobBoredSettingsDiscoveryAdapters;
  if (Adapters) {
    Adapters.focusDiscoveryWebhookField();
    return;
  }
  const el = document.getElementById("settingsDiscoveryWebhookUrl");
  if (!el) return;
  el.focus();
  if (typeof el.select === "function") el.select();
}

async function openSettingsForDiscoveryWebhook() {
  return requestDiscoverySetup({
    entryPoint: "settings",
    flow: getDiscoveryWizardRecommendedFlow(getDiscoveryReadinessSnapshot()),
    allowWhileOnboarding: true,
  });
}

async function requestDiscoverySetup(options = {}) {
  const {
    stripSetupParam = false,
    allowWhileOnboarding = false,
    ...wizardOptions
  } = options;
  if (isOnboardingWizardVisible() && !allowWhileOnboarding) {
    queuePendingDiscoverySetup();
    if (stripSetupParam) {
      stripSetupDiscoveryParam();
    }
    return { deferred: true };
  }
  await openDiscoverySetupWizard(wizardOptions);
  if (stripSetupParam) {
    stripSetupDiscoveryParam();
  }
  return { deferred: false };
}

// ============================================
// DISCOVERY RUN STATUS POLLING
// ============================================

const MAX_POLL_ERRORS = 3;
const STATUS_POLL_DEBOUNCE_MS = 500;

/**
 * Build the full status URL from a relative statusPath.
 * Handles explicit statusPath or constructs from runId + base webhook URL.
 * @param {string} statusPath  e.g. "/runs/run_abc" or "/runs/run_abc?worker=local"
 * @param {string} webhookUrl  the configured discovery webhook base URL
 * @returns {string}  fully qualified status fetch URL
 */
function buildRunStatusUrl(statusPath, webhookUrl) {
  const path = String(statusPath || "").trim();
  if (!path) return "";
  try {
    if (path.startsWith("http://") || path.startsWith("https://")) {
      return path;
    }
    const base = new URL(String(webhookUrl || ""));
    if (path.startsWith("/")) {
      return new URL(path, base.origin).toString();
    }
    const baseDir = base.href.endsWith("/")
      ? base.href
      : base.href.replace(/\/[^/]*$/, "/");
    return new URL(path, baseDir).toString();
  } catch (_) {
    return "";
  }
}

/**
 * Fetch and process a single status poll for the active run.
 * Returns the parsed status body or null on error.
 * @param {string} webhookUrl
 * @returns {Promise<object|null>}
 */
async function pollRunStatus(webhookUrl) {
  const tracker = discoveryRunTracker;
  const state = tracker.getState();
  if (!state.runId || !state.statusPath) return null;

  const statusUrl = buildRunStatusUrl(state.statusPath, webhookUrl);
  if (!statusUrl) return null;

  let response;
  try {
    response = await fetch(statusUrl, {
      method: "GET",
      mode: "cors",
      headers: { Accept: "application/json" },
    });
  } catch (err) {
    tracker.markPollError(
      `Network error fetching status: ${err && err.message ? err.message : String(err)}`,
    );
    return null;
  }

  if (!response.ok) {
    tracker.markPollError(
      `Status endpoint returned HTTP ${response.status}`,
    );
    return null;
  }

  let data;
  try {
    data = await response.json();
  } catch (_) {
    tracker.markPollError("Status response was not valid JSON");
    return null;
  }

  return data;
}

/**
 * Main polling loop — call once after an accepted_async response.
 * Automatically stops when the run reaches a terminal state or polling errors exceed limit.
 *
 * @param {string} webhookUrl  discovery webhook URL (used to resolve relative statusPath)
 */
async function startDiscoveryStatusPolling(webhookUrl) {
  const tracker = discoveryRunTracker;

  // Cancel any in-flight polling session before starting fresh
  if (tracker._pollTimer) {
    clearTimeout(tracker._pollTimer);
    tracker._pollTimer = null;
  }

  async function poll() {
    const state = tracker.getState();

    // If we've reached terminal or been cleared, stop
    if (!state.runId || state.status === "idle") {
      return;
    }

    const statusData = await pollRunStatus(webhookUrl);
    if (statusData) {
      tracker.updateFromStatusResponse(statusData);
    }

    const updated = tracker.getState();

    if (updated.status === "polling_error") {
      if (updated.pollErrorCount >= MAX_POLL_ERRORS) {
        // Exhausted retries — surface error and stop
        tracker.markFailed(
          "Status polling failed after multiple attempts. Check the discovery worker logs.",
        );
        renderDiscoveryRunStatus();
        return;
      }
      // Exponential-ish back-off: 1s, 2s, 4s
      const backoff = Math.min(4000, 500 * Math.pow(2, updated.pollErrorCount));
      tracker._pollTimer = setTimeout(poll, backoff);
      return;
    }

    if (updated.isTerminal()) {
      renderDiscoveryRunStatus();
      return;
    }

    // Normal: wait pollAfterMs then poll again
    const interval = Number.isFinite(updated.pollAfterMs)
      ? Math.max(STATUS_POLL_DEBOUNCE_MS, updated.pollAfterMs)
      : 2000;
    tracker._pollTimer = setTimeout(poll, interval);
  }

  // Kick off the first poll after the advertised pollAfterMs
  const state = tracker.getState();
  const firstDelay = Math.max(
    STATUS_POLL_DEBOUNCE_MS,
    Number.isFinite(state.pollAfterMs) ? state.pollAfterMs : 2000,
  );
  tracker._pollTimer = setTimeout(poll, firstDelay);
}

/** Stop any active polling loop without clearing run state */
function stopDiscoveryStatusPolling() {
  if (discoveryRunTracker._pollTimer) {
    clearTimeout(discoveryRunTracker._pollTimer);
    discoveryRunTracker._pollTimer = null;
  }
}

/**
 * Render current run status into the discovery status bar (toast area / status chip).
 * Called after every tracker state change so the user sees live progress.
 */
function renderDiscoveryRunStatus() {
  const state = discoveryRunTracker.getState();
  const openBtn = document.getElementById("discoveryBtn");

  if (state.status === "idle") {
    if (openBtn) {
      openBtn.classList.remove("loading", "run-pending", "run-running", "run-terminal");
      openBtn.removeAttribute("aria-label");
    }
    return;
  }

  // Apply CSS class for visual state on the button
  if (openBtn) {
    openBtn.classList.add("run-" + state.status);
    openBtn.classList.remove("loading");
  }

  // Build status message
  let statusMessage = "";
  let statusTone = "info";

  switch (state.status) {
    case "pending":
      statusMessage = `Run ${state.runId ? state.runId.slice(0, 8) + "…" : ""} accepted — checking status…`;
      statusTone = "info";
      break;
    case "running":
      statusMessage = `Run ${state.runId ? state.runId.slice(0, 8) + "…" : ""} in progress…`;
      statusTone = "info";
      break;
    case "polling_error":
      statusMessage = `Run ${state.runId ? state.runId.slice(0, 8) + "…" : ""} — retrying…`;
      statusTone = "warning";
      break;
    case "completed":
      statusMessage = "Discovery complete — new roles will appear in your sheet.";
      statusTone = "success";
      break;
    case "empty":
      statusMessage = "Discovery finished — no new roles found this run.";
      statusTone = "info";
      break;
    case "partial":
      statusMessage =
        "Discovery finished with partial results. " +
        (state.errorMessage ? state.errorMessage + ". " : "") +
        "Check the worker logs for details.";
      statusTone = "warning";
      break;
    case "failed":
      statusMessage =
        "Discovery run failed. " +
        (state.errorMessage ? state.errorMessage : "Check the worker logs.");
      statusTone = "error";
      break;
    default:
      statusMessage = "";
  }

  if (openBtn && statusMessage) {
    openBtn.setAttribute("aria-label", statusMessage);
    // Also surface in a toast for non-terminal states
    if (state.status !== "idle") {
      // Use a transient toast (non-blocking) for live updates
      showToast(statusMessage, statusTone, false);
    }
  }
}

// ============================================
// DISCOVERY SETUP WIZARD
// ============================================

async function handleDiscoverySetupDeepLink() {
  const params = new URLSearchParams(window.location.search);
  if (params.get("setup") !== "discovery") return false;
  await requestDiscoverySetup({
    entryPoint: "deep_link",
    stripSetupParam: true,
  });
  return true;
}

function runPostAccessBootstrapOnce() {
  if (postAccessBootstrapDone) return postAccessBootstrapPromise;
  postAccessBootstrapDone = true;
  postAccessBootstrapPromise = (async () => {
    await checkOnboardingGate();
    await handleDiscoverySetupDeepLink();
  })();
  return postAccessBootstrapPromise;
}

/**
 * Scraper API base URL (no trailing slash).
 * Explicit config wins. If unset and the dashboard is opened on localhost, defaults
 * to the local server so `npm start` works without editing config. On GitHub Pages
 * (HTTPS), leave config empty unless you deploy a scraper — see DEPLOY-SCRAPER.md.
 */
function getJobPostingScrapeUrl() {
  const cfg = window.COMMAND_CENTER_CONFIG;
  const raw = cfg && cfg.jobPostingScrapeUrl;
  if (raw != null && String(raw).trim() !== "") {
    return String(raw).trim().replace(/\/+$/, "");
  }
  if (typeof window === "undefined") return "";
  const h = window.location.hostname;
  if (h === "localhost" || h === "127.0.0.1" || h === "[::1]" || h === "::1") {
    return "http://127.0.0.1:3847";
  }
  return "";
}

function getAtsScoringConfig() {
  const cfg = window.COMMAND_CENTER_CONFIG || {};
  const rawMode = String(cfg.atsScoringMode || "server").toLowerCase();
  const mode = rawMode === "webhook" ? "webhook" : "server";
  const serverUrl = String(cfg.atsScoringServerUrl || "").trim();
  const webhookUrl = String(cfg.atsScoringWebhookUrl || "").trim();
  return {
    mode,
    serverUrl,
    webhookUrl,
  };
}

function getAtsScorecardApiUrl() {
  const cfg = getAtsScoringConfig();
  if (cfg.mode === "webhook") return cfg.webhookUrl;
  if (cfg.serverUrl) {
    const trimmed = cfg.serverUrl.replace(/\/+$/, "");
    return /\/api\/ats-scorecard$/i.test(trimmed)
      ? trimmed
      : `${trimmed}/api/ats-scorecard`;
  }
  if (typeof window === "undefined") return "";
  const h = window.location.hostname;
  if (h === "localhost" || h === "127.0.0.1" || h === "[::1]" || h === "::1") {
    return "http://127.0.0.1:3847/api/ats-scorecard";
  }
  return "/api/ats-scorecard";
}

/**
 * HTTPS pages (e.g. GitHub Pages) cannot fetch http://127.0.0.1 — mixed content.
 */
function isScraperUrlBlockedOnThisPage(baseUrl) {
  if (!baseUrl) return false;
  if (typeof window === "undefined") return false;
  if (window.location.protocol !== "https:") return false;
  try {
    const u = new URL(baseUrl, window.location.href);
    if (u.protocol !== "http:") return false;
    const host = u.hostname.replace(/^\[|\]$/g, "").toLowerCase();
    return host === "localhost" || host === "127.0.0.1" || host === "::1";
  } catch {
    return false;
  }
}

const SCRAPER_HTTPS_BLOCKED_HINT =
  "HTTPS pages (e.g. GitHub Pages) cannot call http://127.0.0.1 — the browser blocks it. Deploy the scraper to a public HTTPS URL and paste it in Settings, or run the app locally with npm start. See DEPLOY-SCRAPER.md.";

function openScraperSetupModal() {
  const modal = document.getElementById("scraperSetupModal");
  const result = document.getElementById("scraperTestResult");
  if (result) {
    result.textContent = "";
    result.className = "scraper-test-result";
  }
  if (modal) {
    modal.style.display = "flex";
    document.getElementById("scraperSetupDoneBtn")?.focus();
  }
}

function closeScraperSetupModal() {
  const modal = document.getElementById("scraperSetupModal");
  if (modal) modal.style.display = "none";
}

function copyTextToClipboard(text) {
  const t = String(text || "");
  if (!t) return;
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(t).then(
      () => showToast("Copied to clipboard", "success"),
      () => showToast("Could not copy — select and copy manually", "info"),
    );
  } else {
    showToast("Clipboard not available", "info");
  }
}

async function runScraperConnectionTest() {
  const el = document.getElementById("settingsJobPostingScrapeUrl");
  const raw = (el && el.value.trim()) || "";
  const base = (raw || getJobPostingScrapeUrl() || "").replace(/\/+$/, "");
  const out = document.getElementById("scraperTestResult");
  if (out) {
    out.textContent = "Checking…";
    out.className = "scraper-test-result";
  }
  if (!base) {
    if (out) {
      out.textContent =
        "No URL — paste a deployed HTTPS scraper, or open this app on localhost (npm start).";
      out.className = "scraper-test-result scraper-test-result--bad";
    }
    showToast(
      "Set a scraper URL in Settings or use the setup guide for local npm start.",
      "error",
    );
    return;
  }
  if (isScraperUrlBlockedOnThisPage(base)) {
    if (out) {
      out.textContent =
        "Blocked: this HTTPS page cannot reach a local HTTP scraper. See DEPLOY-SCRAPER.md.";
      out.className = "scraper-test-result scraper-test-result--bad";
    }
    showToast(SCRAPER_HTTPS_BLOCKED_HINT, "error", true);
    return;
  }
  const url = `${base}/health`;
  try {
    const r = await fetch(url, { method: "GET", mode: "cors" });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    if (j.ok) {
      if (out) {
        out.textContent = "Server reachable";
        out.className = "scraper-test-result scraper-test-result--ok";
      }
      showToast("Scraper server is running", "success");
    } else {
      throw new Error("Unexpected response");
    }
  } catch (e) {
    let msg =
      e && e.message
        ? String(e.message)
        : "Could not reach server — is npm start running?";
    if (isFetchNetworkError(e)) {
      msg =
        "Can't connect — start the server: cd server && npm start (leave the terminal open).";
    }
    if (out) {
      out.textContent = msg;
      out.className = "scraper-test-result scraper-test-result--bad";
    }
  }
}

/** True for offline / connection refused / CORS-style fetch failures */
function isFetchNetworkError(err) {
  if (!err) return false;
  const msg = String(err.message || err || "");
  const name = err.name || "";
  return (
    name === "TypeError" ||
    msg === "Failed to fetch" ||
    msg.includes("NetworkError") ||
    msg.includes("Network request failed") ||
    msg.includes("Load failed") ||
    msg.includes("CONNECTION_REFUSED")
  );
}

async function sha256Hex(text) {
  if (
    typeof crypto === "undefined" ||
    !crypto.subtle ||
    typeof TextEncoder === "undefined"
  ) {
    return "";
  }
  const bytes = new TextEncoder().encode(String(text || ""));
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest), (b) =>
    b.toString(16).padStart(2, "0"),
  ).join("");
}

async function loadAppsScriptStubBundle() {
  let codeResp;
  let manifestResp;
  try {
    [codeResp, manifestResp] = await Promise.all([
      fetch("integrations/apps-script/Code.gs", { cache: "no-store" }),
      fetch("integrations/apps-script/appsscript.json", { cache: "no-store" }),
    ]);
  } catch (err) {
    if (isFetchNetworkError(err)) {
      throw new Error(
        "Could not load the local Apps Script stub files from this site.",
      );
    }
    throw err;
  }
  if (!codeResp.ok || !manifestResp.ok) {
    throw new Error(
      "Could not load integrations/apps-script/Code.gs or appsscript.json.",
    );
  }

  const [codeSource, manifestText] = await Promise.all([
    codeResp.text(),
    manifestResp.text(),
  ]);

  let manifest;
  try {
    manifest = JSON.parse(manifestText);
  } catch (err) {
    throw new Error(
      "integrations/apps-script/appsscript.json is not valid JSON.",
    );
  }

  manifest = manifest && typeof manifest === "object" ? manifest : {};
  manifest.webapp = {
    access: APPS_SCRIPT_WEBAPP_ACCESS,
    executeAs: APPS_SCRIPT_WEBAPP_EXECUTE_AS,
  };
  const manifestSource = JSON.stringify(manifest, null, 2);
  const stubHash = await sha256Hex(`${codeSource}\n---\n${manifestSource}`);

  return {
    files: [
      {
        name: "Code",
        type: "SERVER_JS",
        source: codeSource,
      },
      {
        name: "appsscript",
        type: "JSON",
        source: manifestSource,
      },
    ],
    stubHash,
  };
}

function formatAppsScriptDeployGisError(err) {
  const errType =
    err && typeof err === "object" && err.type != null ? String(err.type) : "";
  const msg =
    err && typeof err === "object" && err.message != null
      ? String(err.message)
      : String(err || "");
  if (
    errType === "popup_failed_to_open" ||
    errType === "popup_closed" ||
    /popup/i.test(msg)
  ) {
    return "Google permission prompt could not open. Allow popups for this site and try again.";
  }
  return "Google did not grant the Apps Script deploy permissions.";
}

function requestAppsScriptDeployAccessToken() {
  const clientId = getSettingsOAuthClientIdValue();
  if (!clientId) {
    return Promise.reject(
      new Error("Add an OAuth Client ID above before deploying."),
    );
  }
  if (hasUnsavedOAuthClientIdChange(clientId)) {
    return Promise.reject(
      new Error(
        "Save Settings first so the page reloads with this OAuth client ID, then retry Deploy.",
      ),
    );
  }
  if (
    !gisLoaded ||
    typeof google === "undefined" ||
    !google.accounts ||
    !google.accounts.oauth2
  ) {
    return Promise.reject(
      new Error("Google sign-in is still loading. Try again in a moment."),
    );
  }

  return new Promise((resolve, reject) => {
    let settled = false;
    const finish = (fn, value) => {
      if (settled) return;
      settled = true;
      fn(value);
    };

    let client;
    try {
      client = google.accounts.oauth2.initTokenClient({
        client_id: clientId,
        scope: APPS_SCRIPT_DEPLOY_SCOPES.join(" "),
        include_granted_scopes: true,
        login_hint: userEmail || undefined,
        callback: (tokenResponse) => {
          if (!tokenResponse || tokenResponse.error) {
            finish(
              reject,
              new Error(
                tokenResponse && tokenResponse.error_description
                  ? tokenResponse.error_description
                  : tokenResponse && tokenResponse.error
                    ? tokenResponse.error
                    : "Google did not return a deploy token.",
              ),
            );
            return;
          }
          if (
            google.accounts.oauth2.hasGrantedAllScopes &&
            !google.accounts.oauth2.hasGrantedAllScopes(
              tokenResponse,
              ...APPS_SCRIPT_DEPLOY_SCOPES,
            )
          ) {
            finish(
              reject,
              new Error(
                "Google did not grant all required Apps Script deploy scopes.",
              ),
            );
            return;
          }
          finish(resolve, tokenResponse.access_token);
        },
        error_callback: (err) => {
          finish(reject, new Error(formatAppsScriptDeployGisError(err)));
        },
      });
      client.requestAccessToken({
        prompt: userEmail ? "" : "select_account",
      });
    } catch (err) {
      finish(reject, err);
    }
  });
}

async function readAppsScriptApiError(resp) {
  const raw = await resp.text().catch(() => "");
  let data = null;
  try {
    data = raw ? JSON.parse(raw) : null;
  } catch (_) {
    data = null;
  }
  const message =
    (data &&
      data.error &&
      typeof data.error === "object" &&
      String(data.error.message || "").trim()) ||
    (data && typeof data.message === "string" && data.message.trim()) ||
    raw.trim() ||
    `HTTP ${resp.status}`;

  const detailTexts = [];
  const detailUrls = [];
  const details =
    data && data.error && Array.isArray(data.error.details)
      ? data.error.details
      : [];

  for (const item of details) {
    if (!item || typeof item !== "object") continue;
    if (typeof item.message === "string" && item.message.trim()) {
      detailTexts.push(item.message.trim());
    }
    if (Array.isArray(item.links)) {
      for (const link of item.links) {
        if (
          link &&
          typeof link === "object" &&
          typeof link.url === "string" &&
          link.url.trim()
        ) {
          detailUrls.push(link.url.trim());
        }
      }
    }
  }

  const urlMatches = `${message}\n${detailTexts.join("\n")}`.match(
    /https:\/\/[^\s)"'<>]+/g,
  );
  if (urlMatches) detailUrls.push(...urlMatches);

  const uniqueUrls = Array.from(
    new Set(
      detailUrls.map((url) =>
        String(url || "")
          .replace(/[.,;:]+$/g, "")
          .trim(),
      ),
    ),
  ).filter(Boolean);

  const fullText = [message, ...detailTexts].filter(Boolean).join(" ");

  if (
    /User has not enabled the Apps Script API/i.test(fullText) ||
    /script\.google\.com\/home\/usersettings/i.test(fullText)
  ) {
    const settingsUrl =
      uniqueUrls.find((url) =>
        /script\.google\.com\/home\/usersettings/i.test(url),
      ) || "https://script.google.com/home/usersettings";
    const err = new Error(message);
    err.deployStatus = {
      tone: "error",
      message: "Enable Apps Script API access in Apps Script user settings.",
      detail:
        "Google says your account has not enabled Apps Script API access for script projects. Open Apps Script user settings, turn on Google Apps Script API access, wait a minute, then retry.",
      actions: [
        {
          label: "Open Apps Script user settings",
          href: settingsUrl,
        },
      ],
    };
    return err;
  }

  if (
    /SERVICE_DISABLED|API has not been used|Access Not Configured|enable it/i.test(
      fullText,
    )
  ) {
    const cloudUrl =
      uniqueUrls.find((url) => /script\.googleapis\.com/i.test(url)) ||
      "https://console.cloud.google.com/apis/library/script.googleapis.com";
    const err = new Error(message);
    err.deployStatus = {
      tone: "error",
      message:
        "Enable Google Apps Script API in the Google Cloud project behind this OAuth client.",
      detail:
        "Google is saying script.googleapis.com is still disabled for the Cloud project that owns this OAuth client ID. Enable it, wait a minute, then retry.",
      actions: [
        {
          label: "Open Apps Script API in Cloud Console",
          href: cloudUrl,
        },
        {
          label: "Open Apps Script user settings",
          href: "https://script.google.com/home/usersettings",
        },
      ],
    };
    return err;
  }

  if (/origin_mismatch/i.test(fullText)) {
    const err = new Error(message);
    err.deployStatus = {
      tone: "error",
      message: "This OAuth client does not allow the current site origin.",
      detail:
        "Add this site under Authorized JavaScript origins in Google Cloud Console, then retry the deploy.",
      actions: [
        {
          label: "Open OAuth clients in Cloud Console",
          href: "https://console.cloud.google.com/auth/clients",
        },
      ],
    };
    return err;
  }

  if (resp.status === 401) {
    const err = new Error(message);
    err.deployStatus = {
      tone: "error",
      message: "Google session expired while deploying.",
      detail: "Retry Deploy and complete the Google permission prompt again.",
      actions: [],
    };
    return err;
  }

  const err = new Error(message);
  err.deployStatus = {
    tone: "error",
    message: "Apps Script deploy failed.",
    detail: message,
    actions: uniqueUrls.length
      ? uniqueUrls.slice(0, 2).map((url) => ({
          label: /script\.google\.com/i.test(url)
            ? "Open Google guidance"
            : "Open related Google console page",
          href: url,
        }))
      : [],
  };
  return err;
}

async function appsScriptApiRequest(path, deployToken, init) {
  const opts = init && typeof init === "object" ? { ...init } : {};
  const headers = new Headers(opts.headers || {});
  headers.set("Authorization", `Bearer ${deployToken}`);
  headers.set("Accept", "application/json");
  if (opts.body != null && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }

  const body =
    opts.body != null && typeof opts.body !== "string"
      ? JSON.stringify(opts.body)
      : opts.body;

  let resp;
  try {
    resp = await fetch(`${APPS_SCRIPT_API_BASE}${path}`, {
      ...opts,
      headers,
      body,
    });
  } catch (err) {
    if (isFetchNetworkError(err)) {
      throw new Error(
        "Could not reach the Google Apps Script API from this browser.",
      );
    }
    throw err;
  }

  if (!resp.ok) {
    throw await readAppsScriptApiError(resp);
  }
  if (resp.status === 204) return null;
  return resp.json().catch(() => ({}));
}

function getAppsScriptDeployStateStore() {
  const UC = window.CommandCenterUserContent;
  return UC &&
    typeof UC.getAppsScriptDeployState === "function" &&
    typeof UC.saveAppsScriptDeployState === "function"
    ? UC
    : null;
}

async function populateAppsScriptDeployStateIntoSettingsForm() {
  const store = getAppsScriptDeployStateStore();
  if (!store) {
    appsScriptDeployStateCache = null;
    renderAppsScriptDeployUi();
    return;
  }
  try {
    appsScriptDeployStateCache = await store.getAppsScriptDeployState();
  } catch (err) {
    console.warn("[JobBored] Apps Script deploy state:", err);
    appsScriptDeployStateCache = null;
    appsScriptDeployStatus = {
      tone: "error",
      message: "Could not load saved Apps Script deploy state.",
      detail: err && err.message ? String(err.message) : "",
    };
  }
  renderAppsScriptDeployUi();
}

function extractWebAppUrlFromDeployment(deployment) {
  const webApp = extractWebAppEntryPointFromDeployment(deployment);
  return webApp.url;
}

function extractWebAppEntryPointFromDeployment(deployment) {
  const entryPoints = Array.isArray(deployment && deployment.entryPoints)
    ? deployment.entryPoints
    : [];
  for (const entryPoint of entryPoints) {
    const webApp =
      entryPoint &&
      entryPoint.entryPointType === "WEB_APP" &&
      entryPoint.webApp &&
      typeof entryPoint.webApp === "object"
        ? entryPoint.webApp
        : null;
    const config =
      webApp &&
      webApp.entryPointConfig &&
      typeof webApp.entryPointConfig === "object"
        ? webApp.entryPointConfig
        : null;
    if (webApp && typeof webApp.url === "string" && webApp.url.trim()) {
      return {
        url: webApp.url.trim(),
        access:
          config && typeof config.access === "string"
            ? config.access.trim()
            : "",
        executeAs:
          config && typeof config.executeAs === "string"
            ? config.executeAs.trim()
            : "",
      };
    }
  }
  return { url: "", access: "", executeAs: "" };
}

async function fetchAppsScriptDeployment(scriptId, deploymentId, deployToken) {
  return appsScriptApiRequest(
    `/projects/${encodeURIComponent(scriptId)}/deployments/${encodeURIComponent(deploymentId)}`,
    deployToken,
    { method: "GET" },
  );
}

function buildAppsScriptPublicProbeUrl(webAppUrl, callbackName) {
  const url = new URL(webAppUrl);
  url.searchParams.set("commandCenterProbe", "1");
  url.searchParams.set("callback", callbackName);
  return url.toString();
}

async function probeAppsScriptWebAppPublicAccess(webAppUrl) {
  if (typeof document === "undefined" || !document.createElement) {
    return { ok: false, reason: "unsupported" };
  }
  return new Promise((resolve) => {
    let settled = false;
    const callbackName = `__jbAppsScriptProbe_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
    const script = document.createElement("script");
    const cleanup = (result) => {
      if (settled) return;
      settled = true;
      try {
        delete window[callbackName];
      } catch (_) {
        window[callbackName] = undefined;
      }
      if (script.parentNode) script.parentNode.removeChild(script);
      resolve(result);
    };
    const timeoutId = window.setTimeout(() => {
      cleanup({ ok: false, reason: "timeout" });
    }, 12000);

    window[callbackName] = (payload) => {
      window.clearTimeout(timeoutId);
      if (
        payload &&
        payload.ok === true &&
        payload.service === "command-center-apps-script-stub"
      ) {
        cleanup({ ok: true, payload });
        return;
      }
      cleanup({ ok: false, reason: "invalid-payload", payload });
    };

    script.async = true;
    script.src = buildAppsScriptPublicProbeUrl(webAppUrl, callbackName);
    script.onerror = () => {
      window.clearTimeout(timeoutId);
      cleanup({ ok: false, reason: "load-error" });
    };
    (document.head || document.documentElement || document.body).appendChild(
      script,
    );
  });
}

async function verifyAppsScriptDeploymentPublicAccess(
  scriptId,
  deploymentId,
  deployToken,
  existingDeployment,
) {
  const deployment =
    existingDeployment &&
    existingDeployment.deploymentId &&
    String(existingDeployment.deploymentId).trim() ===
      String(deploymentId || "").trim()
      ? existingDeployment
      : await fetchAppsScriptDeployment(scriptId, deploymentId, deployToken);

  const webAppEntry = extractWebAppEntryPointFromDeployment(deployment);
  if (!webAppEntry.url) {
    throw new Error(
      "Google deployed the script but did not return a web app /exec URL.",
    );
  }

  const statePatch = {
    webAppUrl: webAppEntry.url,
    access: webAppEntry.access || "",
    executeAs: webAppEntry.executeAs || "",
    deploymentAccess: webAppEntry.access || "",
    deploymentExecuteAs: webAppEntry.executeAs || "",
    publicAccessCheckedAt: new Date().toISOString(),
  };

  if (
    webAppEntry.access !== APPS_SCRIPT_WEBAPP_ACCESS ||
    webAppEntry.executeAs !== APPS_SCRIPT_WEBAPP_EXECUTE_AS
  ) {
    return {
      ready: false,
      statePatch: {
        ...statePatch,
        publicAccessState: APPS_SCRIPT_PUBLIC_ACCESS_NEEDS_REMEDIATION,
        publicAccessIssue: "deployment-config",
      },
      deployStatus: buildAppsScriptPublicAccessRemediationStatus({
        scriptId,
        webAppUrl: webAppEntry.url,
        deploymentAccess: webAppEntry.access,
        deploymentExecuteAs: webAppEntry.executeAs,
        failureKind: "deployment-config",
      }),
    };
  }

  const probe = await probeAppsScriptWebAppPublicAccess(webAppEntry.url);
  if (!probe.ok) {
    return {
      ready: false,
      statePatch: {
        ...statePatch,
        publicAccessState: APPS_SCRIPT_PUBLIC_ACCESS_NEEDS_REMEDIATION,
        publicAccessIssue: "probe",
      },
      deployStatus: buildAppsScriptPublicAccessRemediationStatus({
        scriptId,
        webAppUrl: webAppEntry.url,
        deploymentAccess: webAppEntry.access,
        deploymentExecuteAs: webAppEntry.executeAs,
        failureKind: "probe",
      }),
    };
  }

  return {
    ready: true,
    statePatch: {
      ...statePatch,
      publicAccessState: APPS_SCRIPT_PUBLIC_ACCESS_READY,
      publicAccessIssue: "",
    },
    deployStatus: null,
  };
}

// Layer 5 Tier 1: read-only status refresh for the SerpApi Google Jobs
// onboarding callout. Hits the worker's /health endpoint (same host as the
// saved webhook URL) and updates the [data-configured] attribute on the
// callout so CSS can swap colors + the status badge text reflects reality.
// Silent on network errors — the callout stays in its "Checking…" state
// rather than throwing console noise the user can't act on.
function refreshSerpApiCalloutStatus() {
  const el = document.getElementById("settingsSerpApiCallout");
  const badge = document.getElementById("settingsSerpApiCalloutStatus");
  if (!el || !badge) return;
  const snapshot = getDiscoveryReadinessSnapshot();
  const webhookUrl = (snapshot && snapshot.savedWebhookUrl) || "";
  // Only attempt the probe for locally-reachable workers. A Cloudflare
  // relay hides the real /health from the browser, so skip the probe in
  // that case and leave the callout neutral.
  const isLocalHost = /(^|\/\/)(localhost|127\.0\.0\.1)(:|\/|$)/i.test(
    webhookUrl,
  );
  if (!webhookUrl || !isLocalHost) {
    el.dataset.configured = "unknown";
    badge.textContent = "Worker status unknown";
    return;
  }
  const healthUrl = (() => {
    try {
      const u = new URL(webhookUrl);
      u.pathname = "/health";
      u.search = "";
      u.hash = "";
      return u.toString();
    } catch (_) {
      return "";
    }
  })();
  if (!healthUrl) {
    el.dataset.configured = "unknown";
    badge.textContent = "Worker status unknown";
    return;
  }
  fetch(healthUrl, { method: "GET", mode: "cors" })
    .then(async (r) => (r.ok ? r.json() : null))
    .then((payload) => {
      const flag =
        payload && payload.readiness && payload.readiness.serpApiGoogleJobs;
      if (!flag) {
        el.dataset.configured = "unknown";
        badge.textContent = "Worker too old to report";
        return;
      }
      if (flag.configured) {
        el.dataset.configured = "yes";
        badge.textContent = "✓ Configured";
      } else {
        el.dataset.configured = "no";
        badge.textContent = "Not configured";
      }
    })
    .catch(() => {
      el.dataset.configured = "unknown";
      badge.textContent = "Worker unreachable";
    });
}

function renderDiscoveryEngineStatusUi() {
  refreshSerpApiCalloutStatus();
  const statusCard = document.getElementById("settingsDiscoveryEngineStatus");
  const statusTitle = document.getElementById(
    "settingsDiscoveryEngineStatusTitle",
  );
  const statusDetail = document.getElementById(
    "settingsDiscoveryEngineStatusDetail",
  );
  const statusActions = document.getElementById(
    "settingsDiscoveryEngineStatusActions",
  );
  const chip = document.getElementById("discoveryStatusChip");
  const note = document.getElementById("discoveryStatusNote");
  const snapshot = getDiscoveryReadinessSnapshot();
  const view = getDiscoverySettingsView(snapshot);
  const status = getEffectiveDiscoveryEngineStatus(
    snapshot.savedWebhookUrl || getDiscoveryWebhookUrlForSettingsPreview(),
  );
  const tone = String(view.tone || status.tone || "info");

  if (chip) {
    chip.hidden = !view.chipLabel;
    chip.className = `discovery-state-chip discovery-state-chip--${view.chipTone || tone}`;
    chip.textContent = view.chipLabel || "";
  }

  if (note) {
    const noteText = view.primaryActionHint || view.detail || "";
    if (!noteText) {
      note.hidden = true;
      note.textContent = "";
    } else {
      note.hidden = false;
      note.textContent = noteText;
    }
  }

  if (!statusCard || !statusTitle || !statusDetail || !statusActions) return;

  statusCard.className = `settings-apps-script-status settings-apps-script-status--${tone}`;
  statusTitle.textContent = view.title || status.label;
  statusDetail.textContent = view.detail || status.detail;
  statusActions.innerHTML = "";

  if (view.primaryActionLabel) {
    const button = document.createElement("button");
    button.type = "button";
    button.className =
      "settings-apps-script-status__action btn-discovery-setup";
    button.textContent = view.primaryActionLabel;
    if (view.primaryActionHint) {
      button.title = view.primaryActionHint;
    }
    button.addEventListener("click", () => {
      void requestDiscoverySetup({
        entryPoint: "settings",
        allowWhileOnboarding: true,
      });
    });
    statusActions.appendChild(button);
  }

  const actions = buildDiscoveryStatusActions(status);
  for (const action of actions) {
    const link = document.createElement("a");
    link.className = action.primary
      ? "settings-apps-script-status__action btn-discovery-setup"
      : "settings-apps-script-status__action btn-discovery-setup btn-discovery-setup--secondary";
    link.href = action.href;
    link.target = "_blank";
    link.rel = "noopener";
    link.textContent = action.label;
    statusActions.appendChild(link);
  }
  statusActions.hidden = statusActions.childElementCount === 0;
}

function renderAppsScriptDeployUi() {
  const deployBtn = document.getElementById("settingsAppsScriptDeployBtn");
  const recheckBtn = document.getElementById("settingsAppsScriptRecheckBtn");
  const openBtn = document.getElementById("settingsAppsScriptOpenBtn");
  const copyBtn = document.getElementById("settingsAppsScriptCopyBtn");
  const statusCard = document.getElementById("settingsAppsScriptStatus");
  const statusTitle = document.getElementById("settingsAppsScriptStatusTitle");
  const statusDetail = document.getElementById(
    "settingsAppsScriptStatusDetail",
  );
  const statusSteps = document.getElementById("settingsAppsScriptStatusSteps");
  const statusUrlRow = document.getElementById("settingsAppsScriptUrlRow");
  const statusUrl = document.getElementById("settingsAppsScriptUrl");
  const statusActions = document.getElementById(
    "settingsAppsScriptStatusActions",
  );
  if (!deployBtn || !statusCard || !statusTitle || !statusDetail) return;

  const state = appsScriptDeployStateCache;
  const hasManaged = isManagedAppsScriptDeployState(state);
  const publicAccessReady = isAppsScriptPublicAccessReady(state);
  const scriptId =
    state && typeof state.scriptId === "string" ? state.scriptId.trim() : "";
  const webAppUrl =
    state && typeof state.webAppUrl === "string" ? state.webAppUrl.trim() : "";
  const clientId = getSettingsOAuthClientIdValue();
  const sheetId = getSettingsSheetIdValue();
  const needsOAuthReload = hasUnsavedOAuthClientIdChange(clientId);

  deployBtn.textContent = appsScriptDeployBusy
    ? "Deploying..."
    : hasManaged
      ? "Re-deploy managed Apps Script"
      : "Deploy Google Apps Script stub";
  deployBtn.disabled =
    appsScriptDeployBusy ||
    !clientId ||
    !sheetId ||
    needsOAuthReload ||
    !gisLoaded;

  if (!clientId) {
    deployBtn.title = "Add an OAuth Client ID above first";
  } else if (needsOAuthReload) {
    deployBtn.title =
      "Save Settings so the page reloads with this OAuth client";
  } else if (!sheetId) {
    deployBtn.title = "Paste a spreadsheet URL or Sheet ID above first";
  } else if (!gisLoaded) {
    deployBtn.title = "Google sign-in is still loading";
  } else {
    deployBtn.title = hasManaged
      ? "Upload the latest stub and refresh the managed web app deployment"
      : "Create and deploy a new managed Apps Script web app";
  }

  if (openBtn) {
    const href = getAppsScriptEditorUrl(scriptId);
    openBtn.hidden = !href;
    openBtn.href = href || "#";
  }
  if (recheckBtn) {
    recheckBtn.hidden =
      !hasManaged || publicAccessReady || appsScriptDeployBusy || !scriptId;
    recheckBtn.disabled =
      appsScriptDeployBusy || !gisLoaded || !clientId || needsOAuthReload;
    if (!clientId) {
      recheckBtn.title = "Add an OAuth Client ID above first";
    } else if (needsOAuthReload) {
      recheckBtn.title =
        "Save Settings so the page reloads with this OAuth client";
    } else if (!gisLoaded) {
      recheckBtn.title = "Google sign-in is still loading";
    } else {
      recheckBtn.title =
        "Re-read the managed deployment and rerun the anonymous public-access probe";
    }
  }
  if (copyBtn) {
    copyBtn.hidden = !webAppUrl;
    copyBtn.disabled = !webAppUrl;
  }
  if (statusActions) {
    statusActions.innerHTML = "";
  }
  if (statusSteps) {
    statusSteps.innerHTML = "";
    statusSteps.hidden = true;
  }

  let tone = "info";
  let message =
    "Create a new Apps Script stub in your Google Drive and save its /exec URL here.";
  let detail =
    "This keeps webhook verification in your account. Browser -> /exec requests may still need a proxy or server-side POST if CORS blocks them, and the stub still needs real discovery logic before it can add jobs.";
  let effectiveStatus = appsScriptDeployStatus;

  if (appsScriptDeployStatus && appsScriptDeployStatus.message) {
    tone = appsScriptDeployStatus.tone || "info";
    message = appsScriptDeployStatus.message;
    detail = appsScriptDeployStatus.detail || "";
  } else if (!clientId) {
    tone = "warning";
    message = "Add an OAuth Client ID above to deploy from the dashboard.";
    detail =
      "Use the same Google OAuth web client you use for Sheets access on this site.";
  } else if (!sheetId) {
    tone = "warning";
    message = "Paste a spreadsheet URL or Sheet ID above first.";
    detail =
      "The deploy flow saves the resulting /exec URL for the sheet you’re configuring.";
  } else if (needsOAuthReload) {
    effectiveStatus = buildAppsScriptGisNotReadyStatus(clientId);
    tone = effectiveStatus.tone;
    message = effectiveStatus.message;
    detail = effectiveStatus.detail;
  } else if (!gisLoaded) {
    effectiveStatus = buildAppsScriptGisNotReadyStatus(clientId);
    tone = effectiveStatus.tone;
    message = effectiveStatus.message;
    detail = effectiveStatus.detail;
  } else if (hasManaged && !publicAccessReady) {
    const remediation = buildAppsScriptPublicAccessRemediationStatus({
      scriptId,
      webAppUrl,
      deploymentAccess:
        state && typeof state.deploymentAccess === "string"
          ? state.deploymentAccess
          : state && typeof state.access === "string"
            ? state.access
            : "",
      deploymentExecuteAs:
        state && typeof state.deploymentExecuteAs === "string"
          ? state.deploymentExecuteAs
          : state && typeof state.executeAs === "string"
            ? state.executeAs
            : "",
      failureKind:
        state && typeof state.publicAccessIssue === "string"
          ? state.publicAccessIssue
          : "",
    });
    tone = remediation.tone;
    message = remediation.message;
    detail = remediation.detail;
    effectiveStatus = remediation;
  } else if (hasManaged) {
    tone = "success";
    message = "Managed Apps Script stub ready.";
    detail =
      "The saved web app URL passed the public-access check, but this managed deploy is still only a webhook stub. It can verify wiring, not discover real jobs.";
  }

  statusCard.className = `settings-apps-script-status settings-apps-script-status--${tone}`;
  statusTitle.textContent = message;
  statusDetail.textContent = detail;
  if (
    statusSteps &&
    effectiveStatus &&
    Array.isArray(effectiveStatus.steps) &&
    effectiveStatus.steps.length
  ) {
    for (const step of effectiveStatus.steps) {
      const item = document.createElement("li");
      item.textContent = step;
      statusSteps.appendChild(item);
    }
    statusSteps.hidden = false;
  }
  if (
    statusActions &&
    effectiveStatus &&
    Array.isArray(effectiveStatus.actions) &&
    effectiveStatus.actions.length
  ) {
    for (const action of effectiveStatus.actions) {
      const link = document.createElement("a");
      link.className = action.primary
        ? "settings-apps-script-status__action btn-discovery-setup"
        : "settings-apps-script-status__action btn-discovery-setup btn-discovery-setup--secondary";
      link.href = action.href;
      link.target = "_blank";
      link.rel = "noopener";
      link.textContent = action.label;
      statusActions.appendChild(link);
    }
    statusActions.hidden = false;
  } else if (statusActions) {
    statusActions.hidden = true;
  }

  if (statusUrlRow && statusUrl) {
    const hideRawExecUrl = hasManaged && !publicAccessReady && webAppUrl;
    statusUrlRow.hidden = !webAppUrl || hideRawExecUrl;
    statusUrl.textContent = webAppUrl;
  }
  renderDiscoveryEngineStatusUi();
}

async function deployAppsScriptStubFromSettings() {
  if (appsScriptDeployBusy) return;

  const sheetId = getSettingsSheetIdValue();
  if (!sheetId) {
    setAppsScriptDeployStatus(
      "warning",
      "Paste a spreadsheet URL or Sheet ID above first.",
    );
    return;
  }

  const oauthClientId = getSettingsOAuthClientIdValue();
  if (!oauthClientId) {
    setAppsScriptDeployStatus(
      "warning",
      "Add an OAuth Client ID above before deploying.",
    );
    return;
  }

  appsScriptDeployBusy = true;
  renderAppsScriptDeployUi();

  try {
    setAppsScriptDeployStatus(
      "info",
      "Requesting Google Apps Script deploy permissions…",
    );
    const deployToken = await requestAppsScriptDeployAccessToken();

    setAppsScriptDeployStatus("info", "Loading the repo’s Apps Script stub…");
    const stub = await loadAppsScriptStubBundle();

    const existingState = isManagedAppsScriptDeployState(
      appsScriptDeployStateCache,
    )
      ? appsScriptDeployStateCache
      : null;

    let scriptId =
      existingState && existingState.scriptId
        ? String(existingState.scriptId).trim()
        : "";
    let deploymentId =
      existingState && existingState.deploymentId
        ? String(existingState.deploymentId).trim()
        : "";

    if (!scriptId) {
      setAppsScriptDeployStatus("info", "Creating a new Apps Script project…");
      const project = await appsScriptApiRequest("/projects", deployToken, {
        method: "POST",
        body: { title: APPS_SCRIPT_PROJECT_TITLE },
      });
      scriptId = String(
        project && project.scriptId ? project.scriptId : "",
      ).trim();
      if (!scriptId) {
        throw new Error(
          "Google created a project but did not return a scriptId.",
        );
      }
    }

    setAppsScriptDeployStatus("info", "Uploading Code.gs and appsscript.json…");
    await appsScriptApiRequest(
      `/projects/${encodeURIComponent(scriptId)}/content`,
      deployToken,
      {
        method: "PUT",
        body: { files: stub.files },
      },
    );

    setAppsScriptDeployStatus("info", "Creating a new script version…");
    const version = await appsScriptApiRequest(
      `/projects/${encodeURIComponent(scriptId)}/versions`,
      deployToken,
      {
        method: "POST",
        body: { description: "Command Center dashboard deploy" },
      },
    );
    const versionNumber =
      Number(version && version.versionNumber) > 0
        ? Number(version.versionNumber)
        : null;
    if (!versionNumber) {
      throw new Error(
        "Google created a version but did not return a version number.",
      );
    }

    let deployment;
    if (deploymentId) {
      setAppsScriptDeployStatus(
        "info",
        "Updating the managed web app deployment…",
      );
      deployment = await appsScriptApiRequest(
        `/projects/${encodeURIComponent(scriptId)}/deployments/${encodeURIComponent(deploymentId)}`,
        deployToken,
        {
          method: "PUT",
          body: {
            deploymentConfig: {
              scriptId,
              versionNumber,
              manifestFileName: "appsscript",
              description: "Command Center dashboard deploy",
            },
          },
        },
      );
    } else {
      setAppsScriptDeployStatus("info", "Creating the web app deployment…");
      deployment = await appsScriptApiRequest(
        `/projects/${encodeURIComponent(scriptId)}/deployments`,
        deployToken,
        {
          method: "POST",
          body: {
            versionNumber,
            manifestFileName: "appsscript",
            description: "Command Center dashboard deploy",
          },
        },
      );
    }

    deploymentId = String(
      deployment && deployment.deploymentId ? deployment.deploymentId : "",
    ).trim();
    const webAppUrl = extractWebAppUrlFromDeployment(deployment);
    if (!deploymentId || !webAppUrl) {
      throw new Error(
        "Google deployed the script but did not return a web app /exec URL.",
      );
    }

    setAppsScriptDeployStatus(
      "info",
      "Checking that Google published the web app as public…",
      "Command Center will not save this /exec URL as ready until an anonymous public-access probe succeeds.",
    );
    const readiness = await verifyAppsScriptDeploymentPublicAccess(
      scriptId,
      deploymentId,
      deployToken,
      deployment,
    );

    const store = getAppsScriptDeployStateStore();
    let nextState = {
      managedBy: APPS_SCRIPT_MANAGED_BY,
      origin: window.location.origin || "",
      ownerEmail: userEmail || "",
      scriptId,
      deploymentId,
      webAppUrl,
      executeAs: APPS_SCRIPT_WEBAPP_EXECUTE_AS,
      access: APPS_SCRIPT_WEBAPP_ACCESS,
      projectTitle: APPS_SCRIPT_PROJECT_TITLE,
      lastVersionNumber: versionNumber,
      stubHash: stub.stubHash,
      lastDeployedAt: new Date().toISOString(),
      ...readiness.statePatch,
    };
    if (store) {
      nextState = await store.saveAppsScriptDeployState(nextState);
      if (readiness.ready && typeof store.saveAgentChecklist === "function") {
        await store.saveAgentChecklist({ webhookConfigured: true });
      }
    }
    appsScriptDeployStateCache = nextState;

    if (!readiness.ready) {
      setAppsScriptDeployStatus(
        readiness.deployStatus.tone || "error",
        readiness.deployStatus.message ||
          "Apps Script public-access check failed.",
        readiness.deployStatus.detail || "",
        {
          actions: Array.isArray(readiness.deployStatus.actions)
            ? readiness.deployStatus.actions
            : [],
          steps: Array.isArray(readiness.deployStatus.steps)
            ? readiness.deployStatus.steps
            : [],
        },
      );
      return;
    }

    const urlField = document.getElementById("settingsDiscoveryWebhookUrl");
    if (urlField) urlField.value = webAppUrl;
    mergeStoredConfigOverridePatch({
      sheetId,
      oauthClientId,
      discoveryWebhookUrl: webAppUrl,
    });
    await recordDiscoveryEngineState(
      webAppUrl,
      DISCOVERY_ENGINE_STATE_STUB_ONLY,
      "managed_apps_script_deploy",
    );
    syncDiscoveryButtonState();

    setAppsScriptDeployStatus(
      "success",
      "Apps Script stub deployed and webhook URL was saved.",
      "This confirms webhook wiring only. Use Test webhook for smoke tests, then connect a real discovery engine or replace the stub logic before expecting job rows.",
    );
  } catch (err) {
    console.error("[JobBored] Apps Script deploy:", err);
    const deployStatus =
      err && err.deployStatus && typeof err.deployStatus === "object"
        ? err.deployStatus
        : null;
    if (deployStatus) {
      setAppsScriptDeployStatus(
        deployStatus.tone || "error",
        deployStatus.message || "Apps Script deploy failed.",
        deployStatus.detail || (err && err.message ? String(err.message) : ""),
        Array.isArray(deployStatus.actions) ? deployStatus.actions : [],
      );
    } else {
      setAppsScriptDeployStatus(
        "error",
        "Apps Script deploy failed.",
        err && err.message ? String(err.message) : "Unknown error",
      );
    }
  } finally {
    appsScriptDeployBusy = false;
    renderAppsScriptDeployUi();
  }
}

async function recheckAppsScriptPublicAccessFromSettings() {
  if (appsScriptDeployBusy) return;
  const state = appsScriptDeployStateCache;
  if (!isManagedAppsScriptDeployState(state)) return;

  const scriptId =
    state && typeof state.scriptId === "string" ? state.scriptId.trim() : "";
  const deploymentId =
    state && typeof state.deploymentId === "string"
      ? state.deploymentId.trim()
      : "";
  const webAppUrl =
    state && typeof state.webAppUrl === "string" ? state.webAppUrl.trim() : "";
  if (!scriptId || !deploymentId) return;

  const sheetId = getSettingsSheetIdValue();
  const oauthClientId = getSettingsOAuthClientIdValue();
  if (!oauthClientId) {
    setAppsScriptDeployStatus(
      "warning",
      "Add an OAuth Client ID above before re-checking.",
    );
    return;
  }

  appsScriptDeployBusy = true;
  renderAppsScriptDeployUi();
  try {
    setAppsScriptDeployStatus(
      "info",
      "Re-checking Google web app public access…",
      "This does not redeploy code. It only re-reads the managed deployment and reruns the anonymous public-access probe.",
    );
    const deployToken = await requestAppsScriptDeployAccessToken();
    const readiness = await verifyAppsScriptDeploymentPublicAccess(
      scriptId,
      deploymentId,
      deployToken,
      null,
    );

    const store = getAppsScriptDeployStateStore();
    let nextState = {
      ...(state && typeof state === "object" ? state : {}),
      ...readiness.statePatch,
      webAppUrl: readiness.statePatch.webAppUrl || webAppUrl,
      lastDeployedAt:
        state && typeof state.lastDeployedAt === "string"
          ? state.lastDeployedAt
          : "",
    };

    if (store) {
      nextState = await store.saveAppsScriptDeployState(nextState);
      if (readiness.ready && typeof store.saveAgentChecklist === "function") {
        await store.saveAgentChecklist({ webhookConfigured: true });
      }
    }
    appsScriptDeployStateCache = nextState;

    if (!readiness.ready) {
      setAppsScriptDeployStatus(
        readiness.deployStatus.tone || "error",
        readiness.deployStatus.message ||
          "Apps Script public-access check failed.",
        readiness.deployStatus.detail || "",
        {
          actions: Array.isArray(readiness.deployStatus.actions)
            ? readiness.deployStatus.actions
            : [],
          steps: Array.isArray(readiness.deployStatus.steps)
            ? readiness.deployStatus.steps
            : [],
        },
      );
      return;
    }

    const finalWebAppUrl =
      readiness.statePatch.webAppUrl || nextState.webAppUrl || webAppUrl;
    const urlField = document.getElementById("settingsDiscoveryWebhookUrl");
    if (urlField) urlField.value = finalWebAppUrl;
    mergeStoredConfigOverridePatch({
      ...(sheetId ? { sheetId } : {}),
      ...(oauthClientId ? { oauthClientId } : {}),
      discoveryWebhookUrl: finalWebAppUrl,
    });
    await recordDiscoveryEngineState(
      finalWebAppUrl,
      DISCOVERY_ENGINE_STATE_STUB_ONLY,
      "managed_apps_script_recheck",
    );
    syncDiscoveryButtonState();

    setAppsScriptDeployStatus(
      "success",
      "Apps Script stub now passes the public-access check and webhook URL was saved.",
      "This still leaves discovery in stub-only mode. Use Test webhook for smoke tests, and connect a real discovery engine before expecting Pipeline rows.",
    );
  } catch (err) {
    console.error("[JobBored] Apps Script public access re-check:", err);
    const deployStatus =
      err && err.deployStatus && typeof err.deployStatus === "object"
        ? err.deployStatus
        : null;
    if (deployStatus) {
      setAppsScriptDeployStatus(
        deployStatus.tone || "error",
        deployStatus.message || "Apps Script public-access check failed.",
        deployStatus.detail || (err && err.message ? String(err.message) : ""),
        {
          actions: Array.isArray(deployStatus.actions)
            ? deployStatus.actions
            : [],
          steps: Array.isArray(deployStatus.steps) ? deployStatus.steps : [],
        },
      );
    } else {
      setAppsScriptDeployStatus(
        "error",
        "Apps Script public-access check failed.",
        err && err.message ? String(err.message) : "Unknown error",
      );
    }
  } finally {
    appsScriptDeployBusy = false;
    renderAppsScriptDeployUi();
  }
}

function initScraperSetupGuide() {
  document
    .getElementById("openScraperSetupFromSettings")
    ?.addEventListener("click", () => openScraperSetupModal());
  document
    .getElementById("scraperSetupModalClose")
    ?.addEventListener("click", closeScraperSetupModal);
  document
    .getElementById("scraperSetupDoneBtn")
    ?.addEventListener("click", closeScraperSetupModal);
  document
    .getElementById("scraperTestConnectionBtn")
    ?.addEventListener("click", () => runScraperConnectionTest());

  document
    .querySelectorAll(".btn-copy-scraper[data-copy-text]")
    .forEach((btn) => {
      btn.addEventListener("click", () => {
        const text = btn.getAttribute("data-copy-text");
        if (text) copyTextToClipboard(text);
      });
    });

  const overlay = document.getElementById("scraperSetupModal");
  if (overlay) {
    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) closeScraperSetupModal();
    });
  }
}

// ============================================
// STATE
// ============================================

let SHEET_ID = null;
const REFRESH_INTERVAL = 5 * 60 * 1000; // 5 minutes

let pipelineData = [];
let pipelineRawRows = []; // Keep raw rows for row index mapping
let currentSort = "fit";
let currentSearch = "";
let favoritesOnly = false;
let showDismissed = false;
let dataLoadFailed = false;
let dashboardDataHydrated = false;
let initialSheetAccessResolved = false;
let pendingSetupStarterSheetCreate = false;
let postAccessBootstrapDone = false;
let postAccessBootstrapPromise = Promise.resolve();

/** Pipeline indices with expanded detail panel — preserved across re-renders */
const expandedJobKeys = new Set();

/** Stable keys that have been opened in the detail drawer — persisted to localStorage */
const viewedJobKeys = new Set(
  JSON.parse(localStorage.getItem("jb_viewedKeys") || "[]").map(Number),
);

// ---- Enrichment cache ----
const ENRICHMENT_CACHE_KEY = "jb_enrichment_v1";
const ENRICHMENT_CACHE_MAX = 300;
const ENRICHMENT_CACHE_DESC_LIMIT = 8000; // chars kept for raw description

function _loadEnrichmentCache() {
  try {
    return JSON.parse(localStorage.getItem(ENRICHMENT_CACHE_KEY) || "{}");
  } catch (_) {
    return {};
  }
}

function _saveEnrichmentCache(cache) {
  // Prune to MAX entries by scrapedAt (oldest first)
  const entries = Object.entries(cache);
  if (entries.length > ENRICHMENT_CACHE_MAX) {
    entries.sort((a, b) => (a[1].scrapedAt || 0) - (b[1].scrapedAt || 0));
    const pruned = Object.fromEntries(
      entries.slice(entries.length - ENRICHMENT_CACHE_MAX),
    );
    try {
      localStorage.setItem(ENRICHMENT_CACHE_KEY, JSON.stringify(pruned));
    } catch (_) {}
  } else {
    try {
      localStorage.setItem(ENRICHMENT_CACHE_KEY, JSON.stringify(cache));
    } catch (_) {}
  }
}

/** Call after fetchJobPostingEnrichment succeeds to persist results. */
function cacheEnrichment(url, enrichment) {
  if (!url) return;
  const cache = _loadEnrichmentCache();
  // Store AI fields + trimmed description; skip huge raw text to save space
  cache[url] = {
    ...enrichment,
    description: enrichment.description
      ? String(enrichment.description).slice(0, ENRICHMENT_CACHE_DESC_LIMIT)
      : undefined,
  };
  _saveEnrichmentCache(cache);
}

/** Restore cached enrichments into pipelineData after a Sheet load. */
function applyEnrichmentCache(jobs) {
  const cache = _loadEnrichmentCache();
  if (!Object.keys(cache).length) return;
  for (const job of jobs) {
    if (!job.link || job._postingEnrichment) continue;
    const hit = cache[job.link];
    if (hit && hit.scrapedAt) job._postingEnrichment = hit;
  }
}

function markJobViewed(stableKey) {
  if (viewedJobKeys.has(stableKey)) return;
  viewedJobKeys.add(stableKey);
  try {
    localStorage.setItem("jb_viewedKeys", JSON.stringify([...viewedJobKeys]));
  } catch (_) {}
  // Live-update any visible kanban card without a full re-render
  const el = document.querySelector(
    `.kanban-card[data-stable-key="${stableKey}"]`,
  );
  if (el) el.classList.add("kanban-card--viewed");
}

// ---- Pipeline Board ----
const STAGE_ORDER = [
  "New",
  "Researching",
  "Applied",
  "Phone Screen",
  "Interviewing",
  "Offer",
  "Rejected",
  "Passed",
];
const STAGE_ARCHIVE = new Set(["Rejected", "Passed"]);
/** Which stage lanes are expanded; defaults to active (non-archive) stages */
const expandedStages = new Set(
  STAGE_ORDER.filter((s) => !STAGE_ARCHIVE.has(s)),
);
/** Stable key of the job currently shown in the detail drawer, or -1 */
let activeDetailKey = -1;

// Auth state — access token stays in memory; localStorage only keeps a restore marker
let accessToken = null;
let userEmail = null;

// Minimal external accessor for modules that need the live access token
// without grabbing internal symbols. Kept tiny on purpose — just getters,
// no setters. Used by runs-tab.js to read the DiscoveryRuns sheet tab.
// Guarded for vm-sliced test contexts that don't define `window`.
if (typeof window !== "undefined") {
  window.JobBored = window.JobBored || {};
  window.JobBored.getAccessToken = function () {
    return accessToken;
  };
  window.JobBored.getSheetId = function () {
    return typeof SHEET_ID === "string" ? SHEET_ID : "";
  };
}
/** Profile photo URL from Google userinfo (optional). */
let userPictureUrl = null;
let grantedOauthScopes = "";
/** Epoch ms when accessToken is expected to expire (Google typically ~1h). */
let tokenExpiresAt = null;
let tokenClient = null;
let gisLoaded = false;
let gisInitStartedAt = 0;
let gisInitWatchdogTimer = null;

const OAUTH_SESSION_STORAGE_KEY = "command_center_oauth_session";
const OAUTH_RUNTIME_SESSION_STORAGE_KEY = "command_center_oauth_runtime";

/** Pending GIS callback: interactive sign-in, silent session restore, or silent token refresh (401 / proactive). */
let oauthPendingOp = null;
let tokenRefreshTimer = null;

function canUseLocalStorage() {
  try {
    const k = "__command_center_ls_test__";
    localStorage.setItem(k, "1");
    localStorage.removeItem(k);
    return true;
  } catch (e) {
    return false;
  }
}

function canUseSessionStorage() {
  try {
    const k = "__command_center_ss_test__";
    sessionStorage.setItem(k, "1");
    sessionStorage.removeItem(k);
    return true;
  } catch (e) {
    return false;
  }
}

function normalizeOauthScopes(raw) {
  if (!raw) return "";
  return [...new Set(String(raw).trim().split(/\s+/).filter(Boolean))].join(
    " ",
  );
}

function hasGrantedOauthScope(scope) {
  const wanted = String(scope || "").trim();
  if (!wanted) return false;
  return normalizeOauthScopes(grantedOauthScopes)
    .split(/\s+/)
    .filter(Boolean)
    .includes(wanted);
}

function persistOAuthSession() {
  if (!tokenExpiresAt) return;
  const cid = getOAuthClientId();
  if (!cid) return;
  if (canUseLocalStorage()) {
    try {
      localStorage.setItem(
        OAUTH_SESSION_STORAGE_KEY,
        JSON.stringify({
          expiresAt: tokenExpiresAt,
          userEmail,
          userPictureUrl,
          grantedOauthScopes,
          oauthClientId: cid,
          hasOauthSession: true,
        }),
      );
    } catch (e) {
      // Quota or private mode
    }
  }
  persistRuntimeOAuthSession();
}

function persistRuntimeOAuthSession() {
  // Runtime session (access token + expiry) lives in localStorage so it
  // survives hard refresh. Token is short-lived (~1h) and auto-expires via
  // the loadPersistedRuntimeOAuthSession expiry check below.
  if (!canUseLocalStorage() || !tokenExpiresAt || !accessToken) {
    console.info(
      `[JobBored][auth] persist: skipped (ls=${canUseLocalStorage()} exp=${!!tokenExpiresAt} tok=${!!accessToken})`,
    );
    return;
  }
  const cid = getOAuthClientId();
  if (!cid) {
    console.warn("[JobBored][auth] persist: no oauth client id");
    return;
  }
  try {
    localStorage.setItem(
      OAUTH_RUNTIME_SESSION_STORAGE_KEY,
      JSON.stringify({
        accessToken,
        expiresAt: tokenExpiresAt,
        userEmail,
        userPictureUrl,
        grantedOauthScopes,
        oauthClientId: cid,
        hasOauthSession: true,
      }),
    );
    console.info(
      `[JobBored][auth] persist: OK (expires in ${Math.round((tokenExpiresAt - Date.now()) / 1000)}s)`,
    );
  } catch (e) {
    console.warn("[JobBored][auth] persist: exception", e);
  }
  // Best-effort cleanup of legacy sessionStorage entry from earlier versions.
  if (canUseSessionStorage()) {
    try {
      sessionStorage.removeItem(OAUTH_RUNTIME_SESSION_STORAGE_KEY);
    } catch (e) {
      /* ignore */
    }
  }
}

function updatePersistedUserEmail() {
  persistOAuthSession();
}

function clearPersistedOAuthSession() {
  if (!canUseLocalStorage()) return;
  try {
    localStorage.removeItem(OAUTH_SESSION_STORAGE_KEY);
  } catch (e) {
    /* ignore */
  }
}

function clearPersistedRuntimeOAuthSession() {
  if (canUseLocalStorage()) {
    try {
      localStorage.removeItem(OAUTH_RUNTIME_SESSION_STORAGE_KEY);
    } catch (e) {
      /* ignore */
    }
  }
  if (canUseSessionStorage()) {
    try {
      sessionStorage.removeItem(OAUTH_RUNTIME_SESSION_STORAGE_KEY);
    } catch (e) {
      /* ignore */
    }
  }
}

/** Drop auth state after expiry or failed refresh (does not revoke the token server-side). */
function clearSessionAuthState() {
  clearScheduledTokenRefresh();
  accessToken = null;
  userEmail = null;
  userPictureUrl = null;
  grantedOauthScopes = "";
  tokenExpiresAt = null;
  oauthPendingOp = null;
  pendingSetupStarterSheetCreate = false;
  clearPersistedOAuthSession();
  clearPersistedRuntimeOAuthSession();
  updateAuthUI();
}

function loadPersistedOAuthSession() {
  if (!canUseLocalStorage()) return null;
  const cid = getOAuthClientId();
  if (!cid) return null;
  try {
    const raw = localStorage.getItem(OAUTH_SESSION_STORAGE_KEY);
    if (!raw) return null;
    const o = JSON.parse(raw);
    if (
      !o ||
      typeof o !== "object" ||
      o.hasOauthSession !== true ||
      typeof o.expiresAt !== "number" ||
      o.oauthClientId !== cid
    ) {
      clearPersistedOAuthSession();
      return null;
    }
    return o;
  } catch (e) {
    clearPersistedOAuthSession();
    return null;
  }
}

function loadPersistedRuntimeOAuthSession() {
  if (!canUseLocalStorage()) {
    console.info("[JobBored][auth] restore: localStorage unavailable");
    return null;
  }
  const cid = getOAuthClientId();
  if (!cid) {
    console.info("[JobBored][auth] restore: oauth client id not resolved yet");
    return null;
  }
  try {
    let raw = localStorage.getItem(OAUTH_RUNTIME_SESSION_STORAGE_KEY);
    // Migration from v<12: read any legacy sessionStorage entry, promote it
    // to localStorage on the fly so the first refresh after upgrade Just Works.
    if (!raw && canUseSessionStorage()) {
      try {
        raw = sessionStorage.getItem(OAUTH_RUNTIME_SESSION_STORAGE_KEY);
        if (raw) {
          localStorage.setItem(OAUTH_RUNTIME_SESSION_STORAGE_KEY, raw);
          sessionStorage.removeItem(OAUTH_RUNTIME_SESSION_STORAGE_KEY);
          console.info("[JobBored][auth] restore: promoted legacy sessionStorage entry");
        }
      } catch (e) {
        /* ignore */
      }
    }
    if (!raw) {
      console.info("[JobBored][auth] restore: no persisted token");
      return null;
    }
    const o = JSON.parse(raw);
    // Allow up to 60s of negative clock skew: treat the token as valid until
    // 60s AFTER its recorded expiry, since system clocks occasionally drift
    // backward on wake-from-sleep. The 401/retry/refresh machinery will
    // handle the actual server-side rejection if the token really is dead.
    const nowMs = Date.now();
    const expiresAt = typeof o?.expiresAt === "number" ? o.expiresAt : 0;
    const secondsRemaining = Math.round((expiresAt - nowMs) / 1000);
    if (!o || typeof o !== "object" || o.hasOauthSession !== true) {
      console.warn("[JobBored][auth] restore: payload shape invalid");
      clearPersistedRuntimeOAuthSession();
      return null;
    }
    if (typeof o.accessToken !== "string" || !o.accessToken) {
      console.warn("[JobBored][auth] restore: no access token in payload");
      clearPersistedRuntimeOAuthSession();
      return null;
    }
    if (expiresAt + 60_000 <= nowMs) {
      console.info(
        `[JobBored][auth] restore: token expired (${secondsRemaining}s remaining incl. grace)`,
      );
      clearPersistedRuntimeOAuthSession();
      return null;
    }
    if (o.oauthClientId !== cid) {
      console.warn(
        `[JobBored][auth] restore: client id mismatch (stored=${o.oauthClientId?.slice(0, 12)}… current=${cid.slice(0, 12)}…)`,
      );
      clearPersistedRuntimeOAuthSession();
      return null;
    }
    console.info(
      `[JobBored][auth] restore: OK (${secondsRemaining}s remaining)`,
    );
    return o;
  } catch (e) {
    console.warn("[JobBored][auth] restore: exception", e);
    clearPersistedRuntimeOAuthSession();
    return null;
  }
}

function clearScheduledTokenRefresh() {
  if (tokenRefreshTimer != null) {
    clearTimeout(tokenRefreshTimer);
    tokenRefreshTimer = null;
  }
}

function scheduleTokenRefresh() {
  clearScheduledTokenRefresh();
  if (!tokenExpiresAt || !tokenClient) return;
  // Refresh ~5 minutes before expiry
  const delay = Math.max(10_000, tokenExpiresAt - Date.now() - 5 * 60 * 1000);
  tokenRefreshTimer = setTimeout(async () => {
    tokenRefreshTimer = null;
    if (!accessToken) return;
    const ok = await refreshAccessTokenSilently();
    if (ok) scheduleTokenRefresh();
  }, delay);
}

/**
 * Ask GIS for a new access token without user interaction (uses Google session + prior consent).
 * @returns {Promise<boolean>}
 */
function refreshAccessTokenSilently() {
  if (!tokenClient) return Promise.resolve(false);
  return new Promise((resolve) => {
    let settled = false;
    const done = (ok) => {
      if (settled) return;
      settled = true;
      resolve(ok);
    };
    const t = setTimeout(() => done(false), 25_000);
    oauthPendingOp = {
      kind: "silent-refresh",
      finish: (ok) => {
        clearTimeout(t);
        oauthPendingOp = null;
        done(ok);
      },
    };
    try {
      tokenClient.requestAccessToken({ prompt: "none" });
    } catch (e) {
      clearTimeout(t);
      oauthPendingOp = null;
      done(false);
    }
  });
}

function restoreOAuthSession() {
  const runtimeSession = loadPersistedRuntimeOAuthSession();
  if (runtimeSession) {
    accessToken = runtimeSession.accessToken;
    tokenExpiresAt = runtimeSession.expiresAt;
    userEmail = runtimeSession.userEmail || null;
    userPictureUrl = runtimeSession.userPictureUrl || null;
    grantedOauthScopes = normalizeOauthScopes(
      runtimeSession.grantedOauthScopes || GOOGLE_SIGNIN_SCOPES,
    );
    updateAuthUI();
    if (SHEET_ID) {
      loadAllData();
    } else {
      revealSetupScreenAfterAuth();
    }
    scheduleTokenRefresh();
    maybeSyncSettingsModalModeAfterAuth();
    void fetchUserEmail();
    return;
  }
  const persisted = loadPersistedOAuthSession();
  if (!persisted || !tokenClient) {
    // No runtime token AND no restorable metadata → user is truly signed out.
    // Open the gate now so the dashboard never renders in a broken state.
    if (getOAuthClientId() && !accessToken) {
      showSheetAccessGate("signin");
    }
    return;
  }

  oauthPendingOp = { kind: "silent-restore" };
  try {
    tokenClient.requestAccessToken({ prompt: "none" });
  } catch (e) {
    oauthPendingOp = null;
    clearPersistedOAuthSession();
    if (getOAuthClientId() && !accessToken) {
      showSheetAccessGate("signin");
    }
  }
}

// ============================================
// TOAST SYSTEM
// ============================================

function showToast(message, type = "success", persistent = false, action) {
  const container = document.getElementById("toastContainer");
  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;

  const icons = {
    success: "\u2713",
    error: "\u2717",
    info: "i",
    warning: "\u26A0",
  };

  toast.innerHTML = `
    <span class="toast-icon">${icons[type] || icons.info}</span>
    <span class="toast-message">${escapeHtml(message)}</span>
    <button class="toast-close" aria-label="Dismiss">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
    </button>
  `;

  const dismiss = () => {
    toast.classList.add("removing");
    setTimeout(() => toast.remove(), 200);
  };

  if (action && action.label && typeof action.onClick === "function") {
    const btn = document.createElement("button");
    btn.className = "toast-action-btn";
    btn.textContent = action.label;
    btn.addEventListener("click", () => {
      action.onClick();
      dismiss();
    });
    toast.querySelector(".toast-message").after(btn);
  }

  toast.querySelector(".toast-close").addEventListener("click", dismiss);

  container.appendChild(toast);

  // Auto-dismiss success/info toasts
  if (!persistent && type !== "error") {
    setTimeout(dismiss, 3000);
  }

  return dismiss;
}

// ============================================
// AUTH — Google Identity Services
// ============================================

/**
 * Apply a freshly saved OAuth client ID without forcing a full page reload.
 * Tries to rebuild the GIS tokenClient in place; falls back to reload if that
 * fails (e.g. GIS not loaded yet, or tokenClient threw). Removes the most
 * jarring UX moment in the greenfield setup path.
 */
function applyOAuthClientChange(clientId) {
  const cid = String(clientId || "").trim();
  if (!cid) return false;
  // We only safely re-init when GIS is already loaded.
  if (
    typeof google === "undefined" ||
    !google.accounts ||
    !google.accounts.oauth2 ||
    !gisLoaded
  ) {
    return false;
  }
  try {
    // Drop any cached session bound to a different client id.
    clearPersistedOAuthSession();
    accessToken = null;
    tokenExpiresAt = 0;
    grantedOauthScopes = [];
    tokenClient = google.accounts.oauth2.initTokenClient({
      client_id: cid,
      scope: GOOGLE_SIGNIN_SCOPES,
      include_granted_scopes: true,
      callback: handleTokenResponse,
      error_callback: (err) => {
        console.error("[JobBored] GIS error_callback (re-init):", err);
        recordSheetAccessError(err);
      },
    });
    setupAuthUI();
    renderSetupStarterSheetUi();
    renderAppsScriptDeployUi();
    maybeSyncSettingsModalModeAfterAuth();
    showSheetAccessGate(getOAuthClientId() ? "signin" : "loading");
    return true;
  } catch (e) {
    console.warn("[JobBored] in-place OAuth re-init failed, will reload:", e);
    return false;
  }
}

function initAuth() {
  const clientId = getOAuthClientId();
  if (!clientId) {
    // No OAuth configured — hide auth section entirely
    const authSection = document.getElementById("authSection");
    if (authSection) authSection.style.display = "none";
    return;
  }
  gisInitStartedAt = Date.now();
  if (gisInitWatchdogTimer != null) {
    clearTimeout(gisInitWatchdogTimer);
    gisInitWatchdogTimer = null;
  }
  gisInitWatchdogTimer = setTimeout(() => {
    gisInitWatchdogTimer = null;
    if (!gisLoaded) renderAppsScriptDeployUi();
  }, GIS_INIT_STUCK_MS + 250);

  // Wait for GIS library to load
  function tryInit() {
    if (
      typeof google !== "undefined" &&
      google.accounts &&
      google.accounts.oauth2
    ) {
      gisLoaded = true;
      gisInitStartedAt = 0;
      if (gisInitWatchdogTimer != null) {
        clearTimeout(gisInitWatchdogTimer);
        gisInitWatchdogTimer = null;
      }
      tokenClient = google.accounts.oauth2.initTokenClient({
        client_id: clientId,
        scope: GOOGLE_SIGNIN_SCOPES,
        include_granted_scopes: true,
        callback: handleTokenResponse,
        error_callback: (err) => {
          console.error("[JobBored] GIS error_callback:", err);
          if (oauthPendingOp?.kind === "silent-refresh") {
            oauthPendingOp.finish(false);
            return;
          }
          if (oauthPendingOp?.kind === "silent-restore") {
            clearPersistedOAuthSession();
            oauthPendingOp = null;
            // Silent restore failed — user's Google session is dead or consent was
            // revoked. Open the sign-in gate instead of letting the dashboard render
            // and then throw toasts on the first click.
            if (getOAuthClientId() && !accessToken) {
              showSheetAccessGate("signin");
            }
            return;
          }
          oauthPendingOp = null;
          const errType =
            err && typeof err === "object" && err.type != null
              ? String(err.type)
              : "";
          const isPopup =
            errType === "popup_failed" ||
            errType === "popup_closed" ||
            /popup/i.test(
              String(err && err.message != null ? err.message : err),
            );
          const msg = isPopup
            ? "Google sign-in couldn’t open a window. Allow popups for this site, turn off your popup blocker for localhost, and use a normal browser tab (embedded previews often block OAuth)."
            : "Google sign-in failed. Try again, allow third-party cookies for accounts.google.com if your browser blocks them, or open the app in Chrome/Edge.";
          showToast(msg, "error", true);
        },
      });
      setupAuthUI();
      restoreOAuthSession();
      renderSetupStarterSheetUi();
      renderAppsScriptDeployUi();
      maybeSyncSettingsModalModeAfterAuth();
    } else {
      // Retry in 200ms — GIS library is loaded async
      setTimeout(tryInit, 200);
    }
  }

  tryInit();
}

function handleTokenResponse(tokenResponse) {
  const pending = oauthPendingOp;
  const silentOp =
    pending &&
    (pending.kind === "silent-refresh" || pending.kind === "silent-restore");

  if (tokenResponse.error) {
    console.error("[JobBored] OAuth error:", tokenResponse.error);
    if (pending?.kind === "silent-refresh") {
      pending.finish(false);
    } else {
      if (pending?.kind === "silent-restore") {
        clearPersistedOAuthSession();
      }
      oauthPendingOp = null;
    }
    if (silentOp && getOAuthClientId() && !accessToken) {
      showSheetAccessGate("signin");
    }
    if (!silentOp) {
      showToast(
        "Sign-in failed: " +
          (tokenResponse.error_description || tokenResponse.error),
        "error",
      );
    }
    return;
  }

  accessToken = tokenResponse.access_token;
  grantedOauthScopes = normalizeOauthScopes(
    tokenResponse.scope || GOOGLE_SIGNIN_SCOPES,
  );
  const expiresIn = Number(tokenResponse.expires_in) || 3600;
  tokenExpiresAt = Date.now() + expiresIn * 1000;
  persistOAuthSession();

  if (pending?.kind === "silent-refresh") {
    pending.finish(true);
    fetchUserEmail();
    updateAuthUI();
    maybeSyncSettingsModalModeAfterAuth();
    return;
  }

  if (pending?.kind === "silent-restore") {
    oauthPendingOp = null;
    fetchUserEmail();
    updateAuthUI();
    if (SHEET_ID) {
      loadAllData();
    } else {
      revealSetupScreenAfterAuth();
    }
    scheduleTokenRefresh();
    maybeSyncSettingsModalModeAfterAuth();
    return;
  }

  oauthPendingOp = null;

  fetchUserEmail();
  updateAuthUI();
  showToast("Signed in", "success");

  if (pendingSetupStarterSheetCreate) {
    pendingSetupStarterSheetCreate = false;
    scheduleTokenRefresh();
    if (!SHEET_ID) revealSetupScreenAfterAuth();
    void handleSetupCreateStarterSheet();
    maybeSyncSettingsModalModeAfterAuth();
    return;
  }

  if (SHEET_ID) {
    loadAllData();
  } else {
    revealSetupScreenAfterAuth();
  }
  scheduleTokenRefresh();
  maybeSyncSettingsModalModeAfterAuth();
}

async function fetchUserEmail() {
  if (!accessToken) return;
  const userInfoUrl = "https://www.googleapis.com/oauth2/v3/userinfo";
  try {
    let resp = await fetch(userInfoUrl, {
      headers: { Authorization: `Bearer ${accessToken}` },
    });
    if (resp.ok) {
      const data = await resp.json();
      userEmail = data.email || null;
      userPictureUrl =
        typeof data.picture === "string" && data.picture.trim()
          ? data.picture.trim()
          : null;
      updateAuthUI();
      updatePersistedUserEmail();
      return;
    }
    if (resp.status === 401) {
      const ok = await refreshAccessTokenSilently();
      if (!ok || !accessToken) return;
      resp = await fetch(userInfoUrl, {
        headers: { Authorization: `Bearer ${accessToken}` },
      });
      if (resp.ok) {
        const data = await resp.json();
        userEmail = data.email || null;
        userPictureUrl =
          typeof data.picture === "string" && data.picture.trim()
            ? data.picture.trim()
            : null;
        updateAuthUI();
        updatePersistedUserEmail();
      }
    }
  } catch (err) {
    console.warn("[JobBored] Could not fetch user email:", err.message);
  }
}

function signIn(options = {}) {
  if (!tokenClient) {
    showToast(
      "Google sign-in is not ready yet. Save your OAuth client and reload first.",
      "error",
      true,
    );
    return;
  }
  if (oauthPendingOp?.kind === "silent-refresh") {
    oauthPendingOp.finish(false);
  } else if (oauthPendingOp?.kind === "silent-restore") {
    oauthPendingOp = null;
  }
  oauthPendingOp = { kind: "interactive" };
  const request = {};
  let prompt =
    options && typeof options === "object" && options.prompt != null
      ? String(options.prompt)
      : "";
  // One-shot consent override: if the user just ran "Clear settings", force
  // the consent screen on the very next interactive sign-in so they cannot
  // be silently re-authed from a lingering Google consent grant. Consume the
  // flag here so it only applies once.
  try {
    if (canUseLocalStorage() && localStorage.getItem(FORCE_CONSENT_PROMPT_KEY)) {
      prompt = "consent";
      localStorage.removeItem(FORCE_CONSENT_PROMPT_KEY);
    }
  } catch (_) {
    /* ignore */
  }
  if (prompt) request.prompt = prompt;
  tokenClient.requestAccessToken(request);
}

function signOut() {
  closeAuthUserMenu();
  if (accessToken) {
    try {
      google.accounts.oauth2.revoke(accessToken, () => {
        console.log("[JobBored] Token revoked");
      });
    } catch (e) {
      // Ignore revoke errors
    }
  }
  clearSessionAuthState();
  // Wipe in-memory and on-DOM pipeline data so the signed-out session can't
  // see or interact with what was loaded before.
  pipelineRawRows = null;
  pipelineData = [];
  dashboardDataHydrated = false;
  try {
    renderPipeline();
  } catch (e) {
    /* render may no-op if the dashboard is hidden — safe to ignore */
  }
  showToast("Signed out", "info");
  maybeSyncSettingsModalModeAfterAuth();
  if (SHEET_ID) {
    initialSheetAccessResolved = false;
    // Do NOT call loadAllData() here — the JSONP fallback would re-populate
    // pipelineData from a public sheet and re-reveal the dashboard. The gate
    // is the terminal state until the user signs back in.
    showSheetAccessGate(getOAuthClientId() ? "signin" : "loading");
  } else {
    const setup = document.getElementById("setupScreen");
    if (setup) setup.style.display = "none";
    if (getOAuthClientId()) {
      showSheetAccessGate("signin");
    } else {
      showSheetAccessGate("no-oauth");
    }
    renderSetupStarterSheetUi();
  }
}

function setupAuthUI() {
  const signInBtn = document.getElementById("signInBtn");
  const signOutBtn = document.getElementById("signOutBtn");

  if (signInBtn) signInBtn.addEventListener("click", signIn);
  if (signOutBtn) signOutBtn.addEventListener("click", signOut);
}

function closeAuthUserMenu() {
  const menu = document.getElementById("authUserMenu");
  const toggle = document.getElementById("authMenuToggle");
  if (menu && !menu.hidden) {
    menu.hidden = true;
    if (toggle) toggle.setAttribute("aria-expanded", "false");
  }
}

function isAuthUserMenuOpen() {
  const menu = document.getElementById("authUserMenu");
  return !!(menu && !menu.hidden);
}

async function toggleAuthUserMenu() {
  const menu = document.getElementById("authUserMenu");
  const toggle = document.getElementById("authMenuToggle");
  if (!menu || !toggle) return;
  const willOpen = !!menu.hidden;
  if (willOpen) await refreshPersonalPreferencesPanel();
  menu.hidden = !willOpen;
  toggle.setAttribute("aria-expanded", willOpen ? "true" : "false");
}

let authUserMenuInitialized = false;

function initAuthUserMenu() {
  if (authUserMenuInitialized) return;
  const toggle = document.getElementById("authMenuToggle");
  const menu = document.getElementById("authUserMenu");
  if (!toggle || !menu) return;
  authUserMenuInitialized = true;

  toggle.addEventListener("click", async (e) => {
    e.stopPropagation();
    await toggleAuthUserMenu();
  });

  document.addEventListener(
    "click",
    (e) => {
      if (!isAuthUserMenuOpen()) return;
      const t = e.target;
      if (toggle.contains(t)) return;
      if (menu.contains(t)) return;
      closeAuthUserMenu();
    },
    true,
  );

  // "Resume onboarding": always-available re-entry into the wizard,
  // regardless of whether onboarding was previously marked complete.
  const resumeBtn = document.getElementById("resumeOnboardingBtn");
  if (resumeBtn) {
    resumeBtn.addEventListener("click", () => {
      closeAuthUserMenu();
      try {
        showOnboardingWizard();
      } catch (e) {
        console.warn("[JobBored] resume onboarding:", e);
      }
    });
  }

  // "Run setup doctor": run a full diagnose+autoHeal pass on demand.
  const doctorBtn = document.getElementById("setupDoctorBtn");
  if (doctorBtn) {
    doctorBtn.addEventListener("click", async () => {
      closeAuthUserMenu();
      if (!window.SetupDoctor) {
        showToast("Setup doctor unavailable in this build.", "warning");
        return;
      }
      showToast("Running setup doctor…", "info");
      const ctx = { lastError: lastSheetAccessError || "" };
      const report = await window.SetupDoctor.diagnose(ctx);
      if (!report.issues.length) {
        showToast("Setup looks healthy.", "success");
        return;
      }
      // Render into the login gate panel slot so the user has a
      // consistent place to act on findings, even if they're already
      // signed in.
      showSheetAccessGate("error");
    });
  }

  const healthBtn = document.getElementById("setupHealthBtn");
  if (healthBtn) {
    healthBtn.addEventListener("click", async () => {
      closeAuthUserMenu();
      const result = await installDoctor();
      if (!result || result.notImplemented) {
        showToast("Install doctor isn't available in this build.", "info");
        return;
      }
      const missing = (result && result.missing) || [];
      if (missing.length) {
        showToast(missing[0], "warning", true);
      } else {
        showToast("All install tools look healthy.", "success");
      }
      refreshKeepAlivePill();
    });
  }

  const authToggle = document.getElementById("authMenuToggle");
  if (authToggle) {
    authToggle.addEventListener("click", () => {
      refreshKeepAlivePill();
    });
  }
}

async function installDoctor() {
  try {
    const resp = await fetch("/__proxy/install-doctor", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: "{}",
    });
    if (resp.status === 501) {
      return { ok: false, notImplemented: true };
    }
    const body = await resp.json().catch(() => ({}));
    if (typeof window !== "undefined") {
      window.installDoctorState = body;
      try {
        window.dispatchEvent(
          new CustomEvent("jobbored:install-doctor:update", { detail: body }),
        );
      } catch (_) {}
    }
    return body;
  } catch (e) {
    return { ok: false, error: e && e.message };
  }
}

if (typeof window !== "undefined") {
  window.installDoctor = installDoctor;
}

const KEEP_ALIVE_INSTALLED_KEY = "jb:install-keep-alive:installedAt";

async function installKeepAliveOnce() {
  try {
    if (
      typeof localStorage !== "undefined" &&
      localStorage.getItem(KEEP_ALIVE_INSTALLED_KEY)
    ) {
      return;
    }
    const resp = await fetch("/__proxy/install-keep-alive", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ schedule: "auto" }),
    });
    if (resp.status === 501) return;
    const body = await resp.json().catch(() => ({}));
    if (body && body.ok) {
      try {
        if (typeof localStorage !== "undefined") {
          localStorage.setItem(
            KEEP_ALIVE_INSTALLED_KEY,
            body.installedAt || new Date().toISOString(),
          );
        }
      } catch (_) {}
      if (typeof window !== "undefined") {
        window.keepAliveStatusState = {
          installed: true,
          lastRunAt: body.installedAt,
          jobLabel: body.jobLabel,
        };
      }
    }
  } catch (_) {
    /* silent — never block the user */
  }
}

if (typeof window !== "undefined") {
  window.installKeepAliveOnce = installKeepAliveOnce;
}

async function refreshKeepAlivePill() {
  const pill = document.getElementById("keepAlivePill");
  if (!pill) return;
  try {
    const resp = await fetch("/__proxy/install-keep-alive/status");
    if (resp.status === 501) {
      pill.hidden = true;
      return;
    }
    const body = await resp.json().catch(() => ({}));
    if (typeof window !== "undefined") {
      window.keepAliveStatusState = body;
    }
    pill.hidden = false;
    if (body && body.installed) {
      pill.textContent = "Auto-healing on";
      pill.classList.add("doctor-keep-alive-pill--on");
      pill.classList.remove("doctor-keep-alive-pill--off");
    } else {
      pill.textContent = "Not installed — install";
      pill.classList.add("doctor-keep-alive-pill--off");
      pill.classList.remove("doctor-keep-alive-pill--on");
    }
  } catch (_) {
    pill.hidden = true;
  }
}

function setAuthAvatarDisplay() {
  const slot = document.getElementById("authAvatarSlot");
  const img = document.getElementById("authAvatarImg");
  const fb = document.getElementById("authAvatarFallback");
  if (!slot || !img || !fb) return;

  if (!accessToken) {
    img.removeAttribute("src");
    img.hidden = true;
    img.alt = "";
    fb.textContent = "";
    slot.classList.remove("auth-avatar--show-fallback");
    slot.removeAttribute("title");
    slot.removeAttribute("role");
    slot.removeAttribute("aria-label");
    document.getElementById("authMenuToggle")?.removeAttribute("aria-label");
    return;
  }

  const tip = userEmail || "Signed in";
  slot.title = tip;
  slot.setAttribute("role", "presentation");
  slot.removeAttribute("aria-label");
  img.alt = "";
  const menuToggle = document.getElementById("authMenuToggle");
  if (menuToggle) {
    menuToggle.setAttribute(
      "aria-label",
      userEmail
        ? `Account menu — signed in as ${userEmail}`
        : "Account menu — personal preferences",
    );
  }

  const initial = (userEmail || "?").trim().charAt(0).toUpperCase() || "?";
  fb.textContent = initial;

  if (userPictureUrl) {
    img.onerror = () => {
      img.hidden = true;
      img.removeAttribute("src");
      slot.classList.add("auth-avatar--show-fallback");
    };
    img.onload = () => {
      img.hidden = false;
      slot.classList.remove("auth-avatar--show-fallback");
    };
    const next = userPictureUrl;
    if (img.getAttribute("src") !== next) {
      img.hidden = true;
      slot.classList.add("auth-avatar--show-fallback");
      img.src = next;
    } else if (img.complete && img.naturalWidth > 0) {
      img.hidden = false;
      slot.classList.remove("auth-avatar--show-fallback");
    }
  } else {
    img.removeAttribute("src");
    img.hidden = true;
    slot.classList.add("auth-avatar--show-fallback");
  }
}

function updateAuthUI() {
  const signInBtn = document.getElementById("signInBtn");
  const authUser = document.getElementById("authUser");

  if (accessToken) {
    signInBtn.style.display = "none";
    authUser.style.display = "flex";
    setAuthAvatarDisplay();
  } else {
    signInBtn.style.display = "flex";
    authUser.style.display = "none";
    setAuthAvatarDisplay();
  }
  renderSetupStarterSheetUi();
}

function isSignedIn() {
  return !!accessToken;
}

/** Rotating hero tips on the login gate (left panel). */
const LOGIN_GATE_TIPS = [
  {
    label: "Did you know?",
    headline: "Your pipeline, one glance",
    body: "Scan cards for stage, notes, and follow-ups without digging through rows.",
  },
  {
    label: "Did you know?",
    headline: "Write-back stays in your sheet",
    body: "Updates sync to Google Sheets — your spreadsheet remains the source of truth.",
  },
  {
    label: "Did you know?",
    headline: "Built for speed",
    body: "Filter, sort, and expand details only when you need the full story.",
  },
];

let loginGateTipTimer = null;

function stopLoginGateTipRotation() {
  if (loginGateTipTimer != null) {
    clearInterval(loginGateTipTimer);
    loginGateTipTimer = null;
  }
}

function applyLoginGateTip(index) {
  const tip = LOGIN_GATE_TIPS[index % LOGIN_GATE_TIPS.length];
  const labelEl = document.getElementById("sheetAccessGateTipLabel");
  const headEl = document.getElementById("sheetAccessGateTipHeadline");
  const bodyEl = document.getElementById("sheetAccessGateTipBody");
  if (!tip || !labelEl || !headEl || !bodyEl) return;
  labelEl.textContent = tip.label;
  headEl.textContent = tip.headline;
  bodyEl.textContent = tip.body;
}

function startLoginGateTipRotation() {
  stopLoginGateTipRotation();
  let i = Math.floor(Math.random() * LOGIN_GATE_TIPS.length);
  applyLoginGateTip(i);
  loginGateTipTimer = setInterval(() => {
    i = (i + 1) % LOGIN_GATE_TIPS.length;
    applyLoginGateTip(i);
  }, 52000);
}

function setDashboardSheetLinks() {
  const currentSheetId = getSheetId() || SHEET_ID;
  if (!currentSheetId) return;
  SHEET_ID = currentSheetId;
  const sheetUrl = `https://docs.google.com/spreadsheets/d/${currentSheetId}/edit`;
  const sheetLink = document.getElementById("sheetLink");
  const footerSheetLink = document.getElementById("footerSheetLink");
  if (sheetLink) sheetLink.href = sheetUrl;
  if (footerSheetLink) footerSheetLink.href = sheetUrl;
}

function syncLoginGateOAuthOriginDisplay() {
  const originEl = document.getElementById("sheetAccessGateOAuthOriginDisplay");
  if (originEl && typeof window !== "undefined" && window.location) {
    originEl.textContent = window.location.origin;
  }
}

function resetLoginGateOAuthWizardToChoice() {
  const choice = document.getElementById("sheetAccessGateOAuthChoice");
  const wizard = document.getElementById("sheetAccessGateOAuthWizard");
  const input = document.getElementById("sheetAccessGateOAuthClientIdInput");
  if (choice) choice.hidden = false;
  if (wizard) wizard.hidden = true;
  syncLoginGateOAuthOriginDisplay();
  if (input) {
    const stored = readStoredConfigOverrides().oauthClientId;
    const s = stored != null ? String(stored).trim() : "";
    input.value =
      s &&
      s !== "YOUR_CLIENT_ID_HERE.apps.googleusercontent.com" &&
      /\.apps\.googleusercontent\.com$/i.test(s)
        ? s
        : "";
  }
}

function initLoginGateOAuthUi() {
  const createOAuth = document.getElementById("sheetAccessGateBtnCreateOAuth");
  const back = document.getElementById("sheetAccessGateOAuthWizardBack");
  const save = document.getElementById("sheetAccessGateOAuthSaveBtn");
  const openConsole = document.getElementById(
    "sheetAccessGateOAuthOpenConsoleBtn",
  );
  const inputs = [
    document.getElementById("sheetAccessGateOAuthClientIdInput"),
    document.getElementById("sheetAccessGateOAuthClientIdInputAlt"),
  ].filter(Boolean);

  /** Accept any pasted Client ID (raw, full URL, or surrounding whitespace). */
  function extractClientIdFromInput(raw) {
    const t = String(raw || "").trim();
    if (!t) return "";
    const m = t.match(/[\w-]+\.apps\.googleusercontent\.com/i);
    return m ? m[0] : "";
  }

  function trySaveAndContinue(raw) {
    const id = extractClientIdFromInput(raw);
    if (!id || id === "YOUR_CLIENT_ID_HERE.apps.googleusercontent.com") {
      return false;
    }
    mergeStoredConfigOverridePatch({ oauthClientId: id });
    if (applyOAuthClientChange(id)) {
      showToast("Signed-in setup saved.", "success");
    } else {
      showToast("Saved — reloading…", "success");
      setTimeout(() => window.location.reload(), 400);
    }
    return true;
  }

  // Auto-save on paste — no separate "Save" click required.
  inputs.forEach((input) => {
    input.addEventListener("input", () => {
      trySaveAndContinue(input.value);
    });
  });

  if (createOAuth) {
    createOAuth.addEventListener("click", async () => {
      const choice = document.getElementById("sheetAccessGateOAuthChoice");
      const wizard = document.getElementById("sheetAccessGateOAuthWizard");
      syncLoginGateOAuthOriginDisplay();
      // Pre-copy the origin so the user just pastes when Google asks.
      try {
        await navigator.clipboard.writeText(window.location.origin);
      } catch (_) {
        /* clipboard may be blocked — non-fatal, the origin is still visible */
      }
      if (choice) choice.hidden = true;
      if (wizard) wizard.hidden = false;
      document
        .getElementById("sheetAccessGateOAuthClientIdInputAlt")
        ?.focus();
      maybeRevealOAuthGcloudButton();
    });
  }

  const gcloudBtn = document.getElementById("sheetAccessGateOAuthGcloudBtn");
  if (gcloudBtn) {
    gcloudBtn.addEventListener("click", async () => {
      gcloudBtn.disabled = true;
      const original = gcloudBtn.textContent;
      gcloudBtn.textContent = "Creating with gcloud…";
      try {
        const resp = await fetch("/__proxy/oauth-bootstrap", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: "{}",
        });
        if (resp.status === 501) {
          gcloudBtn.hidden = true;
          return;
        }
        const body = await resp.json().catch(() => ({}));
        if (body && body.ok && body.clientId) {
          const altInput = document.getElementById(
            "sheetAccessGateOAuthClientIdInputAlt",
          );
          if (altInput) altInput.value = body.clientId;
          if (trySaveAndContinue(body.clientId)) {
            showToast("Client ID created with gcloud.", "success");
            return;
          }
        }
        const message =
          (body && body.actionable) ||
          "gcloud couldn’t create a Client ID. Try the manual steps.";
        showToast(message, "warning", true);
      } catch (e) {
        console.warn("[JobBored] oauth-bootstrap:", e);
        showToast(
          "gcloud auto-create unavailable. Try manual steps.",
          "warning",
        );
      } finally {
        gcloudBtn.disabled = false;
        gcloudBtn.textContent = original;
      }
    });
  }
  if (openConsole) {
    openConsole.addEventListener("click", () => {
      // Deep-link straight to the OAuth client creation page.
      window.open(
        "https://console.cloud.google.com/apis/credentials/oauthclient",
        "_blank",
        "noopener",
      );
    });
  }
  if (back) {
    back.addEventListener("click", () => {
      resetLoginGateOAuthWizardToChoice();
    });
  }
  if (save) {
    save.addEventListener("click", () => {
      const input = document.getElementById(
        "sheetAccessGateOAuthClientIdInput",
      );
      if (!trySaveAndContinue(input ? input.value : "")) {
        showToast("Paste a valid Google Client ID.", "error", true);
      }
    });
  }
}

async function maybeRevealOAuthGcloudButton() {
  const btn = document.getElementById("sheetAccessGateOAuthGcloudBtn");
  if (!btn) return;
  btn.hidden = true;
  try {
    const result = await installDoctor();
    if (!result || result.notImplemented) return;
    const gcloud = result.tools && result.tools.gcloud;
    if (gcloud && gcloud.installed && gcloud.loggedIn) {
      btn.hidden = false;
    }
  } catch (_) {
    /* leave hidden */
  }
}

function showSheetAccessGate(mode) {
  const screen = document.getElementById("sheetAccessGateScreen");
  const dashboard = document.getElementById("dashboard");
  const setup = document.getElementById("setupScreen");
  if (!screen || !dashboard) return;

  // Signed-in users without a pipeline sheet belong on the setup steps, not the login gate.
  // Many code paths call showSheetAccessGate() and would otherwise hide #setupScreen.
  if (!getSheetId() && accessToken && mode !== "no-oauth") {
    revealPipelineSetupStepsScreen();
    return;
  }

  screen.dataset.gateMode = mode;

  const mainFlow = document.getElementById("sheetAccessGateMainFlow");
  const oauthShell = document.getElementById("sheetAccessGateOAuthShell");
  const panelInner = document.getElementById("sheetAccessGatePanelInner");

  const title = document.getElementById("sheetAccessGateTitle");
  const detail = document.getElementById("sheetAccessGateDetail");
  const stepTitle = document.getElementById("sheetAccessGateStepTitle");
  const stepBody = document.getElementById("sheetAccessGateStepBody");
  const statusBlock = document.getElementById("sheetAccessGateStatusBlock");
  const signInBtn = document.getElementById("sheetAccessGateSignInBtn");
  const settingsBtn = document.getElementById("sheetAccessGateOpenSettingsBtn");
  const reloadBtn = document.getElementById("sheetAccessGateReloadBtn");
  const spinner = document.getElementById("sheetAccessGateSpinner");
  const foot = document.getElementById("sheetAccessGateFoot");

  let nextTitle = "Opening your workspace";
  let nextDetail = "";
  let nextStepTitle = "";
  let nextStepBody = "";
  let showSignIn = false;
  let footText = "Google sign-in";
  let showSpinner = mode === "loading";

  const showOAuthShell = mode === "no-oauth";

  stopLoginGateTipRotation();

  if (mode === "loading") {
    nextTitle = "Opening your workspace";
    nextDetail = "";
    nextStepTitle = "";
    nextStepBody = "";
    const canOAuth = !!getOAuthClientId();
    const needGoogleBtn = canOAuth && !accessToken;
    showSignIn = needGoogleBtn;
    showSpinner = !needGoogleBtn;
    footText = needGoogleBtn
      ? "Log in with Google to continue."
      : "Connecting to your sheet…";
    startLoginGateTipRotation();
  } else if (mode === "signin") {
    if (!SHEET_ID) {
      nextTitle = "Get started";
      footText =
        "Sign in with Google to create a starter sheet or connect your sheet.";
    } else {
      nextTitle = "Welcome back";
      footText = "Use the Google account that can access this sheet.";
    }
    nextDetail = "";
    nextStepTitle = "";
    nextStepBody = "";
    showSignIn = true;
    startLoginGateTipRotation();
  } else if (mode === "no-oauth") {
    nextTitle = "";
    nextDetail = "";
    nextStepTitle = "";
    nextStepBody = "";
    showSignIn = false;
    footText = "Choose an option or follow the guide to create a client ID.";
    resetLoginGateOAuthWizardToChoice();
    startLoginGateTipRotation();
  } else if (mode === "error") {
    nextTitle = "Couldn’t load this sheet";
    nextDetail = "Check the Sheet ID and permissions, then try again.";
    nextStepTitle = "";
    nextStepBody = "";
    showSignIn = !!getOAuthClientId() && !accessToken;
    footText = showSignIn
      ? "Sign in with the account that can open this sheet."
      : "Check Settings or your network and reload.";
    startLoginGateTipRotation();
  }

  if (mainFlow) mainFlow.hidden = !!showOAuthShell;
  if (oauthShell) oauthShell.hidden = !showOAuthShell;
  if (panelInner) {
    panelInner.classList.toggle(
      "login-gate__panel-inner--oauth",
      !!showOAuthShell,
    );
  }

  if (title) title.textContent = nextTitle;
  if (detail) detail.textContent = nextDetail;
  if (stepTitle) stepTitle.textContent = nextStepTitle;
  if (stepBody) stepBody.textContent = nextStepBody;
  if (signInBtn) signInBtn.hidden = !showSignIn;
  if (settingsBtn) settingsBtn.hidden = !!showOAuthShell;
  if (reloadBtn) reloadBtn.hidden = false;
  if (spinner) spinner.hidden = !showSpinner;
  if (foot) foot.textContent = footText;

  if (statusBlock) {
    const hasCallout =
      String(nextStepTitle || "").trim() || String(nextStepBody || "").trim();
    statusBlock.hidden = !hasCallout;
  }

  if (setup) setup.style.display = "none";
  dashboard.style.display = "none";
  screen.style.display = "flex";

  // Run the SetupDoctor in error mode so the user sees concrete fix actions
  // instead of a generic "Couldn't load this sheet" message.
  const doctorHost = document.getElementById("sheetAccessGateDoctorPanel");
  if (
    doctorHost &&
    typeof window !== "undefined" &&
    window.SetupDoctor &&
    typeof window.SetupDoctor.diagnose === "function"
  ) {
    if (mode === "error") {
      doctorHost.hidden = false;
      const ctx = { lastError: lastSheetAccessError || "" };
      window.SetupDoctor.diagnose(ctx)
        .then((report) => {
          report._ctx = ctx;
          if (report.issues.length === 0) return;
          window.SetupDoctor.renderInline(doctorHost, report);
        })
        .catch(() => {
          /* doctor is best-effort; ignore */
        });
    } else {
      doctorHost.hidden = true;
      while (doctorHost.firstChild) doctorHost.removeChild(doctorHost.firstChild);
    }
  }
}

/** Last raw error string the sheet/auth pipeline saw — fed into SetupDoctor. */
let lastSheetAccessError = "";
function recordSheetAccessError(err) {
  if (!err) return;
  lastSheetAccessError = err && err.message ? String(err.message) : String(err);
}

function hideSheetAccessGate() {
  stopLoginGateTipRotation();
  const screen = document.getElementById("sheetAccessGateScreen");
  if (screen) screen.style.display = "none";
}

/** Show the starter Pipeline setup screen before the guided wizard takes over. */
function revealPipelineSetupStepsScreen() {
  const setup = document.getElementById("setupScreen");
  const dashboard = document.getElementById("dashboard");
  hideSheetAccessGate();
  if (setup) setup.style.display = "flex";
  if (dashboard) dashboard.style.display = "none";
  renderSetupStarterSheetUi();
}

/** No Sheet ID yet: after Google sign-in, show the starter-sheet setup steps. */
function revealSetupScreenAfterAuth() {
  if (getSheetId()) return;
  revealPipelineSetupStepsScreen();
}

function revealDashboardShell() {
  const setup = document.getElementById("setupScreen");
  const screen = document.getElementById("sheetAccessGateScreen");
  const dashboard = document.getElementById("dashboard");
  if (setup) setup.style.display = "none";
  if (screen) screen.style.display = "none";
  if (dashboard) dashboard.style.display = "block";
}

function renderSetupStarterSheetUi() {
  const btn = document.getElementById("setupCreateStarterSheetBtn");
  const status = document.getElementById("setupCreateStarterSheetStatus");
  if (!btn || !status) return;

  const hasClient = !!getOAuthClientId();
  if (!hasClient) {
    btn.disabled = false;
    btn.textContent = "Create blank starter sheet";
    status.textContent =
      "Complete OAuth setup on the sign-in screen, then reload this page.";
    return;
  }
  if (!gisLoaded) {
    btn.disabled = true;
    btn.textContent = "Loading Google sign-in…";
    status.textContent =
      "Reload once after signing in so Google sign-in can initialize.";
    return;
  }
  if (!accessToken) {
    btn.disabled = false;
    btn.textContent = "Sign in & create blank starter sheet";
    status.textContent =
      "This will open Google sign-in, then create a fresh Pipeline sheet with just the headers.";
    return;
  }

  if (getSheetId()) {
    btn.disabled = true;
    btn.textContent = "Starter sheet linked";
    status.textContent =
      "Your Pipeline sheet is saved. The guided setup wizard is the next step.";
    return;
  }

  btn.disabled = false;
  btn.textContent = "Create blank starter sheet";
  status.textContent =
    "Signed in and ready. This creates a fresh Pipeline sheet with only the required headers.";
}

async function createBlankStarterSheet(isRetry) {
  if (!accessToken) {
    showSheetAccessGate("signin");
    return null;
  }

  const title = `JobBored Pipeline ${new Date().toISOString().slice(0, 10)}`;
  try {
    const createResp = await fetch(
      "https://sheets.googleapis.com/v4/spreadsheets",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          properties: { title },
          sheets: [
            {
              properties: {
                title: "Pipeline",
                gridProperties: {
                  rowCount: 200,
                  columnCount: STARTER_PIPELINE_HEADERS.length,
                  frozenRowCount: 1,
                },
              },
            },
          ],
        }),
      },
    );

    if (createResp.status === 401) {
      if (!isRetry) {
        const ok = await refreshAccessTokenSilently();
        if (ok) return createBlankStarterSheet(true);
      }
      clearSessionAuthState();
      throw new Error(
        "Google session expired while creating the starter sheet.",
      );
    }

    if (!createResp.ok) {
      const err = await createResp.json().catch(() => ({}));
      const message = String(
        err.error?.message ||
          `Starter sheet creation failed (HTTP ${createResp.status}).`,
      );
      if (
        createResp.status === 403 &&
        /insufficient authentication scopes/i.test(message) &&
        !isRetry
      ) {
        pendingSetupStarterSheetCreate = true;
        showToast(
          "Google needs Sheets permission before JobBored can create a starter sheet. Approve the prompt and try again.",
          "info",
          true,
        );
        signIn({ prompt: "consent" });
        return null;
      }
      throw new Error(message);
    }

    const spreadsheet = await createResp.json();
    const spreadsheetId =
      spreadsheet && spreadsheet.spreadsheetId
        ? String(spreadsheet.spreadsheetId).trim()
        : "";
    const spreadsheetUrl =
      spreadsheet && spreadsheet.spreadsheetUrl
        ? String(spreadsheet.spreadsheetUrl).trim()
        : "";
    if (!spreadsheetId) {
      throw new Error(
        "Google created a sheet but did not return a spreadsheetId.",
      );
    }

    const headerResp = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${encodeURIComponent(spreadsheetId)}/values/${encodeURIComponent(STARTER_PIPELINE_HEADER_RANGE)}?valueInputOption=RAW`,
      {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          range: STARTER_PIPELINE_HEADER_RANGE,
          majorDimension: "ROWS",
          values: [STARTER_PIPELINE_HEADERS],
        }),
      },
    );

    if (!headerResp.ok) {
      const err = await headerResp.json().catch(() => ({}));
      throw new Error(
        err.error?.message ||
          `Starter sheet header setup failed (HTTP ${headerResp.status}).`,
      );
    }

    return { spreadsheetId, spreadsheetUrl };
  } catch (err) {
    console.error("[JobBored] Starter sheet:", err);
    showToast(
      String(err.message || err || "Could not create starter sheet"),
      "error",
      true,
    );
    return null;
  }
}

async function handleSetupCreateStarterSheet() {
  if (!getOAuthClientId()) {
    showToast(
      "Save a Google OAuth client in Settings first, then come back and create the sheet.",
      "error",
      true,
    );
    void openCommandCenterSettingsModal();
    return;
  }
  if (!gisLoaded || !tokenClient) {
    showToast(
      "Google sign-in is not ready yet. Save the OAuth client, reload, then try again.",
      "error",
      true,
    );
    return;
  }
  if (!accessToken || !hasGrantedOauthScope(GOOGLE_SHEETS_SCOPE)) {
    pendingSetupStarterSheetCreate = true;
    signIn({
      prompt: accessToken ? "consent" : "",
    });
    return;
  }

  const btn = document.getElementById("setupCreateStarterSheetBtn");
  if (btn) {
    btn.disabled = true;
    btn.textContent = "Creating starter sheet…";
  }
  const created = await createBlankStarterSheet(false);
  renderSetupStarterSheetUi();
  if (!created) return;

  mergeStoredConfigOverridePatch({ sheetId: created.spreadsheetId });
  SHEET_ID = created.spreadsheetId;
  initialSheetAccessResolved = true;
  setDashboardSheetLinks();
  revealDashboardShell();
  const hadDiscoveryDeepLink =
    new URLSearchParams(window.location.search).get("setup") === "discovery";
  await runPostAccessBootstrapOnce();
  void loadAllData();
  if (created.spreadsheetUrl) {
    window.open(created.spreadsheetUrl, "_blank", "noopener");
  }
  if (!hadDiscoveryDeepLink) {
    await requestDiscoverySetup({ entryPoint: "starter_sheet_created" });
  }
  showToast(
    hasPendingDiscoverySetup()
      ? "Starter sheet created. Finish onboarding to continue guided setup."
      : "Starter sheet created. Opening guided setup…",
    "success",
  );
}

// ============================================
// WRITE-BACK — Google Sheets API v4
// ============================================

async function updateSheetCell(range, value, isRetry) {
  if (!accessToken) {
    showSheetAccessGate("signin");
    return false;
  }

  const url = `https://sheets.googleapis.com/v4/spreadsheets/${SHEET_ID}/values/${encodeURIComponent(range)}?valueInputOption=USER_ENTERED`;

  try {
    const resp = await fetch(url, {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        range: range,
        majorDimension: "ROWS",
        values: [[value]],
      }),
    });

    if (resp.status === 401) {
      if (!isRetry) {
        const refreshed = await refreshAccessTokenSilently();
        if (refreshed) return updateSheetCell(range, value, true);
      }
      clearSessionAuthState();
      renderPipeline();
      showToast("Session expired — please sign in again", "error");
      return false;
    }

    if (!resp.ok) {
      const errData = await resp.json().catch(() => ({}));
      const errMsg = errData.error?.message || `HTTP ${resp.status}`;
      console.error("[JobBored] Sheet update failed:", errMsg);
      showToast("Update failed: " + errMsg, "error");
      return false;
    }

    return true;
  } catch (err) {
    console.error("[JobBored] Sheet update error:", err);
    showToast("Update failed — check your connection", "error");
    return false;
  }
}

function generateDiscoveryVariationKey() {
  if (typeof crypto !== "undefined" && crypto.getRandomValues) {
    const bytes = new Uint8Array(8);
    crypto.getRandomValues(bytes);
    return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
  }
  return `${Date.now()}-${Math.random().toString(36).slice(2, 12)}`;
}

/** Notify automation (Hermes, n8n, etc.) to run another discovery pass (varied query). */
async function triggerDiscoveryRun() {
  const hook = normalizeDiscoveryWebhookIdentity(getDiscoveryWebhookUrl());
  if (!hook) {
    void requestDiscoverySetup({
      entryPoint: "run_discovery",
      allowWhileOnboarding: true,
    });
    return { ok: false, reason: "no_url" };
  }
  try {
    const payload = await buildDiscoveryWebhookPayload(SHEET_ID);
    // Guardrail: verify intent is present before sending webhook request
    const profile = payload && payload.discoveryProfile;
    const targetRoles = (profile && profile.targetRoles || "").trim();
    const keywordsInclude = (profile && profile.keywordsInclude || "").trim();
    if (!targetRoles && !keywordsInclude) {
      showToast(
        "Add target roles or keywords to include, or use the AI Suggest tab to generate them.",
        "warning",
        true,
      );
      return { ok: false, reason: "blank_intent" };
    }
    const result = await verifyDiscoveryWebhookWithSharedModel(hook, payload, {
      context: "run_discovery",
      sheetId: SHEET_ID || "",
    });
    if (result.ok) {
      const engineState = getDiscoveryEngineStateFromVerificationResult(result);
      if (engineState) {
        await recordDiscoveryEngineState(hook, engineState, "run_discovery");
      }
      await refreshDiscoveryReadinessSnapshot({ force: true, rerender: false });
      showDiscoveryVerificationToast(result, { context: "run_discovery" });

      // Extract run tracking metadata from accepted_async responses and start polling
      if (result.kind === "accepted_async" && result.runId) {
        const webhookUrl = String(hook || "").trim();
        // statusPath may come from the response body directly when the verifier
        // parses the raw JSON and attaches it to the result object.
        const statusPath = String(result.statusPath || result.status_path || "").trim();
        discoveryRunTracker.beginTracking({
          runId: result.runId,
          statusPath,
          pollAfterMs: Number.isFinite(result.pollAfterMs) ? result.pollAfterMs : 2000,
          webhookUrl,
          trigger: "manual",
          variationKey: payload.variationKey || "",
          requestedAt: payload.requestedAt || "",
        });
        // Show initial pending feedback immediately
        renderDiscoveryRunStatus();
        // Start async polling — will update tracker state on each response
        void startDiscoveryStatusPolling(webhookUrl);
      }

      return { ok: true, kind: result.kind };
    }
    if (
      (result.kind === "network_error" || result.kind === "invalid_endpoint") &&
      (await handleAppsScriptBrowserCorsFailure(hook, result.kind))
    ) {
      // Apps Script stub is publicly accessible — CORS blocked the browser from
      // reading the response, but the endpoint did receive the request.
      // Classify as stub_only so the Run discovery path preserves wiring-only
      // semantics and does not report full-connected success.
      result.kind = "stub_only";
      result.engineState = "stub_only";
      showDiscoveryVerificationToast(result, {
        context: "run_discovery",
        endpointUrl: hook,
      });
      return { ok: false, kind: "stub_only" };
    }
    showDiscoveryVerificationToast(result, {
      context: "run_discovery",
      endpointUrl: hook,
    });
    return { ok: false, reason: result.kind || "http" };
  } catch (err) {
    console.error("[JobBored] Discovery webhook:", err);
    showToast(String(err && err.message ? err.message : err), "error", true);
    return { ok: false, reason: "error" };
  }
}

/**
 * POST a test payload from the Settings form (same shape as Run discovery).
 * Uses unsaved field values so you can test before Save.
 */
async function testDiscoveryWebhookFromSettings() {
  const urlEl = document.getElementById("settingsDiscoveryWebhookUrl");
  const secretEl = document.getElementById("settingsDiscoveryWebhookSecret");
  const sheetEl = document.getElementById("settingsSheetId");
  const url = normalizeDiscoveryWebhookIdentity(urlEl && urlEl.value.trim());
  const secret = secretEl ? String(secretEl.value || "").trim() : "";
  const sheetRaw = sheetEl && sheetEl.value.trim();
  const sheetId = parseGoogleSheetId(sheetRaw || "");
  if (!url) {
    showToast("Paste a discovery webhook URL first", "error");
    return;
  }
  if (!sheetId) {
    showToast("Set a valid Spreadsheet URL or Sheet ID above first", "error");
    return;
  }
  const testBtn = document.getElementById("settingsDiscoveryTestBtn");
  if (testBtn) testBtn.disabled = true;
  try {
    const payload = await buildDiscoveryWebhookPayload(sheetId);
    const result = await verifyDiscoveryWebhookWithSharedModel(url, payload, {
      context: "test_webhook",
      sheetId,
      secret,
    });
    if (result.ok) {
      const engineState = getDiscoveryEngineStateFromVerificationResult(result);
      if (engineState) {
        await recordDiscoveryEngineState(url, engineState, "test_webhook");
      }
      await refreshDiscoveryReadinessSnapshot({ force: true, rerender: false });
      showDiscoveryVerificationToast(result, {
        context: "test_webhook",
        endpointUrl: url,
      });
      return;
    }
    if (
      (result.kind === "network_error" || result.kind === "invalid_endpoint") &&
      (await handleAppsScriptBrowserCorsFailure(url, result.kind))
    ) {
      // Apps Script stub is publicly accessible — CORS blocked the browser from
      // reading the response, but the endpoint did receive the request.
      // Classify as stub_only so Test webhook shows warning semantics, not
      // a generic network error.
      result.kind = "stub_only";
      result.engineState = "stub_only";
      result.message =
        "Apps Script stub received the request. Wiring works, but the stub does not find real jobs.";
      result.detail =
        "Switch to a real discovery engine or set up a Cloudflare relay to enable real discovery.";
      showDiscoveryVerificationToast(result, {
        context: "test_webhook",
        endpointUrl: url,
      });
      return;
    }
    showDiscoveryVerificationToast(result, {
      context: "test_webhook",
      endpointUrl: url,
    });
  } catch (err) {
    showToast(String(err.message || err || "Test failed"), "error");
  } finally {
    if (testBtn) testBtn.disabled = false;
    refreshDiscoveryUiState();
  }
}

function openDiscoveryPathsModal() {
  const m = document.getElementById("discoveryPathsModal");
  if (m) m.style.display = "flex";
  document.getElementById("discoveryPathsDoneBtn")?.focus();
}

function closeDiscoveryPathsModal() {
  const m = document.getElementById("discoveryPathsModal");
  if (m) m.style.display = "none";
}

function openDiscoverySetupGuideModal() {
  const m = document.getElementById("discoverySetupGuideModal");
  if (m) m.style.display = "flex";
  document.getElementById("discoverySetupGuideDoneBtn")?.focus();
}

function closeDiscoverySetupGuideModal() {
  const m = document.getElementById("discoverySetupGuideModal");
  if (m) m.style.display = "none";
}

function renderDiscoveryLocalTunnelSetupUi() {
  const statusCard = document.getElementById("discoveryLocalTunnelStatus");
  const statusTitle = document.getElementById(
    "discoveryLocalTunnelStatusTitle",
  );
  const statusDetail = document.getElementById(
    "discoveryLocalTunnelStatusDetail",
  );
  const localInput = document.getElementById("discoveryLocalWebhookUrl");
  const tunnelInput = document.getElementById("discoveryTunnelPublicUrl");
  const healthValue = document.getElementById("discoveryLocalWebhookHealthUrl");
  const tunnelCommand = document.getElementById(
    "discoveryLocalTunnelStartCommand",
  );
  const publicTargetValue = document.getElementById(
    "discoveryLocalTunnelTargetValue",
  );
  const copyHealthBtn = document.getElementById(
    "discoveryLocalTunnelCopyHealthBtn",
  );
  const copyTargetBtn = document.getElementById(
    "discoveryLocalTunnelCopyTargetBtn",
  );
  const copyStartBtn = document.getElementById(
    "discoveryLocalTunnelCopyStartBtn",
  );
  const openRelayBtn = document.getElementById("discoveryLocalTunnelRelayBtn");
  if (
    !statusCard ||
    !statusTitle ||
    !statusDetail ||
    !healthValue ||
    !tunnelCommand ||
    !publicTargetValue
  ) {
    return;
  }

  const localWebhookUrl = normalizeDiscoveryLocalWebhookUrl(
    localInput ? localInput.value : "",
  );
  const tunnelPublicUrl = normalizeDiscoveryTunnelPublicUrl(
    tunnelInput ? tunnelInput.value : "",
  );
  const publicTargetUrl = buildDiscoveryTunnelTargetUrl(
    localWebhookUrl,
    tunnelPublicUrl,
  );
  const healthUrl = getDiscoveryLocalWebhookHealthUrl(localWebhookUrl);
  const port = inferLocalWebhookPort(localWebhookUrl);

  let tone = "info";
  let title = "Start with your local discovery receiver.";
  let detail =
    "Recommended: use the browser-use worker on this machine. Paste the exact local webhook URL, then start ngrok on the same port and paste the public HTTPS forwarding URL. Advanced only: you can still use a Hermes/OpenClaw route.";

  if (localWebhookUrl && !tunnelPublicUrl) {
    tone = "warning";
    title = "Local receiver saved. Public tunnel still missing.";
    detail = `Your local receiver is on port ${port}. Run ngrok on that port, then paste the https:// forwarding URL here.`;
  } else if (!localWebhookUrl && tunnelPublicUrl) {
    tone = "warning";
    title = "Public tunnel saved. Local receiver path still missing.";
    detail =
      "Paste the exact local webhook URL too, so JobBored can build the public target path for the Cloudflare Worker.";
  } else if (publicTargetUrl) {
    tone = "success";
    title = "Public target ready for the Cloudflare relay.";
    detail =
      "Use the generated target below as TARGET_URL in the Worker helper. Keep Discovery webhook URL pointed at the Worker, not ngrok directly.";
  }

  statusCard.className = `settings-apps-script-status settings-apps-script-status--${tone}`;
  statusTitle.textContent = title;
  statusDetail.textContent = detail;

  healthValue.textContent =
    healthUrl || "Paste your local webhook URL to generate /health.";
  tunnelCommand.textContent = `ngrok http ${port}`;
  if (copyStartBtn) {
    copyStartBtn.setAttribute("data-copy-text", tunnelCommand.textContent);
  }
  publicTargetValue.textContent =
    publicTargetUrl ||
    "Paste both the local webhook URL and the public ngrok URL to generate the target.";

  if (copyHealthBtn) copyHealthBtn.disabled = !healthUrl;
  if (copyTargetBtn) copyTargetBtn.disabled = !publicTargetUrl;
  if (openRelayBtn) openRelayBtn.disabled = !publicTargetUrl;
}

function populateDiscoveryLocalTunnelModal() {
  const state = getDiscoveryTransportSetupState();
  const localInput = document.getElementById("discoveryLocalWebhookUrl");
  const tunnelInput = document.getElementById("discoveryTunnelPublicUrl");
  if (localInput) localInput.value = state.localWebhookUrl || "";
  if (tunnelInput) tunnelInput.value = state.tunnelPublicUrl || "";
  renderDiscoveryLocalTunnelSetupUi();
}

async function openDiscoveryLocalTunnelModal() {
  await hydrateDiscoveryTransportSetupFromLocalBootstrap();
  populateDiscoveryLocalTunnelModal();
  const modal = document.getElementById("discoveryLocalTunnelModal");
  if (modal) modal.style.display = "flex";
  document.getElementById("discoveryLocalWebhookUrl")?.focus();
  void probeAndShowTunnelStaleBanner();
}

async function probeNgrokFromLocalApi() {
  try {
    const controller =
      typeof AbortController !== "undefined" ? new AbortController() : null;
    const timeout = controller
      ? window.setTimeout(() => controller.abort(), 2500)
      : null;
    try {
      const res = await fetch("/__proxy/ngrok-tunnels", {
        cache: "no-store",
        signal: controller ? controller.signal : undefined,
      });
      if (!res.ok) return "";
      const data = await res.json().catch(() => null);
      const tunnels = Array.isArray(data && data.tunnels) ? data.tunnels : [];
      for (const t of tunnels) {
        const url = String(t && (t.public_url || t.publicUrl || "")).trim();
        if (/^https:\/\//i.test(url)) return url.replace(/\/+$/, "");
      }
      const direct = String(
        data && (data.public_url || data.publicUrl || ""),
      ).trim();
      return /^https:\/\//i.test(direct) ? direct.replace(/\/+$/, "") : "";
    } finally {
      if (timeout != null) window.clearTimeout(timeout);
    }
  } catch (_) {
    return "";
  }
}

async function probeAndShowTunnelStaleBanner() {
  const banner = document.getElementById("tunnelStaleBanner");
  if (!banner) return;

  const bannerTitle = document.getElementById("tunnelStaleBannerTitle");
  const bannerDetail = document.getElementById("tunnelStaleBannerDetail");
  const bannerAction = document.getElementById("tunnelStaleBannerAction");
  if (!bannerTitle || !bannerDetail || !bannerAction) return;

  if (!isLocalDashboardOrigin()) {
    banner.style.display = "none";
    return;
  }

  const stored = getDiscoveryTransportSetupState();
  const storedUrl = (stored.tunnelPublicUrl || "").replace(/\/+$/, "");

  const liveUrl = await probeNgrokFromLocalApi();

  if (!liveUrl && !storedUrl) {
    banner.style.display = "none";
    return;
  }

  if (!liveUrl) {
    banner.style.display = "flex";
    banner.className = "tunnel-stale-banner tunnel-stale-banner--down";
    const port = inferLocalWebhookPort(stored.localWebhookUrl);
    bannerTitle.textContent = "No ngrok tunnel detected.";
    bannerDetail.textContent = `Run ngrok http ${port} to restart the public tunnel to your local worker, then click Detect.`;
    bannerAction.style.display = "none";
    return;
  }

  if (storedUrl && liveUrl !== storedUrl) {
    banner.style.display = "flex";
    banner.className = "tunnel-stale-banner";
    bannerTitle.textContent = "Public tunnel changed.";
    bannerDetail.textContent = [
      "ngrok gave your local setup a new public URL.",
      `Previous tunnel: ${storedUrl}`,
      `Current tunnel: ${liveUrl}`,
      "Use the current tunnel URL here, then redeploy the Cloudflare relay. Keep the same Worker URL saved in JobBored.",
    ].join("\n");
    bannerAction.textContent = "Use current URL";
    bannerAction.style.display = "";
    bannerAction.onclick = () => {
      const tunnelInput = document.getElementById("discoveryTunnelPublicUrl");
      if (tunnelInput) tunnelInput.value = liveUrl;
      renderDiscoveryLocalTunnelSetupUi();
      saveDiscoveryLocalTunnelSetup(true);
      const relayBtn = document.getElementById("discoveryLocalTunnelRelayBtn");
      if (relayBtn && typeof relayBtn.focus === "function") relayBtn.focus();
      showToast(
        "Tunnel URL updated. Redeploy the Cloudflare relay so it points at the new tunnel. Keep the same Worker URL saved in JobBored.",
        "info",
      );
      banner.style.display = "none";
    };
    return;
  }

  banner.style.display = "none";
}

function closeDiscoveryLocalTunnelModal() {
  const modal = document.getElementById("discoveryLocalTunnelModal");
  if (modal) modal.style.display = "none";
}

async function probeTunnelStaleBadge() {
  const badge = document.getElementById("settingsTunnelStaleBadge");
  if (!badge || !isLocalDashboardOrigin()) {
    if (badge) badge.style.display = "none";
    return;
  }
  const stored = getDiscoveryTransportSetupState();
  if (!stored.tunnelPublicUrl) {
    badge.style.display = "none";
    return;
  }
  const liveUrl = await probeNgrokFromLocalApi();
  const storedNorm = stored.tunnelPublicUrl.replace(/\/+$/, "");
  const stale = !liveUrl || liveUrl !== storedNorm;
  badge.style.display = stale ? "inline-block" : "none";
}

function saveDiscoveryLocalTunnelSetup(openRelayAfterSave) {
  const localInput = document.getElementById("discoveryLocalWebhookUrl");
  const tunnelInput = document.getElementById("discoveryTunnelPublicUrl");
  if (!localInput || !tunnelInput) return;

  const localRaw = String(localInput.value || "").trim();
  const tunnelRaw = String(tunnelInput.value || "").trim();
  const localWebhookUrl = normalizeDiscoveryLocalWebhookUrl(localRaw);
  const tunnelPublicUrl = normalizeDiscoveryTunnelPublicUrl(tunnelRaw);

  if (localRaw && !localWebhookUrl) {
    showToast("Paste a valid http:// or https:// local webhook URL.", "error");
    localInput.focus();
    return;
  }
  if (tunnelRaw && !tunnelPublicUrl) {
    showToast("Paste a valid https:// ngrok forwarding URL.", "error");
    tunnelInput.focus();
    return;
  }

  const previousState = getDiscoveryTransportSetupState();
  const tunnelUrlChanged =
    tunnelPublicUrl &&
    previousState.tunnelPublicUrl &&
    tunnelPublicUrl !== previousState.tunnelPublicUrl;

  writeDiscoveryTransportSetupState({
    localWebhookUrl,
    tunnelPublicUrl,
  });
  renderDiscoveryLocalTunnelSetupUi();

  const shouldOpenRelay = openRelayAfterSave || tunnelUrlChanged;

  if (shouldOpenRelay) {
    const publicTargetUrl = buildDiscoveryTunnelTargetUrl(
      localWebhookUrl,
      tunnelPublicUrl,
    );
    if (!publicTargetUrl) {
      showToast(
        "Paste both the local webhook URL and the ngrok URL first.",
        "error",
      );
      return;
    }
    closeDiscoveryLocalTunnelModal();
    void openCloudflareRelaySetupModal();
    const deployCommand = buildDiscoveryRelayDeployCommandForTarget(
      publicTargetUrl,
      {},
    );
    showToast(
      tunnelUrlChanged
        ? "ngrok URL updated. Copy the command, paste it into a terminal in the Job-Bored repo, and press Enter."
        : "Local tunnel info saved. Copy the relay command, paste it into a terminal in the Job-Bored repo, and press Enter.",
      tunnelUrlChanged ? "warning" : "success",
      tunnelUrlChanged,
      createDiscoveryRelayCopyCommandToastAction(deployCommand),
    );
    return;
  }

  showToast("Local tunnel info saved in this browser.", "success");
}

function populateCloudflareRelaySetupModal() {
  const statusCard = document.getElementById("cloudflareRelayStatus");
  const statusTitle = document.getElementById("cloudflareRelayStatusTitle");
  const statusDetail = document.getElementById("cloudflareRelayStatusDetail");
  const targetValue = document.getElementById("cloudflareRelayTargetValue");
  const agentPrompt = document.getElementById("cloudflareRelayAgentPrompt");
  const deployCommand = document.getElementById("cloudflareRelayDeployCommand");
  const originValue = document.getElementById("cloudflareRelayOriginValue");
  const corsSnippet = document.getElementById("cloudflareRelayCorsSnippet");
  const workerInput = document.getElementById("cloudflareRelayWorkerUrl");
  const copyTargetBtn = document.getElementById("cloudflareRelayCopyTargetBtn");
  const copyPromptBtn = document.getElementById(
    "cloudflareRelayCopyAgentPromptBtn",
  );
  const copyCommandBtn = document.getElementById(
    "cloudflareRelayCopyDeployCommandBtn",
  );
  if (
    !statusCard ||
    !statusTitle ||
    !statusDetail ||
    !targetValue ||
    !agentPrompt ||
    !deployCommand ||
    !originValue ||
    !corsSnippet
  ) {
    return;
  }

  const targetInfo = getCloudflareRelayTargetInfo();
  const targetUrl = targetInfo.url;
  const currentWebhookUrl =
    getSettingsFieldValue("settingsDiscoveryWebhookUrl").trim() ||
    getDiscoveryWebhookUrl();
  const suggestedOrigin = getDiscoveryRelaySuggestedOrigin() || "*";
  const workerName = getDiscoveryRelayWorkerName(targetUrl, currentWebhookUrl);
  const sheetId = getSettingsSheetIdValue() || "";

  let tone = "info";
  let title = "Fastest path: let your coding agent deploy the relay.";
  let detail =
    "The local helper script handles Wrangler deploy + TARGET_URL secret upload. You only need Cloudflare auth when the agent asks for it.";

  if (!targetUrl) {
    tone = "warning";
    title = "No webhook URL detected yet.";
    detail =
      "Deploy Apps Script first, or paste its /exec URL into Discovery webhook URL.";
  } else if (
    isLikelyCloudflareWorkerUrl(currentWebhookUrl) &&
    targetInfo.source === "managed"
  ) {
    title = "Current webhook already looks like a Cloudflare Worker.";
    detail =
      "The target below comes from your managed Apps Script deploy. Use it as TARGET_URL if you are re-creating or rotating the relay.";
  } else if (targetInfo.source === "managed") {
    detail =
      "Using the managed Apps Script deploy URL from this browser as TARGET_URL.";
  } else if (targetInfo.source === "local_tunnel") {
    title = "Using your ngrok tunnel as the relay target.";
    detail =
      "The Worker will forward requests to your tunnel, which reaches your local server.";
  } else if (!isLikelyAppsScriptWebAppUrl(targetUrl)) {
    tone = "warning";
    title = "Current webhook URL does not look like Apps Script.";
    detail =
      "You can still use the Worker as a generic relay, but this path is mainly meant for Apps Script /exec CORS failures.";
  }

  statusCard.className = `settings-apps-script-status settings-apps-script-status--${tone}`;
  statusTitle.textContent = title;
  statusDetail.textContent = detail;

  targetValue.textContent =
    targetUrl || "No Apps Script /exec URL detected yet.";
  if (copyTargetBtn) copyTargetBtn.disabled = !targetUrl;

  const deployCommandText = targetUrl
    ? buildDiscoveryRelayDeployCommandForTarget(targetUrl, {
        origin: suggestedOrigin,
        workerName,
        workerUrl: currentWebhookUrl,
        sheetId,
      })
    : "Deploy Apps Script first to generate a one-command Cloudflare relay setup.";
  agentPrompt.textContent = buildCloudflareRelayAgentPrompt(
    targetUrl,
    suggestedOrigin,
    workerName,
    sheetId,
  );
  deployCommand.textContent = deployCommandText;
  if (copyPromptBtn) copyPromptBtn.disabled = !targetUrl;
  if (copyCommandBtn) copyCommandBtn.disabled = !targetUrl;

  originValue.textContent = suggestedOrigin;
  corsSnippet.textContent = buildCloudflareRelayCorsSnippet(suggestedOrigin);

  if (workerInput) {
    workerInput.value = isLikelyCloudflareWorkerUrl(currentWebhookUrl)
      ? currentWebhookUrl
      : "";
  }
}

async function openCloudflareRelaySetupModal() {
  if (showAppsScriptPublicAccessRemediationFromState()) {
    showToast(
      "Fix Apps Script public access first. Cloudflare relay is not the next step until Google allows anonymous access.",
      "error",
      true,
    );
    return;
  }
  await hydrateDiscoveryTransportSetupFromLocalBootstrap();
  populateCloudflareRelaySetupModal();
  const m = document.getElementById("cloudflareRelaySetupModal");
  if (m) m.style.display = "flex";
  const promptBtn = document.getElementById(
    "cloudflareRelayCopyAgentPromptBtn",
  );
  if (promptBtn && !promptBtn.disabled) {
    promptBtn.focus();
    return;
  }
  document.getElementById("cloudflareRelayWorkerUrl")?.focus();
}

function closeCloudflareRelaySetupModal() {
  const m = document.getElementById("cloudflareRelaySetupModal");
  if (m) m.style.display = "none";
}

function isSettingsModalOpen() {
  const modal = document.getElementById("settingsModal");
  return !!(modal && modal.style.display === "flex");
}

async function openCloudflareRelaySetupFromAppsScriptFailure() {
  if (!isSettingsModalOpen()) {
    await openCommandCenterSettingsModal();
  }
  await openCloudflareRelaySetupModal();
}

async function applyCloudflareRelayWorkerUrl(testAfterApply) {
  const input = document.getElementById("cloudflareRelayWorkerUrl");
  const urlField = document.getElementById("settingsDiscoveryWebhookUrl");
  const workerUrl = input ? String(input.value || "").trim() : "";
  if (!input || !urlField) return;

  if (!workerUrl) {
    showToast("Paste your deployed Worker URL first", "error");
    input.focus();
    return;
  }

  let parsed;
  try {
    parsed = new URL(workerUrl);
  } catch (_) {
    showToast("Paste a valid https:// Worker URL", "error");
    input.focus();
    return;
  }

  if (parsed.protocol !== "https:") {
    showToast("Use an https:// Worker URL", "error");
    input.focus();
    return;
  }

  const normalizedPath = parsed.pathname.replace(/\/+$/, "");
  if (normalizedPath.endsWith("/forward")) {
    showToast(
      "Use the open Worker URL, not /forward — the dashboard does not send custom auth headers yet.",
      "error",
      true,
    );
    input.focus();
    return;
  }

  const normalizedWorkerUrl = parsed.toString();

  urlField.value = normalizedWorkerUrl;
  mergeStoredConfigOverridePatch({
    discoveryWebhookUrl: normalizedWorkerUrl,
  });
  syncDiscoveryButtonState();
  closeCloudflareRelaySetupModal();

  if (testAfterApply) {
    showToast("Worker URL saved. Testing from this browser…", "info");
    await testDiscoveryWebhookFromSettings();
    return;
  }

  focusDiscoveryWebhookFieldInSettings();
  showToast("Worker URL saved in this browser.", "success");
}

async function handleAppsScriptBrowserCorsFailure(
  url,
  resultKind = "network_error",
) {
  if (!isLikelyAppsScriptWebAppUrl(url)) return false;
  const isNetworkLikeFailure =
    (resultKind === "network_error" &&
      isManagedAppsScriptDeployState(appsScriptDeployStateCache)) ||
    (resultKind === "invalid_endpoint" &&
      isManagedAppsScriptDeployState(appsScriptDeployStateCache));
  if (!isNetworkLikeFailure) return false;
  if (
    isManagedAppsScriptDeployState(appsScriptDeployStateCache) &&
    !isAppsScriptPublicAccessReady(appsScriptDeployStateCache)
  ) {
    if (!isSettingsModalOpen()) {
      await openCommandCenterSettingsModal();
    }
    showAppsScriptPublicAccessRemediationFromState();
    showToast(
      "Apps Script is not publicly callable yet. Finish the remediation steps in Settings before using the relay.",
      "error",
      true,
    );
    return true;
  }
  // Apps Script is publicly accessible — treat as stub-only wiring confirmation.
  // The endpoint accepted the request but is not a real discovery engine.
  // Suppress the generic CORS/network error and let the caller treat this as stub_only.
  showToast(
    "Apps Script stub received the request. This is wiring-only — the stub does not find real jobs.",
    "warning",
    true,
  );
  return true;
}

function initDiscoverySetupGuide() {
  document
    .getElementById("settingsDiscoveryGuideBtn")
    ?.addEventListener("click", () => {
      void requestDiscoverySetup({
        entryPoint: "settings",
        allowWhileOnboarding: true,
      });
    });
  document
    .getElementById("settingsDiscoveryLocalSetupBtn")
    ?.addEventListener("click", () => {
      void requestDiscoverySetup({
        entryPoint: "settings",
        flow: "local_agent",
        startStep: "bootstrap",
        allowWhileOnboarding: true,
      });
    });
  document
    .getElementById("settingsDiscoveryRelayBtn")
    ?.addEventListener("click", () => {
      void requestDiscoverySetup({
        entryPoint: "settings",
        flow: "local_agent",
        startStep: "relay_deploy",
        allowWhileOnboarding: true,
      });
    });
  document
    .getElementById("settingsDiscoveryPathsBtn")
    ?.addEventListener("click", () => {
      openDiscoveryPathsModal();
    });
  document
    .getElementById("settingsDiscoveryTestBtn")
    ?.addEventListener("click", () => {
      void testDiscoveryWebhookFromSettings();
    });

  document
    .getElementById("discoveryPathsModalClose")
    ?.addEventListener("click", () => {
      closeDiscoveryPathsModal();
    });
  document
    .getElementById("discoveryPathsDoneBtn")
    ?.addEventListener("click", () => {
      closeDiscoveryPathsModal();
    });
  const pathsOverlay = document.getElementById("discoveryPathsModal");
  if (pathsOverlay) {
    pathsOverlay.addEventListener("click", (e) => {
      if (e.target === pathsOverlay) closeDiscoveryPathsModal();
    });
  }

  document
    .getElementById("discoverySetupGuideModalClose")
    ?.addEventListener("click", () => {
      closeDiscoverySetupGuideModal();
    });
  document
    .getElementById("discoverySetupGuideDoneBtn")
    ?.addEventListener("click", () => {
      closeDiscoverySetupGuideModal();
    });
  document
    .getElementById("discoverySetupGuideLocalBtn")
    ?.addEventListener("click", () => {
      closeDiscoverySetupGuideModal();
      void requestDiscoverySetup({
        entryPoint: "guide",
        flow: "local_agent",
        startStep: "bootstrap",
        allowWhileOnboarding: true,
      });
    });
  document
    .getElementById("discoverySetupGuideRelayBtn")
    ?.addEventListener("click", () => {
      closeDiscoverySetupGuideModal();
      void requestDiscoverySetup({
        entryPoint: "guide",
        flow: "local_agent",
        startStep: "relay_deploy",
        allowWhileOnboarding: true,
      });
    });
  const guideOverlay = document.getElementById("discoverySetupGuideModal");
  if (guideOverlay) {
    guideOverlay.addEventListener("click", (e) => {
      if (e.target === guideOverlay) closeDiscoverySetupGuideModal();
    });
  }

  document
    .getElementById("discoveryLocalTunnelModalClose")
    ?.addEventListener("click", () => {
      closeDiscoveryLocalTunnelModal();
    });
  document
    .getElementById("discoveryLocalTunnelDoneBtn")
    ?.addEventListener("click", () => {
      closeDiscoveryLocalTunnelModal();
    });
  document
    .getElementById("discoveryLocalTunnelSaveBtn")
    ?.addEventListener("click", () => {
      saveDiscoveryLocalTunnelSetup(false);
    });
  document
    .getElementById("discoveryLocalTunnelRelayBtn")
    ?.addEventListener("click", () => {
      saveDiscoveryLocalTunnelSetup(true);
    });
  document
    .getElementById("discoveryLocalTunnelCopyHealthBtn")
    ?.addEventListener("click", () => {
      const text = document.getElementById("discoveryLocalWebhookHealthUrl");
      if (!text || !text.textContent) return;
      copyTextToClipboard(text.textContent);
    });
  document
    .getElementById("discoveryLocalTunnelCopyTargetBtn")
    ?.addEventListener("click", () => {
      const text = document.getElementById("discoveryLocalTunnelTargetValue");
      if (!text || !text.textContent) return;
      copyTextToClipboard(text.textContent);
    });
  document
    .querySelectorAll(
      "#discoveryLocalTunnelModal .btn-copy-scraper[data-copy-text]",
    )
    .forEach((btn) => {
      btn.addEventListener("click", () => {
        const text = btn.getAttribute("data-copy-text");
        if (text) copyTextToClipboard(text);
      });
    });
  document
    .getElementById("discoveryLocalWebhookUrl")
    ?.addEventListener("input", () => {
      renderDiscoveryLocalTunnelSetupUi();
    });
  document
    .getElementById("discoveryTunnelPublicUrl")
    ?.addEventListener("input", () => {
      renderDiscoveryLocalTunnelSetupUi();
    });
  document
    .getElementById("tunnelDetectBtn")
    ?.addEventListener("click", async () => {
      const btn = document.getElementById("tunnelDetectBtn");
      const hint = document.getElementById("tunnelDetectHint");
      const tunnelInput = document.getElementById("discoveryTunnelPublicUrl");
      if (!btn || !tunnelInput) return;

      btn.disabled = true;
      btn.textContent = "Detecting\u2026";
      try {
        const liveUrl = await probeNgrokFromLocalApi();
        if (liveUrl) {
          const oldVal = tunnelInput.value.trim().replace(/\/+$/, "");
          tunnelInput.value = liveUrl;
          renderDiscoveryLocalTunnelSetupUi();
          if (hint) {
            const changed = oldVal && oldVal !== liveUrl;
            hint.innerHTML = changed
              ? "<strong>Updated</strong> \u2014 ngrok URL was refreshed."
              : "<strong>Detected</strong> \u2014 ngrok tunnel found.";
            hint.classList.add("tunnel-detect-hint--updated");
            setTimeout(
              () => hint.classList.remove("tunnel-detect-hint--updated"),
              3000,
            );
          }
        } else {
          const port = inferLocalWebhookPort(
            document.getElementById("discoveryLocalWebhookUrl")?.value || "",
          );
          if (hint) {
            hint.innerHTML = `No tunnel found. Run <code class="modal-code">ngrok http ${port}</code> first.`;
          }
        }
      } finally {
        btn.disabled = false;
        btn.textContent = "Detect";
      }
    });
  const localTunnelOverlay = document.getElementById(
    "discoveryLocalTunnelModal",
  );
  if (localTunnelOverlay) {
    localTunnelOverlay.addEventListener("click", (e) => {
      if (e.target === localTunnelOverlay) closeDiscoveryLocalTunnelModal();
    });
  }

  document
    .getElementById("cloudflareRelaySetupModalClose")
    ?.addEventListener("click", () => {
      closeCloudflareRelaySetupModal();
    });
  document
    .getElementById("cloudflareRelaySetupDoneBtn")
    ?.addEventListener("click", () => {
      closeCloudflareRelaySetupModal();
    });
  document
    .getElementById("cloudflareRelayCopyTargetBtn")
    ?.addEventListener("click", () => {
      const text = document.getElementById("cloudflareRelayTargetValue");
      if (!text || !text.textContent) return;
      copyTextToClipboard(text.textContent);
    });
  document
    .getElementById("cloudflareRelayCopyAgentPromptBtn")
    ?.addEventListener("click", () => {
      const text = document.getElementById("cloudflareRelayAgentPrompt");
      if (!text || !text.textContent) return;
      copyTextToClipboard(text.textContent);
    });
  document
    .getElementById("cloudflareRelayCopyDeployCommandBtn")
    ?.addEventListener("click", () => {
      const text = document.getElementById("cloudflareRelayDeployCommand");
      if (!text || !text.textContent) return;
      copyTextToClipboard(text.textContent);
    });
  document
    .getElementById("cloudflareRelayCopyManualCommandsBtn")
    ?.addEventListener("click", () => {
      const text = document.getElementById("cloudflareRelayCommandBlock");
      if (!text || !text.textContent) return;
      copyTextToClipboard(text.textContent);
    });
  document
    .getElementById("cloudflareRelayCopyCorsBtn")
    ?.addEventListener("click", () => {
      const text = document.getElementById("cloudflareRelayCorsSnippet");
      if (!text || !text.textContent) return;
      copyTextToClipboard(text.textContent);
    });
  document
    .getElementById("cloudflareRelayCopyOriginBtn")
    ?.addEventListener("click", () => {
      const text = document.getElementById("cloudflareRelayOriginValue");
      if (!text || !text.textContent) return;
      copyTextToClipboard(text.textContent);
    });
  document
    .getElementById("cloudflareRelayUseBtn")
    ?.addEventListener("click", () => {
      void applyCloudflareRelayWorkerUrl(false);
    });
  document
    .getElementById("cloudflareRelayUseAndTestBtn")
    ?.addEventListener("click", () => {
      void applyCloudflareRelayWorkerUrl(true);
    });
  const relayOverlay = document.getElementById("cloudflareRelaySetupModal");
  if (relayOverlay) {
    relayOverlay.addEventListener("click", (e) => {
      if (e.target === relayOverlay) closeCloudflareRelaySetupModal();
    });
  }

  document
    .querySelectorAll(
      "#discoverySetupGuideModal .btn-copy-scraper[data-copy-text]",
    )
    .forEach((btn) => {
      btn.addEventListener("click", () => {
        const text = btn.getAttribute("data-copy-text");
        if (text) copyTextToClipboard(text);
      });
    });

  document
    .getElementById("discoveryHelpFullGuideBtn")
    ?.addEventListener("click", () => {
      const help = document.getElementById("discoveryHelpModal");
      if (help) help.style.display = "none";
      void requestDiscoverySetup({
        entryPoint: "help",
        allowWhileOnboarding: true,
      });
    });
  document
    .getElementById("discoveryHelpPathsBtn")
    ?.addEventListener("click", () => {
      const help = document.getElementById("discoveryHelpModal");
      if (help) help.style.display = "none";
      openDiscoveryPathsModal();
    });

  document.addEventListener(
    "keydown",
    (e) => {
      if (e.key !== "Escape") return;
      const relay = document.getElementById("cloudflareRelaySetupModal");
      if (relay && relay.style.display === "flex") {
        e.preventDefault();
        e.stopPropagation();
        closeCloudflareRelaySetupModal();
        return;
      }
      const guide = document.getElementById("discoverySetupGuideModal");
      if (guide && guide.style.display === "flex") {
        e.preventDefault();
        e.stopPropagation();
        closeDiscoverySetupGuideModal();
        return;
      }
      const localTunnel = document.getElementById("discoveryLocalTunnelModal");
      if (localTunnel && localTunnel.style.display === "flex") {
        e.preventDefault();
        e.stopPropagation();
        closeDiscoveryLocalTunnelModal();
        return;
      }
      const paths = document.getElementById("discoveryPathsModal");
      if (paths && paths.style.display === "flex") {
        e.preventDefault();
        e.stopPropagation();
        closeDiscoveryPathsModal();
      }
    },
    true,
  );
}

async function updateMultipleCells(updates, isRetry) {
  // updates: Array of { range, value }
  if (!accessToken) {
    showSheetAccessGate("signin");
    return false;
  }

  const url = `https://sheets.googleapis.com/v4/spreadsheets/${SHEET_ID}/values:batchUpdate`;

  try {
    const resp = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        valueInputOption: "USER_ENTERED",
        data: updates.map((u) => ({
          range: u.range,
          majorDimension: "ROWS",
          values: [[u.value]],
        })),
      }),
    });

    if (resp.status === 401) {
      if (!isRetry) {
        const refreshed = await refreshAccessTokenSilently();
        if (refreshed) return updateMultipleCells(updates, true);
      }
      clearSessionAuthState();
      renderPipeline();
      showToast("Session expired — please sign in again", "error");
      return false;
    }

    if (!resp.ok) {
      const errData = await resp.json().catch(() => ({}));
      const errMsg = errData.error?.message || `HTTP ${resp.status}`;
      showToast("Update failed: " + errMsg, "error");
      return false;
    }

    return true;
  } catch (err) {
    showToast("Update failed — check your connection", "error");
    return false;
  }
}

// ============================================
// Favorite / Dismiss + Blacklist (Layer 5)
// ============================================

// Mirror the backend's normalizeLeadUrl. Keep the two in lockstep —
// the Blacklist dedup breaks if frontend writes a differently-normalized
// URL than the backend reads.
const BLACKLIST_STRIP_PARAMS =
  /^(utm_.+|ref|source|src|gh_src|lever-source|fbclid|gclid|trk)$/i;

function normalizeLeadUrlClient(raw) {
  if (!raw) return "";
  const trimmed = String(raw).trim();
  if (!trimmed) return "";
  let u;
  try {
    u = new URL(trimmed);
  } catch {
    return trimmed;
  }
  u.hash = "";
  u.username = "";
  u.password = "";
  if (
    (u.protocol === "http:" && u.port === "80") ||
    (u.protocol === "https:" && u.port === "443")
  ) {
    u.port = "";
  }
  const keep = [];
  for (const [k, v] of u.searchParams) {
    if (!BLACKLIST_STRIP_PARAMS.test(k)) keep.push([k, v]);
  }
  // Rebuild query in original order minus stripped keys
  const params = new URLSearchParams();
  for (const [k, v] of keep) params.append(k, v);
  u.search = params.toString() ? `?${params.toString()}` : "";
  // Strip trailing slashes from pathname, but keep root "/"
  if (u.pathname && u.pathname !== "/") {
    u.pathname = u.pathname.replace(/\/+$/, "") || "/";
  }
  return u.toString();
}

async function sheetsBatchUpdate(body, isRetry) {
  const url = `https://sheets.googleapis.com/v4/spreadsheets/${SHEET_ID}:batchUpdate`;
  const resp = await fetch(url, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  });
  if (resp.status === 401 && !isRetry) {
    const ok = await refreshAccessTokenSilently();
    if (ok) return sheetsBatchUpdate(body, true);
  }
  if (!resp.ok) {
    const err = await resp.json().catch(() => ({}));
    const msg = err.error?.message || `HTTP ${resp.status}`;
    throw new Error(msg);
  }
  return resp.json();
}

async function sheetsValuesAppend(range, values, isRetry) {
  const url = `https://sheets.googleapis.com/v4/spreadsheets/${SHEET_ID}/values/${encodeURIComponent(
    range,
  )}:append?valueInputOption=RAW&insertDataOption=INSERT_ROWS`;
  const resp = await fetch(url, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ values }),
  });
  if (resp.status === 401 && !isRetry) {
    const ok = await refreshAccessTokenSilently();
    if (ok) return sheetsValuesAppend(range, values, true);
  }
  if (!resp.ok) {
    const err = await resp.json().catch(() => ({}));
    const msg = err.error?.message || `HTTP ${resp.status}`;
    const e = new Error(msg);
    e.status = resp.status;
    throw e;
  }
  return resp.json();
}

async function sheetsValuesGet(range, isRetry) {
  const url = `https://sheets.googleapis.com/v4/spreadsheets/${SHEET_ID}/values/${encodeURIComponent(
    range,
  )}`;
  const resp = await fetch(url, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  if (resp.status === 401 && !isRetry) {
    const ok = await refreshAccessTokenSilently();
    if (ok) return sheetsValuesGet(range, true);
  }
  if (!resp.ok) {
    const err = await resp.json().catch(() => ({}));
    const e = new Error(err.error?.message || `HTTP ${resp.status}`);
    e.status = resp.status;
    throw e;
  }
  return resp.json();
}

async function sheetsValuesUpdate(range, values, isRetry) {
  const url = `https://sheets.googleapis.com/v4/spreadsheets/${SHEET_ID}/values/${encodeURIComponent(
    range,
  )}?valueInputOption=RAW`;
  const resp = await fetch(url, {
    method: "PUT",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ values }),
  });
  if (resp.status === 401 && !isRetry) {
    const ok = await refreshAccessTokenSilently();
    if (ok) return sheetsValuesUpdate(range, values, true);
  }
  if (!resp.ok) {
    const err = await resp.json().catch(() => ({}));
    throw new Error(err.error?.message || `HTTP ${resp.status}`);
  }
  return resp.json();
}

async function ensureBlacklistTab() {
  // Create the Blacklist tab + header row. Called only on the
  // "Unable to parse range" failure path, so we know the tab is missing.
  await sheetsBatchUpdate({
    requests: [{ addSheet: { properties: { title: "Blacklist" } } }],
  });
  await sheetsValuesUpdate("Blacklist!A1:E1", [
    ["URL", "Dismissed At", "Title", "Company", "Reason"],
  ]);
}

async function appendBlacklistRow({ url, dismissedAt, title, company }) {
  if (!accessToken) throw new Error("Not signed in");
  const normalized = normalizeLeadUrlClient(url || "");
  const row = [
    normalized,
    dismissedAt || "",
    title || "",
    company || "",
    "",
  ];
  try {
    await sheetsValuesAppend("Blacklist!A:E", [row]);
    return;
  } catch (err) {
    const msg = String(err?.message || "");
    if (/Unable to parse range/i.test(msg)) {
      await ensureBlacklistTab();
      await sheetsValuesAppend("Blacklist!A:E", [row]);
      return;
    }
    throw err;
  }
}

async function deleteBlacklistRowByUrl(url) {
  if (!accessToken) throw new Error("Not signed in");
  const normalized = normalizeLeadUrlClient(url || "");
  if (!normalized) return false;
  let data;
  try {
    data = await sheetsValuesGet("Blacklist!A:A");
  } catch (err) {
    const msg = String(err?.message || "");
    if (/Unable to parse range/i.test(msg)) return false;
    throw err;
  }
  const values = data.values || [];
  let rowIndex = -1; // 0-based sheet row
  for (let i = 0; i < values.length; i++) {
    const cell = (values[i] && values[i][0]) || "";
    if (normalizeLeadUrlClient(cell) === normalized) {
      rowIndex = i;
      break;
    }
  }
  if (rowIndex < 1) return false; // skip header row (0) or missing
  // Look up the sheetId for "Blacklist"
  const meta = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${SHEET_ID}?fields=sheets.properties`,
    { headers: { Authorization: `Bearer ${accessToken}` } },
  ).then((r) => r.json());
  const sheet = (meta.sheets || []).find(
    (s) => s.properties && s.properties.title === "Blacklist",
  );
  if (!sheet) return false;
  await sheetsBatchUpdate({
    requests: [
      {
        deleteDimension: {
          range: {
            sheetId: sheet.properties.sheetId,
            dimension: "ROWS",
            startIndex: rowIndex,
            endIndex: rowIndex + 1,
          },
        },
      },
    ],
  });
  return true;
}

async function toggleFavorite(stableKey) {
  const job = pipelineData[stableKey];
  if (!job) return;
  if (!accessToken) {
    showSheetAccessGate("signin");
    return;
  }
  const sheetRow = getSheetRow(stableKey);
  if (!sheetRow) return;
  const next = !job.favorite;
  job.favorite = next;
  renderPipeline();
  const ok = await updateMultipleCells([
    { range: `Pipeline!V${sheetRow}`, value: next ? "★" : "" },
  ]);
  if (ok) {
    showToast(next ? "Favorited" : "Unfavorited", "success");
  } else {
    job.favorite = !next;
    renderPipeline();
    showToast("Couldn't save favorite", "error");
  }
}

async function dismissJob(stableKey) {
  const job = pipelineData[stableKey];
  if (!job) return;
  if (!accessToken) {
    showSheetAccessGate("signin");
    return;
  }
  const sheetRow = getSheetRow(stableKey);
  if (!sheetRow) return;
  const now = new Date().toISOString();
  job.dismissedAt = now;
  renderPipeline();

  let undone = false;
  const dismissToast = showToast(
    `Dismissed "${job.title || "role"}"`,
    "info",
    true,
    {
      label: "Undo",
      onClick: () => {
        undone = true;
        job.dismissedAt = null;
        renderPipeline();
      },
    },
  );

  await new Promise((r) => setTimeout(r, 10_000));
  if (typeof dismissToast === "function") dismissToast();
  if (undone) return;

  try {
    await Promise.all([
      (async () => {
        const ok = await updateMultipleCells([
          { range: `Pipeline!W${sheetRow}`, value: now },
        ]);
        if (!ok) throw new Error("Pipeline W write failed");
      })(),
      appendBlacklistRow({
        url: job.link || "",
        dismissedAt: now,
        title: job.title || "",
        company: job.company || "",
      }),
    ]);
  } catch (err) {
    console.error("[JobBored] dismiss persist failed", err);
    job.dismissedAt = null;
    renderPipeline();
    showToast("Couldn't save dismiss — reverted", "error");
  }
}

async function restoreJob(stableKey) {
  const job = pipelineData[stableKey];
  if (!job) return;
  if (!accessToken) {
    showSheetAccessGate("signin");
    return;
  }
  const sheetRow = getSheetRow(stableKey);
  if (!sheetRow) return;
  const prev = job.dismissedAt;
  job.dismissedAt = null;
  renderPipeline();
  try {
    const ok = await updateMultipleCells([
      { range: `Pipeline!W${sheetRow}`, value: "" },
    ]);
    if (!ok) throw new Error("Pipeline W clear failed");
    await deleteBlacklistRowByUrl(job.link || "");
    showToast("Restored", "success");
  } catch (err) {
    console.error("[JobBored] restore failed", err);
    job.dismissedAt = prev;
    renderPipeline();
    showToast("Couldn't restore — reverted", "error");
  }
}

// Row index: the position in pipelineData maps to raw row index
// pipelineData[i] comes from pipelineRawRows[i], which is rows[i+1] (skip header)
// So sheet row = rawRowIndex + 2 (1-indexed, +1 for header)
function getSheetRow(dataIndex) {
  // dataIndex is the index into pipelineData
  // We need to map back to the original row in the raw CSV
  const job = pipelineData[dataIndex];
  if (!job || job._rawIndex == null) return null;
  return job._rawIndex + 2; // +1 for 0-based, +1 for header row
}

function todayStr() {
  return new Date().toISOString().split("T")[0];
}

function futureDateStr(daysFromNow) {
  const d = new Date();
  d.setDate(d.getDate() + daysFromNow);
  return d.toISOString().split("T")[0];
}

// Smart status transitions — each status change may auto-update related fields
function getStatusSideEffects(newStatus, job, sheetRow) {
  const updates = [{ range: `Pipeline!M${sheetRow}`, value: newStatus }];
  const localUpdates = { status: newStatus };
  const today = todayStr();

  switch (newStatus) {
    case "Applied":
      // Set Applied Date to today if not already set
      if (!job.appliedDate) {
        updates.push({ range: `Pipeline!N${sheetRow}`, value: today });
        localUpdates.appliedDate = today;
      }
      // Set Follow-up Date to 5 business days out if not already set
      if (!job.followUpDate) {
        const followUp = futureDateStr(7);
        updates.push({ range: `Pipeline!P${sheetRow}`, value: followUp });
        localUpdates.followUpDate = followUp;
      }
      break;

    case "Phone Screen":
      // Set Applied Date if somehow skipped
      if (!job.appliedDate) {
        updates.push({ range: `Pipeline!N${sheetRow}`, value: today });
        localUpdates.appliedDate = today;
      }
      // Set Follow-up Date to 3 days out (tighter loop)
      const psFollowUp = futureDateStr(3);
      updates.push({ range: `Pipeline!P${sheetRow}`, value: psFollowUp });
      localUpdates.followUpDate = psFollowUp;
      break;

    case "Interviewing":
      // Set Applied Date if somehow skipped
      if (!job.appliedDate) {
        updates.push({ range: `Pipeline!N${sheetRow}`, value: today });
        localUpdates.appliedDate = today;
      }
      // Set Follow-up Date to 5 days out
      const intFollowUp = futureDateStr(5);
      updates.push({ range: `Pipeline!P${sheetRow}`, value: intFollowUp });
      localUpdates.followUpDate = intFollowUp;
      break;

    case "Offer":
      // Clear Follow-up Date (you got the offer)
      updates.push({ range: `Pipeline!P${sheetRow}`, value: "" });
      localUpdates.followUpDate = null;
      break;

    case "Rejected":
      // Clear Follow-up Date
      updates.push({ range: `Pipeline!P${sheetRow}`, value: "" });
      localUpdates.followUpDate = null;
      break;

    case "Passed":
      // Clear Follow-up Date
      updates.push({ range: `Pipeline!P${sheetRow}`, value: "" });
      localUpdates.followUpDate = null;
      break;

    case "New":
      // Reverting — clear Applied Date and Follow-up Date
      updates.push({ range: `Pipeline!N${sheetRow}`, value: "" });
      updates.push({ range: `Pipeline!P${sheetRow}`, value: "" });
      localUpdates.appliedDate = null;
      localUpdates.followUpDate = null;
      break;

    case "Researching":
      // No side effects
      break;
  }

  return { updates, localUpdates };
}

async function updateJobStatus(dataIndex, newStatus) {
  const sheetRow = getSheetRow(dataIndex);
  if (!sheetRow) {
    return false;
  }

  const job = pipelineData[dataIndex];
  const { updates, localUpdates } = getStatusSideEffects(
    newStatus,
    job,
    sheetRow,
  );

  const success = await updateMultipleCells(updates);

  if (success) {
    // Apply all local updates
    Object.assign(pipelineData[dataIndex], localUpdates);
    renderPipeline();
    renderStats();
    renderBrief();

    // Build a descriptive toast
    const extras = [];
    if (localUpdates.appliedDate) extras.push("applied date set");
    if (localUpdates.followUpDate)
      extras.push(`follow-up: ${localUpdates.followUpDate}`);
    if (localUpdates.followUpDate === null && newStatus !== "New")
      extras.push("follow-up cleared");
    const msg =
      extras.length > 0
        ? `${newStatus} — ${extras.join(", ")}`
        : `Updated to "${newStatus}"`;
    showToast(msg);
  }
  return success;
}

async function updateJobNotes(dataIndex, notes) {
  const sheetRow = getSheetRow(dataIndex);
  if (!sheetRow) return;

  const range = `Pipeline!O${sheetRow}`;
  const success = await updateSheetCell(range, notes);

  if (success) {
    pipelineData[dataIndex].notes = notes;
    refreshDrawerIfOpen(dataIndex);
    renderBrief();
    showToast("Notes saved");
  }
}

async function updateFollowUpDate(dataIndex, date) {
  const sheetRow = getSheetRow(dataIndex);
  if (!sheetRow) return;

  const range = `Pipeline!P${sheetRow}`;
  const success = await updateSheetCell(range, date);

  if (success) {
    pipelineData[dataIndex].followUpDate = date || null;
    refreshDrawerIfOpen(dataIndex);
    renderPipeline();
    renderBrief();
    showToast(date ? `Follow-up set: ${date}` : "Follow-up cleared");
  }
}

async function updateLastHeardFrom(dataIndex, value) {
  const sheetRow = getSheetRow(dataIndex);
  if (!sheetRow) return;

  const range = `Pipeline!R${sheetRow}`;
  const success = await updateSheetCell(range, value);

  if (success) {
    pipelineData[dataIndex].lastHeardFrom = value.trim() ? value.trim() : null;
    refreshDrawerIfOpen(dataIndex);
    renderBrief();
    showToast("Last contact saved");
  }
}

async function updateJobResponseFlag(dataIndex, value) {
  const sheetRow = getSheetRow(dataIndex);
  if (!sheetRow) return;

  const range = `Pipeline!S${sheetRow}`;
  const success = await updateSheetCell(range, value);

  if (success) {
    pipelineData[dataIndex].responseFlag = value.trim() ? value.trim() : null;
    refreshDrawerIfOpen(dataIndex);
    renderBrief();
    renderStats();
    showToast("Reply status saved");
  }
}

// ============================================
// LIGHTWEIGHT CSV PARSER
// ============================================

function parseCSV(text) {
  const rows = [];
  let current = "";
  let inQuotes = false;
  let row = [];
  let fieldStart = true;

  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    const next = text[i + 1];

    if (fieldStart && ch === '"') {
      inQuotes = true;
      fieldStart = false;
      continue;
    }

    fieldStart = false;

    if (inQuotes) {
      if (ch === '"') {
        if (next === '"') {
          current += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        current += ch;
      }
    } else {
      if (ch === ",") {
        row.push(current.trim());
        current = "";
        fieldStart = true;
      } else if (ch === "\n" || (ch === "\r" && next === "\n")) {
        row.push(current.trim());
        if (row.some((cell) => cell !== "")) {
          rows.push(row);
        }
        row = [];
        current = "";
        fieldStart = true;
        if (ch === "\r") i++;
      } else if (ch === "\r") {
        row.push(current.trim());
        if (row.some((cell) => cell !== "")) {
          rows.push(row);
        }
        row = [];
        current = "";
        fieldStart = true;
      } else {
        current += ch;
      }
    }
  }

  row.push(current.trim());
  if (row.some((cell) => cell !== "")) {
    rows.push(row);
  }

  return rows;
}

// ============================================
// DATA FETCHING — JSONP (bypasses CORS/iframe restrictions)
// ============================================

let _jsonpCounter = 0;

function fetchSheetJSONP(sheetName) {
  return new Promise((resolve, reject) => {
    const callbackName = `__commandCenter_cb_${++_jsonpCounter}`;
    const url = `https://docs.google.com/spreadsheets/d/${SHEET_ID}/gviz/tq?tqx=out:json;responseHandler:${callbackName}&sheet=${encodeURIComponent(sheetName)}`;

    console.log(`[JobBored] JSONP fetch: ${sheetName}`);

    const timeout = setTimeout(() => {
      cleanup();
      console.error(`[JobBored] JSONP timeout for ${sheetName}`);
      reject(new Error(`Timeout fetching ${sheetName}`));
    }, 15000);

    function cleanup() {
      clearTimeout(timeout);
      delete window[callbackName];
      const el = document.getElementById(`jsonp-${callbackName}`);
      if (el) el.remove();
    }

    window[callbackName] = function (response) {
      cleanup();
      if (!response || !response.table) {
        reject(new Error(`Invalid response for ${sheetName}`));
        return;
      }
      console.log(
        `[JobBored] ${sheetName} loaded via JSONP (${response.table.rows ? response.table.rows.length : 0} rows)`,
      );
      resolve(response.table);
    };

    const script = document.createElement("script");
    script.id = `jsonp-${callbackName}`;
    script.src = url;
    script.onerror = () => {
      cleanup();
      console.error(`[JobBored] JSONP script error for ${sheetName}`);
      reject(new Error(`Script load failed for ${sheetName}`));
    };
    document.head.appendChild(script);
  });
}

function getCellValue(cell) {
  if (!cell) return null;
  if (cell.v === null || cell.v === undefined) return null;
  return cell.v;
}

function getCellFormatted(cell) {
  if (!cell) return null;
  if (cell.f) return cell.f;
  return getCellValue(cell);
}

function parseGvizDate(val) {
  if (!val) return null;
  if (typeof val === "string" && val.startsWith("Date(")) {
    const parts = val.match(/Date\((\d+),(\d+),(\d+)\)/);
    if (parts)
      return new Date(
        parseInt(parts[1]),
        parseInt(parts[2]),
        parseInt(parts[3]),
      );
  }
  const d = new Date(val);
  return isNaN(d.getTime()) ? null : d;
}

/**
 * Read sheet values with OAuth (works for private sheets — no publish step).
 * Returns null on hard failure; [] if the tab exists but has no cells.
 */
async function fetchSheetViaSheetsAPI(sheetName, isRetry) {
  if (!accessToken || !SHEET_ID) return null;
  const name = String(sheetName);
  const needsQuote = /[^A-Za-z0-9_]/.test(name) || /^\d/.test(name);
  const a1 = needsQuote ? `'${name.replace(/'/g, "''")}'!A:ZZ` : `${name}!A:ZZ`;
  const encRange = encodeURIComponent(a1);
  const url = `https://sheets.googleapis.com/v4/spreadsheets/${encodeURIComponent(SHEET_ID)}/values/${encRange}`;
  const resp = await fetch(url, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  if (resp.status === 401) {
    if (!isRetry) {
      const ok = await refreshAccessTokenSilently();
      if (ok) return fetchSheetViaSheetsAPI(sheetName, true);
    }
    clearSessionAuthState();
    return null;
  }
  if (!resp.ok) {
    const err = await resp.json().catch(() => ({}));
    console.error(
      "[JobBored] Sheets API read failed:",
      resp.status,
      err.error || err,
    );
    // Record the raw Google API error for SetupDoctor to classify
    // (insufficient_scope, origin_mismatch, sheet 403/404, etc.).
    const msg =
      (err.error && err.error.message) ||
      `Sheets API ${resp.status} on ${name}`;
    recordSheetAccessError({ message: msg, status: resp.status });
    return null;
  }
  const data = await resp.json();
  return data.values != null ? data.values : [];
}

async function fetchSheetCSV(sheetName) {
  // 1) Signed in: Google Sheets API (private sheet in your Drive — no "publish to web")
  if (accessToken) {
    try {
      const apiRows = await fetchSheetViaSheetsAPI(sheetName);
      if (apiRows !== null) {
        return apiRows;
      }
    } catch (e) {
      console.warn("[JobBored] Sheets API read:", e);
    }
  }

  // 2) Public / published: JSONP (works inside iframes, no CORS issues)
  try {
    const table = await fetchSheetJSONP(sheetName);
    // Convert gviz table to CSV-like rows array for compatibility with existing parsers
    const headers = table.cols.map((c) => c.label || c.id);
    const rows = [headers];
    for (const row of table.rows || []) {
      const cells = [];
      for (let i = 0; i < headers.length; i++) {
        const cell = row.c ? row.c[i] : null;
        if (!cell || cell.v === null || cell.v === undefined) {
          cells.push("");
        } else if (typeof cell.v === "string" && cell.v.startsWith("Date(")) {
          const d = parseGvizDate(cell.v);
          cells.push(d ? d.toISOString().split("T")[0] : cell.f || "");
        } else if (cell.f) {
          cells.push(cell.f);
        } else {
          cells.push(String(cell.v));
        }
      }
      rows.push(cells);
    }
    return rows;
  } catch (err) {
    console.error(`[JobBored] JSONP failed for ${sheetName}:`, err.message);
  }

  // Fallback: try fetch CSV (works when not in iframe)
  const csvUrls = [
    `https://docs.google.com/spreadsheets/d/${SHEET_ID}/gviz/tq?tqx=out:csv&sheet=${encodeURIComponent(sheetName)}`,
    `https://docs.google.com/spreadsheets/d/${SHEET_ID}/pub?gid=0&single=true&output=csv`,
  ];

  for (const url of csvUrls) {
    try {
      const resp = await fetch(url);
      if (!resp.ok) continue;
      const text = await resp.text();
      if (!text || text.length < 10) continue;
      if (text.trim().startsWith("<!") || text.trim().startsWith("<html"))
        continue;
      console.log(`[JobBored] ${sheetName} loaded via CSV fallback`);
      return parseCSV(text);
    } catch (e) {
      continue;
    }
  }

  console.error(`[JobBored] All fetch attempts failed for ${sheetName}`);
  return null;
}

/**
 * Some discovery/LLM automations write run provenance into Pipeline column O (Notes).
 * That is not user notes — hide it in the UI; saving real notes still overwrites the cell.
 */
function isDiscoveryAutomationNotesString(text) {
  const t = String(text || "").trim();
  if (!t) return false;
  if (/^Discovered\s+via\s+variationKey\b/i.test(t)) return true;
  if (
    /^Discovered\s+via\s+/i.test(t) &&
    /\bvariationKey\b/i.test(t) &&
    /\b(direct-source|direct\s+source)\b/i.test(t)
  ) {
    return true;
  }
  if (
    /^Discovered\s+via\s+/i.test(t) &&
    /\bvariationKey\b/i.test(t) &&
    /\bYC\b/i.test(t)
  ) {
    return true;
  }
  return false;
}

function sanitizePipelineNotesFromSheet(raw) {
  const s = String(raw ?? "").trim();
  if (!s) return "";
  if (isDiscoveryAutomationNotesString(s)) return "";
  return s;
}

function parsePipelineCSV(rows) {
  if (!rows || rows.length < 2) return [];

  const dataRows = rows.slice(1);
  const results = [];

  for (let i = 0; i < dataRows.length; i++) {
    const row = dataRows[i];
    const title = row[1] || null;
    const company = row[2] || null;

    if (!title && !company) continue;
    if (!company && !row[4] && !row[7]) continue;

    const fitScoreRaw = row[7];
    let fitScore = null;
    if (fitScoreRaw) {
      const parsed = parseFloat(fitScoreRaw);
      if (!isNaN(parsed)) fitScore = parsed;
    }

    let dateFound = null;
    const dateRaw = row[0] || null;
    if (dateRaw) {
      const d = new Date(dateRaw);
      if (!isNaN(d.getTime())) dateFound = d;
    }

    results.push({
      _rawIndex: i, // Index into dataRows (0-based), sheet row = i + 2
      dateFound: dateFound,
      dateFoundRaw: dateRaw,
      title: title ? title.trim() : null,
      company: company,
      location: row[3] || null,
      link: row[4] || null,
      source: row[5] || null,
      salary: row[6] || null,
      fitScore: fitScore,
      priority: row[8] || null,
      tags: row[9] || null,
      fitAssessment: row[10] || null,
      contact: row[11] || null,
      status: row[12] || null,
      appliedDate: row[13] || null,
      notes: sanitizePipelineNotesFromSheet(row[14]) || null,
      followUpDate: row[15] || null,
      talkingPoints: row[16] || null,
      lastHeardFrom:
        row[17] != null && String(row[17]).trim() !== ""
          ? String(row[17]).trim()
          : null,
      responseFlag:
        row[18] != null && String(row[18]).trim() !== ""
          ? String(row[18]).trim()
          : null,
      logoUrl: row[19] ? String(row[19]).trim() : null,
      favorite: row[21] === "★",
      dismissedAt: row[22] ? String(row[22]).trim() || null : null,
    });
  }

  return results;
}

// ============================================
// MAIN DATA LOADER
// ============================================

async function loadAllData() {
  // Auth gate: if OAuth is configured but the user has no valid token, never
  // fetch the sheet (the public JSONP fallback would otherwise leak a
  // publicly-shared sheet's contents to a signed-out session).
  if (getOAuthClientId() && !accessToken) {
    pipelineRawRows = null;
    pipelineData = [];
    dashboardDataHydrated = false;
    showSheetAccessGate("signin");
    return false;
  }

  const refreshBtn = document.getElementById("refreshBtn");
  if (refreshBtn) refreshBtn.classList.add("loading");

  try {
    const pipelineRows = await fetchSheetCSV("Pipeline");

    if (!pipelineRows) {
      if (!initialSheetAccessResolved) {
        if (!accessToken && getOAuthClientId()) {
          showSheetAccessGate("signin");
        } else if (!getOAuthClientId()) {
          showSheetAccessGate("no-oauth");
        } else {
          showSheetAccessGate("error");
        }
      } else {
        showErrorState();
      }
      dataLoadFailed = true;
      return false;
    }

    dataLoadFailed = false;
    hideErrorState();

    pipelineRawRows = pipelineRows;
    pipelineData = parsePipelineCSV(pipelineRows);
    applyEnrichmentCache(pipelineData);
    console.log(`[JobBored] Pipeline: ${pipelineData.length} jobs`);

    dashboardDataHydrated = true;
    renderAll();
    updateLastRefresh();
    if (!initialSheetAccessResolved) {
      // OAuth is configured but the user is signed out — block the dashboard
      // entirely, even if the JSONP path would have succeeded against a
      // publicly-shared sheet. The gate is the only thing the user should see.
      if (getOAuthClientId() && !accessToken) {
        pipelineRawRows = null;
        pipelineData = [];
        dashboardDataHydrated = false;
        showSheetAccessGate("signin");
        return true;
      }
      initialSheetAccessResolved = true;
      revealDashboardShell();
      runPostAccessBootstrapOnce();
    }
    return true;
  } catch (err) {
    console.error("[JobBored] Error loading data:", err);
    if (!initialSheetAccessResolved) {
      showSheetAccessGate(
        !accessToken && getOAuthClientId() ? "signin" : "error",
      );
    } else {
      showErrorState();
    }
    dataLoadFailed = true;
    return false;
  } finally {
    if (refreshBtn) refreshBtn.classList.remove("loading");
  }
}

function showErrorState() {
  const jobCards = document.getElementById("jobCards");
  const errorState = document.getElementById("errorState");
  const errorOpenDirect = document.getElementById("errorOpenDirect");
  const errorViewSheet = document.getElementById("errorViewSheet");
  const errorHint = document.getElementById("errorStateHint");

  jobCards.innerHTML = "";
  errorState.style.display = "block";
  errorOpenDirect.href = window.location.href;
  errorViewSheet.href = `https://docs.google.com/spreadsheets/d/${SHEET_ID}`;
  if (errorHint) {
    if (getOAuthClientId()) {
      errorHint.textContent =
        "Confirm you’re signed in with Google and the Sheet ID is correct.";
    } else {
      errorHint.textContent =
        "Publish the sheet for public read access, or add an OAuth client in Settings.";
    }
  }
}

function hideErrorState() {
  document.getElementById("errorState").style.display = "none";
}

// ============================================
// RENDERING
// ============================================

function renderAll() {
  renderPipeline();
  renderBrief();
}

function renderStats() {
  // Momentum metrics are now rendered as part of renderBrief()
}

function animateNumber(id, value) {
  const el = document.getElementById(id);
  if (el.textContent === "—" || el.textContent === "0") {
    el.textContent = value;
    return;
  }
  const start = parseInt(el.textContent) || 0;
  if (start === value) return;
  const duration = 400;
  const startTime = performance.now();
  function step(now) {
    const progress = Math.min((now - startTime) / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    el.textContent = Math.round(start + (value - start) * eased);
    if (progress < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

// --- Pipeline ---
function normalizeStatusStr(status) {
  return (status || "").trim().toLowerCase();
}

/** Inbox: not yet in downstream stages (New, Researching, or blank). */
function isInboxJob(job) {
  const s = normalizeStatusStr(job.status);
  if (!s) return true;
  return s === "new" || s === "researching";
}

// ---- Pipeline Board helpers ----

function stageToCssKey(stage) {
  return stage.toLowerCase().replace(/\s+/g, "-");
}

const _LOGO_CACHE = new Map();
const _LOGO_PENDING = new Set();

function _fetchCompanyLogo(name) {
  if (_LOGO_CACHE.has(name) || _LOGO_PENDING.has(name)) return;
  _LOGO_PENDING.add(name);
  fetch(
    "https://autocomplete.clearbit.com/v1/companies/suggest?query=" +
      encodeURIComponent(name),
  )
    .then(function (r) {
      return r.ok ? r.json() : [];
    })
    .then(function (results) {
      var url = "";
      if (Array.isArray(results) && results.length) {
        var hit = results[0];
        if (hit && hit.logo) {
          url = hit.logo;
        } else if (hit && hit.domain) {
          url =
            "https://www.google.com/s2/favicons?domain=" +
            encodeURIComponent(hit.domain) +
            "&sz=128";
        }
      }
      _LOGO_CACHE.set(name, url);
      _LOGO_PENDING.delete(name);
      if (url) _upgradePlaceholders(name, url);
    })
    .catch(function () {
      _LOGO_CACHE.set(name, "");
      _LOGO_PENDING.delete(name);
    });
}

// Promise-returning version of the Clearbit/Google-favicon lookup used by
// the auto-enrich path. Resolves to a usable logo URL or empty string.
// Never rejects — worst case returns a Google-favicon fallback built from
// the company's slug, which renders as a generic "?" icon if the domain
// doesn't exist (harmless).
async function resolveCompanyLogoUrl(companyName) {
  const name = String(companyName || "").trim();
  if (!name) return "";
  // Fast path: already cached from earlier render.
  const cached = _LOGO_CACHE.get(name);
  if (cached !== undefined) return cached || "";
  // Piggyback on the existing fetcher so the in-memory cache + DOM upgrade
  // both fire as a side-effect. We still do our own fetch because we need
  // a Promise-shaped return for the auto-enrich caller.
  _fetchCompanyLogo(name);
  try {
    const resp = await fetch(
      "https://autocomplete.clearbit.com/v1/companies/suggest?query=" +
        encodeURIComponent(name),
      { method: "GET" },
    );
    if (resp.ok) {
      const results = await resp.json();
      if (Array.isArray(results) && results.length) {
        const hit = results[0];
        if (hit && hit.logo) return String(hit.logo);
        if (hit && hit.domain) {
          return (
            "https://www.google.com/s2/favicons?domain=" +
            encodeURIComponent(hit.domain) +
            "&sz=128"
          );
        }
      }
    }
  } catch (_) {
    /* network failure → fall through to slug fallback */
  }
  const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, "");
  if (!slug) return "";
  return (
    "https://www.google.com/s2/favicons?domain=" +
    encodeURIComponent(slug + ".com") +
    "&sz=128"
  );
}

// True when the existing Logo URL cell is a placeholder that was derived
// from an aggregator hostname (linkedin.com, indeed.com, etc.). Those were
// written by the worker's deriveLogoUrl when the company name was still
// the aggregator-hostname placeholder; auto-enrich should replace them.
function isPlaceholderLogoUrl(value) {
  const v = String(value || "").trim().toLowerCase();
  if (!v) return true;
  // Google-favicon URLs keyed to an aggregator or to the raw hostname slug
  // of the paste URL. Match the ?domain= query-string param directly.
  const aggrMatch = /domain=(?:[a-z0-9-.%]+\.)?(linkedin|indeed|glassdoor|ziprecruiter|monster|simplyhired|careerbuilder|wellfound|google|builtin|dice)/i;
  return aggrMatch.test(v);
}

function _upgradePlaceholders(companyName, logoUrl) {
  document
    .querySelectorAll(
      '.co-logo-wrap[data-company="' + CSS.escape(companyName) + '"]',
    )
    .forEach(function (wrap) {
      var fallback = wrap.querySelector(".co-logo--fallback");
      if (!fallback) return;
      var img = document.createElement("img");
      img.className = fallback.className
        .replace("co-logo--fallback", "")
        .trim();
      img.src = logoUrl;
      img.alt = "";
      img.loading = "lazy";
      img.referrerPolicy = "no-referrer";
      img.onerror = function () {
        img.remove();
      };
      fallback.before(img);
      fallback.remove();
    });
}

/**
 * Render a logo wrapper. Shows initials immediately. If a Clearbit result
 * is cached it renders an <img> directly; otherwise kicks off the async
 * lookup and upgrades the placeholder when it resolves.
 */
function renderLogoHtml(job, variant) {
  var companyName = (job.company || "").trim();
  var initial = (companyName || "?").charAt(0).toUpperCase();
  var sizeClass =
    variant === "drawer"
      ? "co-logo--lg"
      : variant === "kanban"
        ? "co-logo--sm"
        : "co-logo--md";
  var cachedUrl =
    safeHref(job.logoUrl) || safeHref(_LOGO_CACHE.get(companyName)) || "";
  var inner;

  if (cachedUrl) {
    inner =
      '<img class="co-logo ' +
      sizeClass +
      '" src="' +
      escapeHtml(cachedUrl) +
      '" alt="" loading="lazy" referrerpolicy="no-referrer">';
  } else {
    inner =
      '<span class="co-logo co-logo--fallback ' +
      sizeClass +
      '" aria-hidden="true">' +
      escapeHtml(initial) +
      "</span>";
    if (companyName) _fetchCompanyLogo(companyName);
  }

  return (
    '<span class="co-logo-wrap" data-company="' +
    escapeHtml(companyName) +
    '">' +
    inner +
    "</span>"
  );
}

/**
 * Location + salary — shared strip (list card, board card, drawer header).
 * @param {"card"|"kanban"|"drawer"} variant
 */
function renderRoleFactsHtml(job, variant = "card") {
  const rawSalary = String(job.salary ?? "").trim();
  const salaryStr =
    rawSalary.includes("<") ||
    rawSalary.includes("&lt;") ||
    rawSalary.includes("&gt;") ||
    rawSalary.length > 120
      ? ""
      : rawSalary;
  const showSalary = salaryStr && salaryStr.toLowerCase() !== "not listed";
  const loc = job.location ? String(job.location).trim() : "";
  if (!loc && !showSalary) return "";
  const mod =
    variant === "drawer"
      ? "role-facts--drawer"
      : variant === "kanban"
        ? "role-facts--kanban"
        : "role-facts--card";
  const parts = [];
  if (loc) {
    parts.push(
      `<div class="role-fact"><span class="role-fact__label">Location</span><span class="role-fact__value">${escapeHtml(loc)}</span></div>`,
    );
  }
  if (showSalary) {
    parts.push(
      `<div class="role-fact"><span class="role-fact__label">Salary</span><span class="role-fact__value role-fact__value--salary">${escapeHtml(salaryStr)}</span></div>`,
    );
  }
  return `<div class="role-facts ${mod}" role="group" aria-label="Location and compensation">${parts.join("")}</div>`;
}

function groupByStage(data) {
  const byStage = new Map(STAGE_ORDER.map((s) => [s, []]));
  for (const job of data) {
    const raw = (job.status || "").trim();
    const key =
      STAGE_ORDER.find((s) => s.toLowerCase() === raw.toLowerCase()) || "New";
    byStage.get(key).push(job);
  }
  return byStage;
}

function renderKanbanCard(job, index) {
  const dataIndex = pipelineData.indexOf(job);
  const stableKey = dataIndex >= 0 ? dataIndex : index;
  const title = job.title || "Untitled Role";
  const company = job.company || "Unknown Company";
  const roleFactsHtml = renderRoleFactsHtml(job, "kanban");
  const isViewed = viewedJobKeys.has(stableKey);

  // First 3 tags from the sheet Tags column
  const tagChips = job.tags
    ? job.tags
        .split(",")
        .map((t) => t.trim())
        .filter(Boolean)
        .slice(0, 3)
        .map((t) => `<span class="kanban-card__tag">${escapeHtml(t)}</span>`)
        .join("")
    : "";

  const stageClass = `kanban-card--stage-${stageToCssKey((job.status || "new").trim() || "new")}`;
  const isFavorite = !!job.favorite;
  const isDismissed = !!job.dismissedAt;
  const cardModClasses = [
    stageClass,
    isViewed ? "kanban-card--viewed" : "",
    isFavorite ? "kanban-card--favorited" : "",
    isDismissed ? "kanban-card--dismissed" : "",
  ]
    .filter(Boolean)
    .join(" ");
  const favBtnHtml = `<button type="button" class="card-action-btn card-action-btn--fav${isFavorite ? " is-active" : ""}" data-action="toggle-favorite" data-key="${stableKey}" aria-label="${isFavorite ? "Unfavorite" : "Favorite"}" aria-pressed="${isFavorite}" title="${isFavorite ? "Unfavorite" : "Favorite"}">
    <svg width="16" height="16" viewBox="0 0 24 24" fill="${isFavorite ? "currentColor" : "none"}" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
  </button>`;
  const dismissBtnHtml = isDismissed
    ? `<button type="button" class="card-action-btn card-action-btn--restore" data-action="restore" data-key="${stableKey}" aria-label="Restore" title="Restore">
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="3 7 3 12 8 12"/><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/></svg>
  </button>`
    : `<button type="button" class="card-action-btn card-action-btn--dismiss" data-action="dismiss" data-key="${stableKey}" aria-label="Dismiss" title="Dismiss">
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
  </button>`;

  return `
    <article class="kanban-card ${cardModClasses}" role="button" tabindex="0" data-action="open-detail" data-stable-key="${stableKey}" ${dataIndex >= 0 ? `data-index="${dataIndex}"` : ""} style="animation-delay:${index * 30}ms">
      ${isViewed ? `<span class="kanban-card__viewed-dot" aria-label="Previously viewed" title="Previously viewed"></span>` : ""}
      <div class="kanban-card__actions" aria-label="Card actions">
        ${favBtnHtml}
        ${dismissBtnHtml}
      </div>
      <div class="kanban-card__identity">
        ${renderLogoHtml(job, "kanban")}
        <div class="kanban-card__identity-text">
          <span class="kanban-card__title">${escapeHtml(title)}</span>
          <span class="kanban-card__company">${escapeHtml(company)}</span>
        </div>
      </div>
      ${roleFactsHtml}
      ${tagChips ? `<div class="kanban-card__tags">${tagChips}</div>` : ""}
    </article>`;
}

function renderStageLane(stage, jobs) {
  const isExpanded = expandedStages.has(stage);
  const isArchive = STAGE_ARCHIVE.has(stage);
  const cssKey = stageToCssKey(stage);

  return `
    <section class="stage-lane${isArchive ? " stage-lane--archive" : ""}${isExpanded ? " stage-lane--expanded" : ""}" data-stage="${escapeHtml(stage)}">
      <button type="button" class="stage-lane__header" data-action="toggle-stage" data-stage="${escapeHtml(stage)}">
        <span class="stage-dot stage-dot--${cssKey}" aria-hidden="true"></span>
        <span class="stage-lane__name">${escapeHtml(stage)}</span>
        <span class="stage-lane__count">${jobs.length}</span>
        <svg class="stage-lane__chevron" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>
      </button>
      <div class="stage-lane__body">
        <div class="stage-lane__scroll-area">
          <button type="button" class="stage-lane__nav stage-lane__nav--prev" data-action="scroll-stage" data-dir="prev" data-stage="${escapeHtml(stage)}" aria-label="Scroll left" disabled>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="15 18 9 12 15 6"/></svg>
          </button>
          <div class="stage-lane__track" id="track-${cssKey}">
            ${jobs.map((job, i) => renderKanbanCard(job, i)).join("")}
          </div>
          <button type="button" class="stage-lane__nav stage-lane__nav--next" data-action="scroll-stage" data-dir="next" data-stage="${escapeHtml(stage)}" aria-label="Scroll right">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 18 15 12 9 6"/></svg>
          </button>
        </div>
        <div class="stage-lane__indicator">
          <div class="stage-indicator-thumb" id="thumb-${cssKey}"></div>
        </div>
      </div>
    </section>`;
}

function renderPipelineBoard(data) {
  const byStage = groupByStage(data);
  const lanes = STAGE_ORDER.filter((stage) => byStage.get(stage).length > 0)
    .map((stage) => renderStageLane(stage, byStage.get(stage)))
    .join("");
  return lanes ? `<div class="pipeline-board">${lanes}</div>` : "";
}

// ---- Detail drawer ----

function handleDetailEscape(e) {
  if (e.key === "Escape") closeJobDetail();
}

function renderStageStepper(job, dataIndex) {
  const stages = [
    "New",
    "Researching",
    "Applied",
    "Phone Screen",
    "Interviewing",
    "Offer",
    "Rejected",
    "Passed",
  ];
  const normalized = (job.status || "").trim().toLowerCase();
  const curIdx = stages.findIndex((s) => s.toLowerCase() === normalized);
  const activeIdx = curIdx >= 0 ? curIdx : 0;
  const isTerminal = activeIdx >= 6; // Rejected or Passed

  return `<div class="stage-stepper-wrap">
    <button type="button" class="stage-stepper__chevron stage-stepper__chevron--left" data-action="scroll-stage" data-dir="-1" aria-label="Scroll left">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
    </button>
    <div class="stage-stepper" role="group" aria-label="Pipeline stage">${stages
      .map((s, i) => {
        let cls = "stage-step";
        if (i === activeIdx) cls += " stage-step--active";
        else if (!isTerminal && i < activeIdx) cls += " stage-step--done";
        else if (isTerminal && i < 6 && i < activeIdx)
          cls += " stage-step--done";
        if (i >= 6) cls += " stage-step--terminal";
        const connector =
          i > 0
            ? `<span class="stage-step__line${i <= activeIdx && !isTerminal ? " stage-step__line--done" : ""}"></span>`
            : "";
        return `${connector}<button type="button" class="${cls}" data-action="stage-step" data-stage="${escapeHtml(s)}" data-index="${dataIndex}" title="Move to ${escapeHtml(s)}"><span class="stage-step__dot"></span><span class="stage-step__label">${escapeHtml(s)}</span></button>`;
      })
      .join("")}</div>
    <button type="button" class="stage-stepper__chevron stage-stepper__chevron--right" data-action="scroll-stage" data-dir="1" aria-label="Scroll right">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
    </button>
  </div>`;
}

function renderDrawerContent(job, stableKey) {
  const dataIndex = pipelineData.indexOf(job);
  const enr = job._postingEnrichment;
  const draftLibraryHtml =
    dataIndex >= 0 ? renderDraftLibraryCardHtml(job, dataIndex) : "";

  // ── Stage stepper ──
  const stepperHtml = isSignedIn() ? renderStageStepper(job, dataIndex) : "";

  // ── Notes (prominent, left column) ──
  const notesHtml = isSignedIn()
    ? `<div class="drawer-notes">
    <label class="drawer-section__label" for="drawer-notes-${stableKey}">Notes</label>
    <textarea id="drawer-notes-${stableKey}" class="drawer-notes__input" data-action="notes" data-index="${dataIndex}" placeholder="Interview prep, recruiter name, next steps&#8230;">${escapeHtml(job.notes || "")}</textarea>
  </div>`
    : "";

  // ── AI / role content (reused from card logic) ──
  const sheetTags = job.tags
    ? job.tags
        .split(",")
        .map((t) => t.trim())
        .filter(Boolean)
    : [];
  const tags = (() => {
    const m = new Map();
    const add = (raw) => {
      const t = String(raw || "").trim();
      if (t) {
        const k = t.toLowerCase();
        if (!m.has(k)) m.set(k, t);
      }
    };
    sheetTags.forEach(add);
    if (enr && Array.isArray(enr.skills)) enr.skills.forEach(add);
    if (enr && Array.isArray(enr.extraKeywords)) enr.extraKeywords.forEach(add);
    return [...m.values()];
  })();

  const hookText = (() => {
    const oneLine = enr && String(enr.roleInOneLine || "").trim();
    if (oneLine) return oneLine;
    const fitAngle = enr && String(enr.fitAngle || "").trim();
    if (fitAngle)
      return fitAngle.length > 120
        ? `${fitAngle.slice(0, 117).trim()}…`
        : fitAngle;
    const fitAssess = String(job.fitAssessment || "").trim();
    if (fitAssess)
      return fitAssess.length > 120
        ? `${fitAssess.slice(0, 117).trim()}…`
        : fitAssess;
    return "";
  })();
  const hookHtml = hookText
    ? `<p class="drawer-hook">${escapeHtml(hookText)}</p>`
    : "";

  const ctxHtml = job.dateFoundRaw
    ? `<p class="drawer-context drawer-context--date">${escapeHtml(job.dateFoundRaw)}</p>`
    : "";

  // AI Summary
  const aiText = String(enr?.postingSummary || "").trim();
  const aiHtml = aiText
    ? `<div class="drawer-ai-section"><span class="drawer-section__label">AI Summary</span><p class="drawer-ai-text">${escapeHtml(aiText)}</p></div>`
    : "";

  // Fit — always show full text, no truncation
  const fitAngle = enr && String(enr.fitAngle || "").trim();
  const fitAssessment = String(job.fitAssessment || "").trim();
  const fitText = fitAngle || fitAssessment;
  const fitHtml = fitText
    ? `<div class="drawer-ai-section"><span class="drawer-section__label">Fit</span><p class="drawer-ai-text">${escapeHtml(fitText)}</p></div>`
    : "";
  const profileMatchBadgeHtml = renderProfileMatchBadgeHtml(job, dataIndex);

  // Tags
  const SKILL_MAX = 14;
  const vis = tags.slice(0, SKILL_MAX);
  const extraN = tags.length - vis.length;
  const extraChips =
    extraN > 0
      ? tags
          .slice(SKILL_MAX)
          .map((t) => `<span class="skill-chip">${escapeHtml(t)}</span>`)
          .join("")
      : "";
  const tagsHtml =
    tags.length > 0
      ? `<div class="drawer-ai-section"><span class="drawer-section__label">Tags &amp; skills</span><div class="card-tags card-skills-tags" data-tags-wrap="${stableKey}">${vis.map((t) => `<span class="skill-chip">${escapeHtml(t)}</span>`).join("")}${extraN > 0 ? `<span class="card-tags-extra">${extraChips}</span><button type="button" class="tag-more-btn" data-action="toggle-tags" data-tags-key="${stableKey}" aria-expanded="false">+${extraN} more</button>` : ""}</div></div>`
      : "";

  // Must-haves
  const mustArr =
    enr && Array.isArray(enr.mustHaves)
      ? enr.mustHaves.map((x) => String(x).trim()).filter(Boolean)
      : [];
  const mustHtml = mustArr.length
    ? `<div class="drawer-ai-section"><span class="drawer-section__label">Must-haves</span><ul class="card-peek__list">${mustArr
        .slice(0, 8)
        .map(
          (r) =>
            `<li>${escapeHtml(r.length > 200 ? r.slice(0, 200) + "…" : r)}</li>`,
        )
        .join("")}</ul></div>`
    : "";

  // Source
  const srcHtml = job.source
    ? `<p class="card-peek__source">via ${escapeHtml(job.source)}</p>`
    : "";

  // Talking points
  const tpFromEnr =
    enr && Array.isArray(enr.talkingPoints) && enr.talkingPoints.length > 0
      ? enr.talkingPoints.map((p) => String(p).trim()).filter(Boolean)
      : null;
  const tpFromSheet = job.talkingPoints
    ? job.talkingPoints
        .split("\n")
        .map((l) => l.replace(/^[•\-\*]\s*/, "").trim())
        .filter(Boolean)
    : [];
  const tpLabel =
    tpFromEnr && tpFromEnr.length
      ? "Talking points (from posting + AI)"
      : "Talking points";
  const tpList = tpFromEnr && tpFromEnr.length ? tpFromEnr : tpFromSheet;
  const tpHtml =
    tpList.length > 0
      ? `<div class="drawer-ai-section"><span class="drawer-section__label"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg> ${escapeHtml(tpLabel)}</span><ul class="talking-points-list">${tpList.map((p) => `<li>${escapeHtml(p)}</li>`).join("")}</ul></div>`
      : "";

  // Structured lists
  const hasAiStructure =
    enr &&
    (String(enr.postingSummary || "").trim().length > 0 ||
      (Array.isArray(enr.mustHaves) && enr.mustHaves.length > 0));
  const listSec = (label, items, cls) => {
    const arr = Array.isArray(items)
      ? items.map((x) => String(x).trim()).filter(Boolean)
      : [];
    if (!arr.length) return "";
    return `<div class="posting-struct ${cls || ""}"><span class="posting-snippet-label">${escapeHtml(label)}</span><ul class="posting-req-list">${arr
      .slice(0, 12)
      .map(
        (r) =>
          `<li>${escapeHtml(r.length > 500 ? r.slice(0, 500) + "…" : r)}</li>`,
      )
      .join("")}</ul></div>`;
  };
  const structHtml =
    enr && hasAiStructure
      ? [
          listSec(
            "Responsibilities",
            enr.responsibilities,
            "posting-struct--resp",
          ),
          listSec("Nice-to-haves", enr.niceToHaves, "posting-struct--nice"),
          listSec("Tools & stack", enr.toolsAndStack, "posting-struct--tools"),
        ].join("")
      : "";

  // Enrichment loading skeleton (shown while auto-fetch is in flight)
  // _d() injects staggered animation-delay so bones shimmer in a cascade
  const _d = (ms) => `style="animation-delay:${ms}ms"`;
  const enrichmentSkeleton = `<div class="drawer-enrichment-skeleton" aria-busy="true" aria-label="Loading AI insights">

    <div class="enr-skel-card">
      <div class="enr-skel-card__head">
        <div class="enr-skel-bone enr-skel-card__arrow" ${_d(0)}></div>
        <div class="enr-skel-bone enr-skel-card__title" ${_d(40)}></div>
      </div>
      <div class="enr-skel-card__body">

        <div class="enr-skel-section">
          <div class="enr-skel-bone enr-skel-line enr-skel-line--w92" ${_d(80)}></div>
          <div class="enr-skel-bone enr-skel-line enr-skel-line--w65" ${_d(120)}></div>
        </div>

        <div class="enr-skel-section">
          <div class="enr-skel-bone enr-skel-section__label" ${_d(160)}></div>
          <div class="enr-skel-bone enr-skel-line enr-skel-line--w100" ${_d(200)}></div>
          <div class="enr-skel-bone enr-skel-line enr-skel-line--w92"  ${_d(240)}></div>
          <div class="enr-skel-bone enr-skel-line enr-skel-line--w83"  ${_d(280)}></div>
          <div class="enr-skel-bone enr-skel-line enr-skel-line--w56"  ${_d(320)}></div>
        </div>

        <div class="enr-skel-section">
          <div class="enr-skel-bone enr-skel-section__label" ${_d(360)}></div>
          <div class="enr-skel-bone enr-skel-line enr-skel-line--w83" ${_d(400)}></div>
          <div class="enr-skel-bone enr-skel-line enr-skel-line--w65" ${_d(440)}></div>
        </div>

        <div class="enr-skel-section">
          <div class="enr-skel-bone enr-skel-section__label" ${_d(480)}></div>
          <div class="enr-skel-chips">
            <div class="enr-skel-bone enr-skel-chip enr-skel-chip--sm" ${_d(520)}></div>
            <div class="enr-skel-bone enr-skel-chip enr-skel-chip--md" ${_d(550)}></div>
            <div class="enr-skel-bone enr-skel-chip enr-skel-chip--xs" ${_d(580)}></div>
            <div class="enr-skel-bone enr-skel-chip enr-skel-chip--lg" ${_d(610)}></div>
            <div class="enr-skel-bone enr-skel-chip enr-skel-chip--sm" ${_d(640)}></div>
            <div class="enr-skel-bone enr-skel-chip enr-skel-chip--xs" ${_d(670)}></div>
          </div>
        </div>

        <div class="enr-skel-section">
          <div class="enr-skel-bone enr-skel-section__label" ${_d(700)}></div>
          <div class="enr-skel-bone enr-skel-line enr-skel-line--w92" ${_d(730)}></div>
          <div class="enr-skel-bone enr-skel-line enr-skel-line--w74" ${_d(760)}></div>
          <div class="enr-skel-bone enr-skel-line enr-skel-line--w83" ${_d(790)}></div>
        </div>

      </div>
    </div>

    <div class="enr-skel-tp">
      <div class="enr-skel-bone enr-skel-tp__label" ${_d(820)}></div>
      <div class="enr-skel-tp__item">
        <div class="enr-skel-bone enr-skel-tp__bullet" ${_d(850)}></div>
        <div class="enr-skel-bone enr-skel-tp__text enr-skel-line--w83" ${_d(850)}></div>
      </div>
      <div class="enr-skel-tp__item">
        <div class="enr-skel-bone enr-skel-tp__bullet" ${_d(880)}></div>
        <div class="enr-skel-bone enr-skel-tp__text enr-skel-line--w92" ${_d(880)}></div>
      </div>
      <div class="enr-skel-tp__item">
        <div class="enr-skel-bone enr-skel-tp__bullet" ${_d(910)}></div>
        <div class="enr-skel-bone enr-skel-tp__text enr-skel-line--w65" ${_d(910)}></div>
      </div>
      <div class="enr-skel-tp__item">
        <div class="enr-skel-bone enr-skel-tp__bullet" ${_d(940)}></div>
        <div class="enr-skel-bone enr-skel-tp__text enr-skel-line--w74" ${_d(940)}></div>
      </div>
    </div>

  </div>`;

  const llmWarn =
    enr && enr.llmError
      ? `<p class="posting-llm-warn">${escapeHtml(enr.llmError)}</p>`
      : "";

  // ── Right column: compact property panel ──
  const normalized = (job.status || "").trim().toLowerCase();

  const followUpVal = job.followUpDate || "";
  const followUpIsOverdue = followUpVal && new Date(followUpVal) < new Date();

  const respSel = selectedResponseSheetValue(job);

  const stageOptions = STAGE_ORDER.map((s) => {
    const sel = s.toLowerCase() === normalized || (!normalized && s === "New");
    return `<option value="${escapeHtml(s)}"${sel ? " selected" : ""}>${escapeHtml(s)}</option>`;
  }).join("");

  const propsHtml = isSignedIn()
    ? `<div class="drawer-props">
    <div class="drawer-prop">
      <svg class="drawer-prop__icon" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/></svg>
      <span class="drawer-prop__key">Stage</span>
      <select class="drawer-prop__val status-select" data-action="status-select" data-index="${dataIndex}">${stageOptions}</select>
    </div>
    <div class="drawer-prop">
      <svg class="drawer-prop__icon" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
      <span class="drawer-prop__key">Follow-up</span>
      <input type="date" class="drawer-prop__val followup-input" data-action="followup" data-index="${dataIndex}" value="${escapeHtml(followUpVal)}" />
      ${followUpIsOverdue ? '<span class="overdue-badge">overdue</span>' : ""}
    </div>
    <div class="drawer-prop">
      <svg class="drawer-prop__icon" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
      <span class="drawer-prop__key">Last contact</span>
      <input type="text" class="drawer-prop__val last-heard-input" data-action="last-heard" data-index="${dataIndex}" value="${escapeHtml(job.lastHeardFrom || "")}" placeholder="e.g. Jan 12" autocomplete="off" />
    </div>
    <div class="drawer-prop">
      <svg class="drawer-prop__icon" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
      <span class="drawer-prop__key">Reply</span>
      <select class="drawer-prop__val response-select" data-action="response-flag" data-index="${dataIndex}">
        <option value="">Not set</option>
        <option value="Yes"${respSel === "Yes" ? " selected" : ""}>Yes</option>
        <option value="No"${respSel === "No" ? " selected" : ""}>No</option>
        <option value="Unknown"${respSel === "Unknown" ? " selected" : ""}>Not sure</option>
      </select>
    </div>
    ${job.appliedDate ? `<div class="drawer-prop"><svg class="drawer-prop__icon" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 2L11 13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg><span class="drawer-prop__key">Applied</span><span class="drawer-prop__val drawer-prop__val--static">${escapeHtml(job.appliedDate)}</span></div>` : ""}
  </div>`
    : "";

  // Assemble
  const aboutHasContent = aiHtml || fitHtml || tagsHtml || mustHtml || srcHtml;
  const aboutSection = aboutHasContent
    ? `<details class="drawer-about" open><summary class="drawer-about__toggle">About this role</summary><div class="drawer-about__body">${hookHtml}${ctxHtml}${aiHtml}${fitHtml}${tagsHtml}${mustHtml}${srcHtml}</div></details>`
    : `${hookHtml}${ctxHtml}`;

  // While enrichment is in-flight and no cached data exists yet, show only the
  // skeleton — suppress talking points and structured sections so nothing
  // appears before LLM data is ready.
  const mainColContent =
    job._enrichmentLoading && !enr
      ? enrichmentSkeleton
      : `${aboutSection}${tpHtml}${structHtml}${llmWarn}`;

  return `<div class="drawer-content">
    ${stepperHtml}
    ${profileMatchBadgeHtml}
    <div class="drawer-columns">
      <div class="drawer-col drawer-col--main">
        ${mainColContent}
      </div>
      <div class="drawer-col drawer-col--props">
        ${propsHtml}
        <div class="drawer-inputs">
          ${notesHtml}
        </div>
        ${draftLibraryHtml}
      </div>
    </div>
  </div>`;
}

function openJobDetail(stableKey) {
  closeJobDetail();
  const job = pipelineData[stableKey];
  if (!job) return;
  activeDetailKey = stableKey;
  markJobViewed(stableKey);

  const overlay = document.createElement("div");
  overlay.className = "detail-overlay";
  overlay.id = "detailOverlay";
  const drawerActionsHtml = (() => {
    const coverBtn =
      stableKey >= 0
        ? `<button type="button" class="drawer-btn drawer-btn--cover" data-action="resume-cover" data-index="${stableKey}">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
          Cover letter
        </button>`
        : "";
    const tailorBtn =
      stableKey >= 0
        ? `<button type="button" class="drawer-btn drawer-btn--tailor" data-action="resume-tailor" data-index="${stableKey}">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
          Tailor resume
        </button>`
        : "";
    const viewBtn = safeHref(job.link)
      ? `<a href="${escapeHtml(safeHref(job.link))}" target="_blank" rel="noopener" class="drawer-btn drawer-btn--view">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
          View posting
        </a>`
      : "";
    if (!viewBtn && !coverBtn && !tailorBtn) return "";
    return `<div class="detail-drawer__actions">${coverBtn}${tailorBtn}${viewBtn}</div>`;
  })();

  overlay.innerHTML = `
    <button class="detail-overlay__backdrop" data-action="close-detail" aria-label="Close detail panel"></button>
    <aside class="detail-drawer" role="complementary" aria-label="${escapeHtml(job.title || "Job detail")}">
      <div class="detail-drawer__head">
        ${renderLogoHtml(job, "drawer")}
        <div class="detail-drawer__head-main">
          <h2 class="detail-drawer__head-title">${escapeHtml(job.title || "Job detail")}</h2>
          ${
            job.company
              ? `<p class="detail-drawer__head-company">${escapeHtml(job.company)}</p>`
              : ""
          }
          ${renderRoleFactsHtml(job, "drawer")}
        </div>
        <button type="button" class="detail-drawer__close" data-action="close-detail" aria-label="Close">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
      </div>
      ${drawerActionsHtml}
      <div class="detail-drawer__body">
        ${renderDrawerContent(job, stableKey)}
      </div>
    </aside>`;

  document.body.appendChild(overlay);
  document.body.classList.add("detail-open");

  attachCardListeners();

  overlay.querySelectorAll('[data-action="close-detail"]').forEach((el) => {
    el.addEventListener("click", closeJobDetail);
  });
  document.addEventListener("keydown", handleDetailEscape);

  // Auto-fetch enrichment only when the scraper is configured and the job hasn't been scraped yet.
  // Guard against getJobPostingScrapeUrl() returning null to avoid a noisy toast on every open.
  if (
    job.link &&
    !job._postingEnrichment?.scrapedAt &&
    getJobPostingScrapeUrl()
  ) {
    fetchJobPostingEnrichment(stableKey).catch(() => {});
  }
}

function closeJobDetail() {
  const overlay = document.getElementById("detailOverlay");
  if (overlay) overlay.remove();
  document.removeEventListener("keydown", handleDetailEscape);
  document.body.classList.remove("detail-open");
  activeDetailKey = -1;
}

function refreshDrawerIfOpen(dataIndex) {
  const overlay = document.getElementById("detailOverlay");
  if (!overlay || activeDetailKey !== dataIndex) return;
  const job = pipelineData[dataIndex];
  if (!job) return;
  const body = overlay.querySelector(".detail-drawer__body");
  if (!body) return;

  // Capture scroll position so re-render doesn't jump
  const drawer = overlay.querySelector(".detail-drawer");
  const scrollTop = drawer ? drawer.scrollTop : 0;

  body.innerHTML = renderDrawerContent(job, dataIndex);

  attachCardListeners();

  // Re-wire close buttons that are inside the body (backdrop/head close are already wired)
  overlay.querySelectorAll('[data-action="close-detail"]').forEach((el) => {
    el.addEventListener("click", closeJobDetail);
  });

  if (drawer) drawer.scrollTop = scrollTop;
}

function updateTrackIndicator(track) {
  const cssKey = track.id.replace("track-", "");
  const thumb = document.getElementById(`thumb-${cssKey}`);
  const bar = thumb ? thumb.parentElement : null;
  if (!thumb || !bar) return;
  const { scrollLeft, scrollWidth, clientWidth } = track;
  if (scrollWidth <= clientWidth + 2) {
    bar.style.visibility = "hidden";
    return;
  }
  bar.style.visibility = "";
  const ratio = clientWidth / scrollWidth;
  const pos = scrollLeft / (scrollWidth - clientWidth);
  thumb.style.width = `${ratio * 100}%`;
  thumb.style.left = `${pos * (100 - ratio * 100)}%`;
}

function updateNavVisibility(track) {
  const lane = track.closest(".stage-lane");
  if (!lane) return;
  const { scrollLeft, scrollWidth, clientWidth } = track;
  const noScroll = scrollWidth <= clientWidth + 2;
  const atStart = scrollLeft < 2;
  const atEnd = scrollLeft + clientWidth >= scrollWidth - 2;
  const prev = lane.querySelector(
    '[data-action="scroll-stage"][data-dir="prev"]',
  );
  const next = lane.querySelector(
    '[data-action="scroll-stage"][data-dir="next"]',
  );
  if (prev) prev.disabled = atStart || noScroll;
  if (next) next.disabled = atEnd || noScroll;
}

function attachBoardListeners() {
  // Stage collapse toggle + indicator init on expand
  document.querySelectorAll('[data-action="toggle-stage"]').forEach((btn) => {
    btn.addEventListener("click", () => {
      const stage = btn.dataset.stage;
      const lane = btn.closest(".stage-lane");
      if (!lane) return;
      const nowExpanded = lane.classList.toggle("stage-lane--expanded");
      if (nowExpanded) {
        expandedStages.add(stage);
        const track = document.getElementById(`track-${stageToCssKey(stage)}`);
        if (track) {
          updateTrackIndicator(track);
          updateNavVisibility(track);
        }
      } else {
        expandedStages.delete(stage);
      }
    });
  });

  // Horizontal chevron navigation
  document.querySelectorAll('[data-action="scroll-stage"]').forEach((btn) => {
    btn.addEventListener("click", () => {
      // Board scroll buttons (inside a stage-lane with data-stage)
      if (btn.dataset.stage) {
        const track = document.getElementById(
          `track-${stageToCssKey(btn.dataset.stage)}`,
        );
        if (!track) return;
        const card = track.querySelector(".kanban-card");
        const step = card ? card.offsetWidth + 12 : 228;
        track.scrollBy({
          left: btn.dataset.dir === "next" ? step : -step,
          behavior: "smooth",
        });
        return;
      }
      // Drawer stepper chevrons (inside stage-stepper-wrap)
      const stepper = btn.closest(".stage-stepper-wrap");
      if (stepper) {
        const inner = stepper.querySelector(".stage-stepper");
        if (inner)
          inner.scrollBy({
            left: parseInt(btn.dataset.dir, 10) * 80,
            behavior: "smooth",
          });
      }
    });
  });

  // Scroll indicator + nav state on scroll
  document.querySelectorAll(".stage-lane__track").forEach((track) => {
    updateTrackIndicator(track);
    updateNavVisibility(track);
    track.addEventListener(
      "scroll",
      () => {
        updateTrackIndicator(track);
        updateNavVisibility(track);
      },
      { passive: true },
    );
  });

  // Detail drawer — click or keyboard Enter/Space on the card
  document.querySelectorAll('[data-action="open-detail"]').forEach((el) => {
    el.addEventListener("click", () => {
      const key = parseInt(el.dataset.stableKey, 10);
      if (!Number.isNaN(key)) openJobDetail(key);
    });
    el.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        const key = parseInt(el.dataset.stableKey, 10);
        if (!Number.isNaN(key)) openJobDetail(key);
      }
    });
  });

  // Card action buttons (favorite / dismiss / restore) — stop propagation
  // so clicks don't bubble into the card's open-detail handler.
  document
    .querySelectorAll('[data-action="toggle-favorite"]')
    .forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        const key = parseInt(btn.dataset.key, 10);
        if (!Number.isNaN(key)) toggleFavorite(key);
      });
    });
  document.querySelectorAll('[data-action="dismiss"]').forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const key = parseInt(btn.dataset.key, 10);
      if (!Number.isNaN(key)) dismissJob(key);
    });
  });
  document.querySelectorAll('[data-action="restore"]').forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const key = parseInt(btn.dataset.key, 10);
      if (!Number.isNaN(key)) restoreJob(key);
    });
  });
}

// ---- Board filtering & sort (pure functions) ----

/**
 * Filter jobs by search term and sort by the specified mode.
 * Returns a new array; does not mutate the input.
 *
 * @param {Array} jobs - Array of pipeline job objects
 * @param {string} search - Search query (empty string means no filtering)
 * @param {string} sort - Sort mode: "fit" | "date" | "company" | "priority"
 * @returns {Array} - New filtered and sorted array
 */
function filterAndSortJobs(jobs, search, sort) {
  let data = [...jobs];

  if (!showDismissed) data = data.filter((j) => !j.dismissedAt);
  if (favoritesOnly) data = data.filter((j) => j.favorite);

  if (search) {
    const q = search.toLowerCase();
    data = data.filter((r) => {
      return [
        r.title,
        r.company,
        r.tags,
        r.location,
        r.source,
        r.notes,
        r.lastHeardFrom,
        r.responseFlag,
      ]
        .filter(Boolean)
        .join(" ")
        .toLowerCase()
        .includes(q);
    });
  }

  switch (sort) {
    case "fit":
      data.sort((a, b) => (b.fitScore || 0) - (a.fitScore || 0));
      break;
    case "date":
      data.sort((a, b) => {
        const da = a.dateFound ? a.dateFound.getTime() : 0;
        const db = b.dateFound ? b.dateFound.getTime() : 0;
        return db - da;
      });
      break;
    case "company":
      data.sort((a, b) => (a.company || "").localeCompare(b.company || ""));
      break;
    case "priority": {
      const priorityOrder = { "🔥": 0, "⚡": 1, "—": 2, "↓": 3 };
      data.sort(
        (a, b) =>
          (priorityOrder[a.priority] ?? 2) - (priorityOrder[b.priority] ?? 2),
      );
      break;
    }
  }

  return data;
}

function renderPipeline() {
  const container = document.getElementById("jobCards");
  const emptyState = document.getElementById("emptyState");
  const roleCountEl = document.getElementById("roleCount");

  // Board view: apply only search+sort, stages shown as collapsible lanes
  const data = filterAndSortJobs(pipelineData, currentSearch, currentSort);

  roleCountEl.textContent = `${data.length} of ${pipelineData.length}`;

  if (data.length === 0 && !dataLoadFailed) {
    container.innerHTML = "";
    emptyState.style.display = "block";
    const emptyTitle =
      document.getElementById("emptyStateTitle") ||
      emptyState.querySelector("h3");
    const emptyP =
      document.getElementById("emptyStateBody") ||
      emptyState.querySelector("p");
    const emptyActions = document.getElementById("emptyStateActions");
    if (emptyTitle && emptyP) {
      if (pipelineData.length === 0) {
        emptyTitle.textContent = "Your pipeline is empty";
        emptyP.textContent =
          "Paste a job URL above, or click Add manually, and your roles will land here.";
        if (emptyActions) {
          emptyActions.innerHTML = "";
          emptyActions.style.display = "none";
          emptyActions.setAttribute("aria-hidden", "true");
        }
      } else {
        emptyTitle.textContent = "No roles match";
        emptyP.textContent = "Clear the search box or try a different term.";
        if (emptyActions) {
          emptyActions.innerHTML = "";
          emptyActions.style.display = "none";
          emptyActions.setAttribute("aria-hidden", "true");
        }
      }
    }
    return;
  }

  emptyState.style.display = "none";
  if (data.length === 0) return;

  container.innerHTML = renderPipelineBoard(data);
  attachBoardListeners();
}

function renderCardActions(job, indexForNotesId) {
  const dataIndex = pipelineData.indexOf(job);

  if (!isSignedIn()) {
    return `
      <div class="card-actions card-actions--anon">
        <button type="button" class="btn-google-signin btn-google-signin--card" data-action="signin">
          <svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true">
            <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
            <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
            <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
            <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
          </svg>
          <span>Continue with Google</span>
        </button>
      </div>
    `;
  }

  const statuses = [
    "New",
    "Researching",
    "Applied",
    "Phone Screen",
    "Interviewing",
    "Offer",
    "Rejected",
    "Passed",
  ];
  const normalized = (job.status || "").trim().toLowerCase();
  const hasStatusMatch = statuses.some((s) => s.toLowerCase() === normalized);

  const options = statuses
    .map((s) => {
      const isSel =
        (hasStatusMatch && s.toLowerCase() === normalized) ||
        (!hasStatusMatch && s === "New");
      return `<option value="${escapeHtml(s)}"${isSel ? " selected" : ""}>${escapeHtml(s)}</option>`;
    })
    .join("");

  const appliedDateHtml = job.appliedDate
    ? `
    <div class="action-meta">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 2L11 13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
      <span>Applied ${escapeHtml(job.appliedDate)}</span>
    </div>
  `
    : "";

  const followUpVal = job.followUpDate || "";
  const followUpIsOverdue = followUpVal && new Date(followUpVal) < new Date();
  const followUpHtml = `
    <div class="action-meta ${followUpIsOverdue ? "overdue" : ""}">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
      <label class="followup-label" for="followup-${indexForNotesId}">Follow-up</label>
      <input type="date" id="followup-${indexForNotesId}" class="followup-input" data-action="followup" data-index="${dataIndex}" value="${escapeHtml(followUpVal)}" />
      ${followUpIsOverdue ? '<span class="overdue-badge">overdue</span>' : ""}
    </div>
  `;

  const respSel = selectedResponseSheetValue(job);
  const contactStatusHtml = `
    <div class="contact-status-row">
      <div class="contact-status-field">
        <label class="field-label" for="last-heard-${indexForNotesId}">Last contact</label>
        <input type="text" id="last-heard-${indexForNotesId}" class="last-heard-input" data-action="last-heard" data-index="${dataIndex}" value="${escapeHtml(job.lastHeardFrom || "")}" placeholder="e.g. Jan 12 or &ldquo;recruiter emailed&rdquo;" autocomplete="off" />
      </div>
      <div class="contact-status-field">
        <label class="field-label" for="response-${indexForNotesId}">Did they reply?</label>
        <select id="response-${indexForNotesId}" class="response-select" data-action="response-flag" data-index="${dataIndex}">
          <option value="">Not set</option>
          <option value="Yes"${respSel === "Yes" ? " selected" : ""}>Yes</option>
          <option value="No"${respSel === "No" ? " selected" : ""}>No</option>
          <option value="Unknown"${respSel === "Unknown" ? " selected" : ""}>Not sure</option>
        </select>
      </div>
    </div>
  `;

  return `
    <div class="card-actions">
      <div class="status-field">
        <label class="field-label" for="status-${dataIndex}-${indexForNotesId}">Pipeline stage</label>
        <select id="status-${dataIndex}-${indexForNotesId}" class="status-select" data-action="status-select" data-index="${dataIndex}">
          ${options}
        </select>
      </div>
      <div class="card-actions__tools">
        ${appliedDateHtml}
        ${followUpHtml}
      </div>
      ${contactStatusHtml}
      <div class="notes-wrapper">
        <label class="notes-label" for="notes-${dataIndex}-${indexForNotesId}">Notes</label>
        <textarea id="notes-${dataIndex}-${indexForNotesId}" class="notes-textarea" data-action="notes" data-index="${dataIndex}" placeholder="Interview prep, recruiter name, next step…">${escapeHtml(job.notes || "")}</textarea>
      </div>
    </div>
  `;
}

function attachCardListeners() {
  // Extra tags "+N"
  document.querySelectorAll('[data-action="toggle-tags"]').forEach((btn) => {
    btn.addEventListener("click", () => {
      const wrap = btn.closest("[data-tags-wrap]");
      if (!wrap) return;
      const on = wrap.classList.toggle("card-tags--expanded");
      btn.setAttribute("aria-expanded", on ? "true" : "false");
    });
  });

  // Pipeline stage select
  document.querySelectorAll('[data-action="status-select"]').forEach((sel) => {
    sel.addEventListener("change", async () => {
      const dataIndex = parseInt(sel.dataset.index, 10);
      const newStatus = sel.value;
      sel.disabled = true;
      const ok = await updateJobStatus(dataIndex, newStatus);
      if (ok) {
        refreshDrawerIfOpen(dataIndex);
      }
      sel.disabled = false;
    });
  });
  // Stage stepper clicks (drawer)
  document.querySelectorAll('[data-action="stage-step"]').forEach((btn) => {
    btn.addEventListener("click", async () => {
      if (btn.disabled) return;
      const dataIndex = parseInt(btn.dataset.index, 10);
      const newStage = btn.dataset.stage;
      btn.disabled = true;
      const ok = await updateJobStatus(dataIndex, newStage);
      if (ok) {
        refreshDrawerIfOpen(dataIndex);
        renderPipeline();
      }
      btn.disabled = false;
    });
  });

  // Profile match modal
  document
    .querySelectorAll('[data-action="open-profile-match"]')
    .forEach((btn) => {
      btn.addEventListener("click", () => {
        const idx = parseInt(btn.dataset.index, 10);
        if (!Number.isNaN(idx) && pipelineData[idx]) {
          openProfileMatchModal(pipelineData[idx], idx);
        }
      });
    });

  // Notes blur saves
  document.querySelectorAll('[data-action="notes"]').forEach((textarea) => {
    let originalValue = textarea.value;

    textarea.addEventListener("focus", () => {
      originalValue = textarea.value;
    });

    textarea.addEventListener("blur", async () => {
      const newValue = textarea.value.trim();
      if (newValue === originalValue.trim()) return; // No change

      const dataIndex = parseInt(textarea.dataset.index, 10);
      textarea.classList.add("saving");
      await updateJobNotes(dataIndex, newValue);
      textarea.classList.remove("saving");
      originalValue = newValue;
    });
  });

  // Follow-up date changes
  document.querySelectorAll('[data-action="followup"]').forEach((input) => {
    input.addEventListener("change", async () => {
      const dataIndex = parseInt(input.dataset.index, 10);
      await updateFollowUpDate(dataIndex, input.value);
    });
  });

  // Last contact (column R)
  document.querySelectorAll('[data-action="last-heard"]').forEach((input) => {
    let originalValue = input.value;
    input.addEventListener("focus", () => {
      originalValue = input.value;
    });
    input.addEventListener("blur", async () => {
      const newValue = input.value.trim();
      if (newValue === originalValue.trim()) return;
      const dataIndex = parseInt(input.dataset.index, 10);
      input.classList.add("saving");
      await updateLastHeardFrom(dataIndex, newValue);
      input.classList.remove("saving");
      originalValue = newValue;
    });
  });

  // Did they reply? (column S)
  document.querySelectorAll('[data-action="response-flag"]').forEach((sel) => {
    sel.addEventListener("change", async () => {
      const dataIndex = parseInt(sel.dataset.index, 10);
      sel.disabled = true;
      await updateJobResponseFlag(dataIndex, sel.value);
      sel.disabled = false;
    });
  });

  // Sign-in prompt clicks
  document.querySelectorAll('[data-action="signin"]').forEach((el) => {
    el.addEventListener("click", signIn);
  });

  document.querySelectorAll('[data-action="resume-cover"]').forEach((btn) => {
    btn.addEventListener("click", () => {
      const dataIndex = parseInt(btn.dataset.index, 10);
      if (!Number.isNaN(dataIndex))
        openDraftNotesModal(dataIndex, "cover_letter");
    });
  });

  document.querySelectorAll('[data-action="resume-tailor"]').forEach((btn) => {
    btn.addEventListener("click", () => {
      const dataIndex = parseInt(btn.dataset.index, 10);
      if (!Number.isNaN(dataIndex))
        openDraftNotesModal(dataIndex, "resume_update");
    });
  });

  document
    .querySelectorAll('[data-action="open-draft-version"]')
    .forEach((btn) => {
      btn.addEventListener("click", () => {
        const draftId = btn.dataset.draftId;
        if (draftId) void openSavedDraftVersion(draftId);
      });
    });

  document.querySelectorAll('[data-action="draft-tab"]').forEach((btn) => {
    btn.addEventListener("click", () => {
      const feature = btn.dataset.feature;
      const deck = btn.closest(".draft-deck");
      if (!deck) return;
      deck
        .querySelectorAll(".draft-deck__tab")
        .forEach((t) =>
          t.classList.toggle(
            "draft-deck__tab--active",
            t.dataset.feature === feature,
          ),
        );
      deck
        .querySelectorAll(".draft-deck__panel")
        .forEach((p) =>
          p.classList.toggle(
            "draft-deck__panel--active",
            p.dataset.feature === feature,
          ),
        );
      const activePanel = deck.querySelector(
        `.draft-deck__panel[data-feature="${feature}"]`,
      );
      const activeStack = activePanel?.querySelector(".draft-deck__stack");
      if (activePanel && activeStack) {
        updateDraftDeckState(
          activePanel,
          parseInt(activeStack.dataset.activeIdx || "0", 10),
        );
      }
    });
  });

  const updateDraftDeckState = (panel, targetIdx) => {
    if (!panel) return;
    const stack = panel.querySelector(".draft-deck__stack");
    if (!stack) return;
    const total = parseInt(stack.dataset.total || "0", 10);
    if (!total) return;
    const bounded = Math.max(0, Math.min(total - 1, targetIdx));
    stack.dataset.activeIdx = String(bounded);
    stack.querySelectorAll(".draft-deck__card").forEach((card) => {
      const rel = bounded - parseInt(card.dataset.deckIdx, 10);
      card.className = "draft-deck__card";
      if (rel === 0) {
        card.classList.add("draft-deck__card--front");
        card.tabIndex = 0;
      } else if (rel === 1) {
        card.classList.add("draft-deck__card--back-1");
        card.tabIndex = -1;
      } else if (rel === 2) {
        card.classList.add("draft-deck__card--back-2");
        card.tabIndex = -1;
      } else {
        card.classList.add("draft-deck__card--hidden");
        card.tabIndex = -1;
      }
    });
    const pos = panel.querySelector('[data-role="draft-position"]');
    if (pos) pos.textContent = `V${bounded + 1} of ${total}`;
    const prevBtn = panel.querySelector(
      '[data-action="draft-deck-shift"][data-dir="-1"]',
    );
    const nextBtn = panel.querySelector(
      '[data-action="draft-deck-shift"][data-dir="1"]',
    );
    if (prevBtn) prevBtn.disabled = bounded <= 0;
    if (nextBtn) nextBtn.disabled = bounded >= total - 1;
  };

  document
    .querySelectorAll('[data-action="draft-deck-shift"]')
    .forEach((btn) => {
      btn.addEventListener("click", () => {
        const panel = btn.closest(".draft-deck__panel");
        if (!panel) return;
        const stack = panel.querySelector(".draft-deck__stack");
        if (!stack) return;
        const currentIdx = parseInt(stack.dataset.activeIdx || "0", 10);
        const dir = parseInt(btn.dataset.dir || "0", 10);
        if (!dir) return;
        updateDraftDeckState(panel, currentIdx + dir);
      });
    });

  document.querySelectorAll(".draft-deck__panel").forEach((panel) => {
    const stack = panel.querySelector(".draft-deck__stack");
    if (!stack) return;
    updateDraftDeckState(panel, parseInt(stack.dataset.activeIdx || "0", 10));
  });
}

// --- Daily Brief (pipeline-derived) ---
/** Local calendar days; appeal rank; stale applied = no forward progress (see SETUP.md). */
const BRIEF_STALE_APPLIED_DAYS = 14;
const BRIEF_WAITING_REPLY_MIN_DAYS = 7;

function localDateKey(d) {
  if (!d || !(d instanceof Date) || isNaN(d.getTime())) return null;
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function parseBriefDate(str) {
  if (!str) return null;
  const d = new Date(str);
  return isNaN(d.getTime()) ? null : d;
}

function priorityRank(p) {
  const order = { "🔥": 0, "⚡": 1, "—": 2, "↓": 3 };
  return order[p] ?? 2;
}

function rankByAppeal(jobs) {
  return [...jobs].sort((a, b) => {
    const fs = (b.fitScore ?? -1) - (a.fitScore ?? -1);
    if (fs !== 0) return fs;
    const po = priorityRank(a.priority) - priorityRank(b.priority);
    if (po !== 0) return po;
    return (a.company || "").localeCompare(b.company || "");
  });
}

function jobsFoundToday(jobs) {
  const todayKey = localDateKey(new Date());
  return jobs.filter(
    (j) => j.dateFound && localDateKey(j.dateFound) === todayKey,
  );
}

function startOfWeekMonday(d) {
  const x = new Date(d);
  const day = x.getDay();
  const diff = day === 0 ? -6 : 1 - day;
  x.setDate(x.getDate() + diff);
  x.setHours(0, 0, 0, 0);
  return x;
}

function appliedThisWeekCount(jobs) {
  const start = startOfWeekMonday(new Date());
  return jobs.filter((j) => {
    if (!j.appliedDate) return false;
    const ad = parseBriefDate(j.appliedDate);
    return ad && ad >= start;
  }).length;
}

function isStaleApplied(job) {
  const s = (job.status || "").toLowerCase();
  if (!s.includes("applied")) return false;
  if (
    s.includes("interview") ||
    s.includes("phone screen") ||
    s.includes("offer")
  )
    return false;
  if (s.includes("reject") || s.includes("passed")) return false;
  if (!job.appliedDate) return false;
  const ad = parseBriefDate(job.appliedDate);
  if (!ad) return false;
  const days = (Date.now() - ad.getTime()) / (24 * 3600 * 1000);
  return days >= BRIEF_STALE_APPLIED_DAYS;
}

function overdueFollowUps(jobs) {
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  return jobs.filter((j) => {
    if (!j.followUpDate) return false;
    const fd = parseBriefDate(j.followUpDate);
    if (!fd) return false;
    fd.setHours(0, 0, 0, 0);
    return fd < now;
  });
}

function upcomingFollowUps48h(jobs) {
  const now = new Date();
  const end = new Date(now.getTime() + 48 * 3600 * 1000);
  return jobs.filter((j) => {
    if (!j.followUpDate) return false;
    const fd = parseBriefDate(j.followUpDate);
    if (!fd) return false;
    return fd >= now && fd <= end;
  });
}

function normalizeResponseFlag(val) {
  if (!val || !String(val).trim()) return "";
  const v = String(val).trim().toLowerCase();
  if (v === "yes" || v === "y") return "yes";
  if (v === "no" || v === "n") return "no";
  if (v === "unknown" || v === "?") return "unknown";
  return "";
}

/** Short label for chips and the brief (user-facing). */
function responseLabelForDisplay(flag) {
  const n = normalizeResponseFlag(flag);
  if (n === "yes") return "Yes";
  if (n === "no") return "No";
  if (n === "unknown") return "Not sure";
  if (flag && String(flag).trim()) return String(flag).trim();
  return "";
}

function selectedResponseSheetValue(job) {
  const n = normalizeResponseFlag(job.responseFlag);
  if (n === "yes") return "Yes";
  if (n === "no") return "No";
  if (n === "unknown") return "Unknown";
  return "";
}

function waitingOnReplyJobs(jobs) {
  return jobs.filter((j) => {
    const s = (j.status || "").toLowerCase();
    if (
      s.includes("interviewing") ||
      s.includes("offer") ||
      s.includes("reject") ||
      s.includes("passed") ||
      s === "new" ||
      s.includes("researching")
    ) {
      return false;
    }
    const waitingStage = s === "applied" || s.includes("phone screen");
    if (!waitingStage) return false;

    const flag = normalizeResponseFlag(j.responseFlag);
    if (flag === "yes") return false;
    if (flag === "no") return true;

    if (!j.appliedDate) return false;
    const ad = parseBriefDate(j.appliedDate);
    if (!ad) return false;
    const days = (Date.now() - ad.getTime()) / (24 * 3600 * 1000);
    return days >= BRIEF_WAITING_REPLY_MIN_DAYS;
  });
}

function pipelineStatusCounts(jobs) {
  const map = {};
  for (const j of jobs) {
    const k = (j.status || "Unknown").trim() || "Unknown";
    map[k] = (map[k] || 0) + 1;
  }
  return map;
}

function briefJobLine(job, extraHtml) {
  const title = escapeHtml(job.title || "Role");
  const co = escapeHtml(job.company || "");
  const extra = extraHtml || "";
  return `<li><strong>${title}</strong>${co ? ` — ${co}` : ""} ${extra}</li>`;
}

function briefJobLineWithLastHeard(job) {
  const heard = job.lastHeardFrom
    ? ` <span class="brief-meta">Last contact: ${escapeHtml(job.lastHeardFrom)}</span>`
    : "";
  const reply = responseLabelForDisplay(job.responseFlag)
    ? ` <span class="brief-meta">Reply: ${escapeHtml(responseLabelForDisplay(job.responseFlag))}</span>`
    : "";
  return briefJobLine(job, heard + reply);
}

// --- Brief: Headline ---

function briefHeadlineSentence(overdue, waiting, stale, todayJobs) {
  const ov = overdue.length;
  const wt = waiting.length;
  const st = stale.length;
  const nw = todayJobs.length;
  const urgent = ov + wt + st;

  if (!urgent && !nw)
    return "Nothing demands your attention today. The pipeline is steady&mdash;a good day to sharpen your story or reach out to someone new.";

  if (!urgent && nw)
    return `Your pipeline is clear and ${nw === 1 ? "a promising new opportunity has" : `<strong>${nw}</strong> fresh opportunities have`} surfaced since yesterday. A clean slate and new leads&mdash;today is yours to move fast.`;

  const threads = [];
  if (ov)
    threads.push(
      ov === 1
        ? "one follow-up has gone unanswered past its window"
        : `<strong>${ov}</strong> follow-ups have slipped past their window`,
    );
  if (wt)
    threads.push(
      wt === 1
        ? "one conversation is still waiting on you"
        : `<strong>${wt}</strong> conversations are still waiting on you`,
    );
  if (st)
    threads.push(
      st === 1
        ? "one application has gone quiet"
        : `<strong>${st}</strong> applications have gone quiet`,
    );

  let prose = threads[0];
  if (threads.length === 2) prose += ", and " + threads[1];
  else if (threads.length === 3)
    prose += ", " + threads[1] + ", and " + threads[2];

  prose = prose.charAt(0).toUpperCase() + prose.slice(1);

  if (nw)
    prose += `. On the bright side, ${nw === 1 ? "a new match" : `<strong>${nw}</strong> new matches`} arrived today&mdash;momentum is building.`;
  else prose += ". Clearing these will put you back in control of the pace.";

  return prose;
}

// --- Brief: Opportunity column ---

function briefDaysSince(dateStr) {
  const d = parseBriefDate(dateStr);
  if (!d) return null;
  return Math.floor((Date.now() - d.getTime()) / (24 * 3600 * 1000));
}

/** Rolling windows: last 7 calendar days vs the 7 days before that (local midnight). */
function getInsightDateWindows() {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const recentEnd = new Date(today);
  recentEnd.setDate(recentEnd.getDate() + 1);
  const recentStart = new Date(today);
  recentStart.setDate(recentStart.getDate() - 7);
  const priorEnd = recentStart;
  const priorStart = new Date(recentStart);
  priorStart.setDate(priorStart.getDate() - 7);
  return { recentStart, recentEnd, priorStart, priorEnd };
}

function dateInWindow(d, start, end) {
  return d >= start && d < end;
}

function countDateFoundInWindow(jobs, start, end) {
  return jobs.filter((j) => {
    const d = parseBriefDate(j.dateFound);
    return d && dateInWindow(d, start, end);
  }).length;
}

function countAppliedInWindow(jobs, start, end) {
  return jobs.filter((j) => {
    const d = parseBriefDate(j.appliedDate);
    return d && dateInWindow(d, start, end);
  }).length;
}

function trendDeltaLabel(cur, prev) {
  const d = cur - prev;
  if (d === 0) return "same as prior week";
  if (d > 0) return `up ${d} vs prior week`;
  return `down ${-d} vs prior week`;
}

/** Short delta for insight tiles: +2, −1, 0 */
function trendDeltaShort(cur, prev) {
  const d = cur - prev;
  if (d === 0) return "0";
  if (d > 0) return `+${d}`;
  return `${d}`;
}

function trendPillClass(cur, prev) {
  const d = cur - prev;
  if (d > 0) return "insight-pill--up";
  if (d < 0) return "insight-pill--down";
  return "insight-pill--flat";
}

function medianDaysDiscoveryToApply(jobs) {
  const deltas = [];
  for (const j of jobs) {
    const df = parseBriefDate(j.dateFound);
    const da = parseBriefDate(j.appliedDate);
    if (!df || !da) continue;
    const days = Math.round((da - df) / (24 * 3600 * 1000));
    if (days >= 0) deltas.push(days);
  }
  if (deltas.length < 2) return null;
  deltas.sort((a, b) => a - b);
  return deltas[Math.floor(deltas.length / 2)];
}

function topSourcesInWindow(jobs, start, end, limit) {
  const map = {};
  for (const j of jobs) {
    const d = parseBriefDate(j.dateFound);
    if (!d || !dateInWindow(d, start, end)) continue;
    const src = (j.source || "").trim() || "Unknown";
    map[src] = (map[src] || 0) + 1;
  }
  return Object.entries(map)
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit);
}

let briefActivityRange = "7d";

function getBreakdownForRange(jobs, range) {
  const totalDays = { "7d": 7, "14d": 14, "30d": 30, "90d": 90 }[range] || 7;
  const groupSize = totalDays >= 30 ? 7 : 1;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const daily = [];
  for (let i = totalDays - 1; i >= 0; i--) {
    const s = new Date(today);
    s.setDate(s.getDate() - i);
    const e = new Date(s);
    e.setDate(e.getDate() + 1);
    daily.push({
      date: s,
      discovered: jobs.filter((j) => {
        const d = parseBriefDate(j.dateFound);
        return d && d >= s && d < e;
      }).length,
      applied: jobs.filter((j) => {
        const d = parseBriefDate(j.appliedDate);
        return d && d >= s && d < e;
      }).length,
    });
  }
  if (groupSize === 1) {
    const short = totalDays <= 7;
    return daily.map((d) => ({
      ...d,
      label: short
        ? d.date.toLocaleDateString(undefined, { weekday: "short" }).slice(0, 2)
        : d.date.toLocaleDateString(undefined, {
            month: "short",
            day: "numeric",
          }),
    }));
  }
  const groups = [];
  for (let i = 0; i < daily.length; i += groupSize) {
    const ch = daily.slice(i, i + groupSize);
    groups.push({
      date: ch[0].date,
      label: ch[0].date.toLocaleDateString(undefined, {
        month: "short",
        day: "numeric",
      }),
      discovered: ch.reduce((a, d) => a + d.discovered, 0),
      applied: ch.reduce((a, d) => a + d.applied, 0),
    });
  }
  return groups;
}

function niceAxisMax(v) {
  if (v <= 0) return 5;
  return (
    [5, 10, 15, 20, 25, 30, 40, 50, 75, 100, 150, 200, 300, 500, 1000].find(
      (t) => t >= v,
    ) || Math.ceil(v / 100) * 100
  );
}

function catmullRomPath(pts) {
  if (pts.length < 2) return "";
  let d = `M ${pts[0].x},${pts[0].y}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[Math.max(0, i - 1)],
      p1 = pts[i],
      p2 = pts[i + 1],
      p3 = pts[Math.min(pts.length - 1, i + 2)];
    const t = 6;
    d += ` C ${p1.x + (p2.x - p0.x) / t},${p1.y + (p2.y - p0.y) / t} ${p2.x - (p3.x - p1.x) / t},${p2.y - (p3.y - p1.y) / t} ${p2.x},${p2.y}`;
  }
  return d;
}

function countStatusMatches(jobs, pred) {
  return jobs.filter(pred).length;
}

function buildBriefSuggestions(ctx) {
  const tips = [];
  const {
    staleLen,
    waitingLen,
    overdueLen,
    inboxCount,
    discRecent,
    appliedRecent,
    offers,
    total,
  } = ctx;
  if (total === 0) return tips;
  if (discRecent === 0 && total > 0)
    tips.push(
      "No new discoveries in the last 7 days — try a different discovery query or widen locations.",
    );
  if (inboxCount >= 8)
    tips.push(
      `Large inbox (${inboxCount} roles) — block time to triage so nothing goes stale.`,
    );
  if (staleLen > 0)
    tips.push(
      "Stale applications need a decision: follow up once, then close or move on.",
    );
  if (waitingLen >= 4)
    tips.push(
      "Several applications are waiting on replies — a single follow-up sweep can clear mental load.",
    );
  if (offers > 0)
    tips.push(
      "You have an active offer — compare deadlines and total comp before you sign.",
    );
  if (appliedRecent >= 5 && tips.length < 4)
    tips.push(
      "Heavy apply week — note which sources or companies reply so you can double down next week.",
    );
  if (overdueLen > 0 && tips.length < 4)
    tips.push(
      "Overdue follow-up dates are promises to yourself — reschedule or send one short note.",
    );
  return tips.slice(0, 4);
}

function renderBriefStats(ctx) {
  const {
    discRecent,
    discPrior,
    appRecent,
    appPrior,
    inLoop,
    offers,
    medianDays,
  } = ctx;

  function deltaClass(cur, prev) {
    const d = cur - prev;
    if (d > 0) return "stat-card__delta--up";
    if (d < 0) return "stat-card__delta--down";
    return "stat-card__delta--flat";
  }

  let html = "";

  html += `<div class="stat-card">
    <span class="stat-card__label">Found this week</span>
    <div class="stat-card__row">
      <span class="stat-card__value">${discRecent}</span>
      <span class="stat-card__delta ${deltaClass(discRecent, discPrior)}">${trendDeltaShort(discRecent, discPrior)}</span>
    </div>
    <span class="stat-card__sub">vs ${discPrior} prior week</span>
  </div>`;

  html += `<div class="stat-card">
    <span class="stat-card__label">Applied this week</span>
    <div class="stat-card__row">
      <span class="stat-card__value">${appRecent}</span>
      <span class="stat-card__delta ${deltaClass(appRecent, appPrior)}">${trendDeltaShort(appRecent, appPrior)}</span>
    </div>
    <span class="stat-card__sub">vs ${appPrior} prior week</span>
  </div>`;

  html += `<div class="stat-card">
    <span class="stat-card__label">In loop</span>
    <div class="stat-card__row">
      <span class="stat-card__value">${inLoop}</span>
    </div>
    <span class="stat-card__sub">interviewing + screens</span>
  </div>`;

  html += `<div class="stat-card">
    <span class="stat-card__label">Offers</span>
    <div class="stat-card__row">
      <span class="stat-card__value">${offers}</span>
    </div>
    <span class="stat-card__sub">${medianDays != null ? `${medianDays}d median find\u2009\u2192\u2009apply` : "full pipeline"}</span>
  </div>`;

  return html;
}

function renderDonutWidget(stages) {
  const total = stages.reduce((s, st) => s + st.count, 0);
  if (total === 0) return "";
  const filtered = stages.filter((s) => s.count > 0);
  let cumPct = 0;
  const segs = filtered.map((s) => {
    const p = (s.count / total) * 100;
    const f = cumPct;
    cumPct += p;
    return `${s.color} ${f}% ${cumPct}%`;
  });
  let h =
    '<h4 class="brief-widget__title">Pipeline</h4><div class="donut-layout">';
  h += `<div class="donut-wrap"><div class="donut" style="background:conic-gradient(${segs.join(",")})"></div>`;
  h += `<div class="donut-center"><span class="donut-center__val">${total}</span><span class="donut-center__lbl">total</span></div></div>`;
  h += '<div class="donut-legend">';
  for (const s of filtered)
    h += `<div class="donut-legend__item"><span class="donut-legend__dot" style="background:${s.color}"></span><span class="donut-legend__label">${escapeHtml(s.label)}</span><span class="donut-legend__val">${s.count}</span></div>`;
  h += "</div></div>";
  return h;
}

function renderAreaWidget(jobs, range) {
  const data = getBreakdownForRange(jobs, range);
  const maxRaw = Math.max(0, ...data.flatMap((d) => [d.discovered, d.applied]));
  const maxY = niceAxisMax(maxRaw);
  const L = 50,
    R = 490,
    T = 12,
    B = 160,
    W = R - L,
    H = B - T,
    n = data.length;
  const xS = n > 1 ? W / (n - 1) : 0;
  function pts(k) {
    return data.map((d, i) => ({ x: L + i * xS, y: B - (d[k] / maxY) * H }));
  }
  const dp = pts("discovered"),
    ap = pts("applied");
  function aD(p) {
    return p.length < 2
      ? ""
      : catmullRomPath(p) + ` L ${p[p.length - 1].x},${B} L ${p[0].x},${B} Z`;
  }
  const ranges = ["7d", "14d", "30d", "90d"];
  let h =
    '<div class="area-header"><h4 class="area-header__title">Activity</h4><div class="area-range">';
  for (const r of ranges)
    h += `<button class="area-range__btn${r === range ? " area-range__btn--active" : ""}" data-range="${r}">${r}</button>`;
  h += "</div></div>";
  h +=
    '<svg viewBox="0 0 500 190" class="area-svg" preserveAspectRatio="xMidYMid meet">';
  for (const g of [0, 0.5, 1]) {
    const y = B - g * H;
    h += `<line x1="${L}" y1="${y}" x2="${R}" y2="${y}" class="area-grid-line"/><text x="${L - 6}" y="${y + 3}" class="area-y-label">${Math.round(maxY * g)}</text>`;
  }
  h += `<path d="${aD(dp)}" class="area-fill--disc"/><path d="${aD(ap)}" class="area-fill--app"/>`;
  h += `<path d="${catmullRomPath(dp)}" class="area-line--disc"/><path d="${catmullRomPath(ap)}" class="area-line--app"/>`;
  for (let i = 0; i < n; i++) {
    h += `<circle cx="${dp[i].x}" cy="${dp[i].y}" r="3" class="area-dot--disc"><title>Found: ${data[i].discovered}</title></circle>`;
    h += `<circle cx="${ap[i].x}" cy="${ap[i].y}" r="3" class="area-dot--app"><title>Applied: ${data[i].applied}</title></circle>`;
  }
  const every = Math.max(1, Math.ceil(n / 7));
  for (let i = 0; i < n; i++) {
    if (i % every === 0 || i === n - 1)
      h += `<text x="${L + i * xS}" y="${B + 18}" class="area-x-label">${escapeHtml(data[i].label)}</text>`;
  }
  h += "</svg>";
  h +=
    '<div class="area-legend"><span class="area-legend__key"><span class="area-legend__dot area-legend__dot--disc"></span>Discovered</span><span class="area-legend__key"><span class="area-legend__dot area-legend__dot--app"></span>Applied</span></div>';
  return h;
}

function renderSourceWidget(sources, suggestions) {
  let h = "";
  if (sources.length > 0) {
    const mx = sources[0][1];
    h +=
      '<h4 class="brief-widget__title">Top sources <span style="font-weight:500;color:var(--text-faint);font-size:var(--text-xs)">7d</span></h4>';
    for (const [name, count] of sources) {
      const p = Math.max(4, (count / mx) * 100);
      h += `<div class="source-bars__row"><span class="source-bars__name">${escapeHtml(name)}</span><div class="source-bars__track"><div class="source-bars__fill" style="width:${p}%"></div></div><span class="source-bars__count">${count}</span></div>`;
    }
  }
  if (suggestions.length > 0) {
    h += `<div style="margin-top:auto;padding-top:var(--space-3);border-top:1px solid var(--divider)"><ul class="brief-tips__list">${suggestions
      .slice(0, 2)
      .map((t) => `<li>${escapeHtml(t)}</li>`)
      .join("")}</ul></div>`;
  }
  return h;
}

function renderEmptyDonutScaffold() {
  const stages = [
    { label: "New", color: "var(--stage-rail-new)" },
    { label: "Researching", color: "var(--stage-rail-researching)" },
    { label: "Applied", color: "var(--stage-rail-applied)" },
    { label: "Phone Screen", color: "var(--stage-rail-phone-screen)" },
    { label: "Interviewing", color: "var(--stage-rail-interviewing)" },
    { label: "Offer", color: "var(--stage-rail-offer)" },
  ];
  let h =
    '<h4 class="brief-widget__title">Pipeline</h4><div class="donut-layout donut-layout--empty">';
  h += '<div class="donut-wrap"><div class="donut donut--empty"></div>';
  h +=
    '<div class="donut-center"><span class="donut-center__val">0</span><span class="donut-center__lbl">total</span></div></div>';
  h += '<div class="donut-legend">';
  for (const s of stages) {
    h += `<div class="donut-legend__item donut-legend__item--empty"><span class="donut-legend__dot" style="background:${s.color}"></span><span class="donut-legend__label">${escapeHtml(s.label)}</span><span class="donut-legend__val">0</span></div>`;
  }
  h += "</div></div>";
  return h;
}

function renderEmptyInsightsScaffold() {
  return `<h4 class="brief-widget__title">7-day activity</h4>
    <div class="brief-scaffold-empty">
      <p class="brief-scaffold-empty__text">Your discovery and apply trend will plot here once jobs land in the pipeline.</p>
    </div>`;
}

function renderEmptySourcesScaffold() {
  return `<h4 class="brief-widget__title">Top sources</h4>
    <div class="brief-scaffold-empty">
      <p class="brief-scaffold-empty__text">The job boards you use most will rank here.</p>
    </div>`;
}

function _UNUSED_renderBriefCharts(ctx) {
  /* removed — replaced by renderDonutWidget, renderAreaWidget, renderSourceWidget */
  const { stages, dailyBreakdown, sources, suggestions } = ctx;

  let html = "";

  // Pipeline funnel
  const total = stages.reduce((s, st) => s + st.count, 0);
  if (total > 0) {
    html += '<div class="pipeline-funnel">';
    html += '<h4 class="pipeline-funnel__title">Pipeline distribution</h4>';
    html += '<div class="pipeline-funnel__bar">';
    for (const s of stages) {
      if (s.count === 0) continue;
      html += `<div class="pipeline-funnel__seg" style="flex:${s.count};background:${s.color}" title="${escapeHtml(s.label)}: ${s.count}"></div>`;
    }
    html += "</div>";
    html += '<div class="pipeline-funnel__legend">';
    for (const s of stages) {
      if (s.count === 0) continue;
      html += `<span class="pipeline-funnel__key"><span class="pipeline-funnel__dot" style="background:${s.color}"></span>${escapeHtml(s.label)} <strong>${s.count}</strong></span>`;
    }
    html += "</div></div>";
  }

  // 7-day activity chart
  const maxVal = Math.max(
    1,
    ...dailyBreakdown.map((d) => Math.max(d.discovered, d.applied)),
  );
  html += '<div class="activity-chart">';
  html += '<h4 class="activity-chart__title">7-day activity</h4>';
  html += '<div class="activity-chart__bars">';
  for (const d of dailyBreakdown) {
    const discH = Math.max(
      d.discovered > 0 ? 3 : 0,
      (d.discovered / maxVal) * 100,
    );
    const appH = Math.max(d.applied > 0 ? 3 : 0, (d.applied / maxVal) * 100);
    html += `<div class="activity-chart__col">
      <div class="activity-chart__pair">
        <div class="activity-chart__bar activity-chart__bar--disc" style="height:${discH}%" title="Found: ${d.discovered}"></div>
        <div class="activity-chart__bar activity-chart__bar--app" style="height:${appH}%" title="Applied: ${d.applied}"></div>
      </div>
      <span class="activity-chart__day">${d.label}</span>
    </div>`;
  }
  html += "</div>";
  html += '<div class="activity-chart__legend">';
  html +=
    '<span class="activity-chart__key"><span class="activity-chart__dot activity-chart__dot--disc"></span>Discovered</span>';
  html +=
    '<span class="activity-chart__key"><span class="activity-chart__dot activity-chart__dot--app"></span>Applied</span>';
  html += "</div></div>";

  // Source bars
  if (sources.length > 0) {
    const maxSrc = sources[0][1];
    html += '<div class="source-bars">';
    html +=
      '<h4 class="source-bars__title">Top sources <span class="source-bars__period">7d</span></h4>';
    for (const [name, count] of sources) {
      const pct = Math.max(4, (count / maxSrc) * 100);
      html += `<div class="source-bars__row">
        <span class="source-bars__name">${escapeHtml(name)}</span>
        <div class="source-bars__track"><div class="source-bars__fill" style="width:${pct}%"></div></div>
        <span class="source-bars__count">${count}</span>
      </div>`;
    }
    html += "</div>";
  }

  // Tips
  if (suggestions.length > 0) {
    const tips = suggestions.slice(0, 3);
    html += '<div class="brief-tips">';
    html += '<h4 class="brief-tips__title">Tips</h4>';
    html += `<ul class="brief-tips__list">${tips.map((t) => `<li>${escapeHtml(t)}</li>`).join("")}</ul>`;
    html += "</div>";
  }

  return html;
}

// --- Brief: Activity feed ---

function renderBriefFeed(overdue, upcoming, waiting, stale) {
  function keyOf(j) {
    return pipelineData.indexOf(j);
  }
  const items = [];
  for (const j of overdue) {
    const d = briefDaysSince(j.followUpDate);
    items.push({
      type: "urgent",
      title: `${j.title || "Role"} \u2014 ${j.company || ""}`,
      desc: "Follow-up overdue",
      meta: d != null ? `${d}d late` : "",
      pri: 0,
      days: d || 0,
      key: keyOf(j),
    });
  }
  for (const j of waiting) {
    const d = briefDaysSince(j.appliedDate);
    items.push({
      type: "waiting",
      title: `${j.title || "Role"} \u2014 ${j.company || ""}`,
      desc: "Awaiting reply",
      meta: d != null ? `${d}d ago` : "",
      pri: 1,
      days: d || 0,
      key: keyOf(j),
    });
  }
  for (const j of stale) {
    const d = briefDaysSince(j.appliedDate);
    items.push({
      type: "stale",
      title: `${j.title || "Role"} \u2014 ${j.company || ""}`,
      desc: "Going stale",
      meta: d != null ? `${d}d` : "",
      pri: 2,
      days: d || 0,
      key: keyOf(j),
    });
  }
  for (const j of upcoming.slice(0, 3)) {
    items.push({
      type: "upcoming",
      title: `${j.title || "Role"} \u2014 ${j.company || ""}`,
      desc: "Follow-up soon",
      meta: "48h",
      pri: 3,
      days: 0,
      key: keyOf(j),
    });
  }
  items.sort((a, b) => a.pri - b.pri || b.days - a.days);

  if (!items.length) {
    return '<div class="feed-clear"><div class="feed-clear__icon"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg></div><p class="feed-clear__text">All clear</p><p class="feed-clear__sub">Nothing needs your attention right now.</p></div>';
  }
  const chevron =
    '<svg class="feed-item__chevron" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>';
  let html = '<div class="feed-list">';
  const shown = items.slice(0, 12);
  for (const it of shown) {
    const keyAttr = it.key >= 0 ? ` data-stable-key="${it.key}"` : "";
    html += `<button type="button" class="feed-item feed-item--${it.type}" data-action="open-detail"${keyAttr}><div class="feed-item__dot"></div><div class="feed-item__body"><span class="feed-item__title">${escapeHtml(it.title)}</span><span class="feed-item__desc">${it.desc}</span></div><span class="feed-item__meta">${it.meta}</span>${chevron}</button>`;
  }
  if (items.length > 12)
    html += `<div class="feed-more">+${items.length - 12} more</div>`;
  html += "</div>";
  return html;
}

function _DEAD_renderBriefQueue(overdue, upcoming, waiting, stale) {
  const hasItems = overdue.length || waiting.length || stale.length;

  if (!hasItems) {
    let html = '<div class="queue-clear">';
    html +=
      '<div class="queue-clear__icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg></div>';
    html +=
      '<p class="queue-clear__text">Nothing needs your attention right now.</p>';
    if (upcoming.length > 0) {
      html += `<p class="queue-clear__text" style="margin-top:var(--space-2)">Next follow-up in 48 h: <strong>${escapeHtml(upcoming[0].title || "Role")} &mdash; ${escapeHtml(upcoming[0].company || "")}</strong></p>`;
    }
    html += "</div>";
    return html;
  }

  let html = "";

  function renderQueueGroup(dotClass, label, jobs, metaFn, limit) {
    if (jobs.length === 0) return "";
    let g = '<div class="queue-group">';
    g += `<div class="queue-group__header"><span class="queue-group__dot ${dotClass}"></span><span class="queue-group__label">${label}</span><span class="queue-group__count">${jobs.length}</span></div>`;
    const shown = jobs.slice(0, limit || 3);
    for (const j of shown) {
      const meta = metaFn(j);
      g += `<div class="queue-item"><span class="queue-item__title">${escapeHtml(j.title || "Role")} &mdash; ${escapeHtml(j.company || "")}</span>${meta}</div>`;
    }
    const remaining = jobs.length - shown.length;
    if (remaining > 0) g += `<p class="queue-overflow">+${remaining} more</p>`;
    g += "</div>";
    return g;
  }

  html += renderQueueGroup(
    "queue-group__dot--urgent",
    "Follow-ups overdue",
    overdue,
    (j) => {
      const d = briefDaysSince(j.followUpDate);
      return d != null
        ? `<span class="queue-item__meta queue-item__meta--warn">${d}d late</span>`
        : "";
    },
  );

  if (upcoming.length > 0 && overdue.length > 0) {
    let upHtml =
      '<div class="queue-upcoming"><span class="queue-upcoming__label">Next 48 h: </span>';
    upHtml += upcoming
      .slice(0, 2)
      .map(
        (j) =>
          `${escapeHtml(j.title || "Role")} &mdash; ${escapeHtml(j.company || "")}`,
      )
      .join(", ");
    upHtml += "</div>";
    html += upHtml;
  }

  html += renderQueueGroup(
    "queue-group__dot--waiting",
    "Awaiting reply",
    waiting,
    (j) => {
      const d = briefDaysSince(j.appliedDate);
      return d != null ? `<span class="queue-item__meta">${d}d ago</span>` : "";
    },
  );

  html += renderQueueGroup(
    "queue-group__dot--stale",
    "Stale applications",
    stale,
    (j) => {
      const d = briefDaysSince(j.appliedDate);
      return d != null
        ? `<span class="queue-item__meta queue-item__meta--warn">${d}d</span>`
        : "";
    },
  );

  return html;
}

// --- Brief: orchestrator ---

function renderPipelineDailyBrief() {
  return pipelineData.length > 0;
}

function renderBrief() {
  const dateEl = document.getElementById("briefDate");
  const headlineEl = document.getElementById("briefHeadline");
  const insightsEl = document.getElementById("briefInsights");
  const actionEl = document.getElementById("briefAction");
  const followPanel = document.getElementById("briefFollowupPanel");
  const mainGrid = document.getElementById("briefMainGrid");
  const statsEl = document.getElementById("briefStats");

  const now = new Date();
  if (dateEl)
    dateEl.textContent = now.toLocaleDateString(undefined, {
      weekday: "short",
      month: "short",
      day: "numeric",
      year: "numeric",
    });

  const pipelineEl = document.getElementById("briefPipeline");
  const sourcesEl = document.getElementById("briefSources");

  if (!pipelineData.length) {
    if (headlineEl) headlineEl.innerHTML = "";
    if (actionEl) actionEl.innerHTML = "";
    if (followPanel) {
      followPanel.hidden = true;
      followPanel.style.display = "none";
    }
    if (mainGrid) mainGrid.classList.remove("brief-dashboard--empty");
    if (statsEl)
      statsEl.innerHTML = renderBriefStats({
        discRecent: 0,
        discPrior: 0,
        appRecent: 0,
        appPrior: 0,
        inLoop: 0,
        offers: 0,
        medianDays: null,
      });
    if (pipelineEl) pipelineEl.innerHTML = renderEmptyDonutScaffold();
    if (insightsEl) insightsEl.innerHTML = renderEmptyInsightsScaffold();
    if (sourcesEl) sourcesEl.innerHTML = renderEmptySourcesScaffold();
    return;
  }

  if (followPanel) {
    followPanel.hidden = false;
    followPanel.style.display = "";
  }
  if (mainGrid) mainGrid.classList.remove("brief-dashboard--empty");

  const todayJobs = jobsFoundToday(pipelineData);
  const overdue = overdueFollowUps(pipelineData);
  const upcoming = upcomingFollowUps48h(pipelineData);
  const stale = pipelineData.filter(isStaleApplied);
  const waiting = waitingOnReplyJobs(pipelineData);

  const w = getInsightDateWindows();
  const discRecent = countDateFoundInWindow(
    pipelineData,
    w.recentStart,
    w.recentEnd,
  );
  const discPrior = countDateFoundInWindow(
    pipelineData,
    w.priorStart,
    w.priorEnd,
  );
  const appRecent = countAppliedInWindow(
    pipelineData,
    w.recentStart,
    w.recentEnd,
  );
  const appPrior = countAppliedInWindow(pipelineData, w.priorStart, w.priorEnd);

  const stn = (s) => (s || "").toLowerCase().trim();
  const offers = pipelineData.filter((j) =>
    stn(j.status).includes("offer"),
  ).length;
  const interviewing = pipelineData.filter((j) =>
    stn(j.status).includes("interviewing"),
  ).length;
  const phoneScreens = pipelineData.filter((j) =>
    stn(j.status).includes("phone screen"),
  ).length;
  const rejected = pipelineData.filter((j) =>
    stn(j.status).includes("rejected"),
  ).length;
  const passed = pipelineData.filter((j) => stn(j.status) === "passed").length;

  const inboxCount = pipelineData.filter((j) => {
    const s = stn(j.status);
    return !s || s === "new" || s === "researching";
  }).length;
  const appliedCount = pipelineData.filter(
    (j) => stn(j.status) === "applied",
  ).length;
  const researchingCount = pipelineData.filter(
    (j) => stn(j.status) === "researching",
  ).length;
  const newCount = inboxCount - researchingCount;

  const medianDays = medianDaysDiscoveryToApply(pipelineData);
  const sources = topSourcesInWindow(
    pipelineData,
    w.recentStart,
    w.recentEnd,
    5,
  );

  const suggestions = buildBriefSuggestions({
    staleLen: stale.length,
    waitingLen: waiting.length,
    overdueLen: overdue.length,
    inboxCount,
    discRecent,
    appliedRecent: appRecent,
    offers,
    total: pipelineData.length,
  });

  const inLoop = interviewing + phoneScreens;

  if (headlineEl)
    headlineEl.innerHTML = briefHeadlineSentence(
      overdue,
      waiting,
      stale,
      todayJobs,
    );

  if (statsEl)
    statsEl.innerHTML = renderBriefStats({
      discRecent,
      discPrior,
      appRecent,
      appPrior,
      inLoop,
      offers,
      medianDays,
    });

  const stages = [
    { label: "New", count: newCount, color: "var(--stage-rail-new)" },
    {
      label: "Researching",
      count: researchingCount,
      color: "var(--stage-rail-researching)",
    },
    {
      label: "Applied",
      count: appliedCount,
      color: "var(--stage-rail-applied)",
    },
    {
      label: "Phone Screen",
      count: phoneScreens,
      color: "var(--stage-rail-phone-screen)",
    },
    {
      label: "Interviewing",
      count: interviewing,
      color: "var(--stage-rail-interviewing)",
    },
    { label: "Offer", count: offers, color: "var(--stage-rail-offer)" },
    { label: "Rejected", count: rejected, color: "var(--stage-rail-rejected)" },
    { label: "Passed", count: passed, color: "var(--stage-rail-passed)" },
  ];

  if (pipelineEl) pipelineEl.innerHTML = renderDonutWidget(stages);
  if (insightsEl)
    insightsEl.innerHTML = renderAreaWidget(pipelineData, briefActivityRange);
  if (sourcesEl) sourcesEl.innerHTML = renderSourceWidget(sources, suggestions);
  if (actionEl)
    actionEl.innerHTML = renderBriefFeed(overdue, upcoming, waiting, stale);
}

// ============================================
// UTILITY
// ============================================

function escapeHtml(str) {
  if (!str) return "";
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function safeHref(url) {
  if (!url) return "";
  var s = String(url).trim();
  if (/^https?:\/\//i.test(s)) return s;
  return "";
}

function updateLastRefresh() {
  const el = document.getElementById("lastRefresh");
  const now = new Date();
  const time = now.toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  });
  if (el) el.textContent = `Updated ${time}`;
}

// ============================================
// RESUME MATERIALS & GENERATION (IndexedDB + BYOK / webhook)
// ============================================

/** Staged resume during onboarding (before save). */
let onboardingResumeDraft = null;
/** How user supplied resume: "upload" | "paste" (for Back navigation from tone step). */
let onboardingResumePath = null;

// 4 steps: 1=resume, 2=role chips (Gemini-suggested), 3=AI context, 4=tone.
// Step 2 is the "delight + don't pigeonhole" stage — it asks Gemini for
// adjacent + lateral career suggestions so users with one-track resumes
// don't accidentally narrow the discovery algorithm to that single track.
const ONBOARDING_TOTAL_STEPS = 4;
let lastResumeGenerationSession = null;
let pendingDraftNotesRequest = null;
let candidateProfileMatchCache = {
  loaded: false,
  rawText: "",
  normalizedText: "",
  tokenSet: new Set(),
};
let generatedDraftLibraryCache = {
  loaded: false,
  byId: new Map(),
  byJobKey: new Map(),
  byJobFeature: new Map(),
};
let atsScorecardState = {
  cacheKey: "",
  status: "idle", // idle | loading | success | error
  result: null,
  error: "",
  payload: null,
};
let resumeGenerateAtsRefreshTimer = null;

function getUserContent() {
  return window.CommandCenterUserContent;
}

function getResumeBundle() {
  return window.CommandCenterResumeBundle;
}

function getResumeGenerate() {
  return window.CommandCenterResumeGenerate;
}

function getResumeIngest() {
  return window.CommandCenterResumeIngest;
}

/**
 * Async variant of getResumeIngest that waits up to ~3s for the resume-ingest
 * module + its CDN-loaded dependencies (pdf.js, mammoth) to be ready.
 *
 * Why this exists: pdf.js and mammoth are pulled from CDNs in <script> tags
 * without async/defer. On most loads they're synchronously ready before
 * DOMContentLoaded, but on cold caches or slow links they can finish a few
 * hundred ms later. The onboarding file-input change handler used to call
 * the sync getter directly and fail with "Resume reader didn't load" on the
 * first pick — which the user reported as "I have to refresh the page in
 * order for the file selector to successfully put the file visibly into the
 * UX". Waiting briefly fixes that without a refresh.
 *
 * Retries every 100ms (~30 polls) before giving up; immediate-resolve when
 * ready so the common fast path adds zero latency.
 */
async function getResumeIngestReady(maxWaitMs) {
  const limitMs = typeof maxWaitMs === "number" ? maxWaitMs : 3000;
  const stepMs = 100;
  const start = Date.now();
  let ingest = window.CommandCenterResumeIngest;
  while (!ingest && Date.now() - start < limitMs) {
    await new Promise((resolve) => setTimeout(resolve, stepMs));
    ingest = window.CommandCenterResumeIngest;
  }
  return ingest || null;
}

function getJobOpportunityKey(job) {
  const UC = getUserContent();
  if (UC && typeof UC.makeJobOpportunityKey === "function") {
    return UC.makeJobOpportunityKey(job);
  }
  const o = job && typeof job === "object" ? job : {};
  return [
    String(o.link || o.url || "")
      .trim()
      .toLowerCase() ||
      [
        String(o.company || "")
          .trim()
          .toLowerCase(),
        String(o.title || "")
          .trim()
          .toLowerCase(),
        String(o.location || "")
          .trim()
          .toLowerCase(),
      ].join("::"),
  ].join("");
}

function getDraftFeatureLabel(feature) {
  return feature === "resume_update" ? "Resume" : "Cover letter";
}

function getDraftModeLabel(mode) {
  return mode === "refine" ? "Refined" : "Initial";
}

function formatDraftSavedAt(iso) {
  if (!iso) return "Saved";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "Saved";
  return d.toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

function rebuildGeneratedDraftLibraryCache(rows) {
  const byId = new Map();
  const byJobKey = new Map();
  const byJobFeature = new Map();
  (rows || []).forEach((draft) => {
    byId.set(draft.id, draft);
    const jobArr = byJobKey.get(draft.jobKey) || [];
    jobArr.push(draft);
    byJobKey.set(draft.jobKey, jobArr);
    const featureKey = `${draft.jobKey}::${draft.feature}`;
    const featureArr = byJobFeature.get(featureKey) || [];
    featureArr.push(draft);
    byJobFeature.set(featureKey, featureArr);
  });
  byJobKey.forEach((arr, key) => {
    arr.sort((a, b) => (b.createdAt || "").localeCompare(a.createdAt || ""));
    byJobKey.set(key, arr);
  });
  byJobFeature.forEach((arr, key) => {
    arr.sort((a, b) => (b.createdAt || "").localeCompare(a.createdAt || ""));
    byJobFeature.set(key, arr);
  });
  generatedDraftLibraryCache = {
    loaded: true,
    byId,
    byJobKey,
    byJobFeature,
  };
  return generatedDraftLibraryCache;
}

async function refreshGeneratedDraftLibraryCache() {
  const UC = getUserContent();
  if (!UC || typeof UC.listGeneratedDrafts !== "function") {
    return rebuildGeneratedDraftLibraryCache([]);
  }
  try {
    await UC.openDb();
    const drafts = await UC.listGeneratedDrafts();
    return rebuildGeneratedDraftLibraryCache(drafts);
  } catch (err) {
    console.warn("[JobBored] generated drafts:", err);
    return rebuildGeneratedDraftLibraryCache([]);
  }
}

function scheduleGeneratedDraftLibraryRefresh(shouldRender) {
  void refreshGeneratedDraftLibraryCache().then(() => {
    if (!shouldRender) return;
    renderPipeline();
    if (activeDetailKey >= 0) refreshDrawerIfOpen(activeDetailKey);
  });
}

function getDraftsForJob(job, feature) {
  const jobKey = getJobOpportunityKey(job);
  if (!jobKey) return [];
  if (feature) {
    return (
      generatedDraftLibraryCache.byJobFeature.get(`${jobKey}::${feature}`) || []
    );
  }
  return generatedDraftLibraryCache.byJobKey.get(jobKey) || [];
}

function getDraftByIdFromCache(id) {
  return generatedDraftLibraryCache.byId.get(id) || null;
}

async function buildCandidateProfileExcerpt(UC, maxChars) {
  const hardMax =
    Number.isFinite(maxChars) && maxChars > 0 ? Math.floor(maxChars) : 14000;
  const active = await UC.getActiveResume();
  const linkedIn =
    typeof UC.getLinkedInProfile === "function"
      ? await UC.getLinkedInProfile()
      : { text: "", updatedAt: "" };
  const additional =
    typeof UC.getAdditionalContext === "function"
      ? await UC.getAdditionalContext()
      : { text: "", updatedAt: "" };
  const resumeText =
    active && active.extractedText ? String(active.extractedText).trim() : "";
  const linkedInText =
    linkedIn && linkedIn.text ? String(linkedIn.text).trim() : "";
  const additionalText =
    additional && additional.text ? String(additional.text).trim() : "";

  const sections = [];
  if (resumeText) {
    sections.push(`Resume text:\n${resumeText}`);
  }
  if (linkedInText) {
    sections.push(`LinkedIn / online profile text:\n${linkedInText}`);
  }
  if (additionalText) {
    sections.push(`AI context dump (professional notes):\n${additionalText}`);
  }
  if (!sections.length) return "";
  const joined = sections.join("\n\n");
  if (joined.length <= hardMax) return joined;
  return joined.slice(0, hardMax);
}

const KEYWORD_STOP_WORDS = new Set([
  "a",
  "an",
  "and",
  "are",
  "as",
  "at",
  "be",
  "by",
  "for",
  "from",
  "in",
  "into",
  "of",
  "on",
  "or",
  "the",
  "to",
  "with",
  "using",
  "your",
  "our",
  "their",
  "you",
  "we",
  "will",
  "have",
  "has",
  "had",
  "this",
  "that",
  "these",
  "those",
  "years",
  "year",
  "plus",
  "strong",
  "ability",
  "abilities",
  "experience",
  "experienced",
  "knowledge",
  "understanding",
  "background",
  "preferred",
  "required",
  "requirement",
  "requirements",
]);

const KEYWORD_ALIAS_GROUPS = [
  ["javascript", "js"],
  ["typescript", "ts"],
  ["nodejs", "node js", "node.js"],
  ["react", "reactjs", "react.js"],
  ["ci cd", "ci/cd", "continuous integration", "continuous delivery"],
  ["machine learning", "ml"],
  ["artificial intelligence", "ai"],
  ["kubernetes", "k8s"],
  ["postgresql", "postgres"],
  ["amazon web services", "aws"],
  ["google cloud platform", "gcp", "google cloud"],
  ["microsoft azure", "azure"],
];

function normalizeKeywordSearchText(text) {
  let s = String(text || "").toLowerCase();
  s = s.replace(/\bc\+\+\b/g, "cplusplus");
  s = s.replace(/\bc#\b/g, "csharp");
  s = s.replace(/\bci\/cd\b/g, "ci cd");
  s = s.replace(/\bnode\.js\b/g, "nodejs");
  s = s.replace(/\breact\.js\b/g, "react");
  s = s.replace(/&/g, " and ");
  s = s.replace(/[’']/g, "");
  s = s.replace(/[^a-z0-9+#.%/\-\s]+/g, " ");
  s = s.replace(/\s+/g, " ").trim();
  return s;
}

function buildKeywordSearchIndex(text) {
  const normalizedText = normalizeKeywordSearchText(text);
  return {
    rawText: String(text || ""),
    normalizedText,
    tokenSet: new Set(normalizedText.split(" ").filter(Boolean)),
  };
}

function keywordTextContainsPhrase(normalizedHaystack, normalizedNeedle) {
  const hay = ` ${String(normalizedHaystack || "")} `;
  const needle = ` ${String(normalizedNeedle || "").trim()} `;
  return !!needle.trim() && hay.includes(needle);
}

function searchIndexHasToken(searchIndex, token) {
  const tokenSet =
    searchIndex && searchIndex.tokenSet instanceof Set
      ? searchIndex.tokenSet
      : new Set();
  if (!token) return false;
  if (tokenSet.has(token)) return true;
  if (token.endsWith("ies") && tokenSet.has(`${token.slice(0, -3)}y`)) {
    return true;
  }
  if (token.endsWith("s") && tokenSet.has(token.slice(0, -1))) return true;
  if (tokenSet.has(`${token}s`)) return true;
  return false;
}

function getSignificantKeywordTokens(text) {
  return normalizeKeywordSearchText(text)
    .split(" ")
    .filter(Boolean)
    .filter((token) => token.length > 1 || /\d/.test(token))
    .filter((token) => !KEYWORD_STOP_WORDS.has(token));
}

function expandKeywordVariants(text) {
  const base = normalizeKeywordSearchText(text);
  const variants = new Set(base ? [base] : []);
  KEYWORD_ALIAS_GROUPS.forEach((group) => {
    const normalizedGroup = group
      .map((v) => normalizeKeywordSearchText(v))
      .filter(Boolean);
    if (
      normalizedGroup.some((variant) =>
        keywordTextContainsPhrase(base, variant),
      )
    ) {
      normalizedGroup.forEach((variant) => variants.add(variant));
    }
  });
  if (keywordTextContainsPhrase(base, "product manager")) {
    variants.add("product management");
  }
  if (keywordTextContainsPhrase(base, "product management")) {
    variants.add("product manager");
  }
  return [...variants];
}

function stripRequirementLeadIn(text) {
  return String(text || "")
    .replace(/^(must[-\s]?have|required|requirements?)\s*[:\-]\s*/i, "")
    .replace(
      /^(?:\d+\+?\s+years?\s+of\s+)?(?:experience|expertise|proficiency|knowledge|familiarity|background|ability|comfortable|comfort|track record)\s+(?:with|in|using|building|leading|managing|supporting|to)\s+/i,
      "",
    )
    .trim();
}

function collectSearchTermsFromTextItem(text, category) {
  const cleaned = String(text || "")
    .replace(/^[•*\-]\s*/, "")
    .replace(/\s+/g, " ")
    .trim();
  if (!cleaned) return [];
  const phrases = new Set();
  const maybeAdd = (candidate) => {
    const label = String(candidate || "")
      .replace(/^[•*\-]\s*/, "")
      .replace(/^[,:;\-\s]+|[,:;\-\s]+$/g, "")
      .trim();
    if (!label) return;
    const normalized = normalizeKeywordSearchText(label);
    if (!normalized) return;
    const tokens = getSignificantKeywordTokens(label);
    const wordCount = normalized.split(" ").filter(Boolean).length;
    if (category === "requirements" && wordCount > 8 && tokens.length > 3) {
      return;
    }
    if (!tokens.length && wordCount > 3) return;
    phrases.add(label);
  };

  if (category !== "requirements" || cleaned.split(/\s+/).length <= 8) {
    maybeAdd(cleaned);
  }

  const stripped = stripRequirementLeadIn(cleaned);
  stripped
    .split(/[;,|]/)
    .flatMap((part) => part.split(/\b(?:and|or)\b/gi))
    .map((part) => part.trim())
    .forEach(maybeAdd);

  return [...phrases];
}

function collectJobKeywordGroups(job) {
  const enr = job && job._postingEnrichment;
  const empty = {
    mustHaves: [],
    skills: [],
    toolsAndStack: [],
    requirements: [],
    all: [],
  };
  if (!enr) return empty;
  const groups = {};
  const defs = [
    { key: "mustHaves", limit: 20 },
    { key: "skills", limit: 24 },
    { key: "toolsAndStack", limit: 24 },
    { key: "requirements", limit: 20 },
  ];
  defs.forEach(({ key, limit }) => {
    const map = new Map();
    const arr = Array.isArray(enr[key]) ? enr[key] : [];
    arr.forEach((item) => {
      collectSearchTermsFromTextItem(item, key).forEach((termLabel) => {
        const normalized = normalizeKeywordSearchText(termLabel);
        if (!normalized || map.has(normalized)) return;
        map.set(normalized, {
          label:
            termLabel.length > 72
              ? `${termLabel.slice(0, 69).trim()}…`
              : termLabel,
          fullLabel: termLabel,
          normalized,
          variants: expandKeywordVariants(termLabel),
          tokens: getSignificantKeywordTokens(termLabel),
          category: key,
        });
      });
    });
    groups[key] = [...map.values()].slice(0, limit);
  });
  groups.all = [
    ...groups.mustHaves,
    ...groups.skills,
    ...groups.toolsAndStack,
    ...groups.requirements,
  ];
  return groups;
}

function evaluateKeywordTerm(term, searchIndex) {
  const normalizedText =
    searchIndex && typeof searchIndex.normalizedText === "string"
      ? searchIndex.normalizedText
      : "";
  const variants =
    term && Array.isArray(term.variants) && term.variants.length
      ? term.variants
      : [term.normalized];
  const exact = variants.some((variant) =>
    keywordTextContainsPhrase(normalizedText, variant),
  );
  const tokenMatches = (term.tokens || []).filter((token) =>
    searchIndexHasToken(searchIndex, token),
  );
  let status = "missing";
  if (
    exact ||
    ((term.tokens || []).length && tokenMatches.length === term.tokens.length)
  ) {
    status = "found";
  } else if (
    tokenMatches.length &&
    tokenMatches.length >=
      Math.max(1, Math.ceil((term.tokens || []).length / 2))
  ) {
    status = "partial";
  }
  return {
    ...term,
    status,
  };
}

function analyzeKeywordGroupsAgainstText(groups, text) {
  const searchIndex = buildKeywordSearchIndex(text);
  const analyzed = {
    mustHaves: (groups.mustHaves || []).map((term) =>
      evaluateKeywordTerm(term, searchIndex),
    ),
    skills: (groups.skills || []).map((term) =>
      evaluateKeywordTerm(term, searchIndex),
    ),
    toolsAndStack: (groups.toolsAndStack || []).map((term) =>
      evaluateKeywordTerm(term, searchIndex),
    ),
    requirements: (groups.requirements || []).map((term) =>
      evaluateKeywordTerm(term, searchIndex),
    ),
  };
  const deduped = new Map();
  [
    ...analyzed.mustHaves,
    ...analyzed.skills,
    ...analyzed.toolsAndStack,
    ...analyzed.requirements,
  ].forEach((term) => {
    const prev = deduped.get(term.normalized);
    const rank =
      term.status === "found" ? 2 : term.status === "partial" ? 1 : 0;
    const prevRank = !prev
      ? -1
      : prev.status === "found"
        ? 2
        : prev.status === "partial"
          ? 1
          : 0;
    if (!prev || rank > prevRank) deduped.set(term.normalized, term);
  });
  const uniqueTerms = [...deduped.values()];
  const foundCount = uniqueTerms.filter(
    (term) => term.status === "found",
  ).length;
  const partialCount = uniqueTerms.filter(
    (term) => term.status === "partial",
  ).length;
  const missingTerms = uniqueTerms.filter((term) => term.status === "missing");
  const percentage = uniqueTerms.length
    ? Math.round(((foundCount + partialCount * 0.5) / uniqueTerms.length) * 100)
    : 0;
  return {
    groups: analyzed,
    uniqueTerms,
    foundCount,
    partialCount,
    missingTerms,
    totalTerms: uniqueTerms.length,
    percentage,
  };
}

function sortTermsForDisplay(terms) {
  const order = { missing: 0, partial: 1, found: 2 };
  return [...(terms || [])].sort((a, b) => {
    const statusDelta = (order[a.status] ?? 9) - (order[b.status] ?? 9);
    if (statusDelta !== 0) return statusDelta;
    return String(a.label || "").localeCompare(String(b.label || ""));
  });
}

function renderMatchItemsHtml(terms, itemClassName) {
  const cls = itemClassName || "match-checklist__item";
  return sortTermsForDisplay(terms)
    .map((term) => {
      const label = term.label || term.fullLabel || "";
      return `<li class="${cls} ${cls}--${escapeHtml(term.status)}"><span class="${cls}__status" aria-hidden="true"></span><span class="${cls}__label">${escapeHtml(label)}</span><span class="${cls}__meta">${term.status === "found" ? "Found" : term.status === "partial" ? "Partial" : "Missing"}</span></li>`;
    })
    .join("");
}

function renderProfileMatchBadgeHtml(job, dataIndex) {
  const groups = collectJobKeywordGroups(job);
  const hasTerms =
    groups.mustHaves.length ||
    groups.skills.length ||
    groups.toolsAndStack.length;
  if (!hasTerms) return "";

  if (!candidateProfileMatchCache.loaded) {
    return `<div class="profile-match-badge profile-match-badge--loading" aria-label="Profile match loading">
      <div class="profile-match-badge__ring profile-match-badge__ring--empty">
        <span class="profile-match-badge__pct">…</span>
      </div>
      <div class="profile-match-badge__text">
        <span class="profile-match-badge__label">Profile match</span>
        <span class="profile-match-badge__hint">Loading your profile…</span>
      </div>
    </div>`;
  }

  if (!candidateProfileMatchCache.rawText.trim()) {
    return `<div class="profile-match-badge profile-match-badge--empty" aria-label="Profile match unavailable">
      <div class="profile-match-badge__ring profile-match-badge__ring--empty">
        <span class="profile-match-badge__pct">–</span>
      </div>
      <div class="profile-match-badge__text">
        <span class="profile-match-badge__label">Profile match</span>
        <span class="profile-match-badge__hint">Add resume in Profile to see fit</span>
      </div>
    </div>`;
  }

  const analysis = analyzeKeywordGroupsAgainstText(
    {
      mustHaves: groups.mustHaves,
      skills: groups.skills,
      toolsAndStack: groups.toolsAndStack,
      requirements: [],
      all: [...groups.mustHaves, ...groups.skills, ...groups.toolsAndStack],
    },
    candidateProfileMatchCache.rawText,
  );
  const pct = analysis.percentage;
  const ringClass =
    pct >= 70
      ? "profile-match-badge__ring--high"
      : pct >= 40
        ? "profile-match-badge__ring--mid"
        : "profile-match-badge__ring--low";
  const hint =
    analysis.missingTerms.length > 0
      ? `${analysis.missingTerms.length} gap${analysis.missingTerms.length !== 1 ? "s" : ""} · click to review`
      : "Strong match · click to review";

  return `<button type="button" class="profile-match-badge" data-action="open-profile-match" data-index="${dataIndex}" aria-label="Profile match ${pct}% — click to see breakdown">
    <div class="profile-match-badge__ring ${ringClass}">
      <span class="profile-match-badge__pct">${pct}%</span>
    </div>
    <div class="profile-match-badge__text">
      <span class="profile-match-badge__label">Profile match</span>
      <span class="profile-match-badge__hint">${escapeHtml(hint)}</span>
    </div>
    <svg class="profile-match-badge__chevron" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 18 15 12 9 6"/></svg>
  </button>`;
}

function openProfileMatchModal(job, dataIndex) {
  const existing = document.getElementById("profileMatchModal");
  if (existing) existing.remove();

  const content = renderProfileMatchSectionHtml(job);
  if (!content) return;

  const title = escapeHtml(`${job.title || "Role"} · ${job.company || ""}`);
  const overlay = document.createElement("div");
  overlay.className = "modal-overlay profile-match-modal-overlay";
  overlay.id = "profileMatchModal";
  overlay.innerHTML = `
    <div class="profile-match-modal" role="dialog" aria-modal="true" aria-label="Profile match breakdown">
      <div class="profile-match-modal__head">
        <div class="profile-match-modal__title-group">
          <p class="profile-match-modal__kicker">Profile match</p>
          <h3 class="profile-match-modal__title">${title}</h3>
        </div>
        <button type="button" class="profile-match-modal__close" data-action="close-profile-match" aria-label="Close">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
      </div>
      <div class="profile-match-modal__body">
        ${content}
      </div>
    </div>`;

  document.body.appendChild(overlay);

  const close = () => overlay.remove();
  overlay
    .querySelector('[data-action="close-profile-match"]')
    .addEventListener("click", close);
  overlay.addEventListener("click", (e) => {
    if (e.target === overlay) close();
  });
  const onKey = (e) => {
    if (e.key === "Escape") {
      close();
      document.removeEventListener("keydown", onKey);
    }
  };
  document.addEventListener("keydown", onKey);
}

function renderProfileMatchSectionHtml(job) {
  const groups = collectJobKeywordGroups(job);
  const hasTerms =
    groups.mustHaves.length ||
    groups.skills.length ||
    groups.toolsAndStack.length;
  if (!hasTerms) return "";
  if (!candidateProfileMatchCache.loaded) {
    return `<section class="profile-match-card"><div class="profile-match-card__head"><div><p class="profile-match-card__kicker">Profile match</p><h4 class="profile-match-card__title">Comparing your profile to the role</h4></div></div><p class="profile-match-card__summary">Loading your resume, LinkedIn, and AI context…</p></section>`;
  }
  if (!candidateProfileMatchCache.rawText.trim()) {
    return `<section class="profile-match-card"><div class="profile-match-card__head"><div><p class="profile-match-card__kicker">Profile match</p><h4 class="profile-match-card__title">Comparing your profile to the role</h4></div></div><p class="profile-match-card__summary">Add resume, LinkedIn, or AI context in Profile to see the job-fit gap instantly.</p></section>`;
  }
  const analysis = analyzeKeywordGroupsAgainstText(
    {
      mustHaves: groups.mustHaves,
      skills: groups.skills,
      toolsAndStack: groups.toolsAndStack,
      requirements: [],
      all: [...groups.mustHaves, ...groups.skills, ...groups.toolsAndStack],
    },
    candidateProfileMatchCache.rawText,
  );
  const summary =
    analysis.totalTerms > 0
      ? `${analysis.foundCount} found · ${analysis.partialCount} partial · ${analysis.missingTerms.length} missing`
      : "No structured keywords available yet.";
  const missingPreview = analysis.missingTerms
    .slice(0, 4)
    .map((term) => term.label)
    .join(", ");
  return `<section class="profile-match-card"><div class="profile-match-card__head"><div><p class="profile-match-card__kicker">Profile match</p><h4 class="profile-match-card__title">Comparing your profile to the role</h4></div><div class="profile-match-card__score">${analysis.percentage}%</div></div><p class="profile-match-card__summary">${escapeHtml(summary)}</p>${missingPreview ? `<p class="profile-match-card__hint">Gap to close: ${escapeHtml(missingPreview)}</p>` : ""}<div class="profile-match-card__groups">${groups.mustHaves.length ? `<div class="profile-match-card__group"><p class="profile-match-card__group-label">Must-haves</p><ul class="match-checklist">${renderMatchItemsHtml(analysis.groups.mustHaves, "match-checklist__item")}</ul></div>` : ""}${groups.skills.length ? `<div class="profile-match-card__group"><p class="profile-match-card__group-label">Skills</p><ul class="match-checklist">${renderMatchItemsHtml(analysis.groups.skills, "match-checklist__item")}</ul></div>` : ""}${groups.toolsAndStack.length ? `<div class="profile-match-card__group"><p class="profile-match-card__group-label">Tools &amp; stack</p><ul class="match-checklist">${renderMatchItemsHtml(analysis.groups.toolsAndStack, "match-checklist__item")}</ul></div>` : ""}</div></section>`;
}

function renderDraftDeckPanel(job, feature) {
  if (!generatedDraftLibraryCache.loaded) {
    return `<p class="draft-deck__empty">…</p>`;
  }
  const drafts = getDraftsForJob(job, feature)
    .slice()
    .sort(
      (a, b) => Number(a.versionNumber || 0) - Number(b.versionNumber || 0),
    );
  if (!drafts.length) {
    return `<p class="draft-deck__empty">None yet — generate using the buttons above</p>`;
  }
  const activeIdx = drafts.length - 1; // newest version on top
  const cards = drafts
    .map((d, i) => {
      const rel = activeIdx - i; // 0=front, 1=back-1, 2=back-2, >2=hidden
      const depthClass =
        rel === 0
          ? "draft-deck__card--front"
          : rel === 1
            ? "draft-deck__card--back-1"
            : rel === 2
              ? "draft-deck__card--back-2"
              : "draft-deck__card--hidden";
      const vLabel = `V${Number(d.versionNumber || 0)}`;
      const modeLabel = d.mode === "refine" ? "Refined" : "Initial";
      const excerpt = (d.excerpt || "").slice(0, 110);
      return `<button type="button"
        class="draft-deck__card ${depthClass}"
        data-action="open-draft-version"
        data-draft-id="${escapeHtml(d.id)}"
        data-deck-idx="${i}"
        tabindex="${rel === 0 ? 0 : -1}">
        <span class="draft-deck__card-meta">${escapeHtml(vLabel)} · ${escapeHtml(modeLabel)}</span>
        <span class="draft-deck__card-date">${escapeHtml(formatDraftSavedAt(d.createdAt))}</span>
        <p class="draft-deck__card-excerpt">${escapeHtml(excerpt)}${(d.excerpt || "").length > 110 ? "…" : ""}</p>
      </button>`;
    })
    .join("");
  const nav =
    drafts.length > 1
      ? `<div class="draft-deck__nav">
          <button type="button" class="draft-deck__chevron" data-action="draft-deck-shift" data-dir="-1" aria-label="Previous version" title="Previous version">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="15 18 9 12 15 6"/></svg>
          </button>
          <span class="draft-deck__position" data-role="draft-position">V${activeIdx + 1} of ${drafts.length}</span>
          <button type="button" class="draft-deck__chevron" data-action="draft-deck-shift" data-dir="1" aria-label="Next version" title="Next version">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 18 15 12 9 6"/></svg>
          </button>
        </div>`
      : "";
  return `<div class="draft-deck__stack" data-active-idx="${activeIdx}" data-total="${drafts.length}">${cards}</div>${nav}`;
}

function renderDraftLibraryCardHtml(job, dataIndex) {
  const clDrafts = generatedDraftLibraryCache.loaded
    ? getDraftsForJob(job, "cover_letter")
    : [];
  const reDrafts = generatedDraftLibraryCache.loaded
    ? getDraftsForJob(job, "resume_update")
    : [];
  const clCount = clDrafts.length;
  const reCount = reDrafts.length;
  const total = clCount + reCount;
  const countBadge =
    generatedDraftLibraryCache.loaded && total
      ? `<span class="draft-deck__count">${total}</span>`
      : "";
  return `<section class="draft-deck" data-index="${dataIndex}">
    <div class="draft-deck__head">
      <p class="draft-deck__kicker">Draft studio</p>
      ${countBadge}
    </div>
    <div class="draft-deck__tabs">
      <button type="button" class="draft-deck__tab draft-deck__tab--active" data-action="draft-tab" data-feature="cover_letter">
        Cover letter${clCount ? `<span class="draft-deck__tab-badge">${clCount}</span>` : ""}
      </button>
      <button type="button" class="draft-deck__tab" data-action="draft-tab" data-feature="resume_update">
        Resume${reCount ? `<span class="draft-deck__tab-badge">${reCount}</span>` : ""}
      </button>
    </div>
    <div class="draft-deck__panels">
      <div class="draft-deck__panel draft-deck__panel--active" data-feature="cover_letter">
        ${renderDraftDeckPanel(job, "cover_letter")}
      </div>
      <div class="draft-deck__panel" data-feature="resume_update">
        ${renderDraftDeckPanel(job, "resume_update")}
      </div>
    </div>
  </section>`;
}

async function refreshCandidateProfileMatchCache() {
  const UC = getUserContent();
  const Bundle = getResumeBundle();
  if (!UC || !Bundle || typeof Bundle.assembleProfile !== "function") {
    candidateProfileMatchCache = {
      loaded: true,
      rawText: "",
      normalizedText: "",
      tokenSet: new Set(),
    };
    return candidateProfileMatchCache;
  }
  try {
    await UC.openDb();
    const profile = await Bundle.assembleProfile(UC);
    const rawText = [
      profile.resumeText || "",
      profile.linkedinProfileText || "",
      profile.additionalContextText || "",
    ]
      .map((part) => String(part || "").trim())
      .filter(Boolean)
      .join("\n\n");
    candidateProfileMatchCache = {
      loaded: true,
      ...buildKeywordSearchIndex(rawText),
    };
  } catch (err) {
    console.warn("[JobBored] profile match cache:", err);
    candidateProfileMatchCache = {
      loaded: true,
      rawText: "",
      normalizedText: "",
      tokenSet: new Set(),
    };
  }
  return candidateProfileMatchCache;
}

function scheduleCandidateProfileMatchRefresh(shouldRender) {
  void refreshCandidateProfileMatchCache().then(() => {
    if (!shouldRender) return;
    renderPipeline();
    if (activeDetailKey >= 0) refreshDrawerIfOpen(activeDetailKey);
  });
}

async function fetchJobPostingEnrichment(dataIndex) {
  const job = pipelineData[dataIndex];
  if (!job || !job.link) {
    showToast("No job URL to scrape", "error");
    return;
  }
  const base = getJobPostingScrapeUrl();
  if (!base) {
    showToast(
      "Open the setup guide to start the Cheerio server and paste the URL.",
      "error",
    );
    openScraperSetupModal();
    return;
  }
  if (isScraperUrlBlockedOnThisPage(base)) {
    showToast(SCRAPER_HTTPS_BLOCKED_HINT, "error", true);
    openScraperSetupModal();
    return;
  }

  job._enrichmentLoading = true;
  refreshDrawerIfOpen(dataIndex);
  const _abortCtrl = new AbortController();
  const _abortTimer = setTimeout(() => _abortCtrl.abort(), 30_000);
  try {
    const res = await fetch(`${base}/api/scrape-job`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: job.link }),
      signal: _abortCtrl.signal,
    });
    clearTimeout(_abortTimer);
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      throw new Error(data.error || `HTTP ${res.status}`);
    }
    const scraped = {
      ...data,
      scrapedAt: Date.now(),
    };
    let merged = { ...scraped };
    if (
      window.CommandCenterJobPostingInsights &&
      window.CommandCenterJobPostingInsights.canEnrichWithLLM()
    ) {
      try {
        let profileExcerpt = "";
        const UC = getUserContent();
        if (UC) {
          await UC.openDb();
          profileExcerpt = await buildCandidateProfileExcerpt(UC, 14000);
        }
        const llm =
          await window.CommandCenterJobPostingInsights.enrichFromScrape(
            scraped,
            { title: job.title, company: job.company },
            profileExcerpt,
          );
        merged = {
          ...merged,
          // Clean LLM-extracted structured fields used by the paste-to-Pipeline
          // auto-promotion path to patch B/C/D cells in place of the URL-only
          // placeholders ("View" / "linkedin.com" / etc.). Empty strings when
          // the LLM cannot determine a value.
          inferredTitle: llm.inferredTitle,
          inferredCompany: llm.inferredCompany,
          inferredLocation: llm.inferredLocation,
          postingSummary: llm.postingSummary,
          roleInOneLine: llm.roleInOneLine,
          mustHaves: llm.mustHaves,
          niceToHaves: llm.niceToHaves,
          responsibilities: llm.responsibilities,
          toolsAndStack: llm.toolsAndStack,
          fitAngle: llm.fitAngle,
          talkingPoints: llm.talkingPoints,
          extraKeywords: llm.extraKeywords,
        };
      } catch (e) {
        console.warn("[JobBored] Posting LLM enrich:", e);
        merged.llmError = e.message || "AI insight failed";
      }
    }
    job._postingEnrichment = merged;
    cacheEnrichment(job.link, merged);
    renderPipeline();
    showToast("Posting details loaded", "success");
  } catch (e) {
    console.error(e);
    const errMsg = String((e && e.message) || "");
    // Upstream site blocked the scraper (LinkedIn/Indeed/Glassdoor/etc.
    // returning 401/403/429). This is expected for known-blocked
    // aggregators; do NOT surface as an error toast. Instead try the
    // LLM with what we already have from the sheet — for many
    // postings the title + company alone is enough for Gemini to
    // produce a useful role summary.
    const isUpstreamBlock = /\bHTTP\s+(401|403|429)\b/i.test(errMsg);
    if (isFetchNetworkError(e)) {
      showToast(
        `Can't reach the scraper at ${base}. From the project folder run: npm install && npm start — keep that terminal open, then try again.`,
        "error",
        true,
      );
      openScraperSetupModal();
    } else if (isUpstreamBlock) {
      await fallbackEnrichmentFromSheetOnly(job, dataIndex, errMsg);
    } else {
      showToast(e.message || "Could not fetch posting", "error");
    }
  } finally {
    clearTimeout(_abortTimer);
    delete job._enrichmentLoading;
    refreshDrawerIfOpen(dataIndex);
  }
}

// When the upstream job site blocks the scraper (LinkedIn/Indeed/etc.
// returning 401/403/429), fall back to the LLM using only the sheet-
// stored title + company + URL. The response won't have a real job
// description but the LLM can still produce a useful role summary from
// the role+company context. Caches the result so the drawer doesn't
// retry the scrape on every open.
async function fallbackEnrichmentFromSheetOnly(job, dataIndex, errMsg) {
  const stub = {
    title: job.title || "",
    description: "",
    requirements: [],
    skills: [],
    scrapedAt: Date.now(),
    _scrapeBlocked: true,
    _scrapeError: errMsg || "upstream blocked scraper",
  };
  let merged = { ...stub };
  if (
    window.CommandCenterJobPostingInsights &&
    window.CommandCenterJobPostingInsights.canEnrichWithLLM()
  ) {
    try {
      let profileExcerpt = "";
      const UC = getUserContent();
      if (UC) {
        await UC.openDb();
        profileExcerpt = await buildCandidateProfileExcerpt(UC, 14000);
      }
      const llm = await window.CommandCenterJobPostingInsights.enrichFromScrape(
        stub,
        { title: job.title, company: job.company },
        profileExcerpt,
      );
      merged = {
        ...merged,
        inferredTitle: llm.inferredTitle,
        inferredCompany: llm.inferredCompany,
        inferredLocation: llm.inferredLocation,
        postingSummary: llm.postingSummary,
        roleInOneLine: llm.roleInOneLine,
        mustHaves: llm.mustHaves,
        niceToHaves: llm.niceToHaves,
        responsibilities: llm.responsibilities,
        toolsAndStack: llm.toolsAndStack,
        fitAngle: llm.fitAngle,
        talkingPoints: llm.talkingPoints,
        extraKeywords: llm.extraKeywords,
      };
    } catch (llmErr) {
      console.warn("[JobBored] fallback LLM enrich:", llmErr);
      merged.llmError =
        (llmErr && llmErr.message) ||
        "AI insight failed (source blocks scrapers).";
    }
  }
  job._postingEnrichment = merged;
  cacheEnrichment(job.link, merged);
  renderPipeline();
  // Subtle info toast instead of the error toast the old path showed.
  showToast(
    "This site blocks scrapers — details below are inferred from title + company.",
    "info",
  );
}

/**
 * @param {File} file
 * @param {NonNullable<ReturnType<typeof getUserContent>>} UC
 */
async function profileApplyResumeFile(file, UC) {
  const ingest = getResumeIngest();
  if (!ingest) {
    showToast("Resume processing unavailable", "error");
    return;
  }
  try {
    const text = await ingest.extractTextFromFile(file);
    if (!String(text).trim()) {
      showToast("No text could be extracted from that file", "error");
      return;
    }
    const label =
      (file.name || "Resume").replace(/\.[^/.]+$/, "") || "My resume";
    await UC.setPrimaryResume({
      source: "file",
      rawMime: ingest.guessMime(file),
      label,
      extractedText: text,
    });
    await refreshMaterialsUI();
    showToast("Resume updated", "success");
  } catch (err) {
    console.error(err);
    showToast(err.message || "Could not read file", "error");
  }
}

/**
 * @param {FileList|File[]} fileList
 * @param {NonNullable<ReturnType<typeof getUserContent>>} UC
 */
async function profileApplySampleFiles(fileList, UC) {
  const ingest = getResumeIngest();
  if (!ingest) {
    showToast("File processing unavailable", "error");
    return;
  }
  const arr = Array.from(fileList || []).filter(Boolean);
  if (!arr.length) return;
  let added = 0;
  let failed = 0;
  for (const file of arr) {
    try {
      const text = await ingest.extractTextFromFile(file);
      if (!String(text).trim()) {
        failed++;
        continue;
      }
      const title =
        (file.name || "Sample").replace(/\.[^/.]+$/, "") || "Writing sample";
      await UC.addWritingSample({
        title,
        tags: [],
        extractedText: text,
      });
      added++;
    } catch (err) {
      console.warn(err);
      failed++;
    }
  }
  await refreshMaterialsUI();
  if (added === 1) showToast("Writing sample added", "success");
  else if (added > 1) showToast(`${added} samples added`, "success");
  if (!added && failed)
    showToast("Could not read those files — try PDF, Word, or .txt", "error");
  else if (failed && added) showToast("Some files could not be added", "info");
}

/**
 * @param {HTMLElement | null} zoneEl
 * @param {(files: FileList) => void} onFiles
 */
function bindProfileDropzone(zoneEl, onFiles) {
  if (!zoneEl) return;
  zoneEl.addEventListener("dragenter", (e) => {
    e.preventDefault();
    e.stopPropagation();
    zoneEl.classList.add("profile-dropzone--drag");
  });
  zoneEl.addEventListener("dragleave", (e) => {
    e.preventDefault();
    e.stopPropagation();
    const rel = e.relatedTarget;
    if (rel && zoneEl.contains(/** @type {Node} */ (rel))) return;
    zoneEl.classList.remove("profile-dropzone--drag");
  });
  zoneEl.addEventListener("dragover", (e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "copy";
  });
  zoneEl.addEventListener("drop", (e) => {
    e.preventDefault();
    e.stopPropagation();
    zoneEl.classList.remove("profile-dropzone--drag");
    const files = e.dataTransfer.files;
    if (files && files.length) onFiles(files);
  });
}

function renderLinkedInProfileMeta(text, updatedAt) {
  const chars = String(text || "").length;
  if (!chars) return "No LinkedIn profile text saved.";
  const updated = updatedAt ? new Date(updatedAt).toLocaleDateString() : "";
  return updated
    ? `${chars.toLocaleString()} chars saved · Updated ${updated}`
    : `${chars.toLocaleString()} chars saved`;
}

function renderAdditionalContextMeta(text, updatedAt) {
  const chars = String(text || "").length;
  if (!chars) return "No AI context dump saved.";
  const updated = updatedAt ? new Date(updatedAt).toLocaleDateString() : "";
  return updated
    ? `${chars.toLocaleString()} chars saved · Updated ${updated}`
    : `${chars.toLocaleString()} chars saved`;
}

const LINKEDIN_CAPTURE_FIELDS = [
  { id: "linkedInCaptureHeadline", label: "HEADLINE" },
  { id: "linkedInCaptureAbout", label: "ABOUT" },
  { id: "linkedInCaptureExperience", label: "EXPERIENCE" },
  { id: "linkedInCaptureSkills", label: "SKILLS" },
  { id: "linkedInCaptureEducation", label: "EDUCATION_AND_CERTIFICATIONS" },
  { id: "linkedInCaptureExtras", label: "EXTRA_HIGHLIGHTS" },
];

function normalizeProfileTextInput(raw) {
  const ingest = getResumeIngest();
  const text = raw != null ? String(raw) : "";
  return ingest && typeof ingest.normalizeExtractedText === "function"
    ? ingest.normalizeExtractedText(text)
    : text.trim();
}

function collectLinkedInCaptureSections() {
  return LINKEDIN_CAPTURE_FIELDS.map((f) => {
    const el = document.getElementById(f.id);
    return {
      label: f.label,
      text: normalizeProfileTextInput(el && el.value ? el.value : ""),
    };
  });
}

function buildLinkedInCaptureProfileText() {
  const sections = collectLinkedInCaptureSections().filter((s) => s.text);
  if (!sections.length) return "";
  const lines = [
    "LinkedIn profile capture (assisted)",
    `Captured at: ${new Date().toISOString()}`,
  ];
  sections.forEach((s) => {
    lines.push("");
    lines.push(s.label);
    lines.push(s.text);
  });
  return lines.join("\n");
}

function getLinkedInCaptureCompleteness() {
  const byId = {};
  collectLinkedInCaptureSections().forEach((s, i) => {
    byId[LINKEDIN_CAPTURE_FIELDS[i].id] = s.text;
  });
  const hasExperience = !!String(byId.linkedInCaptureExperience || "").trim();
  const hasSkills = !!String(byId.linkedInCaptureSkills || "").trim();
  return {
    hasExperience,
    hasSkills,
    canSave: hasExperience && hasSkills,
  };
}

function updateLinkedInCapturePreview() {
  const preview = document.getElementById("linkedInCapturePreview");
  const quality = document.getElementById("linkedInCaptureQuality");
  const saveBtn = document.getElementById("linkedInCaptureSaveBtn");
  const built = buildLinkedInCaptureProfileText();
  if (preview) preview.value = built;
  const c = getLinkedInCaptureCompleteness();
  if (saveBtn) saveBtn.disabled = !c.canSave;
  if (quality) {
    quality.classList.remove(
      "linkedincap-quality--ok",
      "linkedincap-quality--warn",
    );
    if (c.canSave) {
      quality.classList.add("linkedincap-quality--ok");
      quality.textContent =
        "Complete enough to save. Experience and Skills captured.";
    } else {
      quality.classList.add("linkedincap-quality--warn");
      quality.textContent =
        "Add both Experience and Skills before saving. These are required for high-quality tailoring.";
    }
  }
}

function openLinkedInCaptureModal() {
  const modal = document.getElementById("linkedInCaptureModal");
  if (!modal) return;
  const existing = document.getElementById("materialsLinkedInText");
  const extras = document.getElementById("linkedInCaptureExtras");
  if (
    existing &&
    extras &&
    extras.tagName === "TEXTAREA" &&
    !String(extras.value || "").trim() &&
    String(existing.value || "").trim()
  ) {
    extras.value = String(existing.value || "");
  }
  modal.style.display = "flex";
  updateLinkedInCapturePreview();
  document.getElementById("linkedInCaptureHeadline")?.focus();
}

function closeLinkedInCaptureModal() {
  const modal = document.getElementById("linkedInCaptureModal");
  if (modal) modal.style.display = "none";
}

/** Populate tone / templates / visual theme fields from stored preferences. */
function applyPreferencesFromData(prefs) {
  if (!prefs || typeof prefs !== "object") return;
  const toneEl = document.getElementById("prefTone");
  const mwEl = document.getElementById("prefMaxWords");
  const indEl = document.getElementById("prefIndustries");
  const avEl = document.getElementById("prefAvoid");
  const voEl = document.getElementById("prefVoice");
  const mergeEl = document.getElementById("prefMergePreference");
  if (toneEl) toneEl.value = prefs.tone || "warm";
  if (mwEl) mwEl.value = String(prefs.defaultMaxWords || 350);
  if (indEl) indEl.value = prefs.industriesToEmphasize || "";
  if (avEl) avEl.value = prefs.wordsToAvoid || "";
  if (voEl) voEl.value = prefs.voiceNotes || "";
  if (mergeEl) mergeEl.value = prefs.profileMergePreference || "merge";

  fillDocumentTemplateSelect(
    "prefCoverLetterTemplate",
    "cover_letter",
    prefs.coverLetterTemplateId,
  );
  fillDocumentTemplateSelect(
    "prefResumeTemplate",
    "resume_update",
    prefs.resumeTemplateId,
  );
  fillVisualThemeSelect("prefVisualTheme", prefs.visualThemeId);
}

async function refreshPersonalPreferencesPanel() {
  const UC = getUserContent();
  if (!UC) return;
  await UC.openDb();
  const prefs = await UC.getPreferences();
  applyPreferencesFromData(prefs);
}

async function refreshMaterialsUI() {
  const UC = getUserContent();
  const resumeMeta = document.getElementById("materialsResumeMeta");
  const resumeHero = document.getElementById("profileResumeDropHero");
  const resumeStatusWrap = document.getElementById("profileResumeStatusWrap");
  const resumeDropzone = document.getElementById("profileResumeDropzone");
  const listSamples = document.getElementById("materialsSamplesList");
  const linkedInTextEl = document.getElementById("materialsLinkedInText");
  const linkedInMetaEl = document.getElementById("materialsLinkedInMeta");
  const aiDumpTextEl = document.getElementById("materialsAiDumpText");
  const aiDumpMetaEl = document.getElementById("materialsAiDumpMeta");
  if (!UC || !listSamples) return;

  await UC.openDb();
  const primary = await UC.getActiveResume();
  const linkedInProfile =
    typeof UC.getLinkedInProfile === "function"
      ? await UC.getLinkedInProfile()
      : { text: "", updatedAt: "" };
  const additionalContext =
    typeof UC.getAdditionalContext === "function"
      ? await UC.getAdditionalContext()
      : { text: "", updatedAt: "" };
  const samples = await UC.listWritingSamples();
  const prefs = await UC.getPreferences();

  if (resumeMeta) {
    if (!primary || !String(primary.extractedText || "").trim()) {
      resumeMeta.innerHTML = "";
      if (resumeHero) resumeHero.hidden = false;
      if (resumeStatusWrap) resumeStatusWrap.hidden = true;
      if (resumeDropzone)
        resumeDropzone.classList.remove("profile-dropzone--has-file");
    } else {
      const created = primary.createdAt
        ? new Date(primary.createdAt).toLocaleDateString()
        : "";
      resumeMeta.innerHTML = `<strong>${escapeHtml(primary.label || "My resume")}</strong><span class="profile-meta-sep">·</span>${String(primary.extractedText || "").length.toLocaleString()} chars${created ? `<span class="profile-meta-sep">·</span>${escapeHtml(created)}` : ""}`;
      if (resumeHero) resumeHero.hidden = true;
      if (resumeStatusWrap) resumeStatusWrap.hidden = false;
      if (resumeDropzone)
        resumeDropzone.classList.add("profile-dropzone--has-file");
    }
  }

  listSamples.innerHTML =
    samples.length === 0
      ? ""
      : samples
          .map((s) => {
            const tags = (s.tags || []).join(", ");
            return `<div class="profile-sample-row" data-sample-id="${escapeHtml(s.id)}">
            <div class="profile-sample-row__main"><span class="profile-sample-title">${escapeHtml(s.title)}</span>${tags ? ` <span class="profile-sample-tags">${escapeHtml(tags)}</span>` : ""}</div>
            <button type="button" class="profile-sample-remove" data-delete-sample="${escapeHtml(s.id)}">Remove</button>
          </div>`;
          })
          .join("");

  applyPreferencesFromData(prefs);

  if (linkedInTextEl) {
    linkedInTextEl.value = linkedInProfile.text || "";
  }
  if (linkedInMetaEl) {
    linkedInMetaEl.textContent = renderLinkedInProfileMeta(
      linkedInProfile.text || "",
      linkedInProfile.updatedAt || "",
    );
  }
  if (aiDumpTextEl) {
    aiDumpTextEl.value = additionalContext.text || "";
  }
  if (aiDumpMetaEl) {
    aiDumpMetaEl.textContent = renderAdditionalContextMeta(
      additionalContext.text || "",
      additionalContext.updatedAt || "",
    );
  }

  listSamples.querySelectorAll("[data-delete-sample]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      await UC.deleteWritingSample(btn.dataset.deleteSample);
      await refreshMaterialsUI();
      showToast("Sample removed", "info");
    });
  });
  scheduleCandidateProfileMatchRefresh(true);
}

function openMaterialsModal() {
  closeAuthUserMenu();
  const modal = document.getElementById("materialsModal");
  if (modal) {
    modal.style.display = "flex";
    refreshMaterialsUI();
    const closeBtn = document.getElementById("materialsModalClose");
    if (closeBtn) closeBtn.focus();
  }
}

function closeMaterialsModal() {
  const modal = document.getElementById("materialsModal");
  if (modal) {
    modal.style.display = "none";
    document.getElementById("materialsBtn")?.focus();
  }
}

function isOnboardingWizardVisible() {
  const w = document.getElementById("onboardingWizard");
  return w && w.style.display === "flex";
}

function hideOnboardingWizard() {
  const w = document.getElementById("onboardingWizard");
  if (w) w.style.display = "none";
}

function showOnboardingWizard() {
  const w = document.getElementById("onboardingWizard");
  if (!w) return;
  onboardingResumeDraft = null;
  onboardingResumePath = null;
  const paste = document.getElementById("onboardingPasteText");
  const status = document.getElementById("onboardingResumeStatus");
  const statusUp = document.getElementById("onboardingResumeStatusUpload");
  const fileIn = document.getElementById("onboardingFileInput");
  const toneHidden = document.getElementById("wizardPrefTone");
  const mw = document.getElementById("wizardPrefMaxWords");
  const voice = document.getElementById("wizardPrefVoice");
  if (paste) paste.value = "";
  if (status) {
    status.textContent = "";
    status.classList.remove("onboarding-status--error");
  }
  if (statusUp) {
    statusUp.textContent = "";
    statusUp.classList.remove("onboarding-status--error");
    statusUp.classList.remove("onboarding-status--ok");
  }
  if (fileIn) fileIn.value = "";
  // Reset the Gemini-suggested careers panel so re-entry starts clean.
  // (Avoids stale chips/loading state if the user reopens the wizard.)
  try {
    onboardingResetSuggestState();
    onboardingSuggestRenderChips();
    onboardingSuggestSetStatus("", null);
    const addInput = document.getElementById("onboardingSuggestAddInput");
    if (addInput) addInput.value = "";
    const keyInput = document.getElementById("onboardingSuggestKeyInput");
    if (keyInput) keyInput.value = "";
    onboardingSuggestShowKeyGate(false);
  } catch (_) {
    /* defensive — function is defined below */
  }
  if (toneHidden) toneHidden.value = "warm";
  if (mw) mw.value = "350";
  if (voice) voice.value = "";
  const samplesIn = document.getElementById("onboardingSamplesFileInput");
  const samplesStatus = document.getElementById("onboardingSamplesStatus");
  const aiCtx = document.getElementById("onboardingAiContextText");
  if (samplesIn) samplesIn.value = "";
  if (samplesStatus) {
    samplesStatus.textContent = "";
    samplesStatus.classList.remove("onboarding-status--error");
  }
  if (aiCtx) aiCtx.value = "";
  // onboardingAiTarget was removed in the Step 3 consolidation — Step 2
  // chips own role targeting now. Only the strength + avoid fields remain.
  ["onboardingAiStrength", "onboardingAiAvoid"].forEach(
    (id) => {
      const el = document.getElementById(id);
      if (el) el.value = "";
    },
  );
  syncOnboardingToneCards("warm");
  setOnboardingStep(1);
  w.style.display = "flex";
  document.getElementById("onboardingFileInput")?.focus();
}

function updateOnboardingProgressUI(step) {
  const label = document.getElementById("onboardingStepLabel");
  const fill = document.getElementById("onboardingProgressBarFill");
  const bar = document.getElementById("onboardingProgressBar");
  if (label) {
    label.textContent = `Step ${step} of ${ONBOARDING_TOTAL_STEPS}`;
  }
  const pct = (step / ONBOARDING_TOTAL_STEPS) * 100;
  if (fill) fill.style.width = `${pct}%`;
  if (bar) bar.setAttribute("aria-valuenow", String(step));
}

function syncOnboardingToneCards(selectedTone) {
  document.querySelectorAll(".onboarding-tone-card").forEach((btn) => {
    const t = btn.getAttribute("data-tone");
    const on = t === selectedTone;
    btn.classList.toggle("onboarding-tone-card--selected", on);
    btn.setAttribute("aria-pressed", on ? "true" : "false");
  });
  const hidden = document.getElementById("wizardPrefTone");
  if (hidden) hidden.value = selectedTone;
}

function renderOnboardingSummary() {
  const ul = document.getElementById("onboardingSummary");
  if (!ul || !onboardingResumeDraft) return;
  const tone = document.getElementById("wizardPrefTone")?.value || "warm";
  const mw = document.getElementById("wizardPrefMaxWords")?.value || "350";
  const voice = (
    document.getElementById("wizardPrefVoice")?.value || ""
  ).trim();
  const label = onboardingResumeDraft.label || "My resume";
  const chars = String(onboardingResumeDraft.extractedText || "").length;
  const toneLabel =
    tone === "direct" ? "Direct" : tone === "formal" ? "Formal" : "Warm";
  let html = `<li><strong>Resume</strong>: ${escapeHtml(label)} (${chars.toLocaleString()} characters)</li>`;
  html += `<li><strong>Tone</strong>: ${escapeHtml(toneLabel)}</li>`;
  html += `<li><strong>Max words</strong>: ${escapeHtml(String(mw))}</li>`;
  if (voice) {
    html += `<li><strong>Voice notes</strong>: ${escapeHtml(voice)}</li>`;
  }
  const samplesIn = document.getElementById("onboardingSamplesFileInput");
  const sn = samplesIn && samplesIn.files ? samplesIn.files.length : 0;
  if (sn) {
    html += `<li><strong>Writing samples</strong>: ${sn} file(s) queued</li>`;
  }
  const aiEl = document.getElementById("onboardingAiContextText");
  const aiRaw = (aiEl && aiEl.value) || "";
  const aiNorm = normalizeProfileTextInput(aiRaw);
  if (aiNorm) {
    html += `<li><strong>AI context</strong>: ${aiNorm.length.toLocaleString()} characters</li>`;
  }
  ul.innerHTML = html;
}

function setOnboardingStep(step) {
  // Four-panel wizard: 1 = resume, 2 = role suggestions, 3 = AI context, 4 = tone.
  for (let i = 1; i <= ONBOARDING_TOTAL_STEPS; i++) {
    const p = document.getElementById(`onboardingPanel${i}`);
    if (p) p.style.display = i === step ? "block" : "none";
  }
  const title = document.getElementById("onboardingWizardTitle");
  const titles = {
    1: "Resume",
    2: "Roles to explore",
    3: "About your search",
    4: "Tone",
  };
  if (title) title.textContent = titles[step] || "Setup";
  updateOnboardingProgressUI(step);
  if (step === 1) updateOnboardingContinue2Enabled();
  if (step === 2) {
    // Lazy-load suggestions the first time we land on this step. Gemini-only
    // by design (per onboarding consultation) — if it's not configured we
    // surface a clear message and let the user free-add their own roles.
    void onboardingSuggestEnsureLoaded();
  }

  const focusMap = {
    1: "onboardingFileInput",
    2: "onboardingSuggestAddInput",
    3: "onboardingAiStrength",
    4: "wizardPrefVoice",
  };
  const fid = focusMap[step];
  if (fid) {
    requestAnimationFrame(() => {
      document.getElementById(fid)?.focus();
    });
  }
}

function updateOnboardingContinue2Enabled() {
  const btn = document.getElementById("onboardingContinue2");
  if (!btn) return;
  const hasDraft =
    onboardingResumeDraft &&
    String(onboardingResumeDraft.extractedText || "").trim();
  btn.disabled = !hasDraft;
}

function updateOnboardingNext3Enabled() {
  const btn = document.getElementById("onboardingNext3");
  if (!btn) return;
  const ingest = getResumeIngest();
  const pasteEl = document.getElementById("onboardingPasteText");
  const pasteRaw = (pasteEl && pasteEl.value) || "";
  const pasteText = ingest
    ? ingest.normalizeExtractedText(pasteRaw)
    : pasteRaw.trim();
  const hasDraft =
    onboardingResumeDraft &&
    String(onboardingResumeDraft.extractedText || "").trim();
  btn.disabled = !hasDraft && !pasteText;
}

async function checkOnboardingGate() {
  const UC = getUserContent();
  if (!UC) return;
  try {
    await UC.openDb();
    await UC.migrateOnboardingState();
    if (await UC.isOnboardingComplete()) return;
    showOnboardingWizard();
  } catch (e) {
    console.warn("[JobBored] Onboarding gate:", e);
  }
}

function ensureResumeDraftFromPasteStep() {
  const ingest = getResumeIngest();
  const pasteEl = document.getElementById("onboardingPasteText");
  const status = document.getElementById("onboardingResumeStatus");
  let d = onboardingResumeDraft;
  if (!d || !String(d.extractedText || "").trim()) {
    const raw = (pasteEl && pasteEl.value) || "";
    const t = ingest ? ingest.normalizeExtractedText(raw) : raw.trim();
    if (!t) {
      if (status) {
        status.textContent = "Paste your resume to continue.";
        status.classList.add("onboarding-status--error");
      }
      return false;
    }
    d = {
      source: "paste",
      rawMime: "text/plain",
      label: "My resume",
      extractedText: t,
    };
    onboardingResumeDraft = d;
  }
  if (status) {
    status.textContent = "";
    status.classList.remove("onboarding-status--error");
  }
  return true;
}

// ============================================
// Onboarding step 2: Suggested careers (Gemini-backed)
// ============================================

// Per-session state for the suggestions panel. Lives in module scope (not
// localStorage) — suggestions are cheap to regenerate and we don't want stale
// chips surviving a wizard re-entry.
let onboardingSuggestState = {
  loaded: false, // true after first successful Gemini call
  loading: false, // in-flight guard (prevents double Show me more clicks)
  error: null, // last error string, surfaced in status line
  generation: 0, // monotonic counter so re-rolls can dedupe vs prior batch
  // Map<lowercase label, { label, selected, source: "gemini"|"custom" }>.
  // Map preserves insertion order so chips don't reshuffle on selection toggle.
  byKey: new Map(),
};

function onboardingResetSuggestState() {
  onboardingSuggestState = {
    loaded: false,
    loading: false,
    error: null,
    generation: 0,
    byKey: new Map(),
  };
}

function onboardingGetSelectedRoles() {
  const out = [];
  for (const v of onboardingSuggestState.byKey.values()) {
    if (v.selected && v.label) out.push(v.label);
  }
  return out;
}

function onboardingSuggestNormalizeLabel(raw) {
  return String(raw || "")
    .replace(/\s+/g, " ")
    .trim();
}

function onboardingSuggestKey(label) {
  return onboardingSuggestNormalizeLabel(label).toLowerCase();
}

/**
 * Render the chip row from current state. Idempotent — safe to call after any
 * state mutation. Each chip is a button so it's keyboard-accessible.
 */
function onboardingSuggestRenderChips() {
  const row = document.getElementById("onboardingSuggestChipRow");
  const foot = document.getElementById("onboardingSuggestFoot");
  if (!row) return;
  row.innerHTML = "";
  const entries = Array.from(onboardingSuggestState.byKey.values());
  if (!entries.length && onboardingSuggestState.loaded) {
    foot && (foot.textContent = "");
    return;
  }
  for (const entry of entries) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "onboarding-suggest-chip";
    btn.setAttribute("role", "listitem");
    btn.setAttribute("aria-pressed", entry.selected ? "true" : "false");
    if (entry.selected) btn.classList.add("onboarding-suggest-chip--selected");
    if (entry.source === "custom") {
      btn.classList.add("onboarding-suggest-chip--custom");
    }
    btn.dataset.suggestKey = onboardingSuggestKey(entry.label);
    btn.textContent = entry.label;
    btn.addEventListener("click", () => {
      entry.selected = !entry.selected;
      btn.setAttribute("aria-pressed", entry.selected ? "true" : "false");
      btn.classList.toggle(
        "onboarding-suggest-chip--selected",
        entry.selected,
      );
      onboardingSuggestRenderFoot();
    });
    row.appendChild(btn);
  }
  onboardingSuggestRenderFoot();
}

function onboardingSuggestRenderFoot() {
  const foot = document.getElementById("onboardingSuggestFoot");
  if (!foot) return;
  const total = onboardingSuggestState.byKey.size;
  const picked = onboardingGetSelectedRoles().length;
  if (!total) {
    foot.textContent = "";
    return;
  }
  foot.textContent = picked
    ? `${picked} selected · ${total} options shown — pick as many as feel right.`
    : `${total} options — pick at least one or skip with Continue.`;
}

function onboardingSuggestSetStatus(message, kind) {
  const el = document.getElementById("onboardingSuggestStatus");
  if (!el) return;
  el.textContent = message || "";
  el.classList.remove(
    "onboarding-status--error",
    "onboarding-status--ok",
    "onboarding-status--loading",
  );
  if (!message) return;
  if (kind === "error") el.classList.add("onboarding-status--error");
  else if (kind === "loading") el.classList.add("onboarding-status--loading");
  else if (kind === "ok") el.classList.add("onboarding-status--ok");
}

function onboardingSuggestSetLoading(loading) {
  onboardingSuggestState.loading = loading;
  const reroll = document.getElementById("onboardingSuggestReroll");
  if (reroll) reroll.disabled = loading;
  if (loading) {
    onboardingSuggestSetStatus(
      "Asking Gemini for adjacent + lateral roles…",
      "loading",
    );
  }
}

/**
 * One-shot loader on first navigation to step 2. Skips if already loaded so
 * Back/Next doesn't burn API calls. Re-roll explicitly resets and reloads.
 */
async function onboardingSuggestEnsureLoaded() {
  if (onboardingSuggestState.loaded || onboardingSuggestState.loading) return;
  await onboardingSuggestLoad({ append: false });
}

/**
 * Re-roll: generate a fresh batch, but keep currently-selected chips so the
 * user doesn't lose their choices when they ask for more variety. New batch
 * is appended (deduped) so the chip set grows rather than churning entirely.
 */
async function onboardingSuggestLoad({ append }) {
  if (onboardingSuggestState.loading) return;
  onboardingSuggestState.error = null;

  const draft = onboardingResumeDraft;
  const resumeText = String(draft && draft.extractedText ? draft.extractedText : "")
    .trim();
  if (!resumeText) {
    onboardingSuggestSetStatus(
      "Upload or paste a resume on the previous step first.",
      "error",
    );
    return;
  }

  // Pull provider config the same way the rest of the AI surfaces do.
  // Model name comes from the central resolver — never inline a model
  // string here, or the next deprecation will silently break onboarding
  // again. (See resolveGeminiModel for the resolution order.)
  const cfg = window.COMMAND_CENTER_CONFIG || {};
  const overrides = readStoredConfigOverrides();
  const apiKey =
    overrides.resumeGeminiApiKey || cfg.resumeGeminiApiKey || "";
  const model = resolveGeminiModel();

  if (!apiKey) {
    // Reveal the inline "get a free key" panel above the chips. Friendlier
    // than a red error toast and doesn't punt the user into Settings.
    onboardingSuggestShowKeyGate(true);
    onboardingSuggestSetStatus(
      "Add a free Gemini key above to see role suggestions — or type your own roles below.",
      null,
    );
    onboardingSuggestState.loaded = true; // unblock the panel; user can free-add
    onboardingSuggestRenderChips();
    return;
  }
  // Key exists: make sure the gate is hidden (covers the case where the
  // user just saved a key and we re-entered the load path).
  onboardingSuggestShowKeyGate(false);

  if (!append) {
    // Initial load: clear gemini-sourced chips but preserve any custom ones.
    const customs = Array.from(onboardingSuggestState.byKey.values()).filter(
      (v) => v.source === "custom",
    );
    onboardingSuggestState.byKey = new Map(
      customs.map((v) => [onboardingSuggestKey(v.label), v]),
    );
  }

  onboardingSuggestSetLoading(true);
  onboardingSuggestState.generation += 1;
  const gen = onboardingSuggestState.generation;
  // Already-shown labels: tell Gemini to avoid these on re-roll.
  const alreadyShown = Array.from(onboardingSuggestState.byKey.values()).map(
    (v) => v.label,
  );

  // Truncate resume to keep the prompt cheap. 12k chars is plenty for role
  // inference and well under any sensible token budget.
  const resumeForPrompt = resumeText.slice(0, 12_000);

  const systemPrompt = [
    "You are a career exploration assistant.",
    "Given a resume, you suggest a BROAD set of role titles the candidate",
    "could realistically pursue — including adjacent specialties AND lateral",
    "pivots one step away from their obvious track.",
    "Goal: prevent the user from pigeonholing themselves before job search.",
    "Cover at least three distinct categories: (a) direct fits, (b) adjacent",
    "specialties (different stack/scope, same craft), (c) lateral pivots",
    "(different craft, transferable skills).",
    "Never repeat titles. Use canonical industry titles (no clickbait).",
    "Avoid seniority prefixes like Senior/Staff/Lead unless the resume strongly",
    "indicates that band — keep titles broad so search isn't over-filtered.",
    "Return STRICT JSON only.",
  ].join(" ");

  const userPayload = {
    instruction:
      "Suggest 15 to 20 distinct role titles the candidate could explore. Mix direct fits, adjacent specialties, and lateral pivots.",
    avoidExactTitles: alreadyShown,
    resume: resumeForPrompt,
    schema: {
      roles: [
        {
          title: "string — concise role title",
          category: "direct | adjacent | lateral",
        },
      ],
    },
  };

  const userPrompt =
    `${JSON.stringify(userPayload, null, 2)}\n\nReturn JSON: { "roles": [ { "title": "...", "category": "..." } ] }`;

  let raw;
  try {
    // json:true → tells the resolver to set responseMimeType=application/json
    // AND raise the output-token cap for 2.5-family thinking models. Without
    // these two flags the model silently truncates with finishReason=MAX_TOKENS
    // before any roles are emitted, which surfaces as "no suggestions".
    raw = await callDiscoveryAiGemini(systemPrompt, userPrompt, apiKey, model, {
      json: true,
    });
  } catch (err) {
    if (gen !== onboardingSuggestState.generation) return; // superseded
    onboardingSuggestSetLoading(false);
    onboardingSuggestState.loaded = true;
    onboardingSuggestState.error =
      (err && err.message) || "Could not reach Gemini.";
    onboardingSuggestSetStatus(
      `Suggestions failed: ${onboardingSuggestState.error}. Type a role below to add it manually.`,
      "error",
    );
    onboardingSuggestRenderChips();
    return;
  }

  if (gen !== onboardingSuggestState.generation) return; // user re-rolled mid-flight

  const parsed = parseJsonSafeForSuggestions(raw);
  const roles = Array.isArray(parsed && parsed.roles) ? parsed.roles : [];
  // Diagnostic — when the model returns text but no roles[] (bad shape,
  // empty array, or off-spec output) we want the failure visible in the
  // console instead of just a vague status string. This is the only path
  // that lets us debug a "Gemini returned no suggestions" report from a
  // user without asking them to open devtools and screenshot.
  if (!roles.length) {
    console.warn("[onboarding/suggest] Gemini parsed payload had no roles", {
      rawLength: String(raw || "").length,
      rawPreview: String(raw || "").slice(0, 400),
      parsedKeys: parsed && typeof parsed === "object" ? Object.keys(parsed) : null,
    });
  }
  let added = 0;
  for (const r of roles) {
    const label = onboardingSuggestNormalizeLabel(r && r.title);
    if (!label) continue;
    const key = onboardingSuggestKey(label);
    if (onboardingSuggestState.byKey.has(key)) continue;
    onboardingSuggestState.byKey.set(key, {
      label,
      selected: false,
      source: "gemini",
    });
    added += 1;
  }

  onboardingSuggestState.loaded = true;
  onboardingSuggestSetLoading(false);
  onboardingSuggestRenderChips();
  if (added === 0 && !onboardingSuggestState.byKey.size) {
    // Distinguish "we got bytes back but they were unparseable" from "the
    // model returned a clean but empty array". Both are useful signals
    // for the user — and far less infuriating than a flat "no suggestions".
    const hadRawBytes = !!String(raw || "").trim();
    const parsedHadStructure = parsed && typeof parsed === "object";
    const message = !hadRawBytes
      ? "Gemini returned an empty response — try Show me more, or paste a longer resume so the model has more to work with."
      : !parsedHadStructure
        ? "Gemini replied but the response wasn't valid JSON. Try Show me more — if it keeps failing, switch models in Settings."
        : "Gemini returned an empty role list — try Show me more, or type a role below to add it manually.";
    onboardingSuggestSetStatus(message, "error");
  } else if (added === 0) {
    onboardingSuggestSetStatus(
      "No new roles this round — try Show me more for a different angle.",
      "ok",
    );
  } else {
    onboardingSuggestSetStatus(
      append
        ? `Added ${added} more — pick whatever fits.`
        : `Tap any chip to add it to your search.`,
      "ok",
    );
  }
}

/**
 * Step 3 "Want our take?" — read the user's resume text + chip-selected
 * roles, ask Gemini for 2–3 distinctive edges (specific accomplishments,
 * unusual skill combos, things that aren't generic resume filler), then
 * insert the result into the superpower textarea so the user can edit on
 * top of it.
 *
 * Prompt is intentionally specific about what NOT to return: no generic
 * skill bullets ("strong communicator"), no career-summary prose, no
 * keyword stuffing. We want the 2–3 things that would survive being
 * shrunk to a single tweet.
 *
 * Uses the same central resolveGeminiModel + responseMimeType=JSON path
 * as the chip suggestions so a model swap stays one-line. Failures
 * surface inline in #onboardingEdgeTakeStatus rather than a toast — the
 * user is mid-flow and shouldn't have their attention pulled to a
 * floating popup.
 */
async function onboardingFillEdgeFromGemini() {
  const btn = document.getElementById("onboardingEdgeTakeBtn");
  const status = document.getElementById("onboardingEdgeTakeStatus");
  const strengthEl = document.getElementById("onboardingAiStrength");

  const setStatus = (text, kind) => {
    if (!status) return;
    status.textContent = text || "";
    status.classList.remove(
      "onboarding-status--ok",
      "onboarding-status--error",
      "onboarding-status--loading",
    );
    if (kind) status.classList.add(`onboarding-status--${kind}`);
  };

  if (!strengthEl) return;

  const cfg = window.COMMAND_CENTER_CONFIG || {};
  const overrides =
    typeof readStoredConfigOverrides === "function"
      ? readStoredConfigOverrides()
      : {};
  const apiKey =
    overrides.resumeGeminiApiKey || cfg.resumeGeminiApiKey || "";
  if (!apiKey) {
    setStatus(
      "Add a free Gemini key on Step 2 first — we use it to read your resume.",
      "error",
    );
    return;
  }

  const resumeText = String(
    (onboardingResumeDraft && onboardingResumeDraft.extractedText) || "",
  ).trim();
  if (!resumeText) {
    setStatus(
      "We don't have your resume text. Go back to Step 1 and upload or paste it first.",
      "error",
    );
    return;
  }

  // Chips give Gemini context for which direction to tailor the edges in.
  // (e.g. if the user picked Forward Deployed Engineer roles, frame edges
  // for that audience rather than a generic "what makes them special".)
  const chipRoles = onboardingGetSelectedRoles().slice(0, 12);

  if (btn) {
    btn.disabled = true;
    btn.dataset.label = btn.dataset.label || btn.textContent;
    btn.textContent = "Thinking…";
  }
  setStatus("Reading your resume…", "loading");

  // Trim resume to a reasonable budget — enough for Gemini to find
  // distinctive details without burning tokens on long appendices.
  const resumeForPrompt =
    resumeText.length > 5000
      ? `${resumeText.slice(0, 5000)}\n\n[...truncated...]`
      : resumeText;

  const systemPrompt = [
    "You read resumes and find the 2–3 things that genuinely set this candidate apart.",
    "Output rules:",
    "- Return SHORT bullet-style phrases (one sentence each, max ~18 words).",
    "- Each must be specific, concrete, and reference real signal from the resume — accomplishments, unusual skill combos, scope, results.",
    "- Skip generic resume filler: no 'strong communicator', no 'team player', no 'detail-oriented'.",
    "- Skip career-summary prose and any sentences that start with 'I am'.",
    "- Frame for the target roles when they meaningfully change emphasis.",
    "- Plain text inside the JSON values — no markdown, no asterisks, no bullet characters.",
    'Return JSON: { "edges": ["...", "...", "..."] }',
  ].join("\n");

  const userPayload = {
    resume: resumeForPrompt,
    targetRoles: chipRoles,
  };
  const userPrompt = `${JSON.stringify(userPayload, null, 2)}\n\nReturn 2–3 edges as JSON.`;

  let raw;
  try {
    raw = await callDiscoveryAiGemini(systemPrompt, userPrompt, apiKey, null, {
      json: true,
    });
  } catch (err) {
    setStatus(
      `Gemini failed: ${(err && err.message) || "unknown error"}. Type your edges by hand below.`,
      "error",
    );
    if (btn) {
      btn.disabled = false;
      btn.textContent = btn.dataset.label || "Want our take?";
    }
    return;
  }

  const parsed = parseJsonSafeForSuggestions(raw);
  const edges = Array.isArray(parsed && parsed.edges)
    ? parsed.edges
        .map((e) => String(e || "").trim())
        .filter((e) => e.length > 0)
    : [];

  if (!edges.length) {
    console.warn("[onboarding/edge] Gemini returned no edges", {
      rawLength: String(raw || "").length,
      rawPreview: String(raw || "").slice(0, 400),
    });
    setStatus(
      "Gemini didn't return anything usable — try again, or type your edges by hand.",
      "error",
    );
    if (btn) {
      btn.disabled = false;
      btn.textContent = btn.dataset.label || "Want our take?";
    }
    return;
  }

  // Insert the edges, separated by newlines, into the textarea. If the
  // user already typed something we APPEND with a blank line so we never
  // wipe their input. This is the "iteration > replacement" intent.
  const formatted = edges.map((e) => `• ${e}`).join("\n");
  const existing = String(strengthEl.value || "").trim();
  strengthEl.value = existing
    ? `${existing}\n\n${formatted}`
    : formatted;
  // Trigger any input listeners (e.g. autosave hooks if they exist later).
  strengthEl.dispatchEvent(new Event("input", { bubbles: true }));

  setStatus(
    `Added ${edges.length} edge${edges.length === 1 ? "" : "s"} — keep, edit, or delete.`,
    "ok",
  );
  if (btn) {
    btn.disabled = false;
    btn.textContent = btn.dataset.label || "Want our take?";
  }
}

function onboardingSuggestAddCustom(rawLabel) {
  const label = onboardingSuggestNormalizeLabel(rawLabel);
  if (!label) return false;
  const key = onboardingSuggestKey(label);
  if (onboardingSuggestState.byKey.has(key)) {
    // Already present — just select it so the user gets feedback.
    const existing = onboardingSuggestState.byKey.get(key);
    existing.selected = true;
    onboardingSuggestRenderChips();
    onboardingSuggestSetStatus(`“${label}” is already in the list.`, "ok");
    return true;
  }
  onboardingSuggestState.byKey.set(key, {
    label,
    selected: true,
    source: "custom",
  });
  onboardingSuggestRenderChips();
  onboardingSuggestSetStatus(`Added “${label}”.`, "ok");
  return true;
}

/**
 * Show or hide the inline "Get a free Gemini key" panel that lives at the
 * top of Step 2. Called by the suggest loader when no key is configured,
 * and again (with false) once a key gets saved.
 */
function onboardingSuggestShowKeyGate(show) {
  const gate = document.getElementById("onboardingSuggestKeyGate");
  if (!gate) return;
  gate.hidden = !show;
  if (show) {
    // Disable Show me more while the gate is up — it can't do anything
    // useful without a key.
    const reroll = document.getElementById("onboardingSuggestReroll");
    if (reroll) reroll.disabled = true;
    // Focus the input so the user can paste immediately.
    requestAnimationFrame(() => {
      document.getElementById("onboardingSuggestKeyInput")?.focus();
    });
  }
}

/**
 * Validate, persist, and use a pasted Gemini API key. Same shape as the
 * existing Settings flow — writes to localStorage overrides via
 * mergeStoredConfigOverridePatch so the key survives reloads, and pokes the
 * runtime config so the very next API call uses it without a page refresh.
 */
async function onboardingSuggestSaveKey(rawKey) {
  const key = String(rawKey || "").trim();
  // Cheap shape check — Google AI Studio keys start with "AIza" and are
  // ~39 chars. Reject obviously bad pastes so the user gets immediate
  // feedback instead of a confusing 400 from the API.
  if (!key) return { ok: false, reason: "empty" };
  if (!/^AIza[0-9A-Za-z\-_]{20,}$/.test(key)) {
    return { ok: false, reason: "shape" };
  }
  try {
    mergeStoredConfigOverridePatch({ resumeGeminiApiKey: key });
  } catch (err) {
    console.warn("[JobBored] save Gemini key failed:", err);
    return { ok: false, reason: "storage" };
  }
  // Apply to the live config object so the next call sees it without reload.
  if (window.COMMAND_CENTER_CONFIG) {
    window.COMMAND_CENTER_CONFIG.resumeGeminiApiKey = key;
  }
  return { ok: true };
}

function initOnboardingSuggestPanel() {
  const reroll = document.getElementById("onboardingSuggestReroll");
  const addInput = document.getElementById("onboardingSuggestAddInput");
  const addBtn = document.getElementById("onboardingSuggestAddBtn");
  const keyInput = document.getElementById("onboardingSuggestKeyInput");
  const keySaveBtn = document.getElementById("onboardingSuggestKeySaveBtn");

  if (reroll) {
    reroll.addEventListener("click", () => {
      void onboardingSuggestLoad({ append: true });
    });
  }
  if (addBtn && addInput) {
    const submit = () => {
      const ok = onboardingSuggestAddCustom(addInput.value);
      if (ok) {
        addInput.value = "";
        addInput.focus();
      }
    };
    addBtn.addEventListener("click", submit);
    addInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        submit();
      }
    });
  }

  if (keyInput && keySaveBtn) {
    const submitKey = async () => {
      const result = await onboardingSuggestSaveKey(keyInput.value);
      if (!result.ok) {
        if (result.reason === "shape") {
          showToast(
            "That doesn't look like a Gemini key — they start with “AIza”. Double-check from AI Studio.",
            "error",
          );
        } else if (result.reason === "storage") {
          showToast(
            "Couldn't save key to local storage. Disable private mode or quota-clear and retry.",
            "error",
          );
        }
        return;
      }
      // Success — hide the gate, clear the input, and (re)load suggestions.
      keyInput.value = "";
      onboardingSuggestShowKeyGate(false);
      showToast("Gemini key saved. Loading role suggestions…", "success");
      // Reset state so the load is treated as fresh, not a re-roll.
      onboardingResetSuggestState();
      void onboardingSuggestLoad({ append: false });
    };
    keySaveBtn.addEventListener("click", () => void submitKey());
    keyInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        void submitKey();
      }
    });
  }
}

function initOnboardingWizard() {
  const fileIn = document.getElementById("onboardingFileInput");
  const pasteEl = document.getElementById("onboardingPasteText");

  // Panel 1 -> Panel 2 (resume drop or paste fallback)
  document
    .getElementById("onboardingContinue2")
    ?.addEventListener("click", () => {
      // Allow either an uploaded resume OR pasted text from the disclosure.
      if (
        !onboardingResumeDraft ||
        !String(onboardingResumeDraft.extractedText || "").trim()
      ) {
        if (!ensureResumeDraftFromPasteStep()) return;
        onboardingResumePath = "paste";
      } else {
        onboardingResumePath = onboardingResumePath || "upload";
      }
      setOnboardingStep(2);
    });

  // Panel 2 (suggested careers) navigation
  initOnboardingSuggestPanel();
  document
    .getElementById("onboardingSuggestBack")
    ?.addEventListener("click", () => {
      setOnboardingStep(1);
    });
  document
    .getElementById("onboardingSuggestNext")
    ?.addEventListener("click", () => {
      // IMPORTANT: do NOT mirror chip selections into Step 3's target-roles
      // textarea. The chips are the source of truth for "roles to explore"
      // and feed the discovery profile via finalizeOnboarding. Mirroring
      // duplicated the choices in two places, so users saw their selected
      // chips pasted into the Step 3 free-text field — confusing and asked
      // them to act on the same data twice.
      setOnboardingStep(3);
    });

  // Panel 3 (AI context) navigation — buttons keep their legacy ids.
  document.getElementById("onboardingBack4")?.addEventListener("click", () => {
    setOnboardingStep(2);
  });
  document.getElementById("onboardingNext4")?.addEventListener("click", () => {
    setOnboardingStep(4);
  });

  // "Want our take?" — Step 3 superpower assist. Reads the user's resume
  // text + chip selections and asks Gemini for 2–3 distinctive edges. The
  // result is INSERTED into the textarea (not replacing user-typed text)
  // so the user can iterate on top of it. See onboardingFillEdgeFromGemini
  // for the prompt + response handling.
  document
    .getElementById("onboardingEdgeTakeBtn")
    ?.addEventListener("click", () => {
      void onboardingFillEdgeFromGemini();
    });

  // Panel 4 (tone & finish) back arrow
  document.getElementById("onboardingBack9")?.addEventListener("click", () => {
    setOnboardingStep(3);
  });

  document.querySelectorAll(".onboarding-tone-card").forEach((btn) => {
    btn.addEventListener("click", () => {
      const t = btn.getAttribute("data-tone");
      if (t) syncOnboardingToneCards(t);
    });
  });

  if (fileIn) {
    fileIn.addEventListener("change", async (e) => {
      const status = document.getElementById("onboardingResumeStatusUpload");
      const file = e.target.files && e.target.files[0];
      e.target.value = "";
      if (!file) return;
      // Immediate "we received your file" feedback so the user is never left
      // staring at a blank screen during PDF/Word extraction. This must
      // happen BEFORE the await for the ingest module so it shows up even
      // when pdf.js + mammoth are still finishing their cold-cache load.
      if (status) {
        status.innerHTML = "";
        status.classList.remove(
          "onboarding-status--ok",
          "onboarding-status--error",
        );
        status.classList.add("onboarding-status--loading");
        status.textContent = `Reading “${file.name || "your file"}”…`;
      }
      // Wait for the resume-ingest module to be ready instead of bailing
      // immediately. Cold-cache loads of pdf.js + mammoth occasionally
      // finish a few hundred ms after DOMContentLoaded; the previous
      // fail-fast branch is what made users say "I have to refresh first".
      const ingest = await getResumeIngestReady(3000);
      if (!ingest) {
        if (status) {
          status.classList.remove("onboarding-status--loading");
          status.classList.add("onboarding-status--error");
          status.textContent =
            "Resume reader still loading after 3s. Check your connection and try again, or paste the text below.";
        }
        return;
      }
      try {
        const text = await ingest.extractTextFromFile(file);
        if (!text.trim()) {
          if (status) {
            status.classList.remove(
              "onboarding-status--ok",
              "onboarding-status--loading",
            );
            status.classList.add("onboarding-status--error");
            status.textContent =
              "We received the file but couldn't read any text from it. If it's a scanned PDF, paste the text below instead.";
          }
          return;
        }
        const label =
          (file.name || "Resume").replace(/\.[^/.]+$/, "") || "My resume";
        onboardingResumeDraft = {
          source: "file",
          rawMime: ingest.guessMime(file),
          label,
          extractedText: text,
        };
        onboardingResumePath = "upload";
        if (status) {
          // Visible confirmation: filename with extension, file-type label,
          // size, and extracted-character count. Replaces the old text-only
          // hint that users could miss before clicking Continue.
          const fullName = String(file.name || `${label}`);
          const extMatch = fullName.match(/\.([a-z0-9]+)$/i);
          const ext = extMatch ? extMatch[1].toUpperCase() : "FILE";
          const sizeKb = Math.max(1, Math.round((file.size || 0) / 1024));
          status.innerHTML = "";
          const ok = document.createElement("span");
          ok.className = "onboarding-status__check";
          ok.setAttribute("aria-hidden", "true");
          ok.textContent = "\u2713";
          const name = document.createElement("strong");
          name.className = "onboarding-status__filename";
          name.textContent = fullName;
          const meta = document.createElement("span");
          meta.className = "onboarding-status__meta";
          meta.textContent = ` · ${ext} · ${sizeKb.toLocaleString()} KB · ${text.length.toLocaleString()} characters extracted`;
          status.appendChild(ok);
          status.appendChild(document.createTextNode(" "));
          status.appendChild(name);
          status.appendChild(meta);
          status.classList.remove(
            "onboarding-status--error",
            "onboarding-status--loading",
          );
          status.classList.add("onboarding-status--ok");
        }
        updateOnboardingContinue2Enabled();
      } catch (err) {
        console.error(err);
        if (status) {
          status.innerHTML = "";
          status.textContent =
            (err && err.message) ||
            "Could not read that file. Try a different format, or paste the text below.";
          status.classList.remove(
            "onboarding-status--ok",
            "onboarding-status--loading",
          );
          status.classList.add("onboarding-status--error");
        }
      }
    });
  }

  if (pasteEl) {
    pasteEl.addEventListener("input", () => {
      // Step 1's button is onboardingContinue2 — both paths (file or paste)
      // must enable it. Bug fix: previously this called the Step 2 helper,
      // so paste-only users were stuck at "Step 1 of 3".
      updateOnboardingContinue2Enabled();
      const ingest = getResumeIngest();
      const raw = pasteEl.value || "";
      const text = ingest ? ingest.normalizeExtractedText(raw) : raw.trim();
      const status = document.getElementById("onboardingResumeStatus");
      if (text) {
        // Mirror the file-upload behavior: stage the draft so Continue uses it.
        onboardingResumeDraft = {
          source: "paste",
          rawMime: "text/plain",
          label: "Pasted resume",
          extractedText: text,
        };
        onboardingResumePath = "paste";
        if (status) {
          status.textContent = `Pasted resume captured (${text.length.toLocaleString()} characters).`;
          status.classList.remove("onboarding-status--error");
        }
        updateOnboardingContinue2Enabled();
      } else {
        // Empty textarea: drop any prior paste draft (but don't wipe a file
        // upload that may have been staged before the user opened the paste
        // disclosure).
        if (onboardingResumeDraft && onboardingResumeDraft.source === "paste") {
          onboardingResumeDraft = null;
          onboardingResumePath = null;
          updateOnboardingContinue2Enabled();
        }
        if (status) {
          status.textContent = "";
          status.classList.remove("onboarding-status--error");
        }
      }
    });
  }

  const onboardingSamplesIn = document.getElementById(
    "onboardingSamplesFileInput",
  );
  const onboardingSamplesStatus = document.getElementById(
    "onboardingSamplesStatus",
  );
  if (onboardingSamplesIn && onboardingSamplesStatus) {
    onboardingSamplesIn.addEventListener("change", () => {
      const n = onboardingSamplesIn.files
        ? onboardingSamplesIn.files.length
        : 0;
      onboardingSamplesStatus.textContent = n
        ? `${n} file(s) selected — will be added when you finish.`
        : "";
      onboardingSamplesStatus.classList.remove("onboarding-status--error");
    });
  }

  document
    .getElementById("onboardingFinish")
    ?.addEventListener("click", async () => {
      const UC = getUserContent();
      if (!UC || !onboardingResumeDraft) return;
      if (!String(onboardingResumeDraft.extractedText || "").trim()) {
        showToast("Resume text is missing — go back a step", "error");
        return;
      }
      const toneEl = document.getElementById("wizardPrefTone");
      const mwEl = document.getElementById("wizardPrefMaxWords");
      const voEl = document.getElementById("wizardPrefVoice");
      const maxWords = parseInt(mwEl && mwEl.value, 10);
      const finish = document.getElementById("onboardingFinish");
      if (finish) finish.disabled = true;
      try {
        await UC.setPrimaryResume(onboardingResumeDraft);
        // Merge Step 3's two remaining guided fields + optional pasted
        // career summary into a single AI context blob. Chip selections
        // from Step 2 are handled separately below (they go into the
        // discovery profile, not the AI context blob — keeps the two
        // surfaces decoupled).
        //
        // The previous "target role" textarea was consolidated out of
        // Step 3 — it duplicated the chip flow on Step 2 and forced users
        // to re-type what they had just clicked. Chips are the source of
        // truth; the discovery save below pulls from there.
        const strengthEl = document.getElementById("onboardingAiStrength");
        const avoidEl = document.getElementById("onboardingAiAvoid");
        const pastedEl = document.getElementById("onboardingAiContextText");
        const guidedParts = [];
        if (strengthEl && strengthEl.value.trim()) {
          guidedParts.push(`Superpower: ${strengthEl.value.trim()}`);
        }
        if (avoidEl && avoidEl.value.trim()) {
          guidedParts.push(`Avoid: ${avoidEl.value.trim()}`);
        }
        if (pastedEl && pastedEl.value.trim()) {
          guidedParts.push(pastedEl.value.trim());
        }
        const aiNorm = normalizeProfileTextInput(guidedParts.join("\n\n"));
        if (aiNorm && typeof UC.saveAdditionalContext === "function") {
          await UC.saveAdditionalContext({
            text: aiNorm,
            updatedAt: new Date().toISOString(),
          });
        }
        // Persist chip selections from Step 2 into the discovery profile.
        // Step 3 used to also have a free-text "target roles" textarea
        // that got merged here, but that surface was consolidated out —
        // chips are the only role-targeting input now.
        try {
          const chipRoles = onboardingGetSelectedRoles();
          const targetRoles = chipRoles
            .map((s) => String(s || "").trim())
            .filter(Boolean)
            .join(", ");
          if (targetRoles && typeof UC.saveDiscoveryProfile === "function") {
            await UC.saveDiscoveryProfile({ targetRoles });
          }
        } catch (chipErr) {
          // Non-fatal: discovery profile save failing shouldn't block
          // finishing onboarding. The user can edit it later in Settings.
          console.warn(
            "[JobBored] saveDiscoveryProfile from chips failed:",
            chipErr,
          );
        }
        await UC.savePreferences({
          tone: (toneEl && toneEl.value) || "warm",
          defaultMaxWords:
            !Number.isNaN(maxWords) && maxWords > 0 ? maxWords : 350,
          industriesToEmphasize: "",
          wordsToAvoid: "",
          voiceNotes: (voEl && voEl.value.trim()) || "",
        });
        await UC.completeOnboarding();
        hideOnboardingWizard();
        void resumePendingDiscoverySetupIfNeeded();
        showToast(
          "You're all set — open Profile anytime to update.",
          "success",
        );
        scheduleCandidateProfileMatchRefresh(true);
        onboardingResumeDraft = null;
        onboardingResumePath = null;
      } catch (err) {
        console.error(err);
        showToast(err.message || "Could not save profile", "error");
      } finally {
        if (finish) finish.disabled = false;
      }
    });
}

function fillOneResumeModelSelect(selectId, optionList, currentValue) {
  const sel = document.getElementById(selectId);
  const opts =
    optionList ||
    (window.CommandCenterResumeModelOptions &&
      window.CommandCenterResumeModelOptions[
        selectId === "settingsResumeGeminiModel"
          ? "gemini"
          : selectId === "settingsResumeOpenAIModel"
            ? "openai"
            : "anthropic"
      ]);
  if (!sel || sel.tagName !== "SELECT" || !Array.isArray(opts)) return;
  const v =
    currentValue != null && String(currentValue).trim() !== ""
      ? String(currentValue).trim()
      : "";
  const values = new Set(opts.map((o) => o.value));
  sel.innerHTML = "";
  opts.forEach((o) => {
    const opt = document.createElement("option");
    opt.value = o.value;
    opt.textContent = o.label;
    sel.appendChild(opt);
  });
  if (v && !values.has(v)) {
    const opt = document.createElement("option");
    opt.value = v;
    opt.textContent = `${v} (saved)`;
    sel.appendChild(opt);
  }
  if (v && [...sel.options].some((o) => o.value === v)) {
    sel.value = v;
  } else if (opts[0]) {
    sel.value = opts[0].value;
  }
}

/**
 * @param {string} selectId
 * @param {'cover_letter'|'resume_update'} kind
 * @param {string} [currentId]
 */
function fillDocumentTemplateSelect(selectId, kind, currentId) {
  const DT = window.CommandCenterDocumentTemplates;
  if (!DT || !Array.isArray(DT.DOCUMENT_TEMPLATES)) return;
  const sel = document.getElementById(selectId);
  if (!sel || sel.tagName !== "SELECT") return;
  const list = DT.DOCUMENT_TEMPLATES.filter((t) => t.kind === kind);
  const defaultId = DT.getDefaultTemplateId(kind);
  let v =
    currentId != null && String(currentId).trim() !== ""
      ? String(currentId).trim()
      : defaultId;
  const values = new Set(list.map((t) => t.id));
  sel.innerHTML = "";
  list.forEach((t) => {
    const opt = document.createElement("option");
    opt.value = t.id;
    opt.textContent = t.label;
    if (t.description) opt.title = t.description;
    sel.appendChild(opt);
  });
  if (!values.has(v)) v = defaultId;
  sel.value = v;
}

/**
 * @param {string} selectId
 * @param {string} [currentId]
 */
function fillVisualThemeSelect(selectId, currentId) {
  const VT = window.CommandCenterVisualThemes;
  if (!VT || !Array.isArray(VT.VISUAL_THEMES)) return;
  const sel = document.getElementById(selectId);
  if (!sel || sel.tagName !== "SELECT") return;
  const list = VT.VISUAL_THEMES;
  const defaultId = VT.getDefaultVisualThemeId();
  let v =
    currentId != null && String(currentId).trim() !== ""
      ? String(currentId).trim()
      : defaultId;
  const resolved =
    VT.resolveVisualTheme && typeof VT.resolveVisualTheme === "function"
      ? VT.resolveVisualTheme(v)
      : { id: v };
  v = resolved.id;
  const values = new Set(list.map((t) => t.id));
  sel.innerHTML = "";
  list.forEach((t) => {
    const opt = document.createElement("option");
    opt.value = t.id;
    opt.textContent = t.label;
    if (t.description) opt.title = t.description;
    sel.appendChild(opt);
  });
  if (!values.has(v)) v = defaultId;
  sel.value = v;
}

async function resolveVisualThemeIdForModal() {
  const VT = window.CommandCenterVisualThemes;
  const fallback =
    VT && typeof VT.getDefaultVisualThemeId === "function"
      ? VT.getDefaultVisualThemeId()
      : "classic";
  try {
    const UC = getUserContent();
    if (!UC) return fallback;
    await UC.openDb();
    const prefs = await UC.getPreferences();
    const raw = prefs.visualThemeId || fallback;
    return VT && typeof VT.resolveVisualTheme === "function"
      ? VT.resolveVisualTheme(raw).id
      : raw;
  } catch (_) {
    return fallback;
  }
}

function fillResumeModelSelectsFromConfig(cfg) {
  const m = window.CommandCenterResumeModelOptions;
  if (!m) return;
  fillOneResumeModelSelect(
    "settingsResumeGeminiModel",
    m.gemini,
    cfg.resumeGeminiModel,
  );
  fillOneResumeModelSelect(
    "settingsResumeOpenAIModel",
    m.openai,
    cfg.resumeOpenAIModel,
  );
  fillOneResumeModelSelect(
    "settingsResumeAnthropicModel",
    m.anthropic,
    cfg.resumeAnthropicModel,
  );
}

async function populateDiscoveryProfileIntoSettingsForm() {
  const UC = window.CommandCenterUserContent;
  if (!UC || typeof UC.getDiscoveryProfile !== "function") return;
  const p = await UC.getDiscoveryProfile();
  const set = (id, v) => {
    const el = document.getElementById(id);
    if (el) el.value = v != null ? String(v) : "";
  };
  set("settingsDiscoveryTargetRoles", p.targetRoles);
  set("settingsDiscoveryLocations", p.locations);
  set("settingsDiscoveryRemotePolicy", p.remotePolicy);
  set("settingsDiscoverySeniority", p.seniority);
  set("settingsDiscoveryKeywordsInclude", p.keywordsInclude);
  set("settingsDiscoveryKeywordsExclude", p.keywordsExclude);
  set("settingsDiscoveryMaxLeadsPerRun", p.maxLeadsPerRun);
  // Handle grounded_web checkbox
  const gwEl = document.getElementById("settingsDiscoveryGroundedWeb");
  if (gwEl) gwEl.checked = p.groundedWebEnabled !== false;
}

function populateCommandCenterSettingsForm() {
  const cfg = {
    ...(window.COMMAND_CENTER_CONFIG || {}),
    ...readStoredConfigOverrides(),
  };
  const set = (id, v) => {
    const el = document.getElementById(id);
    if (el) el.value = v != null ? String(v) : "";
  };
  const sidRaw = cfg.sheetId != null ? String(cfg.sheetId) : "";
  set("settingsSheetId", parseGoogleSheetId(sidRaw) || sidRaw);
  set("settingsOAuthClientId", cfg.oauthClientId);
  set("settingsTitle", normalizeDashboardTitle(cfg.title));
  set("settingsDiscoveryWebhookUrl", cfg.discoveryWebhookUrl);
  set("settingsDiscoveryWebhookSecret", cfg.discoveryWebhookSecret);
  set("settingsJobPostingScrapeUrl", cfg.jobPostingScrapeUrl);
  const atsMode = String(cfg.atsScoringMode || "server").toLowerCase();
  set("settingsAtsScoringMode", atsMode === "webhook" ? "webhook" : "server");
  set("settingsAtsScoringServerUrl", cfg.atsScoringServerUrl);
  set("settingsAtsScoringWebhookUrl", cfg.atsScoringWebhookUrl);
  const prov = String(cfg.resumeProvider || "gemini").toLowerCase();
  const sel = document.getElementById("settingsResumeProvider");
  if (sel) {
    const pv = ["gemini", "openai", "anthropic", "webhook"].includes(prov)
      ? prov
      : "gemini";
    sel.value = pv;
  }
  fillResumeModelSelectsFromConfig(cfg);
  set("settingsResumeGeminiApiKey", cfg.resumeGeminiApiKey);
  set("settingsResumeOpenAIApiKey", cfg.resumeOpenAIApiKey);
  set("settingsResumeAnthropicApiKey", cfg.resumeAnthropicApiKey);
  set("settingsResumeGenerationWebhookUrl", cfg.resumeGenerationWebhookUrl);
  const err = document.getElementById("settingsFormError");
  if (err) {
    err.textContent = "";
    err.style.display = "none";
  }
  renderAppsScriptDeployUi();
}

function updateSettingsProviderPanels() {
  const sel = document.getElementById("settingsResumeProvider");
  const v = sel ? sel.value : "gemini";
  const gem = document.getElementById("settingsPanelGemini");
  const oai = document.getElementById("settingsPanelOpenAI");
  const ant = document.getElementById("settingsPanelAnthropic");
  const hook = document.getElementById("settingsPanelWebhook");
  if (gem) gem.style.display = v === "gemini" ? "block" : "none";
  if (oai) oai.style.display = v === "openai" ? "block" : "none";
  if (ant) ant.style.display = v === "anthropic" ? "block" : "none";
  if (hook) hook.style.display = v === "webhook" ? "block" : "none";
}

/** Default OAuth Web Client ID for phased Settings (before Google sign-in unlocks full settings). */
const DEFAULT_OAUTH_CLIENT_ID_FOR_PHASED_SETTINGS =
  "555157387171-o05ofv6ihjh3brknkvsm2hr7nup7e88a.apps.googleusercontent.com";

/** Settings should always expose sheet/discovery fields; actions that need auth already gate themselves. */
function isSettingsFullExperienceUnlocked() {
  return true;
}

function maybeSyncSettingsModalModeAfterAuth() {
  const m = document.getElementById("settingsModal");
  if (m && m.style.display === "flex") syncSettingsModalMode();
}

function syncSettingsModalMode() {
  const card = document.querySelector("#settingsModal .settings-modal");
  if (!card) return;
  const full = isSettingsFullExperienceUnlocked();
  card.classList.toggle("settings-modal--oauth-only", !full);
  const modalTitle = document.getElementById("settingsModalTitle");
  if (modalTitle) {
    modalTitle.textContent = full ? "JobBored settings" : "Google OAuth setup";
  }
  const oauthLab = document.getElementById("settingsOAuthClientIdLabel");
  if (oauthLab) {
    oauthLab.textContent = full
      ? "OAuth Client ID (optional)"
      : "OAuth Client ID";
  }
}

function maybeApplyPhasedSettingsDefaultOAuthClientId() {
  if (isSettingsFullExperienceUnlocked()) return;
  const el = document.getElementById("settingsOAuthClientId");
  if (!el) return;
  const v = String(el.value || "").trim();
  if (v) return;
  el.value = DEFAULT_OAUTH_CLIENT_ID_FOR_PHASED_SETTINGS;
}

async function openCommandCenterSettingsModal(opts) {
  closeAuthUserMenu();
  appsScriptDeployStatus = null;
  appsScriptDeployStateCache = null;
  hideSettingsClearConfirmBar();
  populateCommandCenterSettingsForm();
  maybeApplyPhasedSettingsDefaultOAuthClientId();
  if (isSettingsFullExperienceUnlocked()) {
    await populateDiscoveryProfileIntoSettingsForm();
    await populateAppsScriptDeployStateIntoSettingsForm();
  }
  updateSettingsProviderPanels();
  syncSettingsModalMode();
  const modal = document.getElementById("settingsModal");
  if (modal) modal.style.display = "flex";
  // Initialize settings tabs
  const TabSchema = window.JobBoredSettingsTabSchema;
  const Tabs = window.JobBoredSettingsTabs;
  if (Tabs && TabSchema && modal) {
    const defaultTab = (opts && opts.tab) || TabSchema.DEFAULT_TAB;
    Tabs.initSettingsTabs(modal, { defaultTab: defaultTab });
  }
  void probeTunnelStaleBadge();
}

function hideSettingsClearConfirmBar() {
  const bar = document.getElementById("settingsClearConfirmBar");
  if (bar) bar.hidden = true;
}

function showSettingsClearConfirmBar() {
  const bar = document.getElementById("settingsClearConfirmBar");
  if (!bar) return;
  bar.hidden = false;
  document.getElementById("settingsClearConfirmYes")?.focus();
}

function closeCommandCenterSettingsModal() {
  hideSettingsClearConfirmBar();
  const modal = document.getElementById("settingsModal");
  if (modal) modal.style.display = "none";
}

async function saveCommandCenterSettingsFromForm() {
  const err = document.getElementById("settingsFormError");
  if (err) {
    err.textContent = "";
    err.style.display = "none";
  }
  if (!isSettingsFullExperienceUnlocked()) {
    const oauthEl = document.getElementById("settingsOAuthClientId");
    const oauthClientIdInput = oauthEl ? oauthEl.value.trim() : "";
    if (!oauthClientIdInput) {
      if (err) {
        err.textContent = "Paste your Google OAuth Client ID.";
        err.style.display = "block";
      }
      return;
    }
    try {
      mergeStoredConfigOverridePatch({
        oauthClientId: oauthClientIdInput,
        title: normalizeDashboardTitle(
          (() => {
            const el = document.getElementById("settingsTitle");
            return el ? el.value.trim() : "";
          })(),
        ),
      });
    } catch (e) {
      if (err) {
        err.textContent = "Could not save OAuth settings. " + (e.message || "");
        err.style.display = "block";
      }
      return;
    }
    syncDiscoveryButtonState();
    if (applyOAuthClientChange(oauthClientIdInput)) {
      showToast("OAuth client saved — sign in to continue.", "success");
      closeCommandCenterSettingsModal();
    } else {
      showToast("OAuth client saved — reloading…", "success");
      setTimeout(() => window.location.reload(), 400);
    }
    return;
  }
  const sheetEl = document.getElementById("settingsSheetId");
  const rawSheet = (sheetEl && sheetEl.value.trim()) || "";
  const sheetId = parseGoogleSheetId(rawSheet);
  const oauthClientIdInput = (() => {
    const el = document.getElementById("settingsOAuthClientId");
    return el ? el.value.trim() : "";
  })();
  if (!sheetId || sheetId === "YOUR_SHEET_ID_HERE") {
    if (oauthClientIdInput) {
      try {
        mergeStoredConfigOverridePatch({
          oauthClientId: oauthClientIdInput,
          title: normalizeDashboardTitle(
            (() => {
              const el = document.getElementById("settingsTitle");
              return el ? el.value.trim() : "";
            })(),
          ),
        });
      } catch (e) {
        if (err) {
          err.textContent =
            "Could not save OAuth settings. " + (e.message || "");
          err.style.display = "block";
        }
        return;
      }
      syncDiscoveryButtonState();
      if (applyOAuthClientChange(oauthClientIdInput)) {
        showToast("OAuth client saved — sign in to continue.", "success");
        closeCommandCenterSettingsModal();
      } else {
        showToast("OAuth client saved — reloading…", "success");
        setTimeout(() => window.location.reload(), 400);
      }
      return;
    }
    if (err) {
      err.textContent =
        "Paste your spreadsheet’s full URL from the browser bar, or the Sheet ID only (the long id between /d/ and /edit).";
      err.style.display = "block";
    }
    const Tabs = window.JobBoredSettingsTabs;
    if (Tabs) Tabs.activateTabForField("settingsSheetId");
    return;
  }
  if (sheetEl) sheetEl.value = sheetId;
  const val = (id) => {
    const el = document.getElementById(id);
    return el ? el.value.trim() : "";
  };
  const provEl = document.getElementById("settingsResumeProvider");
  const provider =
    provEl &&
    ["gemini", "openai", "anthropic", "webhook"].includes(provEl.value)
      ? provEl.value
      : "gemini";
  const payload = {
    sheetId,
    oauthClientId: val("settingsOAuthClientId"),
    title: normalizeDashboardTitle(val("settingsTitle")),
    discoveryWebhookUrl: val("settingsDiscoveryWebhookUrl"),
    discoveryWebhookSecret: val("settingsDiscoveryWebhookSecret"),
    jobPostingScrapeUrl: val("settingsJobPostingScrapeUrl"),
    atsScoringMode:
      val("settingsAtsScoringMode").toLowerCase() === "webhook"
        ? "webhook"
        : "server",
    atsScoringServerUrl: val("settingsAtsScoringServerUrl"),
    atsScoringWebhookUrl: val("settingsAtsScoringWebhookUrl"),
    resumeProvider: provider,
    resumeGeminiApiKey: val("settingsResumeGeminiApiKey"),
    resumeGeminiModel: val("settingsResumeGeminiModel") || resolveGeminiModel(),
    resumeOpenAIApiKey: val("settingsResumeOpenAIApiKey"),
    resumeOpenAIModel: val("settingsResumeOpenAIModel") || "gpt-4o-mini",
    resumeAnthropicApiKey: val("settingsResumeAnthropicApiKey"),
    resumeAnthropicModel:
      val("settingsResumeAnthropicModel") || "claude-sonnet-4-6",
    resumeGenerationWebhookUrl: val("settingsResumeGenerationWebhookUrl"),
  };

  const UC = window.CommandCenterUserContent;
  if (UC && typeof UC.saveDiscoveryProfile === "function") {
    try {
      // Handle grounded_web checkbox
      const gwEl = document.getElementById("settingsDiscoveryGroundedWeb");
      const groundedWebEnabled = gwEl ? gwEl.checked : true;
      await UC.saveDiscoveryProfile({
        targetRoles: val("settingsDiscoveryTargetRoles"),
        locations: val("settingsDiscoveryLocations"),
        remotePolicy: val("settingsDiscoveryRemotePolicy"),
        seniority: val("settingsDiscoverySeniority"),
        keywordsInclude: val("settingsDiscoveryKeywordsInclude"),
        keywordsExclude: val("settingsDiscoveryKeywordsExclude"),
        maxLeadsPerRun: val("settingsDiscoveryMaxLeadsPerRun"),
        groundedWebEnabled,
      });
    } catch (e) {
      console.warn("[JobBored] save discovery profile:", e);
      if (err) {
        err.textContent =
          "Could not save discovery preferences. " + (e.message || "");
        err.style.display = "block";
      }
      return;
    }
  }

  try {
    writeStoredConfigOverrides(payload);
  } catch (e) {
    if (err) {
      err.textContent =
        "Could not save (storage may be full or disabled). " +
        (e.message || "");
      err.style.display = "block";
    }
    return;
  }
  SHEET_ID = sheetId;
  setDashboardSheetLinks();
  const savedWebhookUrl = normalizeDiscoveryWebhookIdentity(
    payload.discoveryWebhookUrl,
  );
  if (!savedWebhookUrl) {
    await recordDiscoveryEngineState(
      "",
      DISCOVERY_ENGINE_STATE_NONE,
      "settings_saved",
    );
  } else {
    const managedUrl = getManagedAppsScriptWebhookIdentity();
    const savedState = getSavedDiscoveryEngineStateForUrl(savedWebhookUrl);
    await recordDiscoveryEngineState(
      savedWebhookUrl,
      savedState && savedState.state
        ? savedState.state
        : managedUrl && managedUrl === savedWebhookUrl
          ? DISCOVERY_ENGINE_STATE_STUB_ONLY
          : DISCOVERY_ENGINE_STATE_UNVERIFIED,
      "settings_saved",
    );
  }
  syncDiscoveryButtonState();
  showToast("Settings saved — reloading…", "success");
  setTimeout(() => window.location.reload(), 400);
}

/**
 * Nuclear "Clear settings": wipes config, OAuth localStorage, IndexedDB user
 * content, revokes the Google access token, and sets a one-shot flag so the
 * next interactive sign-in forces the consent screen. After reload the user
 * is in a true greenfield state (no auto sign-in, no stale resume/profile).
 *
 * Order matters: revoke uses the in-memory token, so we must revoke BEFORE
 * clearing in-memory auth state.
 */
async function performSettingsClearOverrides() {
  if (!canUseLocalStorage()) {
    showToast(
      "This browser blocked local storage — nothing was cleared.",
      "error",
      true,
    );
    return;
  }

  // 1) Revoke Google access token so silent re-auth via prompt:"none" cannot
  //    re-issue from the prior consent grant. Best-effort — network/blocker
  //    failures are non-fatal because we still wipe local state below.
  try {
    if (
      accessToken &&
      window.google &&
      google.accounts &&
      google.accounts.oauth2 &&
      typeof google.accounts.oauth2.revoke === "function"
    ) {
      await new Promise((resolve) => {
        try {
          google.accounts.oauth2.revoke(accessToken, () => resolve());
        } catch (_) {
          resolve();
        }
        // Hard timeout in case Google never invokes the callback.
        setTimeout(resolve, 1500);
      });
    }
  } catch (_) {
    /* best-effort revoke */
  }

  // 2) Drop in-memory auth + clear OAuth localStorage (both keys).
  try {
    clearSessionAuthState();
  } catch (_) {
    /* clearSessionAuthState already calls clearPersisted*; defensive */
  }
  try {
    clearPersistedOAuthSession();
  } catch (_) {}
  try {
    clearPersistedRuntimeOAuthSession();
  } catch (_) {}

  // 3) Clear stored config overrides (sheet ID, OAuth client ID, webhook URL,
  //    discovery profile, etc.).
  try {
    localStorage.removeItem(COMMAND_CENTER_CONFIG_OVERRIDE_KEY);
  } catch (_) {
    showToast("Could not clear saved settings (storage error).", "error", true);
    return;
  }

  // 4) Clear other JobBored localStorage breadcrumbs that would otherwise
  //    leak across a "greenfield" reset.
  try {
    localStorage.removeItem(DISCOVERY_TRANSPORT_SETUP_KEY);
  } catch (_) {}
  try {
    localStorage.removeItem(DISCOVERY_RUN_TRACKER_KEY);
  } catch (_) {}

  // 5) Wipe IndexedDB user content (resume, samples, drafts, AI context).
  //    Uses deleteDatabase which fully drops the DB — next openDb call will
  //    re-create the schema empty.
  try {
    if (window.indexedDB && typeof indexedDB.deleteDatabase === "function") {
      await new Promise((resolve) => {
        let settled = false;
        const finish = () => {
          if (settled) return;
          settled = true;
          resolve();
        };
        try {
          const req = indexedDB.deleteDatabase("command-center-user-content");
          req.onsuccess = finish;
          req.onerror = finish;
          req.onblocked = finish;
        } catch (_) {
          finish();
        }
        // Hard timeout: blocked deletes can hang if another tab holds a connection.
        setTimeout(finish, 1500);
      });
    }
  } catch (_) {
    /* best-effort wipe */
  }

  // 6) Arm the one-shot consent flag so the next signIn() forces Google's
  //    consent screen instead of silently re-issuing a token. This is what
  //    makes "Clear settings" feel like a true greenfield reset for testing.
  try {
    localStorage.setItem(FORCE_CONSENT_PROMPT_KEY, "1");
  } catch (_) {}

  hideSettingsClearConfirmBar();
  window.location.reload();
}

function initCommandCenterSettings() {
  const modal = document.getElementById("settingsModal");
  document.getElementById("settingsBtn")?.addEventListener("click", () => {
    void openCommandCenterSettingsModal();
  });
  document
    .getElementById("setupOpenSettingsBtn")
    ?.addEventListener("click", () => {
      if (!getSheetId()) {
        showToast("Create or connect your Pipeline sheet first.", "info");
        return;
      }
      void requestDiscoverySetup({
        entryPoint: "setup_screen",
        allowWhileOnboarding: true,
      });
    });
  document
    .getElementById("setupOpenSettingsLaterBtn")
    ?.addEventListener("click", () => {
      void openCommandCenterSettingsModal();
    });
  document
    .getElementById("settingsModalClose")
    ?.addEventListener("click", () => {
      closeCommandCenterSettingsModal();
    });
  if (modal) {
    modal.addEventListener("click", (e) => {
      if (e.target === modal) closeCommandCenterSettingsModal();
    });
  }
  document
    .getElementById("settingsResumeProvider")
    ?.addEventListener("change", () => {
      updateSettingsProviderPanels();
    });
  document.getElementById("settingsSaveBtn")?.addEventListener("click", () => {
    void saveCommandCenterSettingsFromForm();
  });
  document.getElementById("settingsClearBtn")?.addEventListener("click", () => {
    showSettingsClearConfirmBar();
  });
  document
    .getElementById("settingsClearConfirmCancel")
    ?.addEventListener("click", () => {
      hideSettingsClearConfirmBar();
    });
  document
    .getElementById("settingsClearConfirmYes")
    ?.addEventListener("click", () => {
      performSettingsClearOverrides();
    });
  const sheetField = document.getElementById("settingsSheetId");
  if (sheetField) {
    sheetField.addEventListener("input", () => {
      if (!appsScriptDeployBusy) appsScriptDeployStatus = null;
      renderAppsScriptDeployUi();
    });
    sheetField.addEventListener("blur", () => {
      const id = parseGoogleSheetId(sheetField.value);
      if (id) sheetField.value = id;
      if (!appsScriptDeployBusy) appsScriptDeployStatus = null;
      renderAppsScriptDeployUi();
    });
  }
  document
    .getElementById("settingsOAuthClientId")
    ?.addEventListener("input", () => {
      if (!appsScriptDeployBusy) appsScriptDeployStatus = null;
      renderAppsScriptDeployUi();
    });
  document
    .getElementById("settingsDiscoveryWebhookUrl")
    ?.addEventListener("input", () => {
      renderDiscoveryEngineStatusUi();
    });
  document
    .getElementById("settingsDiscoveryWebhookUrl")
    ?.addEventListener("blur", () => {
      renderDiscoveryEngineStatusUi();
    });
  document
    .getElementById("settingsAppsScriptDeployBtn")
    ?.addEventListener("click", () => {
      void deployAppsScriptStubFromSettings();
    });
  document
    .getElementById("settingsAppsScriptRecheckBtn")
    ?.addEventListener("click", () => {
      void recheckAppsScriptPublicAccessFromSettings();
    });
  document
    .getElementById("settingsAppsScriptCopyBtn")
    ?.addEventListener("click", () => {
      const url =
        appsScriptDeployStateCache &&
        typeof appsScriptDeployStateCache.webAppUrl === "string"
          ? appsScriptDeployStateCache.webAppUrl.trim()
          : "";
      if (!url) {
        showToast("No managed Apps Script URL to copy yet", "info");
        return;
      }
      copyTextToClipboard(url);
    });
}

function initSetupAndSheetAccessActions() {
  document
    .getElementById("setupCreateStarterSheetBtn")
    ?.addEventListener("click", () => {
      void handleSetupCreateStarterSheet();
    });
  document
    .getElementById("sheetAccessGateSignInBtn")
    ?.addEventListener("click", () => {
      signIn();
    });
  document
    .getElementById("sheetAccessGateOpenSettingsBtn")
    ?.addEventListener("click", () => {
      const input = document.getElementById(
        "sheetAccessGateOAuthClientIdInput",
      );
      const raw = input && input.value ? String(input.value).trim() : "";
      if (
        raw &&
        /\.apps\.googleusercontent\.com$/i.test(raw) &&
        raw !== "YOUR_CLIENT_ID_HERE.apps.googleusercontent.com"
      ) {
        mergeStoredConfigOverridePatch({ oauthClientId: raw });
      }
      void openCommandCenterSettingsModal();
    });
  document
    .getElementById("sheetAccessGateReloadBtn")
    ?.addEventListener("click", () => {
      window.location.reload();
    });
  initLoginGateOAuthUi();
  renderSetupStarterSheetUi();
}

function initPipelineEmptyAndBriefActions() {
  document
    .getElementById("emptyStateActions")
    ?.addEventListener("click", (e) => {
      const b = e.target.closest("[data-empty-action]");
      if (!b) return;
      const a = b.getAttribute("data-empty-action");
      if (a === "settings" || a === "open_setup") {
        void requestDiscoverySetup({
          entryPoint: "empty_state",
          allowWhileOnboarding: true,
        });
      }
      if (a === "run_discovery") {
        void triggerDiscoveryRun();
      }
    });
  document
    .querySelector(".daily-brief-panel")
    ?.addEventListener("click", (e) => {
      const rangeBtn = e.target.closest("[data-range]");
      if (rangeBtn) {
        briefActivityRange = rangeBtn.dataset.range;
        const el = document.getElementById("briefInsights");
        if (el && pipelineData.length)
          el.innerHTML = renderAreaWidget(pipelineData, briefActivityRange);
        return;
      }
      const feedItem = e.target.closest(
        '[data-action="open-detail"][data-stable-key]',
      );
      if (feedItem) {
        const key = parseInt(feedItem.dataset.stableKey, 10);
        if (!Number.isNaN(key)) openJobDetail(key);
        return;
      }
      const b = e.target.closest("[data-brief-action]");
      if (!b) return;
      const a = b.getAttribute("data-brief-action");
      if (a === "settings" || a === "open_setup") {
        void requestDiscoverySetup({
          entryPoint: "brief",
          allowWhileOnboarding: true,
        });
      }
      if (a === "run_discovery") {
        void triggerDiscoveryRun();
      }
      if (a === "agent" || a === "paths") openDiscoveryPathsModal();
    });
}

/** Plain text → safe HTML for cover letter preview (paragraphs + line breaks). */
function formatCoverLetterPreviewHtml(text) {
  if (!text || !String(text).trim()) return "";
  return String(text)
    .trim()
    .split(/\n\s*\n/)
    .filter(Boolean)
    .map((block) => {
      const escaped = escapeHtml(block);
      const withBreaks = escaped.replace(/\n/g, "<br />");
      return `<p class="doc-preview__p">${withBreaks}</p>`;
    })
    .join("");
}

/** Plain text → safe HTML for resume preview (section headers + lines). */
function formatResumePreviewHtml(text) {
  if (!text || !String(text).trim()) return "";
  const lines = String(text).split("\n");
  const parts = [];
  for (const line of lines) {
    const t = line.trim();
    if (!t) {
      parts.push('<div class="doc-preview__gap" aria-hidden="true"></div>');
      continue;
    }
    const esc = escapeHtml(line);
    const upper = t.toUpperCase();
    const isSection =
      t.length >= 3 &&
      t.length <= 56 &&
      t === upper &&
      /^[A-Z0-9\s&/\-–—:,.]+$/.test(t) &&
      !/\d{4}\s*[-–]\s*\d{4}/.test(t);
    if (isSection) {
      parts.push(`<h2 class="doc-preview__section">${esc}</h2>`);
    } else {
      parts.push(`<p class="doc-preview__resume-line">${esc}</p>`);
    }
  }
  return parts.join("");
}

function formatContextDateLabel(iso) {
  if (!iso) return "unknown";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "unknown";
  return d.toLocaleDateString();
}

function buildGenerationContextUsed(profile) {
  if (!profile || typeof profile !== "object") return null;
  const sourceMeta =
    profile.sourceMeta && typeof profile.sourceMeta === "object"
      ? profile.sourceMeta
      : {};
  return {
    resume: {
      chars: String(profile.resumeText || "").length,
      updatedAt: sourceMeta.resumeUpdatedAt || "",
    },
    linkedIn: {
      chars: String(profile.linkedinProfileText || "").length,
      updatedAt: sourceMeta.linkedinUpdatedAt || "",
    },
    aiDump: {
      chars: String(profile.additionalContextText || "").length,
      updatedAt: sourceMeta.additionalContextUpdatedAt || "",
    },
  };
}

function renderGenerationContextUsed(el, contextUsed) {
  if (!el) return;
  if (!contextUsed) {
    el.hidden = true;
    el.innerHTML = "";
    return;
  }
  const mk = (label, v) =>
    `<span class="doc-output-context__chip"><strong>${escapeHtml(label)}</strong>${Number(v.chars || 0).toLocaleString()} chars · ${escapeHtml(formatContextDateLabel(v.updatedAt || ""))}</span>`;
  el.innerHTML = [
    mk("Resume", contextUsed.resume || {}),
    mk("LinkedIn", contextUsed.linkedIn || {}),
    mk("AI dump", contextUsed.aiDump || {}),
  ].join("");
  el.hidden = false;
}

function renderDocMatchGroupHtml(title, terms) {
  if (!terms || !terms.length) return "";
  return `<div class="doc-match-group"><p class="doc-match-group__label">${escapeHtml(title)}</p><ul class="doc-match-list">${renderMatchItemsHtml(terms, "doc-match-item")}</ul></div>`;
}

function hashStringForCache(raw) {
  const s = String(raw || "");
  let h = 2166136261;
  for (let i = 0; i < s.length; i += 1) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(16);
}

function computeAtsScorecardCacheKey(text, job, feature) {
  const t = String(text || "").trim();
  const j = job && typeof job === "object" ? job : null;
  if (!t || !j) return "";
  const title = String(j.title || "").trim();
  const company = String(j.company || "").trim();
  if (!title || !company) return "";
  const enr =
    j._postingEnrichment && typeof j._postingEnrichment === "object"
      ? j._postingEnrichment
      : {};
  const jobKey = getJobOpportunityKey(j);
  const atsCfg = getAtsScoringConfig();
  const transportPart =
    atsCfg.mode === "webhook"
      ? `webhook|${String(atsCfg.webhookUrl || "").trim()}`
      : `server|${String(atsCfg.serverUrl || "").trim()}`;
  return [
    feature === "resume_update" ? "resume_update" : "cover_letter",
    jobKey,
    hashStringForCache(t),
    hashStringForCache(transportPart),
    hashStringForCache(
      `${title}|${company}|${String(enr.description || "")}|${String(
        (enr.requirements || []).join("||"),
      )}`,
    ),
  ].join("|");
}

function normalizeAtsScorecardResult(raw, fallbackModel) {
  const input = raw && typeof raw === "object" ? raw : {};
  const ds =
    input.dimensionScores && typeof input.dimensionScores === "object"
      ? input.dimensionScores
      : {};
  const toScore = (v) => {
    const n = Number(v);
    if (!Number.isFinite(n)) return 0;
    return Math.max(0, Math.min(100, Math.round(n)));
  };
  const toSeverity = (v) => {
    const x = String(v || "").toLowerCase();
    return x === "high" || x === "low" || x === "medium" ? x : "medium";
  };
  const toSourceType = (v) => {
    const x = String(v || "").toLowerCase();
    return ["resume", "cover_letter", "job", "profile"].includes(x)
      ? x
      : "profile";
  };
  return {
    schemaVersion: 1,
    overallScore: toScore(input.overallScore),
    dimensionScores: {
      requirementsCoverage: toScore(ds.requirementsCoverage),
      experienceRelevance: toScore(ds.experienceRelevance),
      impactClarity: toScore(ds.impactClarity),
      atsParseability: toScore(ds.atsParseability),
      toneFit: toScore(ds.toneFit),
    },
    topStrengths: Array.isArray(input.topStrengths)
      ? input.topStrengths
          .map((x) => String(x || "").trim())
          .filter(Boolean)
          .slice(0, 8)
      : [],
    criticalGaps: Array.isArray(input.criticalGaps)
      ? input.criticalGaps
          .map((x) => ({
            gap: String((x && x.gap) || "").trim(),
            whyItMatters: String((x && x.whyItMatters) || "").trim(),
            severity: toSeverity(x && x.severity),
          }))
          .filter((x) => x.gap && x.whyItMatters)
          .slice(0, 10)
      : [],
    evidence: Array.isArray(input.evidence)
      ? input.evidence
          .map((x) => ({
            claim: String((x && x.claim) || "").trim(),
            sourceSnippet: String((x && x.sourceSnippet) || "").trim(),
            sourceType: toSourceType(x && x.sourceType),
          }))
          .filter((x) => x.claim && x.sourceSnippet)
          .slice(0, 10)
      : [],
    rewriteSuggestions: Array.isArray(input.rewriteSuggestions)
      ? input.rewriteSuggestions
          .map((x) => ({
            targetSection: String((x && x.targetSection) || "").trim(),
            before: String((x && x.before) || "").trim(),
            after: String((x && x.after) || "").trim(),
            rationale: String((x && x.rationale) || "").trim(),
          }))
          .filter((x) => x.targetSection && x.after)
          .slice(0, 8)
      : [],
    confidence: (() => {
      const n = Number(input.confidence);
      return Number.isFinite(n) ? Math.max(0, Math.min(1, n)) : 0.5;
    })(),
    model: String(input.model || fallbackModel || "unknown"),
  };
}

function buildAtsScorecardRequestPayload(text, job, session) {
  const clip = (v, max) =>
    String(v || "")
      .trim()
      .slice(0, max);
  const clipArr = (arr, maxItems, maxChars) =>
    Array.isArray(arr)
      ? arr
          .slice(0, maxItems)
          .map((x) => clip(x, maxChars))
          .filter(Boolean)
      : [];
  const bundle = session && session.bundle ? session.bundle : null;
  const feature =
    session && session.feature === "resume_update"
      ? "resume_update"
      : "cover_letter";
  const sourceJob = bundle && bundle.job ? bundle.job : job || {};
  const postingEnrichment =
    sourceJob && sourceJob.postingEnrichment
      ? sourceJob.postingEnrichment
      : job && job._postingEnrichment
        ? {
            description: job._postingEnrichment.description || "",
            requirements: Array.isArray(job._postingEnrichment.requirements)
              ? job._postingEnrichment.requirements
              : [],
            skills: Array.isArray(job._postingEnrichment.skills)
              ? job._postingEnrichment.skills
              : [],
            mustHaves: Array.isArray(job._postingEnrichment.mustHaves)
              ? job._postingEnrichment.mustHaves
              : [],
            responsibilities: Array.isArray(
              job._postingEnrichment.responsibilities,
            )
              ? job._postingEnrichment.responsibilities
              : [],
            toolsAndStack: Array.isArray(job._postingEnrichment.toolsAndStack)
              ? job._postingEnrichment.toolsAndStack
              : [],
          }
        : null;
  const payload = {
    event: "command-center.ats-scorecard",
    schemaVersion: 1,
    feature,
    docText: clip(text, 18000),
    job: {
      title: clip(
        (sourceJob && sourceJob.title) || (job && job.title) || "",
        300,
      ),
      company: clip(
        (sourceJob && sourceJob.company) || (job && job.company) || "",
        300,
      ),
      url: clip((sourceJob && sourceJob.url) || (job && job.link) || "", 3000),
      fitAssessment: clip(
        (sourceJob && sourceJob.fitAssessment) ||
          (job && job.fitAssessment) ||
          "",
        2500,
      ),
      talkingPoints: clip(
        (sourceJob && sourceJob.talkingPoints) ||
          (job && job.talkingPoints) ||
          "",
        2500,
      ),
      notes: clip(
        (sourceJob && sourceJob.notes) || (job && job.notes) || "",
        3000,
      ),
    },
  };
  if (postingEnrichment) {
    payload.job.postingEnrichment = {
      description: clip(postingEnrichment.description || "", 7000),
      requirements: clipArr(postingEnrichment.requirements, 35, 350),
      skills: clipArr(postingEnrichment.skills, 40, 180),
      mustHaves: clipArr(postingEnrichment.mustHaves, 20, 350),
      responsibilities: clipArr(postingEnrichment.responsibilities, 20, 350),
      toolsAndStack: clipArr(postingEnrichment.toolsAndStack, 24, 180),
    };
  }
  if (bundle && bundle.profile) {
    payload.profile = {
      candidateProfileText: clip(
        bundle.profile.candidateProfileText || "",
        10000,
      ),
      resumeSourceText: clip(bundle.profile.resumeSourceText || "", 8000),
      linkedinProfileText: clip(bundle.profile.linkedinProfileText || "", 5000),
      additionalContextText: clip(
        bundle.profile.additionalContextText || "",
        5000,
      ),
    };
  }
  if (bundle && bundle.instructions) {
    payload.instructions = {
      userNotes: clip(bundle.instructions.userNotes || "", 1200),
      refinementFeedback: clip(
        bundle.instructions.refinementFeedback || "",
        1200,
      ),
    };
  }
  if (bundle && bundle.meta) {
    payload.meta = {};
    if (Object.prototype.hasOwnProperty.call(bundle.meta, "sheetId")) {
      payload.meta.sheetId = bundle.meta.sheetId ?? null;
    }
    if (bundle.meta.generatedAt) {
      payload.meta.generatedAt = String(bundle.meta.generatedAt).trim();
    }
  }
  return payload;
}

async function fetchAtsScorecard(payload) {
  const cfg = getAtsScoringConfig();
  const endpoint = getAtsScorecardApiUrl();
  if (!endpoint) {
    throw new Error(
      cfg.mode === "webhook"
        ? 'Set "ATS scorecard webhook URL" in Settings.'
        : 'Set "ATS scorecard server URL" in Settings or run local server.',
    );
  }
  const resp = await fetch(endpoint, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  const raw = await resp.text();
  let data = null;
  try {
    data = raw ? JSON.parse(raw) : null;
  } catch (_) {
    data = null;
  }
  if (!resp.ok) {
    let fallback = `ATS scorecard failed (${resp.status})`;
    if (resp.status === 413) {
      fallback =
        "ATS request was too large for the endpoint. Reduce ATS payload size or increase server body limit.";
    }
    const cleanedRaw =
      raw && /<html|<!doctype/i.test(raw)
        ? fallback
        : sanitizeAtsText(raw).slice(0, 500);
    const msg =
      (data && (data.error || data.message)) || cleanedRaw || fallback;
    throw new Error(String(msg).slice(0, 500));
  }
  if (!data || typeof data !== "object") {
    throw new Error("ATS endpoint returned invalid JSON.");
  }
  return normalizeAtsScorecardResult(
    data,
    cfg.mode === "webhook" ? "webhook" : "server",
  );
}

function renderAtsBulletGroupHtml(title, rows) {
  if (!rows || !rows.length) return "";
  return `<div class="doc-match-group"><p class="doc-match-group__label">${escapeHtml(title)}</p><ul class="doc-match-list">${rows.join("")}</ul></div>`;
}

function sanitizeAtsText(raw) {
  let text = String(raw || "");
  if (!text) return "";
  text = text
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/(p|div|li|h[1-6])>/gi, "\n")
    .replace(/<[^>]*>/g, " ")
    .replace(/\[(.*?)\]\((.*?)\)/g, "$1")
    .replace(/[*_`>#-]/g, " ")
    .replace(/[ \t]+/g, " ")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
  return text;
}

function renderAtsInsightRow(title, detail, meta, status) {
  const tone =
    status === "high"
      ? "missing"
      : status === "medium"
        ? "partial"
        : status === "low"
          ? "found"
          : status || "partial";
  const safeTitle = sanitizeAtsText(title);
  const safeDetail = sanitizeAtsText(detail);
  const safeMeta = sanitizeAtsText(meta);
  return `<li class="doc-match-item doc-match-item--${escapeHtml(tone)}"><span class="doc-match-item__status" aria-hidden="true"></span><span class="doc-match-item__label"><span class="doc-match-item__title">${escapeHtml(safeTitle)}</span>${safeDetail ? `<span class="doc-match-item__detail">${escapeHtml(safeDetail)}</span>` : ""}</span><span class="doc-match-item__meta">${escapeHtml(safeMeta || "")}</span></li>`;
}

function renderAtsScorecardGroupsHtml(scorecard) {
  const strengths = renderAtsBulletGroupHtml(
    "Top strengths",
    (scorecard.topStrengths || []).map((s) =>
      renderAtsInsightRow(s, "", "Strength", "found"),
    ),
  );
  const gaps = renderAtsBulletGroupHtml(
    "Critical gaps",
    (scorecard.criticalGaps || []).map((g) =>
      renderAtsInsightRow(
        g.gap,
        g.whyItMatters,
        g.severity || "medium",
        g.severity || "medium",
      ),
    ),
  );
  const suggestions = renderAtsBulletGroupHtml(
    "Rewrite suggestions",
    (scorecard.rewriteSuggestions || [])
      .slice(0, 4)
      .map((s) =>
        renderAtsInsightRow(
          s.targetSection,
          `After: ${s.after}${s.rationale ? ` · Why: ${s.rationale}` : ""}`,
          "Suggested line",
          "partial",
        ),
      ),
  );
  const evidence = renderAtsBulletGroupHtml(
    "Evidence checks",
    (scorecard.evidence || [])
      .slice(0, 4)
      .map((e) =>
        renderAtsInsightRow(
          e.claim,
          e.sourceSnippet,
          e.sourceType || "source",
          "found",
        ),
      ),
  );
  return [strengths, gaps, suggestions, evidence].filter(Boolean).join("");
}

function formatAtsDimensionSummary(scorecard) {
  const d = scorecard.dimensionScores || {};
  return [
    `Req ${Number(d.requirementsCoverage || 0)}%`,
    `Experience ${Number(d.experienceRelevance || 0)}%`,
    `Impact ${Number(d.impactClarity || 0)}%`,
    `Parseability ${Number(d.atsParseability || 0)}%`,
    `Tone ${Number(d.toneFit || 0)}%`,
  ].join(" · ");
}

function startAtsScorecardAnalysis(cacheKey, payload) {
  atsScorecardState = {
    ...atsScorecardState,
    cacheKey,
    status: "loading",
    result: null,
    error: "",
    payload,
  };
  void (async () => {
    try {
      const result = await fetchAtsScorecard(payload);
      if (atsScorecardState.cacheKey !== cacheKey) return;
      atsScorecardState = {
        ...atsScorecardState,
        status: "success",
        result,
        error: "",
      };
    } catch (err) {
      if (atsScorecardState.cacheKey !== cacheKey) return;
      atsScorecardState = {
        ...atsScorecardState,
        status: "error",
        result: null,
        error:
          err && err.message ? String(err.message) : "ATS scorecard failed",
      };
    }
    renderResumeGenerateInsights(
      payload.docText,
      lastResumeGenerationSession ? lastResumeGenerationSession.job : null,
    );
  })();
}

function getResumeGenerateDraftTextForInsights(fallbackBodyText) {
  const modal = document.getElementById("resumeGenerateModal");
  const ta = document.getElementById("resumeGenerateOutput");
  if (
    modal &&
    modal.style.display === "flex" &&
    ta &&
    modal.getAttribute("aria-busy") !== "true"
  ) {
    const v = String(ta.value || "").trim();
    if (v) return v;
  }
  return String(fallbackBodyText || "").trim();
}

function scheduleResumeGenerateAtsRefresh() {
  if (resumeGenerateAtsRefreshTimer) {
    clearTimeout(resumeGenerateAtsRefreshTimer);
  }
  resumeGenerateAtsRefreshTimer = setTimeout(() => {
    resumeGenerateAtsRefreshTimer = null;
    const ta = document.getElementById("resumeGenerateOutput");
    if (!ta || !lastResumeGenerationSession) return;
    renderResumeGenerateInsights(ta.value, lastResumeGenerationSession.job);
  }, 900);
}

function renderDraftHistoryItemHtml(draft, activeDraftId) {
  const metaBits = [
    `V${Number(draft.versionNumber || 0)}`,
    getDraftModeLabel(draft.mode),
    formatDraftSavedAt(draft.createdAt),
  ];
  const noteBits = [];
  if (draft.userNotes) noteBits.push("Has job notes");
  if (draft.refinementFeedback) noteBits.push("Includes refinement");
  const isActive = draft.id === activeDraftId;
  return `<button type="button" class="draft-history-item${isActive ? " draft-history-item--active" : ""}" data-action="open-saved-draft" data-draft-id="${escapeHtml(draft.id)}" aria-pressed="${isActive ? "true" : "false"}"><span class="draft-history-item__meta">${metaBits.map((bit) => `<span class="draft-history-item__chip">${escapeHtml(bit)}</span>`).join("")}</span><span class="draft-history-item__preview">${escapeHtml(draft.excerpt || "")}</span>${noteBits.length ? `<span class="draft-history-item__notes">${escapeHtml(noteBits.join(" · "))}</span>` : ""}</button>`;
}

function renderResumeGenerateInsights(bodyText, job) {
  const wrap = document.getElementById("resumeGenerateInsights");
  const atsCard = document.getElementById("resumeGenerateAtsCard");
  const atsScore = document.getElementById("resumeGenerateAtsScore");
  const atsSummary = document.getElementById("resumeGenerateAtsSummary");
  const atsHint = document.getElementById("resumeGenerateAtsHint");
  const atsGroups = document.getElementById("resumeGenerateAtsGroups");
  const historyCard = document.getElementById("resumeGenerateHistoryCard");
  const historyCount = document.getElementById("resumeGenerateHistoryCount");
  const historySummary = document.getElementById(
    "resumeGenerateHistorySummary",
  );
  const historyList = document.getElementById("resumeGenerateHistoryList");
  if (!wrap) return;

  const text = getResumeGenerateDraftTextForInsights(bodyText);
  if (!text) {
    wrap.hidden = true;
    if (atsCard) atsCard.hidden = true;
    if (historyCard) historyCard.hidden = true;
    return;
  }

  const session = lastResumeGenerationSession;
  const feature =
    session && session.feature === "resume_update"
      ? "resume_update"
      : "cover_letter";
  const cacheKey = computeAtsScorecardCacheKey(text, job, feature);
  const atsPayload = cacheKey
    ? buildAtsScorecardRequestPayload(text, job, session)
    : null;
  if (atsCard) {
    if (
      !cacheKey ||
      !atsPayload ||
      !atsPayload.job.title ||
      !atsPayload.job.company
    ) {
      atsCard.hidden = true;
    } else {
      if (atsScorecardState.cacheKey !== cacheKey) {
        startAtsScorecardAnalysis(cacheKey, atsPayload);
      }
      if (atsScorecardState.status === "loading") {
        if (atsScore) atsScore.textContent = "…";
        if (atsSummary) {
          atsSummary.textContent =
            "Analyzing this draft against the role with structured LLM scoring…";
        }
        if (atsHint) {
          atsHint.hidden = false;
          atsHint.textContent =
            "Scoring the latest text in the editor after generate or refine finishes.";
        }
        if (atsGroups) atsGroups.innerHTML = "";
      } else if (
        atsScorecardState.status === "success" &&
        atsScorecardState.result
      ) {
        const scorecard = atsScorecardState.result;
        if (atsScore) atsScore.textContent = `${scorecard.overallScore}%`;
        if (atsSummary) {
          const conf = Math.round(Number(scorecard.confidence || 0) * 100);
          atsSummary.textContent = `${formatAtsDimensionSummary(
            scorecard,
          )} · confidence ${conf}% · model ${scorecard.model}`;
        }
        if (atsHint) {
          const topGap = scorecard.criticalGaps && scorecard.criticalGaps[0];
          atsHint.textContent = topGap
            ? `Priority fix: ${sanitizeAtsText(topGap.gap)}`
            : "No critical gaps identified for this draft.";
          atsHint.hidden = false;
        }
        if (atsGroups) {
          atsGroups.innerHTML = renderAtsScorecardGroupsHtml(scorecard);
        }
      } else if (atsScorecardState.status === "error") {
        if (atsScore) atsScore.textContent = "—";
        if (atsSummary) {
          atsSummary.textContent =
            "Could not analyze this draft with ATS scorecard right now.";
        }
        if (atsHint) {
          atsHint.hidden = false;
          atsHint.textContent = atsScorecardState.error || "Unknown error";
        }
        if (atsGroups) {
          atsGroups.innerHTML =
            '<button type="button" class="btn-modal-secondary doc-insight-card__retry" data-action="retry-ats-scorecard">Retry analysis</button>';
        }
      }
      atsCard.hidden = false;
    }
  }

  const historyFeature =
    session && session.feature ? session.feature : "cover_letter";
  const historyDrafts = job ? getDraftsForJob(job, historyFeature) : [];
  if (historyCard) {
    if (historyDrafts.length) {
      if (historyCount) {
        historyCount.textContent = `${historyDrafts.length} version${historyDrafts.length === 1 ? "" : "s"}`;
      }
      if (historySummary) {
        historySummary.textContent =
          "Every generation and refine is auto-saved to this role. Pick any version to reopen or continue from.";
      }
      if (historyList) {
        historyList.innerHTML = historyDrafts
          .map((draft) =>
            renderDraftHistoryItemHtml(
              draft,
              session ? session.savedDraftId || "" : "",
            ),
          )
          .join("");
      }
      historyCard.hidden = false;
    } else {
      if (historyList) historyList.innerHTML = "";
      historyCard.hidden = true;
    }
  }

  wrap.hidden = !!(
    (!atsCard || atsCard.hidden) &&
    (!historyCard || historyCard.hidden)
  );
}

function syncResumeGenerateFooterState() {
  const modal = document.getElementById("resumeGenerateModal");
  const ta = document.getElementById("resumeGenerateOutput");
  const feedback = document.getElementById("resumeGenerateFeedback");
  const refine = document.getElementById("resumeGenerateRefine");
  const copy = document.getElementById("resumeGenerateCopy");
  const print = document.getElementById("resumeGeneratePrint");
  const busy = modal && modal.getAttribute("aria-busy") === "true";
  const hasBody = !!(ta && String(ta.value || "").trim());
  const canRefine = !!(
    !busy &&
    hasBody &&
    lastResumeGenerationSession &&
    lastResumeGenerationSession.bundle &&
    feedback &&
    String(feedback.value || "").trim()
  );
  if (feedback) feedback.disabled = !!busy || !hasBody;
  if (refine) refine.disabled = !canRefine;
  if (copy) copy.disabled = !!busy || !hasBody;
  if (print) print.disabled = !!busy || !hasBody;
}

function openDraftNotesModal(dataIndex, feature) {
  const modal = document.getElementById("draftNotesModal");
  const title = document.getElementById("draftNotesTitle");
  const target = document.getElementById("draftNotesTarget");
  const input = document.getElementById("draftNotesInput");
  const generate = document.getElementById("draftNotesGenerate");
  const job = pipelineData[dataIndex];
  if (!modal || !job) return;
  pendingDraftNotesRequest = { dataIndex, feature };
  if (title) {
    title.textContent =
      feature === "cover_letter"
        ? "Notes for this cover letter"
        : "Notes for this resume";
  }
  if (target) {
    target.textContent = `${job.title || "Role"} · ${job.company || "Company"}`;
  }
  if (input) input.value = "";
  if (generate) {
    generate.textContent =
      feature === "cover_letter" ? "Generate cover letter" : "Generate resume";
  }
  modal.style.display = "flex";
  input?.focus();
}

function closeDraftNotesModal() {
  const modal = document.getElementById("draftNotesModal");
  if (modal) modal.style.display = "none";
  pendingDraftNotesRequest = null;
}

/**
 * @param {string} title
 * @param {string} statusText
 * @param {string} bodyText
 * @param {boolean} isLoading
 * @param {"cover_letter"|"resume_update"} [docKind]
 * @param {{ resume: { chars: number, updatedAt: string }, linkedIn: { chars: number, updatedAt: string }, aiDump: { chars: number, updatedAt: string } } | null} [contextUsed]
 * @param {object | null} [jobForAnalysis]
 */
async function openResumeGenerateModal(
  title,
  statusText,
  bodyText,
  isLoading,
  docKind,
  contextUsed,
  jobForAnalysis,
) {
  const modal = document.getElementById("resumeGenerateModal");
  const kicker = document.getElementById("resumeGenerateKicker");
  const h = document.getElementById("resumeGenerateTitle");
  const meta = document.getElementById("resumeGenerateMeta");
  const st = document.getElementById("resumeGenerateStatus");
  const context = document.getElementById("resumeGenerateContextUsed");
  const ta = document.getElementById("resumeGenerateOutput");
  const preview = document.getElementById("resumeGeneratePreview");
  const skel = document.getElementById("resumeGenerateSkeleton");
  const page = document.getElementById("resumeGeneratePage");
  if (!modal || !h || !ta) return;

  const themeId = await resolveVisualThemeIdForModal();
  if (preview) preview.setAttribute("data-visual-theme", themeId);
  fillVisualThemeSelect("resumeGenerateVisualTheme", themeId);

  const kind = docKind === "resume_update" ? "resume_update" : "cover_letter";
  const isLetter = kind === "cover_letter";

  if (kicker) {
    kicker.textContent = isLetter ? "Cover letter" : "Résumé";
  }
  h.textContent = title;
  if (meta) {
    meta.textContent = isLetter
      ? "Letter-style preview · auto-saved per role · copy as plain text or print to PDF"
      : "Résumé-style layout · auto-saved per role · copy as plain text or print to PDF";
  }
  renderGenerationContextUsed(context, contextUsed || null);

  ta.value = bodyText || "";

  const hasBody = !!(bodyText && String(bodyText).trim());
  const isError = !isLoading && !!(statusText && !hasBody);

  if (st) {
    st.textContent = statusText || "";
    st.style.display = statusText ? "block" : "none";
    st.classList.toggle("doc-output-status--error", isError);
    st.classList.toggle(
      "doc-output-status--loading",
      !!(isLoading && statusText),
    );
  }

  modal.setAttribute("aria-busy", isLoading ? "true" : "false");
  modal.dataset.docKind = kind;

  if (isLoading) {
    atsScorecardState = {
      cacheKey: "",
      status: "idle",
      result: null,
      error: "",
      payload: null,
    };
    if (resumeGenerateAtsRefreshTimer) {
      clearTimeout(resumeGenerateAtsRefreshTimer);
      resumeGenerateAtsRefreshTimer = null;
    }
    if (skel) skel.hidden = false;
    if (preview) {
      preview.hidden = true;
      preview.innerHTML = "";
    }
    if (page) page.classList.add("doc-paper--loading");
    renderResumeGenerateInsights("", null);
  } else {
    if (skel) skel.hidden = true;
    if (page) page.classList.remove("doc-paper--loading");
    if (preview) {
      if (hasBody) {
        preview.hidden = false;
        preview.className =
          "doc-preview " +
          (isLetter ? "doc-preview--letter" : "doc-preview--resume");
        preview.setAttribute("data-visual-theme", themeId);
        preview.innerHTML = isLetter
          ? formatCoverLetterPreviewHtml(bodyText)
          : formatResumePreviewHtml(bodyText);
      } else {
        preview.hidden = true;
        preview.innerHTML = "";
      }
    }
    renderResumeGenerateInsights(
      bodyText,
      jobForAnalysis ||
        (lastResumeGenerationSession ? lastResumeGenerationSession.job : null),
    );
  }

  modal.style.display = "flex";
  syncResumeGenerateFooterState();
}

function closeResumeGenerateModal() {
  const modal = document.getElementById("resumeGenerateModal");
  if (modal) {
    modal.style.display = "none";
    modal.setAttribute("aria-busy", "false");
  }
}

async function runResumeGeneration(dataIndex, feature, options) {
  const UC = getUserContent();
  const Bundle = getResumeBundle();
  const Gen = getResumeGenerate();
  if (!UC || !Bundle || !Gen) {
    showToast("Resume modules failed to load", "error");
    return;
  }

  const job = pipelineData[dataIndex];
  if (!job) {
    showToast("Job not found", "error");
    return;
  }

  if (
    typeof Gen.isResumeGenerationConfigured === "function" &&
    !Gen.isResumeGenerationConfigured()
  ) {
    showToast(
      'Set resumeGeminiApiKey in config.js for Gemini, or switch resumeProvider to "openai", "anthropic", or "webhook" (see SETUP.md).',
      "error",
      true,
    );
    return;
  }

  await UC.openDb();
  const active = await UC.getActiveResume();
  const linkedIn =
    typeof UC.getLinkedInProfile === "function"
      ? await UC.getLinkedInProfile()
      : { text: "" };
  const additional =
    typeof UC.getAdditionalContext === "function"
      ? await UC.getAdditionalContext()
      : { text: "" };
  const hasResume = !!(active && String(active.extractedText || "").trim());
  const hasLinkedIn = !!String(
    linkedIn && linkedIn.text ? linkedIn.text : "",
  ).trim();
  const hasAdditional = !!String(
    additional && additional.text ? additional.text : "",
  ).trim();
  if (!hasResume && !hasLinkedIn && !hasAdditional) {
    showToast(
      "Add resume, LinkedIn, or AI context in Profile first (best results use all three).",
      "error",
    );
    openMaterialsModal();
    return;
  }

  try {
    const userNotes =
      options && options.userNotes != null
        ? String(options.userNotes).trim()
        : "";
    const profile = await Bundle.assembleProfile(UC);
    const contextUsed = buildGenerationContextUsed(profile);
    const title =
      feature === "cover_letter" ? "Cover letter draft" : "Tailored resume";
    const feedbackEl = document.getElementById("resumeGenerateFeedback");
    if (feedbackEl) feedbackEl.value = "";
    await openResumeGenerateModal(
      title,
      "Generating…",
      "",
      true,
      feature,
      contextUsed,
      job,
    );
    const bundle = Bundle.buildResumeContextBundle(
      feature,
      job,
      profile,
      {
        maxWords: profile.preferences.defaultMaxWords,
        userNotes,
      },
      { sheetId: SHEET_ID },
    );
    lastResumeGenerationSession = {
      title,
      feature,
      bundle,
      contextUsed,
      job,
      savedDraftId: null,
      text: "",
    };
    const text = await Gen.generateFromBundle(bundle);
    let savedDraft = null;
    const UC2 = getUserContent();
    if (UC2 && typeof UC2.saveGeneratedDraft === "function") {
      try {
        savedDraft = await UC2.saveGeneratedDraft({
          feature,
          mode: "initial",
          text,
          job,
          userNotes,
        });
        await refreshGeneratedDraftLibraryCache();
        renderPipeline();
        if (activeDetailKey >= 0) refreshDrawerIfOpen(activeDetailKey);
      } catch (draftErr) {
        console.warn("[JobBored] save generated draft:", draftErr);
      }
    }
    lastResumeGenerationSession = {
      ...lastResumeGenerationSession,
      savedDraftId: savedDraft ? savedDraft.id : null,
      text,
    };
    await openResumeGenerateModal(
      title,
      "",
      text,
      false,
      feature,
      contextUsed,
      job,
    );
  } catch (err) {
    console.error("[JobBored] Resume generation:", err);
    const title =
      feature === "cover_letter" ? "Cover letter draft" : "Tailored resume";
    await openResumeGenerateModal(
      title,
      err.message || "Generation failed",
      "",
      false,
      feature,
      null,
      job,
    );
    showToast(err.message || "Generation failed", "error", true);
  }
}

async function refineLastResumeGeneration() {
  const Gen = getResumeGenerate();
  const feedbackEl = document.getElementById("resumeGenerateFeedback");
  const session = lastResumeGenerationSession;
  const ta = document.getElementById("resumeGenerateOutput");
  const editorDraft =
    ta && String(ta.value || "").trim() ? String(ta.value).trim() : "";
  const draftSource = editorDraft || (session && session.text) || "";
  const feedback =
    feedbackEl && feedbackEl.value != null
      ? String(feedbackEl.value).trim()
      : "";
  if (!Gen || !session || !session.bundle || !draftSource) {
    showToast("Generate a draft first", "error");
    return;
  }
  if (!feedback) {
    showToast("Add feedback before refining", "error");
    return;
  }
  try {
    lastResumeGenerationSession = {
      ...session,
      text: draftSource,
    };
    const nextBundle = {
      ...session.bundle,
      instructions: {
        ...(session.bundle.instructions || {}),
        refinementFeedback: feedback,
        previousDraft: draftSource,
      },
      meta: {
        ...(session.bundle.meta || {}),
        generatedAt: new Date().toISOString(),
      },
    };
    await openResumeGenerateModal(
      session.title,
      "Refining…",
      "",
      true,
      session.feature,
      session.contextUsed,
      session.job,
    );
    const nextText = await Gen.generateFromBundle(nextBundle);
    let savedDraft = null;
    const UC = getUserContent();
    if (UC && typeof UC.saveGeneratedDraft === "function") {
      try {
        savedDraft = await UC.saveGeneratedDraft({
          feature: session.feature,
          mode: "refine",
          text: nextText,
          job: session.job,
          parentDraftId: session.savedDraftId || null,
          userNotes:
            nextBundle.instructions && nextBundle.instructions.userNotes
              ? nextBundle.instructions.userNotes
              : "",
          refinementFeedback: feedback,
        });
        await refreshGeneratedDraftLibraryCache();
        renderPipeline();
        if (activeDetailKey >= 0) refreshDrawerIfOpen(activeDetailKey);
      } catch (draftErr) {
        console.warn("[JobBored] save refined draft:", draftErr);
      }
    }
    lastResumeGenerationSession = {
      ...session,
      bundle: nextBundle,
      savedDraftId: savedDraft ? savedDraft.id : session.savedDraftId || null,
      text: nextText,
    };
    if (feedbackEl) feedbackEl.value = "";
    await openResumeGenerateModal(
      session.title,
      "",
      nextText,
      false,
      session.feature,
      session.contextUsed,
      session.job,
    );
  } catch (err) {
    console.error("[JobBored] Resume refinement:", err);
    await openResumeGenerateModal(
      session.title,
      err.message || "Refinement failed",
      session.text,
      false,
      session.feature,
      session.contextUsed,
      session.job,
    );
    showToast(err.message || "Refinement failed", "error", true);
  }
}

async function openSavedDraftVersion(draftId) {
  const draft = getDraftByIdFromCache(draftId);
  if (!draft) {
    showToast("Saved draft not found", "error");
    return;
  }
  const job =
    pipelineData.find((row) => getJobOpportunityKey(row) === draft.jobKey) ||
    draft.jobSnapshot ||
    null;
  if (!job) {
    showToast("Job for this draft is no longer available", "error");
    return;
  }
  const UC = getUserContent();
  const Bundle = getResumeBundle();
  if (!UC || !Bundle) {
    showToast("Resume modules failed to load", "error");
    return;
  }
  try {
    await UC.openDb();
    const profile = await Bundle.assembleProfile(UC);
    const contextUsed = buildGenerationContextUsed(profile);
    const bundle = Bundle.buildResumeContextBundle(
      draft.feature,
      job,
      profile,
      {
        maxWords: profile.preferences.defaultMaxWords,
        userNotes: draft.userNotes || "",
      },
      { sheetId: SHEET_ID },
    );
    lastResumeGenerationSession = {
      title:
        draft.feature === "cover_letter"
          ? "Cover letter draft"
          : "Tailored resume",
      feature: draft.feature,
      bundle,
      contextUsed,
      job,
      savedDraftId: draft.id,
      text: draft.text,
    };
    const feedbackEl = document.getElementById("resumeGenerateFeedback");
    if (feedbackEl) feedbackEl.value = "";
    await openResumeGenerateModal(
      lastResumeGenerationSession.title,
      "",
      draft.text,
      false,
      draft.feature,
      contextUsed,
      job,
    );
  } catch (err) {
    console.error("[JobBored] open saved draft:", err);
    showToast(err.message || "Could not open saved draft", "error", true);
  }
}

async function openLatestSavedDraftForJob(dataIndex, feature) {
  const job = pipelineData[dataIndex];
  if (!job) {
    showToast("Job not found", "error");
    return;
  }
  const drafts = getDraftsForJob(job, feature);
  if (!drafts.length) {
    showToast(
      `No saved ${getDraftFeatureLabel(feature).toLowerCase()} yet`,
      "info",
    );
    return;
  }
  await openSavedDraftVersion(drafts[0].id);
}

function initResumeMaterialsFeature() {
  const UC = getUserContent();
  if (!UC) return;

  UC.openDb().catch((e) => console.warn("[JobBored] User content DB:", e));
  scheduleCandidateProfileMatchRefresh(true);
  scheduleGeneratedDraftLibraryRefresh(true);

  const materialsBtn = document.getElementById("materialsBtn");
  const materialsModal = document.getElementById("materialsModal");
  const materialsClose = document.getElementById("materialsModalClose");
  const materialsCloseX = document.getElementById("materialsModalCloseX");
  const profileResetWizardBtn = document.getElementById(
    "profileResetWizardBtn",
  );
  const fileInput = document.getElementById("materialsFileInput");
  const samplesFileInput = document.getElementById("materialsSamplesFileInput");
  const profileResumeBrowseBtn = document.getElementById(
    "profileResumeBrowseBtn",
  );
  const profileSamplesBrowseBtn = document.getElementById(
    "profileSamplesBrowseBtn",
  );
  const profileResumeDropzone = document.getElementById(
    "profileResumeDropzone",
  );
  const profileSamplesDropzone = document.getElementById(
    "profileSamplesDropzone",
  );
  const pasteBtn = document.getElementById("materialsPasteBtn");
  const linkedInAssistBtn = document.getElementById(
    "materialsLinkedInAssistBtn",
  );
  const linkedInSaveBtn = document.getElementById("materialsLinkedInSaveBtn");
  const linkedInClearBtn = document.getElementById("materialsLinkedInClearBtn");
  const linkedInTextEl = document.getElementById("materialsLinkedInText");
  const linkedInMetaEl = document.getElementById("materialsLinkedInMeta");
  const aiDumpTextEl = document.getElementById("materialsAiDumpText");
  const aiDumpMetaEl = document.getElementById("materialsAiDumpMeta");
  const aiDumpFileEl = document.getElementById("materialsAiDumpFile");
  const aiDumpSaveBtn = document.getElementById("materialsAiDumpSaveBtn");
  const aiDumpClearBtn = document.getElementById("materialsAiDumpClearBtn");
  const aiDumpCopyPromptBtn = document.getElementById(
    "materialsAiDumpCopyPromptBtn",
  );
  const aiDumpPromptEl = document.getElementById("materialsAiDumpPrompt");
  const linkedInCaptureModal = document.getElementById("linkedInCaptureModal");
  const linkedInCaptureClose = document.getElementById("linkedInCaptureClose");
  const linkedInCaptureCloseX = document.getElementById(
    "linkedInCaptureCloseX",
  );
  const linkedInCaptureSaveBtn = document.getElementById(
    "linkedInCaptureSaveBtn",
  );
  const sampleAddBtn = document.getElementById("sampleAddBtn");
  const savePrefsBtn = document.getElementById("materialsSavePrefsBtn");

  if (materialsBtn) {
    materialsBtn.addEventListener("click", () => openMaterialsModal());
  }
  if (materialsModal) {
    materialsModal.addEventListener("click", (e) => {
      if (e.target === materialsModal) closeMaterialsModal();
    });
  }
  if (materialsClose)
    materialsClose.addEventListener("click", closeMaterialsModal);
  if (materialsCloseX)
    materialsCloseX.addEventListener("click", closeMaterialsModal);

  if (profileResetWizardBtn) {
    profileResetWizardBtn.addEventListener("click", async () => {
      const ok = window.confirm(
        "Start the setup wizard again? Your resume and profile stay saved until you finish the new flow.",
      );
      if (!ok) return;
      if (!UC) return;
      try {
        await UC.openDb();
        await UC.resetOnboardingCompletion();
        closeMaterialsModal();
        closeCommandCenterSettingsModal();
        closeAuthUserMenu();
        showOnboardingWizard();
        showToast("Continue the steps below to finish setup.", "info");
      } catch (err) {
        console.error(err);
        showToast(err.message || "Could not reset wizard", "error");
      }
    });
  }

  if (profileResumeBrowseBtn && fileInput) {
    profileResumeBrowseBtn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      fileInput.click();
    });
  }
  if (profileSamplesBrowseBtn && samplesFileInput) {
    profileSamplesBrowseBtn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      samplesFileInput.click();
    });
  }

  bindProfileDropzone(profileResumeDropzone, (files) => {
    const file = files[0];
    if (file) profileApplyResumeFile(file, UC);
  });
  bindProfileDropzone(profileSamplesDropzone, (files) => {
    profileApplySampleFiles(files, UC);
  });

  if (fileInput) {
    fileInput.addEventListener("change", async (e) => {
      const f = e.target.files && e.target.files[0];
      e.target.value = "";
      if (!f) return;
      await profileApplyResumeFile(f, UC);
    });
  }

  if (samplesFileInput) {
    samplesFileInput.addEventListener("change", async (e) => {
      const files = e.target.files;
      e.target.value = "";
      if (!files || !files.length) return;
      await profileApplySampleFiles(files, UC);
    });
  }

  if (pasteBtn) {
    pasteBtn.addEventListener("click", async () => {
      const ingest = getResumeIngest();
      const textEl = document.getElementById("materialsPasteText");
      const raw = (textEl && textEl.value) || "";
      const text = ingest ? ingest.normalizeExtractedText(raw) : raw.trim();
      if (!text) {
        showToast("Paste some resume text first", "error");
        return;
      }
      const label = "My resume";
      await UC.setPrimaryResume({
        source: "paste",
        rawMime: "text/plain",
        label,
        extractedText: text,
      });
      if (textEl) textEl.value = "";
      await refreshMaterialsUI();
      showToast("Resume updated from paste", "success");
    });
  }

  if (linkedInTextEl && linkedInMetaEl) {
    linkedInTextEl.addEventListener("input", () => {
      linkedInMetaEl.textContent = renderLinkedInProfileMeta(
        linkedInTextEl.value,
        "",
      );
    });
  }

  if (aiDumpTextEl && aiDumpMetaEl) {
    aiDumpTextEl.addEventListener("input", () => {
      aiDumpMetaEl.textContent = renderAdditionalContextMeta(
        aiDumpTextEl.value,
        "",
      );
    });
  }

  if (aiDumpCopyPromptBtn && aiDumpPromptEl) {
    aiDumpCopyPromptBtn.addEventListener("click", async () => {
      try {
        await navigator.clipboard.writeText(aiDumpPromptEl.value || "");
        const orig = aiDumpCopyPromptBtn.textContent;
        aiDumpCopyPromptBtn.textContent = "Copied!";
        setTimeout(() => {
          aiDumpCopyPromptBtn.innerHTML =
            '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg> Copy prompt to clipboard';
        }, 1500);
        showToast("Prompt copied — paste it into your chatbot", "success");
      } catch (err) {
        console.warn(err);
        showToast("Could not copy prompt", "info");
      }
    });
  }

  if (aiDumpFileEl) {
    aiDumpFileEl.addEventListener("change", async (e) => {
      const ingest = getResumeIngest();
      const file = e.target.files && e.target.files[0];
      e.target.value = "";
      if (!file) return;
      if (!ingest) {
        showToast("File processing unavailable", "error");
        return;
      }
      try {
        const text = await ingest.extractTextFromFile(file);
        const normalized = normalizeProfileTextInput(text);
        if (!normalized) {
          showToast("No text could be extracted from that file", "error");
          return;
        }
        if (aiDumpTextEl) aiDumpTextEl.value = normalized;
        if (aiDumpMetaEl) {
          aiDumpMetaEl.textContent = renderAdditionalContextMeta(
            normalized,
            "",
          );
        }
        showToast("AI context loaded from file", "success");
      } catch (err) {
        console.error(err);
        showToast(err.message || "Could not read file", "error");
      }
    });
  }

  if (aiDumpSaveBtn) {
    aiDumpSaveBtn.addEventListener("click", async () => {
      if (!UC || typeof UC.saveAdditionalContext !== "function") {
        showToast("AI context storage unavailable", "error");
        return;
      }
      const normalized = normalizeProfileTextInput(
        (aiDumpTextEl && aiDumpTextEl.value) || "",
      );
      if (!normalized) {
        showToast("Paste or upload AI context before saving", "error");
        return;
      }
      await UC.saveAdditionalContext({
        text: normalized,
        updatedAt: new Date().toISOString(),
      });
      await refreshMaterialsUI();
      showToast("AI context saved", "success");
    });
  }

  if (aiDumpClearBtn) {
    aiDumpClearBtn.addEventListener("click", async () => {
      if (!UC || typeof UC.clearAdditionalContext !== "function") {
        showToast("AI context storage unavailable", "error");
        return;
      }
      await UC.clearAdditionalContext();
      await refreshMaterialsUI();
      showToast("AI context cleared", "info");
    });
  }

  if (linkedInAssistBtn) {
    linkedInAssistBtn.addEventListener("click", () => {
      openLinkedInCaptureModal();
    });
  }

  LINKEDIN_CAPTURE_FIELDS.forEach((f) => {
    const el = document.getElementById(f.id);
    if (el) {
      el.addEventListener("input", updateLinkedInCapturePreview);
    }
  });

  if (linkedInCaptureModal) {
    linkedInCaptureModal.addEventListener("click", (e) => {
      if (e.target === linkedInCaptureModal) closeLinkedInCaptureModal();
    });
  }
  if (linkedInCaptureClose) {
    linkedInCaptureClose.addEventListener("click", closeLinkedInCaptureModal);
  }
  if (linkedInCaptureCloseX) {
    linkedInCaptureCloseX.addEventListener("click", closeLinkedInCaptureModal);
  }

  document.querySelectorAll("[data-li-clipboard-target]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const targetId = btn.getAttribute("data-li-clipboard-target");
      const target = targetId ? document.getElementById(targetId) : null;
      if (!target || target.tagName !== "TEXTAREA") return;
      try {
        const clip = await navigator.clipboard.readText();
        target.value = clip || "";
        updateLinkedInCapturePreview();
        showToast("Pasted from clipboard", "success");
      } catch (err) {
        console.warn(err);
        showToast(
          "Clipboard access blocked — paste manually (Cmd/Ctrl+V).",
          "info",
        );
      }
    });
  });

  if (linkedInCaptureSaveBtn) {
    linkedInCaptureSaveBtn.addEventListener("click", async () => {
      if (!UC || typeof UC.saveLinkedInProfile !== "function") {
        showToast("LinkedIn profile storage unavailable", "error");
        return;
      }
      const completeness = getLinkedInCaptureCompleteness();
      if (!completeness.canSave) {
        showToast("Capture Experience and Skills before saving", "error");
        updateLinkedInCapturePreview();
        return;
      }
      const text = buildLinkedInCaptureProfileText();
      if (!text) {
        showToast("Paste at least one LinkedIn section first", "error");
        return;
      }
      await UC.saveLinkedInProfile({
        text,
        updatedAt: new Date().toISOString(),
      });
      if (linkedInTextEl) linkedInTextEl.value = text;
      await refreshMaterialsUI();
      closeLinkedInCaptureModal();
      showToast("LinkedIn profile captured and saved", "success");
    });
  }

  if (linkedInSaveBtn) {
    linkedInSaveBtn.addEventListener("click", async () => {
      if (
        !UC ||
        typeof UC.saveLinkedInProfile !== "function" ||
        typeof UC.normalizeLinkedInProfile !== "function"
      ) {
        showToast("LinkedIn profile storage unavailable", "error");
        return;
      }
      const raw = (linkedInTextEl && linkedInTextEl.value) || "";
      const normalized = UC.normalizeLinkedInProfile({ text: raw });
      await UC.saveLinkedInProfile({
        text: normalized.text,
        updatedAt: new Date().toISOString(),
      });
      await refreshMaterialsUI();
      showToast("LinkedIn profile text saved", "success");
    });
  }

  if (linkedInClearBtn) {
    linkedInClearBtn.addEventListener("click", async () => {
      if (!UC || typeof UC.clearLinkedInProfile !== "function") {
        showToast("LinkedIn profile storage unavailable", "error");
        return;
      }
      await UC.clearLinkedInProfile();
      await refreshMaterialsUI();
      showToast("LinkedIn profile text cleared", "info");
    });
  }

  if (sampleAddBtn) {
    sampleAddBtn.addEventListener("click", async () => {
      const titleEl = document.getElementById("sampleTitle");
      const tagsEl = document.getElementById("sampleTags");
      const textEl = document.getElementById("sampleText");
      const title = (titleEl && titleEl.value.trim()) || "Writing sample";
      const tagsStr = (tagsEl && tagsEl.value) || "";
      const tags = tagsStr
        .split(",")
        .map((t) => t.trim())
        .filter(Boolean);
      const raw = (textEl && textEl.value) || "";
      const ingest = getResumeIngest();
      const text = ingest ? ingest.normalizeExtractedText(raw) : raw.trim();
      if (!text) {
        showToast("Add sample text", "error");
        return;
      }
      await UC.addWritingSample({ title, tags, extractedText: text });
      if (textEl) textEl.value = "";
      if (tagsEl) tagsEl.value = "";
      if (titleEl) titleEl.value = "";
      await refreshMaterialsUI();
      showToast("Writing sample added", "success");
    });
  }

  if (savePrefsBtn) {
    savePrefsBtn.addEventListener("click", async () => {
      const toneEl = document.getElementById("prefTone");
      const mwEl = document.getElementById("prefMaxWords");
      const indEl = document.getElementById("prefIndustries");
      const avEl = document.getElementById("prefAvoid");
      const voEl = document.getElementById("prefVoice");
      const mergeEl = document.getElementById("prefMergePreference");
      const coverTplEl = document.getElementById("prefCoverLetterTemplate");
      const resumeTplEl = document.getElementById("prefResumeTemplate");
      const visualThemeEl = document.getElementById("prefVisualTheme");
      const DT = window.CommandCenterDocumentTemplates;
      const VT = window.CommandCenterVisualThemes;
      const maxWords = parseInt(mwEl && mwEl.value, 10);
      await UC.savePreferences({
        tone: (toneEl && toneEl.value) || "warm",
        defaultMaxWords:
          !Number.isNaN(maxWords) && maxWords > 0 ? maxWords : 350,
        industriesToEmphasize: (indEl && indEl.value) || "",
        wordsToAvoid: (avEl && avEl.value) || "",
        voiceNotes: (voEl && voEl.value) || "",
        profileMergePreference: (mergeEl && mergeEl.value) || "merge",
        coverLetterTemplateId:
          (coverTplEl && coverTplEl.value) ||
          (DT && typeof DT.getDefaultTemplateId === "function"
            ? DT.getDefaultTemplateId("cover_letter")
            : "cover_classic_paragraphs"),
        resumeTemplateId:
          (resumeTplEl && resumeTplEl.value) ||
          (DT && typeof DT.getDefaultTemplateId === "function"
            ? DT.getDefaultTemplateId("resume_update")
            : "resume_traditional_sections"),
        visualThemeId:
          (visualThemeEl && visualThemeEl.value) ||
          (VT && typeof VT.getDefaultVisualThemeId === "function"
            ? VT.getDefaultVisualThemeId()
            : "classic"),
      });
      closeAuthUserMenu();
      showToast("Preferences saved", "success");
    });
  }

  const genModal = document.getElementById("resumeGenerateModal");
  const genClose = document.getElementById("resumeGenerateClose");
  const genDone = document.getElementById("resumeGenerateDone");
  const genPrint = document.getElementById("resumeGeneratePrint");
  const genCopy = document.getElementById("resumeGenerateCopy");
  const genFeedback = document.getElementById("resumeGenerateFeedback");
  const genRefine = document.getElementById("resumeGenerateRefine");
  const genHistoryList = document.getElementById("resumeGenerateHistoryList");
  const draftNotesModal = document.getElementById("draftNotesModal");
  const draftNotesClose = document.getElementById("draftNotesModalClose");
  const draftNotesSkip = document.getElementById("draftNotesSkip");
  const draftNotesGenerate = document.getElementById("draftNotesGenerate");
  const closeGen = () => closeResumeGenerateModal();
  if (genClose) genClose.addEventListener("click", closeGen);
  if (genDone) genDone.addEventListener("click", closeGen);
  if (genModal) {
    genModal.addEventListener("click", (e) => {
      if (e.target === genModal) closeGen();
    });
  }
  if (genPrint) {
    genPrint.addEventListener("click", () => {
      window.print();
    });
  }
  if (genCopy) {
    genCopy.addEventListener("click", async () => {
      const ta = document.getElementById("resumeGenerateOutput");
      if (!ta || !ta.value) return;
      try {
        await navigator.clipboard.writeText(ta.value);
        showToast("Copied to clipboard", "success");
      } catch (_) {
        showToast("Could not copy — select text manually", "info");
      }
    });
  }
  if (genFeedback) {
    genFeedback.addEventListener("input", () =>
      syncResumeGenerateFooterState(),
    );
  }
  const genOutput = document.getElementById("resumeGenerateOutput");
  if (genOutput) {
    genOutput.addEventListener("input", () => {
      syncResumeGenerateFooterState();
      scheduleResumeGenerateAtsRefresh();
    });
  }
  if (genRefine) {
    genRefine.addEventListener("click", () => {
      void refineLastResumeGeneration();
    });
  }
  if (genHistoryList) {
    genHistoryList.addEventListener("click", (e) => {
      const btn = e.target.closest('[data-action="open-saved-draft"]');
      if (!btn) return;
      const draftId = btn.getAttribute("data-draft-id");
      if (draftId) void openSavedDraftVersion(draftId);
    });
  }
  const atsGroups = document.getElementById("resumeGenerateAtsGroups");
  if (atsGroups) {
    atsGroups.addEventListener("click", (e) => {
      const btn = e.target.closest('[data-action="retry-ats-scorecard"]');
      if (!btn) return;
      const session = lastResumeGenerationSession;
      if (!session || !session.job) return;
      const draft = getResumeGenerateDraftTextForInsights(session.text || "");
      if (!draft) return;
      const feature =
        session.feature === "resume_update" ? "resume_update" : "cover_letter";
      const cacheKey = computeAtsScorecardCacheKey(draft, session.job, feature);
      const payload = buildAtsScorecardRequestPayload(
        draft,
        session.job,
        session,
      );
      startAtsScorecardAnalysis(cacheKey, payload);
      renderResumeGenerateInsights(draft, session.job);
    });
  }
  if (draftNotesModal) {
    draftNotesModal.addEventListener("click", (e) => {
      if (e.target === draftNotesModal) closeDraftNotesModal();
    });
  }
  if (draftNotesClose) {
    draftNotesClose.addEventListener("click", closeDraftNotesModal);
  }
  if (draftNotesSkip) {
    draftNotesSkip.addEventListener("click", () => {
      const req = pendingDraftNotesRequest;
      closeDraftNotesModal();
      if (!req) return;
      void runResumeGeneration(req.dataIndex, req.feature, { userNotes: "" });
    });
  }
  if (draftNotesGenerate) {
    draftNotesGenerate.addEventListener("click", () => {
      const req = pendingDraftNotesRequest;
      const input = document.getElementById("draftNotesInput");
      const userNotes =
        input && input.value != null ? String(input.value).trim() : "";
      closeDraftNotesModal();
      if (!req) return;
      void runResumeGeneration(req.dataIndex, req.feature, { userNotes });
    });
  }

  const genThemeSel = document.getElementById("resumeGenerateVisualTheme");
  if (genThemeSel) {
    genThemeSel.addEventListener("change", async () => {
      const UC = getUserContent();
      const id = genThemeSel.value;
      const preview = document.getElementById("resumeGeneratePreview");
      if (preview) preview.setAttribute("data-visual-theme", id);
      if (!UC) return;
      try {
        await UC.openDb();
        await UC.savePreferences({ visualThemeId: id });
      } catch (e) {
        console.warn("[JobBored] save visual theme:", e);
      }
    });
  }

  document.addEventListener("keydown", (e) => {
    if (e.key !== "Escape") return;
    if (isOnboardingWizardVisible()) return;
    if (isAuthUserMenuOpen()) {
      closeAuthUserMenu();
      document.getElementById("authMenuToggle")?.focus();
      return;
    }
    if (linkedInCaptureModal && linkedInCaptureModal.style.display === "flex") {
      closeLinkedInCaptureModal();
      return;
    }
    const scraperModal = document.getElementById("scraperSetupModal");
    if (scraperModal && scraperModal.style.display === "flex") {
      closeScraperSetupModal();
      return;
    }
    const settingsModal = document.getElementById("settingsModal");
    if (settingsModal && settingsModal.style.display === "flex") {
      const clearBar = document.getElementById("settingsClearConfirmBar");
      if (clearBar && !clearBar.hidden) {
        hideSettingsClearConfirmBar();
        return;
      }
      closeCommandCenterSettingsModal();
      return;
    }
    if (draftNotesModal && draftNotesModal.style.display === "flex") {
      closeDraftNotesModal();
      return;
    }
    if (materialsModal && materialsModal.style.display === "flex") {
      closeMaterialsModal();
    }
    if (genModal && genModal.style.display === "flex") {
      closeResumeGenerateModal();
    }
  });

  initOnboardingWizard();
}

// ============================================
// INITIALIZATION
// ============================================

function init() {
  // Check config
  SHEET_ID = getSheetId();
  initialSheetAccessResolved = false;
  postAccessBootstrapDone = false;
  postAccessBootstrapPromise = Promise.resolve();
  initAuthUserMenu();

  // Wire the onboarding wizard + resume materials handlers UNCONDITIONALLY,
  // BEFORE the no-SHEET_ID early return below.
  //
  // Why: greenfield first-time users land here with no SHEET_ID, see the
  // onboarding modal, drop a resume — but until this call ran, the
  // file-input change listener wasn't bound, so the upload silently did
  // nothing. The user experienced this as "I have to refresh the page in
  // order for the file selector to put the file visibly into the UX" —
  // because by the time they refreshed, sign-in had set SHEET_ID and the
  // listener finally got bound on the second pass.
  //
  // initResumeMaterialsFeature is internally idempotent and has no sheet
  // dependency: it opens IndexedDB and wires modal/file listeners. Safe
  // to run pre-SHEET_ID.
  initResumeMaterialsFeature();

  if (!SHEET_ID) {
    // Login gate first; onboarding (blank sheet steps) appears after Google sign-in.
    document.getElementById("dashboard").style.display = "none";
    document.getElementById("setupScreen").style.display = "none";
    if (!getOAuthClientId()) {
      showSheetAccessGate("no-oauth");
    } else {
      showSheetAccessGate("loading");
    }
    initAuth();
    renderSetupStarterSheetUi();
    return;
  }

  // Hold the dashboard behind an access gate until the first read succeeds.
  document.getElementById("setupScreen").style.display = "none";
  document.getElementById("dashboard").style.display = "none";
  showSheetAccessGate("loading");

  // Dashboard wordmark vs custom title
  const cfg = getConfig();
  if (cfg) {
    const effectiveTitle = cfg.title;
    document.title = effectiveTitle + " — Job Search Dashboard";
    const logoEl = document.getElementById("logoHorizontal");
    const titleEl = document.getElementById("dashboardTitle");
    const defaultTitle = "JobBored";
    if (effectiveTitle === defaultTitle) {
      logoEl?.removeAttribute("hidden");
      titleEl?.setAttribute("hidden", "");
    } else {
      logoEl?.setAttribute("hidden", "");
      titleEl?.removeAttribute("hidden");
      if (titleEl) titleEl.textContent = effectiveTitle;
    }
  }

  // Set sheet links
  setDashboardSheetLinks();

  initDiscoveryPrefsModal();
  initDiscoveryButton();
  void preloadDiscoveryUiState();

  // Sort
  document.getElementById("sortSelect").addEventListener("change", (e) => {
    currentSort = e.target.value;
    renderPipeline();
  });

  // Search
  let searchTimeout;
  document.getElementById("searchInput").addEventListener("input", (e) => {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
      currentSearch = e.target.value.trim();
      renderPipeline();
    }, 200);
  });

  // Pipeline filter chips — favorites-only + show-dismissed
  const favChip = document.getElementById("favoritesOnlyChip");
  if (favChip) {
    favChip.addEventListener("click", () => {
      favoritesOnly = !favoritesOnly;
      favChip.classList.toggle("active", favoritesOnly);
      favChip.setAttribute("aria-pressed", String(favoritesOnly));
      renderPipeline();
    });
  }
  const dismissedChip = document.getElementById("showDismissedChip");
  if (dismissedChip) {
    dismissedChip.addEventListener("click", () => {
      showDismissed = !showDismissed;
      dismissedChip.classList.toggle("active", showDismissed);
      dismissedChip.setAttribute("aria-pressed", String(showDismissed));
      renderPipeline();
    });
  }

  // Refresh
  document.getElementById("refreshBtn")?.addEventListener("click", () => {
    loadAllData();
  });

  document
    .getElementById("onboardingWizardBtn")
    ?.addEventListener("click", () => {
      closeAuthUserMenu();
      closeMaterialsModal();
      closeCommandCenterSettingsModal();
      void requestDiscoverySetup({
        entryPoint: "toolbar",
        allowWhileOnboarding: true,
      });
    });

  // Init auth
  initAuth();

  // initResumeMaterialsFeature was hoisted above the no-SHEET_ID early
  // return so greenfield users can actually use the onboarding wizard's
  // file upload. Calling it again here would double-bind every listener
  // (addEventListener doesn't dedupe), so don't.

  loadAllData();

  setInterval(loadAllData, REFRESH_INTERVAL);
}

/**
 * Normalize a source preset value to a valid enum string or empty.
 * @param {unknown} raw
 * @returns {"" | "browser_only" | "ats_only" | "browser_plus_ats"}
 */
function normalizeSourcePreset(raw) {
  const SOURCE_PRESET_VALUES = Object.freeze([
    "browser_only",
    "ats_only",
    "browser_plus_ats",
  ]);
  const v = raw == null ? "" : String(raw).trim();
  if (SOURCE_PRESET_VALUES.includes(v)) return v;
  return "";
}

/**
 * Sync the source preset radio-group UI in the discovery prefs modal to
 * reflect the given normalized preset value. Highlights the active option.
 * @param {"" | "browser_only" | "ats_only" | "browser_plus_ats"} preset
 */
function syncSourcePresetUi(preset) {
  const VALID_PRESETS = ["browser_only", "ats_only", "browser_plus_ats"];
  const resolved = VALID_PRESETS.includes(preset) ? preset : "browser_plus_ats";
  document.querySelectorAll('input[name="dpSourcePreset"]').forEach((el) => {
    const isActive = el.value === resolved;
    el.checked = isActive;
    const option = el.closest(".dp-source-preset-option");
    if (option) {
      option.classList.toggle("dp-source-preset-option--active", isActive);
    }
  });
}

function syncDiscoveryButtonState() {
  const openBtn = document.getElementById("discoveryBtn");
  if (!openBtn) return;
  const snapshot = getDiscoveryReadinessSnapshot();
  const view = getDiscoverySettingsView(snapshot);
  const status = getEffectiveDiscoveryEngineStatus(
    snapshot.savedWebhookUrl || getDiscoveryWebhookUrl(),
  );
  const localSetupDetected =
    snapshot.savedWebhookKind === "local_http" || !!snapshot.localWebhookUrl;
  const stubOnlyDetected =
    snapshot.engineState === DISCOVERY_ENGINE_STATE_STUB_ONLY ||
    snapshot.savedWebhookKind === "apps_script_stub";

  const needsRecovery =
    snapshot.localRecoveryState && snapshot.localRecoveryState !== "ok";

  if (needsRecovery) {
    openBtn.disabled = false;
    openBtn.removeAttribute("aria-disabled");
    openBtn.title = "Local discovery setup needs recovery — click to fix.";
  } else if (view.runDiscoveryEnabled) {
    openBtn.disabled = false;
    openBtn.removeAttribute("aria-disabled");
    openBtn.title =
      status.state === DISCOVERY_ENGINE_STATE_CONNECTED
        ? "Ask your automation to run another search pass"
        : "POST to your configured endpoint. Make sure it writes Pipeline rows.";
  } else if (stubOnlyDetected) {
    openBtn.disabled = true;
    openBtn.setAttribute("aria-disabled", "true");
    openBtn.title =
      "Stub webhook only — use Settings → Discovery to connect a real engine, or click Run discovery to open setup.";
  } else {
    // No endpoint configured — keep button enabled so clicking opens the setup wizard.
    openBtn.disabled = false;
    openBtn.removeAttribute("aria-disabled");
    openBtn.title = view.primaryActionLabel
      ? `${view.primaryActionLabel} — click to open discovery setup.`
      : "Configure discovery in Settings, or click to open the setup wizard.";
  }
}

function openDiscoveryPrefsModal() {
  const modal = document.getElementById("discoveryPrefsModal");
  if (!modal) return;
  const UC = window.CommandCenterUserContent;
  const fieldMap = {
    targetRoles: "dpTargetRoles",
    locations: "dpLocations",
    remotePolicy: "dpRemotePolicy",
    seniority: "dpSeniority",
    keywordsInclude: "dpKeywordsInclude",
    keywordsExclude: "dpKeywordsExclude",
    maxLeadsPerRun: "dpMaxLeads",
  };
  const prefilled =
    UC && typeof UC.getDiscoveryProfile === "function"
      ? UC.getDiscoveryProfile()
      : Promise.resolve({});
  prefilled.then((p) => {
    Object.entries(fieldMap).forEach(([key, id]) => {
      const el = document.getElementById(id);
      if (el) el.value = (p && p[key]) || "";
    });
    // Handle grounded_web checkbox
    const gwEl = document.getElementById("dpGroundedWeb");
    if (gwEl) gwEl.checked = !p || p.groundedWebEnabled !== false;
    // Handle source preset — mutual-exclusivity radio group
    const preset = normalizeSourcePreset(
      p && p.sourcePreset ? p.sourcePreset : "",
    );
    syncSourcePresetUi(preset || "browser_plus_ats");
    modal.style.display = "flex";
    const first = document.getElementById("dpTargetRoles");
    if (first) first.focus();
  });
}

function closeDiscoveryPrefsModal() {
  const modal = document.getElementById("discoveryPrefsModal");
  if (modal) modal.style.display = "none";
}

async function generateDiscoverySuggestions(scrapedJob) {
  const RG = window.CommandCenterResumeGenerate;
  if (!RG || typeof RG.getResumeGenerationConfig !== "function") {
    throw new Error("Resume generation module not loaded.");
  }
  const g = RG.getResumeGenerationConfig();
  const provider = g.provider || "gemini";

  const UC = getUserContent();
  if (!UC) throw new Error("User content store not available.");
  await UC.openDb();

  const profileExcerpt = await buildCandidateProfileExcerpt(UC, 12000);
  const discoveryProfile = UC.getDiscoveryProfile
    ? await UC.getDiscoveryProfile()
    : {};

  const jobContext = scrapedJob
    ? [
        "JOB LISTING (scraped):",
        `Title: ${scrapedJob.title || ""}`,
        `Company: ${scrapedJob.company || ""}`,
        `Location: ${scrapedJob.location || ""}`,
        `Description: ${String(scrapedJob.description || "").slice(0, 4000)}`,
        scrapedJob.requirements && scrapedJob.requirements.length
          ? `Requirements: ${scrapedJob.requirements.slice(0, 20).join("; ")}`
          : "",
        scrapedJob.skills && scrapedJob.skills.length
          ? `Skills: ${scrapedJob.skills.join(", ")}`
          : "",
      ]
        .filter(Boolean)
        .join("\n")
    : "";

  const existingFilters = [
    discoveryProfile.targetRoles
      ? `Current target roles: ${discoveryProfile.targetRoles}`
      : "",
    discoveryProfile.locations
      ? `Current locations: ${discoveryProfile.locations}`
      : "",
    discoveryProfile.remotePolicy
      ? `Current remote policy: ${discoveryProfile.remotePolicy}`
      : "",
    discoveryProfile.seniority
      ? `Current seniority: ${discoveryProfile.seniority}`
      : "",
  ]
    .filter(Boolean)
    .join("\n");

  const systemPrompt =
    "You are an expert career advisor. Analyze the candidate's profile (resume, LinkedIn, AI context) " +
    "and optionally a scraped job listing, then suggest the best discovery search parameters. " +
    "Return ONLY valid JSON with these keys: " +
    "targetRoles (string, comma-separated role titles), " +
    "locations (string, comma-separated cities/regions), " +
    "remotePolicy (string, e.g. 'remote-first, hybrid'), " +
    "seniority (string, e.g. 'senior, staff'), " +
    "keywordsInclude (string, comma-separated positive keywords for search), " +
    "keywordsExclude (string, comma-separated negative keywords to filter out), " +
    "reasoning (string, 1-2 sentences explaining why these parameters fit the candidate). " +
    "Base suggestions on the candidate's actual experience, skills, and career trajectory. " +
    "If a job listing is provided, tune the suggestions to find similar roles.";

  const userParts = [
    "CANDIDATE PROFILE:",
    profileExcerpt || "(No resume or profile data available)",
    "",
  ];
  if (existingFilters) {
    userParts.push("EXISTING DISCOVERY FILTERS:", existingFilters, "");
  }
  if (jobContext) {
    userParts.push(jobContext, "");
  }
  userParts.push(
    "Suggest discovery search parameters that would find roles this candidate is well-suited for.",
    "Return JSON only.",
  );

  const userPrompt = userParts.join("\n");

  let text;
  if (provider === "gemini") {
    if (!g.resumeGeminiApiKey)
      throw new Error("Set a Gemini API key in Settings.");
    text = await callDiscoveryAiGemini(
      systemPrompt,
      userPrompt,
      g.resumeGeminiApiKey,
      g.resumeGeminiModel,
    );
  } else if (provider === "openai") {
    if (!g.resumeOpenAIApiKey)
      throw new Error("Set an OpenAI API key in Settings.");
    text = await callDiscoveryAiOpenAI(
      systemPrompt,
      userPrompt,
      g.resumeOpenAIApiKey,
      g.resumeOpenAIModel,
    );
  } else if (provider === "anthropic") {
    if (!g.resumeAnthropicApiKey)
      throw new Error("Set an Anthropic API key in Settings.");
    text = await callDiscoveryAiAnthropic(
      systemPrompt,
      userPrompt,
      g.resumeAnthropicApiKey,
      g.resumeAnthropicModel,
    );
  } else {
    throw new Error(
      "Switch to Gemini, OpenAI, or Anthropic in Settings for AI suggestions.",
    );
  }

  const parsed = parseJsonSafeForSuggestions(text);
  return {
    targetRoles: parsed.targetRoles || "",
    locations: parsed.locations || "",
    remotePolicy: parsed.remotePolicy || "",
    seniority: parsed.seniority || "",
    keywordsInclude: parsed.keywordsInclude || "",
    keywordsExclude: parsed.keywordsExclude || "",
    reasoning: parsed.reasoning || "",
  };
}

function parseJsonSafeForSuggestions(raw) {
  const s = String(raw || "").trim();
  const fenceMatch = s.match(/```(?:json)?\s*([\s\S]*?)```/);
  const body = fenceMatch ? fenceMatch[1].trim() : s;
  try {
    return JSON.parse(body);
  } catch (_) {
    const braceStart = body.indexOf("{");
    const braceEnd = body.lastIndexOf("}");
    if (braceStart !== -1 && braceEnd > braceStart) {
      try {
        return JSON.parse(body.slice(braceStart, braceEnd + 1));
      } catch (__) {}
    }
    return {};
  }
}

/**
 * Single source of truth for which Gemini model the app uses.
 *
 * Resolution order (high → low):
 *   1. Explicit caller arg (when a feature wants to pin a model — rare)
 *   2. localStorage override (Settings → Resume → Gemini model field)
 *   3. config.js → window.COMMAND_CENTER_CONFIG.resumeGeminiModel
 *   4. Hardcoded fallback (only hit if both config files are missing)
 *
 * If a Gemini model gets retired, this is the ONLY place to update the
 * default. Every Gemini call site must route through here — do not embed
 * model name strings or "gemini-…" fallbacks elsewhere in app.js.
 */
function resolveGeminiModel(explicit) {
  if (explicit && typeof explicit === "string" && explicit.trim()) {
    return explicit.trim();
  }
  try {
    const overrides =
      typeof readStoredConfigOverrides === "function"
        ? readStoredConfigOverrides()
        : {};
    if (overrides && typeof overrides.resumeGeminiModel === "string" && overrides.resumeGeminiModel.trim()) {
      return overrides.resumeGeminiModel.trim();
    }
  } catch (_) {
    /* localStorage may be unavailable in private/embedded contexts. */
  }
  const cfg = (typeof window !== "undefined" && window.COMMAND_CENTER_CONFIG) || {};
  if (typeof cfg.resumeGeminiModel === "string" && cfg.resumeGeminiModel.trim()) {
    return cfg.resumeGeminiModel.trim();
  }
  return "gemini-2.5-flash";
}

async function callDiscoveryAiGemini(system, user, apiKey, model, opts) {
  const resolvedModel = resolveGeminiModel(model);
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(resolvedModel)}:generateContent?key=${encodeURIComponent(apiKey)}`;
  // Detect 2.5+ family — those models burn "thinking tokens" against the
  // output budget, so a 2048-cap on a long-system-prompt JSON response can
  // silently produce zero visible characters with finishReason=MAX_TOKENS.
  // Also pin response MIME to JSON whenever the caller marks the request
  // as JSON-only — this dramatically improves reliability vs. free-form
  // prose responses that have to be regex-extracted later.
  const wantJson = !!(opts && opts.json);
  const isThinkingModel = /^gemini-2\.[5-9]/.test(resolvedModel);
  const generationConfig = {
    maxOutputTokens: isThinkingModel ? 8192 : 2048,
    temperature: 0.5,
  };
  if (wantJson) generationConfig.responseMimeType = "application/json";
  const body = {
    systemInstruction: { parts: [{ text: system }] },
    contents: [{ role: "user", parts: [{ text: user }] }],
    generationConfig,
  };
  const resp = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await resp.json().catch(() => ({}));
  if (!resp.ok) {
    throw new Error(data.error?.message || `Gemini HTTP ${resp.status}`);
  }
  const candidate = data.candidates?.[0];
  const text =
    candidate?.content?.parts?.map((p) => p.text || "").join("") || "";
  if (!text.trim()) {
    // Surface the real reason instead of a generic "Empty response".
    // Common cases: MAX_TOKENS (thinking eats the budget), SAFETY,
    // RECITATION, or upstream finish reasons that need the user to retry
    // with different input rather than silently fail.
    const reason = candidate?.finishReason || data.promptFeedback?.blockReason;
    if (reason === "MAX_TOKENS") {
      throw new Error(
        "Gemini hit the output token cap before producing visible text. Try Show me more, or shorten your resume.",
      );
    }
    if (reason === "SAFETY" || reason === "RECITATION") {
      throw new Error(
        `Gemini blocked the response (${reason}). Try Show me more, or remove sensitive content from your resume.`,
      );
    }
    if (reason) throw new Error(`Gemini returned no text (${reason}).`);
    throw new Error("Empty response from Gemini");
  }
  return text.trim();
}

async function callDiscoveryAiOpenAI(system, user, apiKey, model) {
  const m = model || "gpt-4o-mini";
  const limitKey = m.toLowerCase().startsWith("gpt-5")
    ? "max_completion_tokens"
    : "max_tokens";
  const body = {
    model: m,
    messages: [
      { role: "system", content: system },
      { role: "user", content: user },
    ],
    temperature: 0.5,
    [limitKey]: 2048,
  };
  const resp = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify(body),
  });
  const data = await resp.json().catch(() => ({}));
  if (!resp.ok)
    throw new Error(data.error?.message || `OpenAI HTTP ${resp.status}`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text.trim()) throw new Error("Empty response from OpenAI");
  return text.trim();
}

async function callDiscoveryAiAnthropic(system, user, apiKey, model) {
  const body = {
    model: model || "claude-sonnet-4-6",
    max_tokens: 2048,
    system,
    messages: [{ role: "user", content: user }],
  };
  const resp = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true",
    },
    body: JSON.stringify(body),
  });
  const data = await resp.json().catch(() => ({}));
  if (!resp.ok)
    throw new Error(data.error?.message || `Anthropic HTTP ${resp.status}`);
  const text = Array.isArray(data.content)
    ? data.content
        .filter((b) => b.type === "text")
        .map((b) => b.text || "")
        .join("")
    : "";
  if (!text.trim()) throw new Error("Empty response from Anthropic");
  return text.trim();
}

function initDiscoveryPrefsModal() {
  const modal = document.getElementById("discoveryPrefsModal");
  const runBtn = document.getElementById("discoveryPrefsRun");
  const cancelBtn = document.getElementById("discoveryPrefsCancel");
  const closeBtn = document.getElementById("discoveryPrefsClose");
  if (!modal) return;

  const closeModal = () => {
    modal.style.display = "none";
  };

  if (cancelBtn) cancelBtn.addEventListener("click", closeModal);
  if (closeBtn) closeBtn.addEventListener("click", closeModal);
  modal.addEventListener("click", (e) => {
    if (e.target === modal) closeModal();
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && modal.style.display === "flex") closeModal();
  });

  /* ---- Tab switching ---- */
  const tabManual = document.getElementById("dpTabManual");
  const tabAi = document.getElementById("dpTabAi");
  const panelManual = document.getElementById("dpPanelManual");
  const panelAi = document.getElementById("dpPanelAi");

  function switchTab(tab) {
    const isManual = tab === "manual";
    if (tabManual) {
      tabManual.classList.toggle("dp-tab--active", isManual);
      tabManual.setAttribute("aria-selected", String(isManual));
    }
    if (tabAi) {
      tabAi.classList.toggle("dp-tab--active", !isManual);
      tabAi.setAttribute("aria-selected", String(!isManual));
    }
    if (panelManual) {
      panelManual.classList.toggle("dp-panel--active", isManual);
      panelManual.hidden = !isManual;
    }
    if (panelAi) {
      panelAi.classList.toggle("dp-panel--active", !isManual);
      panelAi.hidden = isManual;
    }
    if (!isManual) checkAiAvailability();
  }

  if (tabManual) tabManual.addEventListener("click", () => switchTab("manual"));
  if (tabAi) tabAi.addEventListener("click", () => switchTab("ai"));

  /* ---- AI availability check ---- */
  function checkAiAvailability() {
    const hint = document.getElementById("dpAiHint");
    const suggestBtn = document.getElementById("dpSuggestBtn");
    const Insights = window.CommandCenterJobPostingInsights;
    const canUse =
      Insights && Insights.canEnrichWithLLM && Insights.canEnrichWithLLM();
    if (hint) hint.hidden = canUse;
    if (suggestBtn) suggestBtn.disabled = !canUse;
  }

  /* ---- Source preset mutual-exclusivity ---- */
  document
    .querySelectorAll('input[name="dpSourcePreset"]')
    .forEach((el) => {
      el.addEventListener("change", () => {
        const checked = document.querySelector(
          'input[name="dpSourcePreset"]:checked',
        );
        syncSourcePresetUi(checked ? normalizeSourcePreset(checked.value) : "");
      });
    });

  /* ---- Scrape job listing ---- */
  const scrapeBtn = document.getElementById("dpScrapeBtn");
  let scrapedJobData = null;

  if (scrapeBtn) {
    scrapeBtn.addEventListener("click", async () => {
      const urlInput = document.getElementById("dpJobUrl");
      const statusEl = document.getElementById("dpScrapeStatus");
      const url = urlInput ? urlInput.value.trim() : "";
      if (!url) {
        if (statusEl) {
          statusEl.textContent = "Paste a URL first.";
          statusEl.hidden = false;
        }
        return;
      }
      const base = getJobPostingScrapeUrl();
      if (!base) {
        if (statusEl) {
          statusEl.textContent =
            "No scraper configured. Set one in Settings or use localhost.";
          statusEl.hidden = false;
        }
        return;
      }
      scrapeBtn.disabled = true;
      scrapeBtn.textContent = "Scraping...";
      if (statusEl) {
        statusEl.textContent = "Fetching job listing...";
        statusEl.hidden = false;
      }
      try {
        const ctrl = new AbortController();
        const timer = setTimeout(() => ctrl.abort(), 30_000);
        const res = await fetch(`${base}/api/scrape-job`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ url }),
          signal: ctrl.signal,
        });
        clearTimeout(timer);
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
        scrapedJobData = data;
        const title = data.title || "Untitled";
        const company = data.company || "";
        if (statusEl) {
          statusEl.textContent = `Scraped: ${title}${company ? " at " + company : ""}`;
          statusEl.hidden = false;
        }
      } catch (err) {
        scrapedJobData = null;
        if (statusEl) {
          statusEl.textContent = `Scrape failed: ${err.message || err}`;
          statusEl.hidden = false;
        }
      } finally {
        scrapeBtn.disabled = false;
        scrapeBtn.textContent = "Scrape";
      }
    });
  }

  /* ---- AI Suggest ---- */
  const suggestBtn = document.getElementById("dpSuggestBtn");

  if (suggestBtn) {
    suggestBtn.addEventListener("click", async () => {
      suggestBtn.disabled = true;
      suggestBtn.textContent = "Analyzing...";
      const outputEl = document.getElementById("dpSuggestOutput");
      const reasoningEl = document.getElementById("dpSuggestReasoning");
      try {
        const result = await generateDiscoverySuggestions(scrapedJobData);
        const setField = (id, val) => {
          const el = document.getElementById(id);
          if (el) el.value = val || "";
        };
        setField("dpSuggestedRoles", result.targetRoles);
        setField("dpSuggestedLocations", result.locations);
        setField("dpSuggestedRemote", result.remotePolicy);
        setField("dpSuggestedSeniority", result.seniority);
        setField("dpSuggestedInclude", result.keywordsInclude);
        setField("dpSuggestedExclude", result.keywordsExclude);
        if (reasoningEl) reasoningEl.textContent = result.reasoning || "";
        if (outputEl) outputEl.hidden = false;
      } catch (err) {
        showToast(`AI suggest failed: ${err.message || err}`, "error");
      } finally {
        suggestBtn.disabled = false;
        suggestBtn.textContent = "Generate suggestions";
      }
    });
  }

  /* ---- Apply suggestions to manual fields ---- */
  const applyBtn = document.getElementById("dpApplySuggestionsBtn");
  if (applyBtn) {
    applyBtn.addEventListener("click", () => {
      const copy = (srcId, destId) => {
        const src = document.getElementById(srcId);
        const dest = document.getElementById(destId);
        if (src && dest && src.value) dest.value = src.value;
      };
      copy("dpSuggestedRoles", "dpTargetRoles");
      copy("dpSuggestedLocations", "dpLocations");
      copy("dpSuggestedRemote", "dpRemotePolicy");
      copy("dpSuggestedSeniority", "dpSeniority");
      copy("dpSuggestedInclude", "dpKeywordsInclude");
      copy("dpSuggestedExclude", "dpKeywordsExclude");
      switchTab("manual");
      showToast("Suggestions applied to manual fields", "success");
    });
  }

  /* ---- Run now (saves from manual fields) ---- */
  if (runBtn) {
    runBtn.addEventListener("click", async () => {
      const UC = window.CommandCenterUserContent;
      const val = (id) => {
        const el = document.getElementById(id);
        return el ? el.value : "";
      };
      const targetRoles = val("dpTargetRoles").trim();
      const keywordsInclude = val("dpKeywordsInclude").trim();

      // AI Suggest Intent Bridge:
      // If manual intent is blank but AI suggestions are non-blank, auto-promote
      // suggested values into manual fields so Run can proceed without requiring
      // the user to manually click "Apply suggestions" first.
      // This persists resolved intent into canonical discoveryProfile fields before
      // webhook dispatch (VAL-API-009).
      const suggestedRoles = val("dpSuggestedRoles").trim();
      const suggestedKeywords = val("dpSuggestedInclude").trim();
      const hasSuggestedIntent = !!(suggestedRoles || suggestedKeywords);

      if (!targetRoles && !keywordsInclude && hasSuggestedIntent) {
        // Auto-promote AI suggestions into manual fields
        const autoCopy = (srcId, destId) => {
          const src = document.getElementById(srcId);
          const dest = document.getElementById(destId);
          if (src && dest && src.value) dest.value = src.value;
        };
        autoCopy("dpSuggestedRoles", "dpTargetRoles");
        autoCopy("dpSuggestedLocations", "dpLocations");
        autoCopy("dpSuggestedRemote", "dpRemotePolicy");
        autoCopy("dpSuggestedSeniority", "dpSeniority");
        autoCopy("dpSuggestedInclude", "dpKeywordsInclude");
        autoCopy("dpSuggestedExclude", "dpKeywordsExclude");
        // Re-read after auto-promotion so the saved profile has resolved values
        void targetRoles; // avoid accidental reuse — fall through to re-read below
      }

      // Intent guardrail: block run only if BOTH manual AND AI-suggested intent are blank.
      // If AI suggestions were just auto-promoted above, this guardrail will not block.
      const finalTargetRoles = val("dpTargetRoles").trim();
      const finalKeywordsInclude = val("dpKeywordsInclude").trim();

      if (!finalTargetRoles && !finalKeywordsInclude) {
        showToast(
          "Add target roles or keywords to include, or use the AI Suggest tab to generate them.",
          "warning",
          true,
        );
        // Switch to AI Suggest tab so user can generate suggestions
        switchTab("ai");
        return;
      }

      // Handle grounded_web checkbox
      const gwEl = document.getElementById("dpGroundedWeb");
      const groundedWebEnabled = gwEl ? gwEl.checked : true;
      // Capture selected source preset at submit time (last-selection-wins)
      const selectedPresetEl = document.querySelector(
        'input[name="dpSourcePreset"]:checked',
      );
      const sourcePreset = selectedPresetEl
        ? normalizeSourcePreset(selectedPresetEl.value)
        : "";
      if (UC && typeof UC.saveDiscoveryProfile === "function") {
        await UC.saveDiscoveryProfile({
          targetRoles: finalTargetRoles,
          locations: val("dpLocations"),
          remotePolicy: val("dpRemotePolicy"),
          seniority: val("dpSeniority"),
          keywordsInclude: finalKeywordsInclude,
          keywordsExclude: val("dpKeywordsExclude"),
          maxLeadsPerRun: val("dpMaxLeads"),
          groundedWebEnabled,
          sourcePreset,
        });
      }
      closeModal();
      const openBtn = document.getElementById("discoveryBtn");
      if (openBtn) {
        openBtn.disabled = true;
        openBtn.classList.add("loading");
      }
      await triggerDiscoveryRun();
      if (openBtn) {
        openBtn.classList.remove("loading");
      }
      syncDiscoveryButtonState();
    });
  }
}

function initDiscoveryButton() {
  const modal = document.getElementById("discoveryHelpModal");
  const openBtn = document.getElementById("discoveryBtn");
  const closeBtn = document.getElementById("discoveryHelpClose");
  const openSettingsBtn = document.getElementById("discoveryHelpOpenSettings");
  if (!openBtn) return;

  function closeHelp(skipFocus) {
    if (modal) modal.style.display = "none";
    if (!skipFocus) openBtn.focus();
  }

  function openHelp() {
    if (modal) modal.style.display = "flex";
    const primary = document.getElementById("discoveryHelpOpenSettings");
    if (primary) primary.focus();
    else if (closeBtn) closeBtn.focus();
  }

  openBtn.addEventListener("click", async () => {
    const view = getDiscoverySettingsView(getDiscoveryReadinessSnapshot());
    const hasWebhook = !!getDiscoveryWebhookUrl();
    const isLocal =
      typeof window !== "undefined" &&
      window.location &&
      (window.location.hostname === "localhost" ||
        window.location.hostname === "127.0.0.1");

    // Greenfield silent path: on localhost, when no webhook is configured,
    // run the full backend boot in one click instead of opening the wizard.
    if (!hasWebhook && isLocal) {
      const originalText = openBtn.textContent;
      openBtn.disabled = true;
      openBtn.classList.add("loading");
      try {
        openBtn.title = "Setting up discovery…";
        showToast("Setting up discovery — this only happens once.", "info");
        const resp = await fetch("/__proxy/full-boot", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: "{}",
        });
        const body = await resp.json().catch(() => ({}));
        if (resp.ok && body && body.ok) {
          // Refresh snapshot so the saved webhook URL is picked up.
          await refreshDiscoveryReadinessSnapshot({ force: true });
          installKeepAliveOnce();
          showToast("Discovery is ready.", "success");
          if (getDiscoveryWebhookUrl()) {
            openDiscoveryPrefsModal();
            return;
          }
        }
        // If full-boot reported a specific blocking issue (Cloudflare auth,
        // etc.), fall back to the wizard at the failed step.
        if (body && body.needsAuth) {
          showToast(
            "Cloudflare needs to be signed in once. Run `npx wrangler login` and click again.",
            "warning",
            true,
          );
          return;
        }
        // Final fallback: open the wizard so a human can finish setup.
        await requestDiscoverySetup({
          entryPoint: "header_full_boot_fallback",
          allowWhileOnboarding: true,
        });
      } catch (e) {
        console.warn("[JobBored] full-boot:", e);
        await requestDiscoverySetup({
          entryPoint: "header",
          allowWhileOnboarding: true,
        });
      } finally {
        openBtn.disabled = false;
        openBtn.classList.remove("loading");
        openBtn.textContent = originalText;
        syncDiscoveryButtonState();
      }
      return;
    }

    if (!view.runDiscoveryEnabled || !hasWebhook) {
      await requestDiscoverySetup({
        entryPoint: "header",
        allowWhileOnboarding: true,
      });
      return;
    }
    openDiscoveryPrefsModal();
  });

  if (closeBtn) closeBtn.addEventListener("click", () => closeHelp());
  if (openSettingsBtn) {
    openSettingsBtn.addEventListener("click", async () => {
      closeHelp(true);
      await openSettingsForDiscoveryWebhook();
    });
  }
  if (modal) {
    modal.addEventListener("click", (e) => {
      if (e.target === modal) closeHelp();
    });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && modal.style.display === "flex") closeHelp();
    });
  }

  syncDiscoveryButtonState();
}

// ============================================
// INGEST URL — paste-a-job-URL flow
// ============================================

const INGEST_URL_TIMEOUT_MS = 20000;
const INGEST_URL_BLOCKED_HOST_LABELS = {
  "linkedin.com": "LinkedIn",
  "indeed.com": "Indeed",
  "glassdoor.com": "Glassdoor",
  "ziprecruiter.com": "ZipRecruiter",
};

function resolveIngestUrlEndpoint(baseUrl) {
  const base = String(baseUrl || "").trim();
  if (!base) return "";
  try {
    const u = new URL(base);
    const path = (u.pathname || "").replace(/\/+$/, "");
    const replaced = path.replace(
      /\/(?:webhook|discovery|discovery-profile|ingest-url)$/i,
      "/ingest-url",
    );
    if (replaced !== path) {
      u.pathname = replaced;
    } else if (path === "") {
      u.pathname = "/ingest-url";
    } else {
      u.pathname = path + "/ingest-url";
    }
    u.search = "";
    u.hash = "";
    return u.toString();
  } catch (_) {
    return base.replace(/\/+$/, "") + "/ingest-url";
  }
}

function isParseableUrl(value) {
  const v = String(value || "").trim();
  if (!v) return false;
  try {
    const u = new URL(v);
    return u.protocol === "http:" || u.protocol === "https:";
  } catch (_) {
    return false;
  }
}

function aggregatorLabelForHost(host) {
  const h = String(host || "")
    .toLowerCase()
    .replace(/^www\./, "");
  for (const key in INGEST_URL_BLOCKED_HOST_LABELS) {
    if (h === key || h.endsWith("." + key)) {
      return INGEST_URL_BLOCKED_HOST_LABELS[key];
    }
  }
  return host || "this site";
}

/**
 * POST to the worker's /ingest-url endpoint.
 * @param {string} url — pasted job URL
 * @param {object} [manualOverride] — { title, company, location, description, fitScore }
 * @returns {Promise<object>} parsed response
 */
async function handleIngestUrlSubmit(url, manualOverride) {
  const webhook = getDiscoveryWebhookUrl();
  if (!webhook) {
    showToast(
      "Configure your discovery webhook URL first",
      "error",
      false,
      {
        label: "Open settings",
        onClick: () => {
          openSettingsForDiscoveryWebhook().catch(() => {});
        },
      },
    );
    throw new Error("missing_discovery_webhook");
  }

  const endpoint = resolveIngestUrlEndpoint(webhook);
  if (!endpoint) {
    showToast("Invalid discovery webhook URL", "error");
    throw new Error("invalid_endpoint");
  }

  const body = {
    event: "ingest.url.request",
    schemaVersion: 1,
    url: String(url || "").trim(),
  };
  const sheetId = getSheetId();
  if (sheetId) body.sheetId = sheetId;
  if (manualOverride && typeof manualOverride === "object") {
    body.manual = {
      title: String(manualOverride.title || "").trim(),
      company: String(manualOverride.company || "").trim(),
      location: String(manualOverride.location || "").trim(),
      description: String(manualOverride.description || "").trim(),
      fitScore: Number.isFinite(manualOverride.fitScore)
        ? manualOverride.fitScore
        : 5,
    };
  }

  const headers = { "content-type": "application/json" };
  const secret = getDiscoveryWebhookSecret();
  if (secret) headers["x-discovery-secret"] = secret;

  const controller = new AbortController();
  const timeoutId = setTimeout(
    () => controller.abort(),
    INGEST_URL_TIMEOUT_MS,
  );

  try {
    const res = await fetch(endpoint, {
      method: "POST",
      headers,
      body: JSON.stringify(body),
      signal: controller.signal,
    });
    let data = null;
    try {
      data = await res.json();
    } catch (_) {
      data = null;
    }
    if (!res.ok && !data) {
      throw new Error("http_" + res.status);
    }
    return data;
  } catch (err) {
    if (err && err.name === "AbortError") {
      throw new Error("timeout");
    }
    throw err;
  } finally {
    clearTimeout(timeoutId);
  }
}

function getIngestManualModalEls() {
  return {
    modal: document.getElementById("ingestManualModal"),
    form: document.getElementById("ingestManualForm"),
    explain: document.getElementById("ingestManualModalExplain"),
    error: document.getElementById("ingestManualModalError"),
    urlField: document.getElementById("ingestManualUrl"),
    title: document.getElementById("ingestManualTitle"),
    company: document.getElementById("ingestManualCompany"),
    location: document.getElementById("ingestManualLocation"),
    description: document.getElementById("ingestManualDescription"),
    fit: document.getElementById("ingestManualFitScore"),
    fitLabel: document.getElementById("ingestManualFitScoreValue"),
    submit: document.getElementById("ingestManualSubmit"),
    cancel: document.getElementById("ingestManualCancel"),
    close: document.getElementById("ingestManualModalClose"),
  };
}

function setIngestManualModalError(message) {
  const els = getIngestManualModalEls();
  if (!els.error) return;
  if (!message) {
    els.error.style.display = "none";
    els.error.textContent = "";
    return;
  }
  els.error.style.display = "";
  els.error.textContent = message;
}

function openIngestManualModal({ url, message }) {
  const els = getIngestManualModalEls();
  if (!els.modal || !els.form) return;
  els.form.reset();
  if (els.urlField) els.urlField.value = url || "";
  if (els.fit) els.fit.value = "5";
  if (els.fitLabel) els.fitLabel.textContent = "5";
  if (els.explain) {
    els.explain.textContent =
      message || "We couldn't auto-scrape this URL — fill in what you can.";
  }
  setIngestManualModalError("");
  els.modal.style.display = "flex";
  if (els.title) {
    setTimeout(() => els.title.focus(), 0);
  }
}

function closeIngestManualModal() {
  const els = getIngestManualModalEls();
  if (els.modal) els.modal.style.display = "none";
  setIngestManualModalError("");
}

function refreshPipelineAfterIngest() {
  if (typeof loadAllData === "function") {
    loadAllData().catch((err) => {
      console.warn("[JobBored] post-ingest refresh failed:", err);
    });
  }
}

// Auto-enrich a freshly-ingested row so the card doesn't live on as
// "View / linkedin.com" placeholders. Reuses fetchJobPostingEnrichment (the
// same scraper + LLM pipeline the drawer runs on click) then patches the
// sheet's Title/Company/Location cells when the LLM inferred better values.
// All errors are non-fatal — row stays in Pipeline regardless, user can edit
// manually or wait for drawer-open enrichment to retry.
async function autoEnrichIngestedRow(url, persistedLead) {
  if (!url) return;

  // Collect every URL candidate we know about. The backend normalizes URLs
  // before writing (strips utm_*, trailing slashes, etc.) so the raw pasted
  // `url` often ≠ `pipelineData[i].link`. Try both and fall back to a loose
  // hostname+path match if strict matching misses.
  const trim = (value) => String(value || "").trim();
  const candidates = [
    trim(url),
    trim(persistedLead && (persistedLead.url || persistedLead.link)),
    trim(persistedLead && persistedLead.canonicalUrl),
    trim(persistedLead && persistedLead.finalUrl),
  ].filter(Boolean);
  if (candidates.length === 0) return;

  function looseUrlKey(value) {
    try {
      const u = new URL(value);
      // Hostname without www + pathname without trailing slash. Ignores
      // protocol, query, hash. Good enough to match "https://www.linkedin.com/
      // jobs/view/123?utm_source=foo" and "https://linkedin.com/jobs/view/123".
      const host = u.hostname.toLowerCase().replace(/^www\./, "");
      const path = u.pathname.replace(/\/+$/, "");
      return host + path;
    } catch {
      return "";
    }
  }
  const looseKeys = candidates.map(looseUrlKey).filter(Boolean);

  function findRowIndex() {
    for (const cand of candidates) {
      const strictIdx = pipelineData.findIndex(
        (job) => job && trim(job.link) === cand,
      );
      if (strictIdx >= 0) return strictIdx;
    }
    for (const key of looseKeys) {
      const looseIdx = pipelineData.findIndex(
        (job) => job && looseUrlKey(job.link || "") === key,
      );
      if (looseIdx >= 0) return looseIdx;
    }
    return -1;
  }

  try {
    // Skip entirely when the Cheerio scraper URL is not configured — the
    // drawer-open enrichment path would also short-circuit here, so the
    // row just stays as url_only. No toast spam for a missing dep.
    if (typeof getJobPostingScrapeUrl === "function" && !getJobPostingScrapeUrl()) {
      console.info("[JobBored] auto-enrich skipped: no scraper URL configured");
      return;
    }

    // 1. Wait for pipeline to refresh so the new row is in pipelineData.
    //    Google Sheets has eventual consistency on read-after-write, so
    //    retry up to 4x with short backoff (total ~6s) before giving up.
    let idx = -1;
    for (let attempt = 0; attempt < 4; attempt += 1) {
      if (typeof loadAllData === "function") {
        await loadAllData().catch(() => {});
      }
      idx = findRowIndex();
      if (idx >= 0) break;
      await new Promise((resolve) => setTimeout(resolve, 500 + attempt * 500));
    }
    if (idx < 0) {
      console.warn(
        "[JobBored] auto-enrich: row not found after 4 retries. URL candidates:",
        candidates,
      );
      return;
    }

    // 2. Visible progress signal — takes 3-8s typically.
    if (typeof showToast === "function") {
      showToast("Fetching job details…", "info");
    }

    // 3. Fire the same enrichment the drawer uses. Populates
    //    pipelineData[idx]._postingEnrichment with inferredTitle/Company/
    //    Location + the full LLM bundle (which ALSO writes to localStorage
    //    cache keyed by job.link, so the drawer picks it up instantly on
    //    open regardless of subsequent loadAllData() re-hydrations).
    await fetchJobPostingEnrichment(idx).catch((err) => {
      console.warn("[JobBored] auto-enrich enrichment call:", err);
    });

    const job = pipelineData[idx];
    const enr = job && job._postingEnrichment;
    if (!enr) return;

    // 5. Compute cell updates. Only replace placeholders ("View", "Linkedin",
    //    "Job at <host>", empty) — never overwrite values the user has
    //    typed/edited since paste.
    const sheetRow = typeof getSheetRow === "function" ? getSheetRow(idx) : null;
    if (!sheetRow) return;

    const isPlaceholderTitle = (value) => {
      const v = String(value || "").trim();
      if (!v) return true;
      if (/^view$/i.test(v)) return true;
      if (/^job at /i.test(v)) return true;
      // URL-slug-derived titles land as Title Case with no real role noun.
      // Leave them alone unless inferred title is clearly richer.
      return false;
    };
    const isPlaceholderCompany = (value) => {
      const v = String(value || "").trim();
      if (!v) return true;
      if (/^unknown company$/i.test(v)) return true;
      // Aggregator-hostname names we wrote as URL-only fallbacks.
      const aggr = /^(linkedin|indeed|glassdoor|ziprecruiter|monster|simplyhired|careerbuilder|wellfound|google|angel|dice|builtin)$/i;
      return aggr.test(v);
    };

    const inferredTitle = String(enr.inferredTitle || "").trim();
    const inferredCompany = String(enr.inferredCompany || "").trim();
    const inferredLocation = String(enr.inferredLocation || "").trim();

    const updates = [];
    if (inferredTitle && isPlaceholderTitle(job.title)) {
      updates.push({ range: `Pipeline!B${sheetRow}`, value: inferredTitle });
      job.title = inferredTitle;
    }
    if (inferredCompany && isPlaceholderCompany(job.company)) {
      updates.push({ range: `Pipeline!C${sheetRow}`, value: inferredCompany });
      job.company = inferredCompany;
    }
    if (inferredLocation && !String(job.location || "").trim()) {
      updates.push({ range: `Pipeline!D${sheetRow}`, value: inferredLocation });
      job.location = inferredLocation;
    }
    // Replace the aggregator-hostname favicon the worker wrote at ingest
    // time (e.g. LinkedIn/Indeed favicon) with a company-specific logo
    // resolved via Clearbit autocomplete. Fires in parallel with the
    // other updates so the sheet write batches together.
    //
    // Gating: we update the logo when EITHER the company name was just
    // promoted (definite stale-logo signal — ignore the placeholder
    // regex entirely), OR the existing Logo URL cell still matches a
    // known aggregator-favicon pattern. User-edited logos (custom hosts
    // outside the aggregator regex) stay untouched when the company
    // didn't change.
    const companyPromotedThisRun = updates.some(
      (u) => u.range === `Pipeline!C${sheetRow}`,
    );
    const shouldUpdateLogo =
      inferredCompany &&
      (companyPromotedThisRun || isPlaceholderLogoUrl(job.logoUrl));
    console.info("[JobBored] auto-enrich logo check:", {
      inferredCompany,
      existingLogoUrl: job.logoUrl,
      companyPromotedThisRun,
      isPlaceholder: isPlaceholderLogoUrl(job.logoUrl),
      shouldUpdateLogo,
    });
    if (shouldUpdateLogo) {
      const newLogoUrl = await resolveCompanyLogoUrl(inferredCompany);
      console.info("[JobBored] auto-enrich resolved logo:", newLogoUrl);
      if (newLogoUrl) {
        updates.push({ range: `Pipeline!T${sheetRow}`, value: newLogoUrl });
        job.logoUrl = newLogoUrl;
        // In-memory bump so the next renderPipeline reflects the real
        // logo even before the sheet round-trip completes. Without
        // this, the card can stay as the LinkedIn "in" icon for ~2s
        // while the sheet write + re-read propagates.
        if (typeof renderPipeline === "function") renderPipeline();
      }
    }

    if (updates.length === 0) {
      // Nothing to promote — drawer enrichment did run and is cached, so
      // drawer open will be instant next time. Just re-render so the card
      // picks up any _postingEnrichment-derived display tweaks.
      if (typeof renderPipeline === "function") renderPipeline();
      return;
    }

    const ok = await updateMultipleCells(updates).catch(() => false);
    if (!ok) {
      // Non-fatal — the row is already in the sheet, just with placeholders.
      // Re-render anyway so the in-memory title/company update is visible
      // locally, even if it doesn't persist to Sheets.
      if (typeof renderPipeline === "function") renderPipeline();
      return;
    }

    // Sheet patched. Refresh again so the pipeline reflects the real values.
    if (typeof loadAllData === "function") {
      await loadAllData().catch(() => {});
    }
    if (typeof showToast === "function") {
      showToast("Details filled in: " + inferredTitle, "success");
    }
  } catch (err) {
    console.warn("[JobBored] autoEnrichIngestedRow:", err);
  }
}

function handleIngestUrlResponse(data, url) {
  if (!data || typeof data !== "object") {
    showToast("Unexpected response from worker", "error", true);
    return;
  }
  if (data.ok === true) {
    const title =
      (data.lead && (data.lead.title || data.lead.role)) || "job";
    const strategy = (data && data.strategy) || "";
    showToast("Added: " + title, "success");
    closeIngestManualModal();
    // For url_only rows we only have URL-derived placeholder title/company.
    // Fire the drawer enrichment pipeline now (scrape + LLM) and promote the
    // sheet row's B/C/D cells with the LLM-inferred real values. Other
    // strategies (ats_api / jsonld / cheerio_dom / manual_fill) already have
    // clean fields — just refresh.
    if (strategy === "url_only") {
      void autoEnrichIngestedRow(url, data.lead);
    } else {
      refreshPipelineAfterIngest();
    }
    return;
  }
  if (data.ok === false) {
    switch (data.reason) {
      case "blocked_aggregator":
      case "scrape_failed": {
        // Defensive branch: the backend now auto-lands a url-only row for
        // these cases (and returns ok:true, strategy:"url_only"). If an
        // older worker is still returning these reasons, fall back to the
        // explicit manual-fill modal so users aren't blocked on the fix
        // deploy. Newer workers never hit this path.
        const label =
          data.reason === "blocked_aggregator"
            ? aggregatorLabelForHost(data.host) + " blocks scrapers — "
            : "";
        const hint =
          (typeof data.hint === "string" && data.hint.trim()) ||
          (typeof data.message === "string" && data.message.trim()) ||
          "We couldn't auto-scrape this URL.";
        openIngestManualModal({
          url,
          message:
            label +
            hint +
            " (This shouldn't normally happen — check your worker version if it keeps showing up.)",
        });
        return;
      }
      case "duplicate": {
        const row = data.rowNumber;
        const suffix = Number.isFinite(row) ? " (row " + row + ")" : "";
        showToast("Already in Pipeline" + suffix, "info");
        closeIngestManualModal();
        return;
      }
      case "invalid_url":
      case "private_network": {
        showToast(
          data.message || "Could not ingest URL: " + data.reason,
          "error",
        );
        return;
      }
      default: {
        showToast(
          data.message || "Unexpected response from worker",
          "error",
          true,
        );
        return;
      }
    }
  }
  showToast("Unexpected response from worker", "error", true);
}

function setIngestSubmitLoading(button, loading) {
  if (!button) return;
  if (loading) {
    button.disabled = true;
    button.dataset.originalLabel = button.textContent || "";
    button.textContent = "Adding…";
  } else {
    button.disabled = false;
    if (button.dataset.originalLabel) {
      button.textContent = button.dataset.originalLabel;
      delete button.dataset.originalLabel;
    }
  }
}

async function submitIngestFromToolbar() {
  const input = document.getElementById("ingestUrlInput");
  const button = document.getElementById("ingestUrlSubmit");
  if (!input) return;
  const url = String(input.value || "").trim();
  if (!url) {
    showToast("Paste a job URL first", "error");
    input.focus();
    return;
  }
  if (!isParseableUrl(url)) {
    showToast("That doesn't look like a valid http(s) URL", "error");
    input.focus();
    if (typeof input.select === "function") input.select();
    return;
  }
  setIngestSubmitLoading(button, true);
  try {
    const data = await handleIngestUrlSubmit(url);
    handleIngestUrlResponse(data, url);
    if (data && data.ok === true) {
      input.value = "";
    }
  } catch (err) {
    if (err && err.message === "missing_discovery_webhook") {
      // toast + settings already triggered inside handleIngestUrlSubmit
    } else if (err && err.message === "timeout") {
      showToast("Ingest timed out — try again", "error");
    } else if (err && err.message === "invalid_endpoint") {
      // toast already shown
    } else {
      console.error("[JobBored] ingest-url submit failed:", err);
      showToast("Network error — could not reach worker", "error");
    }
  } finally {
    setIngestSubmitLoading(button, false);
  }
}

async function submitIngestFromManualModal() {
  const els = getIngestManualModalEls();
  if (!els.form) return;
  const url = (els.urlField && els.urlField.value.trim()) || "";
  const title = (els.title && els.title.value.trim()) || "";
  const company = (els.company && els.company.value.trim()) || "";
  const location = (els.location && els.location.value.trim()) || "";
  const description =
    (els.description && els.description.value.trim()) || "";
  const fitScoreRaw = els.fit ? Number(els.fit.value) : 5;
  const fitScore = Number.isFinite(fitScoreRaw) ? fitScoreRaw : 5;

  setIngestManualModalError("");
  if (!title) {
    setIngestManualModalError("Title is required.");
    if (els.title) els.title.focus();
    return;
  }
  if (!company) {
    setIngestManualModalError("Company is required.");
    if (els.company) els.company.focus();
    return;
  }
  if (!url || !isParseableUrl(url)) {
    setIngestManualModalError("URL is missing or invalid.");
    return;
  }

  setIngestSubmitLoading(els.submit, true);
  try {
    const data = await handleIngestUrlSubmit(url, {
      title,
      company,
      location,
      description,
      fitScore,
    });
    if (data && data.ok === true) {
      handleIngestUrlResponse(data, url);
      const toolbarInput = document.getElementById("ingestUrlInput");
      if (toolbarInput) toolbarInput.value = "";
      return;
    }
    if (data && data.ok === false && data.reason === "duplicate") {
      handleIngestUrlResponse(data, url);
      return;
    }
    setIngestManualModalError(
      (data && data.message) ||
        "Worker rejected the manual entry. Check the fields and try again.",
    );
  } catch (err) {
    if (err && err.message === "missing_discovery_webhook") {
      setIngestManualModalError(
        "Configure your discovery webhook URL in Settings first.",
      );
    } else if (err && err.message === "timeout") {
      setIngestManualModalError("Request timed out. Try again.");
    } else {
      console.error("[JobBored] manual-fill submit failed:", err);
      setIngestManualModalError("Network error — could not reach worker.");
    }
  } finally {
    setIngestSubmitLoading(els.submit, false);
  }
}

function initIngestUrlFlow() {
  const form = document.getElementById("ingestUrlForm");
  if (form) {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      submitIngestFromToolbar();
    });
  }

  const els = getIngestManualModalEls();
  if (els.form) {
    els.form.addEventListener("submit", (e) => {
      e.preventDefault();
      submitIngestFromManualModal();
    });
  }
  if (els.fit && els.fitLabel) {
    els.fit.addEventListener("input", () => {
      els.fitLabel.textContent = String(els.fit.value);
    });
  }
  if (els.cancel) {
    els.cancel.addEventListener("click", () => closeIngestManualModal());
  }
  if (els.close) {
    els.close.addEventListener("click", () => closeIngestManualModal());
  }
  // Explicit "Add manually" escape hatch in the hero card footnote. Lets
  // users skip URL paste entirely (e.g. posting only exists on a site we
  // can't link to, or they want to track a job they heard about verbally).
  const manualOpenBtn = document.getElementById("ingestManualModalOpenBtn");
  if (manualOpenBtn) {
    manualOpenBtn.addEventListener("click", () => {
      openIngestManualModal({
        url: "",
        message:
          "No URL handy? Fill in the basics and we'll track it in your Pipeline.",
      });
    });
  }
  if (els.modal) {
    els.modal.addEventListener("click", (e) => {
      if (e.target === els.modal) closeIngestManualModal();
    });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && els.modal.style.display === "flex") {
        closeIngestManualModal();
      }
    });
  }
}

document.addEventListener("DOMContentLoaded", () => {
  initCommandCenterSettings();
  initSetupAndSheetAccessActions();
  initScraperSetupGuide();
  initDiscoverySetupGuide();
  initPipelineEmptyAndBriefActions();
  initIngestUrlFlow();
  init();
});
